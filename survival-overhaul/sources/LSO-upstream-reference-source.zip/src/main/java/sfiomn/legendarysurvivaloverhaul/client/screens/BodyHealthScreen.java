package sfiomn.legendarysurvivaloverhaul.client.screens;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyDamageUtil;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyPartEnum;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.bodydamage.BodyDamageCapability;
import sfiomn.legendarysurvivaloverhaul.network.packets.BodyPartHealingTimeMessage;
import sfiomn.legendarysurvivaloverhaul.registry.KeyMappingRegistry;
import sfiomn.legendarysurvivaloverhaul.util.CapabilityUtil;
import sfiomn.legendarysurvivaloverhaul.util.MathUtil;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class BodyHealthScreen extends Screen {
    public static final ResourceLocation BODY_HEALTH_SCREEN = new ResourceLocation(LegendarySurvivalOverhaul.MOD_ID, "textures/gui/body_health_screen.png");
    public static final int HEALTH_SCREEN_WIDTH = 176;
    public static final int HEALTH_SCREEN_HEIGHT = 183;
    public static final int HEALTH_BAR_WIDTH = 30;
    public static final int HEALTH_BAR_HEIGHT = 5;
    public static final int TEX_HEALTH_BAR_X = 176;
    public static final int TEX_HEALTH_BAR_Y = 0;

    private final Map<BodyPartEnum, BodyPartButton> bodyPartButtons = new HashMap<>();

    private final Map<BodyPartEnum, Integer> flashCounters = new HashMap<>();
    private final Map<BodyPartEnum, Float> bodyPartHealth = new HashMap<>();
    private int leftPos;
    private int topPos;

    private final Player player;
    private final String itemRegistryName;
    private final InteractionHand hand;
    private int healingCharges;
    private final float healingValue;
    private final int healingTime;
    private boolean consumeItem;
    private boolean applyEffect;

    public BodyHealthScreen(Player player, ResourceLocation itemRegistryName, InteractionHand hand, boolean alreadyConsumed, int healingCharges, float healingValue, int healingTime) {
        super(Component.translatable("screen." + LegendarySurvivalOverhaul.MOD_ID + ".body_health_screen"));

        this.player = player;
        this.itemRegistryName = itemRegistryName != null ? itemRegistryName.toString() : "";
        this.hand = hand;
        this.healingCharges = healingCharges;
        this.healingValue = healingValue;
        this.healingTime = healingTime;
        this.consumeItem = !alreadyConsumed;
        this.applyEffect = true;
    }

    @Override
    protected void init() {
        super.init();
        assert this.minecraft != null;

        this.leftPos = (this.width - HEALTH_SCREEN_WIDTH) / 2;
        this.topPos = (this.height - HEALTH_SCREEN_HEIGHT) / 2;

        addWidget(new BodyPartButton(BodyPartEnum.HEAD, this.leftPos + 68, this.topPos + 46, 38, 34, button -> sendBodyPartHeal(BodyPartEnum.HEAD)));
        addWidget(new BodyPartButton(BodyPartEnum.RIGHT_ARM, this.leftPos + 101, this.topPos + 79, 50, 38, button -> sendBodyPartHeal(BodyPartEnum.RIGHT_ARM)));
        addWidget(new BodyPartButton(BodyPartEnum.LEFT_ARM, this.leftPos + 23, this.topPos + 79, 50, 38, button -> sendBodyPartHeal(BodyPartEnum.LEFT_ARM)));
        addWidget(new BodyPartButton(BodyPartEnum.CHEST, this.leftPos + 73, this.topPos + 79, 28, 38, button -> sendBodyPartHeal(BodyPartEnum.CHEST)));
        addWidget(new BodyPartButton(BodyPartEnum.RIGHT_LEG, this.leftPos + 87, this.topPos + 117, 49, 36, button -> sendBodyPartHeal(BodyPartEnum.RIGHT_LEG)));
        addWidget(new BodyPartButton(BodyPartEnum.RIGHT_FOOT, this.leftPos + 87, this.topPos + 153, 49, 10, button -> sendBodyPartHeal(BodyPartEnum.RIGHT_FOOT)));
        addWidget(new BodyPartButton(BodyPartEnum.LEFT_LEG, this.leftPos + 38, this.topPos + 117, 49, 36, button -> sendBodyPartHeal(BodyPartEnum.LEFT_LEG)));
        addWidget(new BodyPartButton(BodyPartEnum.LEFT_FOOT, this.leftPos + 38, this.topPos + 153, 49, 10, button -> sendBodyPartHeal(BodyPartEnum.LEFT_FOOT)));

        bodyPartButtons.clear();
        for (GuiEventListener button : this.children()) {
            if (button instanceof BodyPartButton bodyPartButton) {
                if (this.hand == null) {
                    bodyPartButton.active = false;
                }
                bodyPartButtons.put(bodyPartButton.bodyPart, bodyPartButton);
            }
        }

        flashCounters.clear();

        BodyDamageCapability cap = CapabilityUtil.getBodyDamageCapability(player);
        bodyPartHealth.clear();
        for (BodyPartEnum bodyPart: BodyPartEnum.values()) {
            bodyPartHealth.put(bodyPart, cap.getBodyPartDamage(bodyPart));
        }
    }

    public void sendBodyPartHeal(BodyPartEnum bodyPart) {
        if (healingCharges > 0) {
            BodyPartHealingTimeMessage.sendToServer(bodyPart, this.itemRegistryName, this.hand, this.consumeItem, this.applyEffect);
            BodyDamageUtil.applyHealingTimeBodyPart(player, bodyPart, this.healingValue, this.healingTime);
            if (this.consumeItem)
                this.consumeItem = false;
            if (this.applyEffect)
                this.applyEffect = false;
            this.healingCharges--;
        }
    }

    @Override
    public void tick() {
        Iterator<Map.Entry<BodyPartEnum, Integer>> iter = flashCounters.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<BodyPartEnum, Integer> flashBodyPart = iter.next();
            if (flashBodyPart.getValue() > 0)
                flashBodyPart.setValue(flashBodyPart.getValue() - 1);
            else
                iter.remove();
        }

        BodyDamageCapability cap = CapabilityUtil.getBodyDamageCapability(player);
        for (BodyPartEnum bodyPart: BodyPartEnum.values()) {
            if (bodyPartHealth.get(bodyPart) != cap.getBodyPartDamage(bodyPart)) {
                flashCounters.put(bodyPart, 4);
                bodyPartHealth.put(bodyPart, cap.getBodyPartDamage(bodyPart));
            }
        }
        super.tick();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.minecraft != null && this.minecraft.player != null) {
            if (this.minecraft.options.keyInventory.matches(keyCode, scanCode)) {
                this.minecraft.setScreen(new InventoryScreen(this.minecraft.player));
                return true;
            }

            if (KeyMappingRegistry.showBodyHealth.matches(keyCode, scanCode)) {
                this.onClose();
                return true;
            }
        }

        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }

    @Override
    public void render(@NotNull GuiGraphics gui, int mouseX, int mouseY, float partialTicks) {
        checkAutoCloseWhenHealing();

        this.renderBackground(gui);

        for (BodyPartEnum bodyPart: BodyPartEnum.values())
            renderBodyPartHealth(gui, bodyPart, mouseX, mouseY, partialTicks);

        super.render(gui, mouseX, mouseY, partialTicks);
    }

    public void checkAutoCloseWhenHealing() {
        if (hand != null && healingCharges == 0) {
            assert this.minecraft != null;
            this.minecraft.setScreen(null);
        }
    }

    @Override
    public void renderBackground(@NotNull GuiGraphics gui) {
        if (minecraft == null) {
            return;
        }
        super.renderBackground(gui);

        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1, 1, 1, 1);

        gui.blit(BODY_HEALTH_SCREEN, leftPos, topPos, 0, 0, HEALTH_SCREEN_WIDTH, HEALTH_SCREEN_HEIGHT);
    }

    private void renderBodyPartHealth(GuiGraphics gui, BodyPartEnum bodyPart, int mouseX, int mouseY, float partialTicks) {
        if (minecraft == null) {
            return;
        }

        float healthRatio = BodyDamageUtil.getHealthRatio(this.player, bodyPart);
        float totalRemainingHealing = BodyDamageUtil.getTotalRemainingHealing(this.player, bodyPart);
        float maxHealth = BodyDamageUtil.getMaxHealth(this.player, bodyPart);

        BodyPartButton bodyPartButton = this.bodyPartButtons.get(bodyPart);

        // Update button health ratio
        bodyPartButton.setHealthRatio(healthRatio);

        // Define button inactive if full health, or pressed, or no healing items used
        if (healthRatio >= 1 || bodyPartButton.isPressed || this.hand == null) {
            if (bodyPartButton.active) {
                bodyPartButton.active = false;
            }
            if (totalRemainingHealing > 0.0f) {
                bodyPartButton.isPressed = false;
            }
        } else if (!bodyPartButton.active) {
            bodyPartButton.active = true;
        }

        bodyPartButton.render(gui, mouseX, mouseY, partialTicks);

        if (bodyPartButton.isMouseOver(mouseX, mouseY) && this.hand != null) {
            totalRemainingHealing += this.healingValue;
        }

        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1, 1, 1, 1);
        drawHealthBar(gui, bodyPart, healthRatio,  MathUtil.round(totalRemainingHealing / maxHealth, 2));
    }

    private void drawHealthBar(GuiGraphics gui, BodyPartEnum bodyPart, float healthRatio, float totalRemainingHealingRatio) {
        HealthBarIcon healthBarIcon = HealthBarIcon.get(bodyPart);
        HealthBarCondition healthBarCondition = HealthBarCondition.get(healthRatio);
        if (healthBarIcon == null)
            return;

        boolean shouldFlash = flashCounters.containsKey(bodyPart);

        // Draw empty health bar
        gui.blit(BODY_HEALTH_SCREEN, this.leftPos + healthBarIcon.x, this.topPos + healthBarIcon.y,
                TEX_HEALTH_BAR_X + HEALTH_BAR_WIDTH * HealthBarCondition.DEAD.iconIndexX,
                TEX_HEALTH_BAR_Y + HEALTH_BAR_HEIGHT * HealthBarCondition.DEAD.iconIndexY,
                HEALTH_BAR_WIDTH, HEALTH_BAR_HEIGHT);

        int healthBarWidth = (int) Math.ceil(HEALTH_BAR_WIDTH * healthRatio);
        int healthBarPreviewWidth = (int) Math.min(Math.ceil(HEALTH_BAR_WIDTH * totalRemainingHealingRatio), HEALTH_BAR_WIDTH - healthBarWidth);

        // Draw current health bar
        if (healthBarWidth > 0)
            gui.blit(BODY_HEALTH_SCREEN, this.leftPos + healthBarIcon.x, this.topPos + healthBarIcon.y,
                    TEX_HEALTH_BAR_X + HEALTH_BAR_WIDTH * healthBarCondition.iconIndexX,
                    TEX_HEALTH_BAR_Y + HEALTH_BAR_HEIGHT * healthBarCondition.iconIndexY,
                    healthBarWidth, HEALTH_BAR_HEIGHT);

        // Draw healing bar
        if (healthBarPreviewWidth > 0)
            gui.blit(BODY_HEALTH_SCREEN, this.leftPos + healthBarIcon.x + healthBarWidth, this.topPos + healthBarIcon.y,
                    TEX_HEALTH_BAR_X + healthBarWidth + HEALTH_BAR_WIDTH * healthBarCondition.getPreviewVariant().iconIndexX,
                    TEX_HEALTH_BAR_Y + HEALTH_BAR_HEIGHT * healthBarCondition.getPreviewVariant().iconIndexY,
                    healthBarPreviewWidth, HEALTH_BAR_HEIGHT);

        if (shouldFlash)
            gui.blit(BODY_HEALTH_SCREEN, this.leftPos + healthBarIcon.x, this.topPos + healthBarIcon.y,
                    TEX_HEALTH_BAR_X + HEALTH_BAR_WIDTH * HealthBarCondition.FLASH.iconIndexX,
                    TEX_HEALTH_BAR_Y + HEALTH_BAR_HEIGHT * HealthBarCondition.FLASH.iconIndexY,
                    HEALTH_BAR_WIDTH, HEALTH_BAR_HEIGHT);
    }

    private enum HealthBarIcon {
        HEAD(72, 46),
        RIGHT_ARM(118, 80),
        LEFT_ARM(27, 80),
        CHEST(72, 92),
        RIGHT_LEG(106, 134),
        LEFT_LEG(39, 134),
        RIGHT_FOOT(106, 156),
        LEFT_FOOT(39, 156);

        public final int x;
        public final int y;

        HealthBarIcon(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public static HealthBarIcon get(BodyPartEnum bodyPart) {
            return switch (bodyPart) {
                case HEAD -> HEAD;
                case RIGHT_ARM -> RIGHT_ARM;
                case LEFT_ARM -> LEFT_ARM;
                case CHEST -> CHEST;
                case RIGHT_LEG -> RIGHT_LEG;
                case RIGHT_FOOT -> RIGHT_FOOT;
                case LEFT_LEG -> LEFT_LEG;
                case LEFT_FOOT -> LEFT_FOOT;
                default -> null;
            };
        }
    }

    private enum HealthBarCondition {
        HEALTHY(0, 0),
        WOUNDED(0, 1),
        HEAVILY_WOUNDED(0, 2),
        DEAD(0, 3),
        HEALTHY_PREVIEW(0, 4),
        WOUNDED_PREVIEW(0, 5),
        HEAVILY_WOUNDED_PREVIEW(0, 6),
        DEAD_PREVIEW(0, 7),
        FLASH(1, 8);

        public final int iconIndexX;
        public final int iconIndexY;

        HealthBarCondition(int iconIndexX, int iconIndexY)
        {
            this.iconIndexX = iconIndexX;
            this.iconIndexY = iconIndexY;
        }

        public static HealthBarCondition get(float healthRatio) {
            if (healthRatio >= 0.66f) {
                return HEALTHY;
            } else if (healthRatio >= 0.33f) {
                return WOUNDED;
            } else if (healthRatio > 0) {
                return HEAVILY_WOUNDED;
            } else {
                return DEAD;
            }
        }

        public HealthBarCondition getPreviewVariant() {
            return switch (this) {
                case HEALTHY -> HEALTHY_PREVIEW;
                case WOUNDED -> WOUNDED_PREVIEW;
                case HEAVILY_WOUNDED -> HEAVILY_WOUNDED_PREVIEW;
                case DEAD -> DEAD_PREVIEW;
                default -> this;
            };
        }
    }
}
