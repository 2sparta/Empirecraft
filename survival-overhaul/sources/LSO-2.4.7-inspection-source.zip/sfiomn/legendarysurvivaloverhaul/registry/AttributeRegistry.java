/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.entity.ai.attributes.RangedAttribute
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package sfiomn.legendarysurvivaloverhaul.registry;

import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;

public class AttributeRegistry {
    public static DeferredRegister<Attribute> ATTRIBUTES = DeferredRegister.create((IForgeRegistry)ForgeRegistries.ATTRIBUTES, (String)"legendarysurvivaloverhaul");
    public static final RegistryObject<Attribute> HEATING_TEMPERATURE = ATTRIBUTES.register("heating_temperature", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.heating_temperature", 0.0, -10000.0, 10000.0).m_22084_(true));
    public static final RegistryObject<Attribute> COOLING_TEMPERATURE = ATTRIBUTES.register("cooling_temperature", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.cooling_temperature", 0.0, -10000.0, 10000.0).m_22084_(true));
    public static final RegistryObject<Attribute> HEAT_RESISTANCE = ATTRIBUTES.register("heat_resistance", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.heat_resistance", 0.0, 0.0, 10000.0).m_22084_(true));
    public static final RegistryObject<Attribute> COLD_RESISTANCE = ATTRIBUTES.register("cold_resistance", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.cold_resistance", 0.0, 0.0, 10000.0).m_22084_(true));
    public static final RegistryObject<Attribute> THERMAL_RESISTANCE = ATTRIBUTES.register("thermal_resistance", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.thermal_resistance", 0.0, 0.0, 10000.0).m_22084_(true));
    public static final RegistryObject<Attribute> BODY_RESISTANCE = ATTRIBUTES.register("body_resistance", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.body_resistance", 0.0, -200.0, 100.0).m_22084_(true));
    public static final RegistryObject<Attribute> HEAD_RESISTANCE = ATTRIBUTES.register("head_resistance", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.head_resistance", 0.0, -200.0, 100.0).m_22084_(true));
    public static final RegistryObject<Attribute> CHEST_RESISTANCE = ATTRIBUTES.register("chest_resistance", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.chest_resistance", 0.0, -200.0, 100.0).m_22084_(true));
    public static final RegistryObject<Attribute> RIGHT_ARM_RESISTANCE = ATTRIBUTES.register("right_arm_resistance", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.right_arm_resistance", 0.0, -200.0, 100.0).m_22084_(true));
    public static final RegistryObject<Attribute> LEFT_ARM_RESISTANCE = ATTRIBUTES.register("left_arm_resistance", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.left_arm_resistance", 0.0, -200.0, 100.0).m_22084_(true));
    public static final RegistryObject<Attribute> LEGS_RESISTANCE = ATTRIBUTES.register("legs_resistance", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.legs_resistance", 0.0, -200.0, 100.0).m_22084_(true));
    public static final RegistryObject<Attribute> FEET_RESISTANCE = ATTRIBUTES.register("feet_resistance", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.feet_resistance", 0.0, -200.0, 100.0).m_22084_(true));
    public static final RegistryObject<Attribute> BROKEN_HEART = ATTRIBUTES.register("broken_heart", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.broken_heart", 0.0, 0.0, 10000.0).m_22084_(true));
    public static final RegistryObject<Attribute> PERMANENT_HEART = ATTRIBUTES.register("permanent_heart", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.permanent_heart", 1.0, 1.0, 10000.0).m_22084_(true));
    public static final RegistryObject<Attribute> BROKEN_HEART_RESILIENCE = ATTRIBUTES.register("broken_heart_resilience", () -> new RangedAttribute("attribute.legendarysurvivaloverhaul.broken_heart_resilience", 1.0, 0.0, 10000.0).m_22084_(true));

    public static void register(IEventBus eventBus) {
        ATTRIBUTES.register(eventBus);
    }
}

