/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryBuilder
 *  net.minecraftforge.registries.RegistryObject
 */
package sfiomn.legendarysurvivaloverhaul.registry;

import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryBuilder;
import net.minecraftforge.registries.RegistryObject;
import sfiomn.legendarysurvivaloverhaul.api.temperature.AttributeModifierBase;
import sfiomn.legendarysurvivaloverhaul.api.temperature.DynamicModifierBase;
import sfiomn.legendarysurvivaloverhaul.api.temperature.ModifierBase;
import sfiomn.legendarysurvivaloverhaul.common.integration.eclipticseasons.EclipticSeasonsModifier;
import sfiomn.legendarysurvivaloverhaul.common.integration.origins.OriginsDynamicModifier;
import sfiomn.legendarysurvivaloverhaul.common.integration.origins.OriginsModifier;
import sfiomn.legendarysurvivaloverhaul.common.integration.sereneseasons.SereneSeasonsModifier;
import sfiomn.legendarysurvivaloverhaul.common.integration.terrafirmacraft.TerraFirmaCraftHeatItemModifier;
import sfiomn.legendarysurvivaloverhaul.common.integration.terrafirmacraft.TerraFirmaCraftModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.AltitudeModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.AttributeModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.BiomeModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.BlockModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.DimensionModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.FreezeModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.MountModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.OnFireModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.PlayerHuddlingModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.SprintModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.TimeModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.WeatherModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.WetModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.attribute.CoatAttributeModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.attribute.ItemAttributeModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.dynamic.MountDynamicModifier;
import sfiomn.legendarysurvivaloverhaul.common.temperature.dynamic.TemperatureResistanceModifier;

public class TemperatureModifierRegistry {
    public static final ResourceLocation MODIFIERS_RESOURCE = new ResourceLocation("legendarysurvivaloverhaul", "temperature_modifiers");
    public static final ResourceLocation DYNAMIC_MODIFIERS_RESOURCE = new ResourceLocation("legendarysurvivaloverhaul", "dynamic_temperature_modifiers");
    public static final ResourceLocation ITEM_ATTRIBUTE_MODIFIERS_RESOURCE = new ResourceLocation("legendarysurvivaloverhaul", "item_attribute_temperature_modifiers");
    public static final DeferredRegister<ModifierBase> MODIFIERS = DeferredRegister.create((ResourceLocation)MODIFIERS_RESOURCE, (String)"legendarysurvivaloverhaul");
    public static final DeferredRegister<DynamicModifierBase> DYNAMIC_MODIFIERS = DeferredRegister.create((ResourceLocation)DYNAMIC_MODIFIERS_RESOURCE, (String)"legendarysurvivaloverhaul");
    public static final DeferredRegister<AttributeModifierBase> ITEM_ATTRIBUTE_MODIFIERS = DeferredRegister.create((ResourceLocation)ITEM_ATTRIBUTE_MODIFIERS_RESOURCE, (String)"legendarysurvivaloverhaul");
    public static final Supplier<IForgeRegistry<ModifierBase>> MODIFIERS_REGISTRY = MODIFIERS.makeRegistry(RegistryBuilder::new);
    public static final Supplier<IForgeRegistry<DynamicModifierBase>> DYNAMIC_MODIFIERS_REGISTRY = DYNAMIC_MODIFIERS.makeRegistry(RegistryBuilder::new);
    public static final Supplier<IForgeRegistry<AttributeModifierBase>> ITEM_ATTRIBUTE_MODIFIERS_REGISTRY = ITEM_ATTRIBUTE_MODIFIERS.makeRegistry(RegistryBuilder::new);
    public static final RegistryObject<ModifierBase> ALTITUDE = MODIFIERS.register("altitude", AltitudeModifier::new);
    public static final RegistryObject<ModifierBase> ATTRIBUTE = MODIFIERS.register("attribute", AttributeModifier::new);
    public static final RegistryObject<ModifierBase> BIOME = MODIFIERS.register("biome", BiomeModifier::new);
    public static final RegistryObject<ModifierBase> BLOCKS = MODIFIERS.register("blocks", BlockModifier::new);
    public static final RegistryObject<ModifierBase> DIMENSION = MODIFIERS.register("dimension", DimensionModifier::new);
    public static final RegistryObject<ModifierBase> MOUNT = MODIFIERS.register("mount", MountModifier::new);
    public static final RegistryObject<ModifierBase> FREEZE = MODIFIERS.register("freeze", FreezeModifier::new);
    public static final RegistryObject<ModifierBase> ON_FIRE = MODIFIERS.register("on_fire", OnFireModifier::new);
    public static final RegistryObject<ModifierBase> PLAYER_HUDDLING = MODIFIERS.register("player_huddling", PlayerHuddlingModifier::new);
    public static final RegistryObject<ModifierBase> SPRINT = MODIFIERS.register("sprint", SprintModifier::new);
    public static final RegistryObject<ModifierBase> TIME = MODIFIERS.register("time", TimeModifier::new);
    public static final RegistryObject<ModifierBase> WEATHER = MODIFIERS.register("weather", WeatherModifier::new);
    public static final RegistryObject<ModifierBase> WETNESS = MODIFIERS.register("wetness", WetModifier::new);
    public static final RegistryObject<AttributeModifierBase> ITEM_ATTRIBUTE = ITEM_ATTRIBUTE_MODIFIERS.register("item_attribute", ItemAttributeModifier::new);
    public static final RegistryObject<AttributeModifierBase> COAT_ATTRIBUTE = ITEM_ATTRIBUTE_MODIFIERS.register("coat_attribute", CoatAttributeModifier::new);
    public static final RegistryObject<DynamicModifierBase> TEMPERATURE_RESISTANCE = DYNAMIC_MODIFIERS.register("temperature_resistance", TemperatureResistanceModifier::new);
    public static final RegistryObject<DynamicModifierBase> MOUNT_DYNAMIC = DYNAMIC_MODIFIERS.register("mount_dynamic", MountDynamicModifier::new);
    public static final RegistryObject<ModifierBase> SERENE_SEASONS = MODIFIERS.register("integration/serene_seasons", SereneSeasonsModifier::new);
    public static final RegistryObject<ModifierBase> ECLIPTIC_SEASONS = MODIFIERS.register("integration/ecliptic_seasons", EclipticSeasonsModifier::new);
    public static final RegistryObject<ModifierBase> WORLD_TEMPERATURE_TERRA_FIRMA_CRAFT = MODIFIERS.register("integration/world_temp_tfc", TerraFirmaCraftModifier::new);
    public static final RegistryObject<AttributeModifierBase> ITEM_TEMPERATURE_TERRA_FIRMA_CRAFT = ITEM_ATTRIBUTE_MODIFIERS.register("integration/item_temp_tfc", TerraFirmaCraftHeatItemModifier::new);
    public static final RegistryObject<ModifierBase> ORIGINS = MODIFIERS.register("integration/origins", OriginsModifier::new);
    public static final RegistryObject<DynamicModifierBase> ORIGINS_RESISTANCE = DYNAMIC_MODIFIERS.register("integration/origins_resistance", OriginsDynamicModifier::new);

    public static void register(IEventBus eventBus) {
        MODIFIERS.register(eventBus);
        DYNAMIC_MODIFIERS.register(eventBus);
        ITEM_ATTRIBUTE_MODIFIERS.register(eventBus);
    }
}

