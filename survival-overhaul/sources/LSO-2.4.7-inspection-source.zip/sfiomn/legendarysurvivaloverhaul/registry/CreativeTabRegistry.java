/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.network.chat.Component
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.world.item.CreativeModeTab
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.block.Block
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.RegistryObject
 */
package sfiomn.legendarysurvivaloverhaul.registry;

import java.util.List;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import sfiomn.legendarysurvivaloverhaul.api.thirst.HydrationEnum;
import sfiomn.legendarysurvivaloverhaul.api.thirst.ThirstUtil;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;

public class CreativeTabRegistry {
    public static final DeferredRegister<CreativeModeTab> ITEM_GROUPS = DeferredRegister.create((ResourceKey)Registries.f_279569_, (String)"legendarysurvivaloverhaul");
    public static final RegistryObject<CreativeModeTab> LEGENDARY_CREATURES_TAB = ITEM_GROUPS.register("legendary_creatures", () -> CreativeModeTab.builder().m_257737_(() -> ((Item)ItemRegistry.THERMOMETER.get()).m_7968_()).m_257501_((parameters, list) -> {
        ItemStack fullCanteen = ((Item)ItemRegistry.CANTEEN.get()).m_7968_();
        ItemStack fullLargeCanteen = ((Item)ItemRegistry.LARGE_CANTEEN.get()).m_7968_();
        ThirstUtil.setCapacityTag(fullCanteen, Config.Baked.canteenCapacity);
        ThirstUtil.setHydrationEnumTag(fullCanteen, HydrationEnum.NORMAL);
        ThirstUtil.setCapacityTag(fullLargeCanteen, Config.Baked.largeCanteenCapacity);
        ThirstUtil.setHydrationEnumTag(fullLargeCanteen, HydrationEnum.NORMAL);
        list.m_246601_(List.of(((Item)ItemRegistry.APPLE_JUICE.get()).m_7968_(), ((Item)ItemRegistry.BEETROOT_JUICE.get()).m_7968_(), ((Item)ItemRegistry.CACTUS_JUICE.get()).m_7968_(), ((Item)ItemRegistry.CARROT_JUICE.get()).m_7968_(), ((Item)ItemRegistry.CHORUS_FRUIT_JUICE.get()).m_7968_(), ((Item)ItemRegistry.GLISTERING_MELON_JUICE.get()).m_7968_(), ((Item)ItemRegistry.GOLDEN_APPLE_JUICE.get()).m_7968_(), ((Item)ItemRegistry.GOLDEN_CARROT_JUICE.get()).m_7968_(), ((Item)ItemRegistry.MELON_JUICE.get()).m_7968_(), ((Item)ItemRegistry.PUMPKIN_JUICE.get()).m_7968_(), ((Item)ItemRegistry.SWEET_BERRIES_JUICE.get()).m_7968_(), ((Item)ItemRegistry.GLOW_BERRIES_JUICE.get()).m_7968_(), ((Item)ItemRegistry.WATER_PURIFIER.get()).m_7968_(), ((Item)ItemRegistry.CANTEEN.get()).m_7968_(), ((Item)ItemRegistry.LARGE_CANTEEN.get()).m_7968_(), fullCanteen, fullLargeCanteen, ((Item)ItemRegistry.PURIFIED_WATER_BOTTLE.get()).m_7968_(), ((Item)ItemRegistry.WATER_PLANT_BAG.get()).m_7968_(), ((Item)ItemRegistry.WATER_PLANT_SEEDS.get()).m_7968_(), ((Item)ItemRegistry.BANDAGE.get()).m_7968_(), ((Item)ItemRegistry.HEALING_HERBS.get()).m_7968_(), ((Item)ItemRegistry.MEDKIT.get()).m_7968_(), ((Item)ItemRegistry.MORPHINE.get()).m_7968_(), ((Item)ItemRegistry.PLASTER.get()).m_7968_(), ((Item)ItemRegistry.TONIC.get()).m_7968_(), ((Item)ItemRegistry.SNOW_BOOTS.get()).m_7968_(), ((Item)ItemRegistry.SNOW_CHEST.get()).m_7968_(), ((Item)ItemRegistry.SNOW_HELMET.get()).m_7968_(), ((Item)ItemRegistry.SNOW_LEGGINGS.get()).m_7968_(), ((Item)ItemRegistry.DESERT_BOOTS.get()).m_7968_(), ((Item)ItemRegistry.DESERT_CHEST.get()).m_7968_(), ((Item)ItemRegistry.DESERT_HELMET.get()).m_7968_(), ((Item)ItemRegistry.DESERT_LEGGINGS.get()).m_7968_(), ((Item)ItemRegistry.ICE_FERN.get()).m_7968_(), ((Item)ItemRegistry.SUN_FERN.get()).m_7968_(), ((Item)ItemRegistry.ICE_FERN_GOLD.get()).m_7968_(), ((Item)ItemRegistry.SUN_FERN_GOLD.get()).m_7968_(), ((Item)ItemRegistry.ICE_FERN_SEEDS.get()).m_7968_(), ((Item)ItemRegistry.SUN_FERN_SEEDS.get()).m_7968_(), ((Item)ItemRegistry.COLD_STRING.get()).m_7968_(), ((Item)ItemRegistry.WARM_STRING.get()).m_7968_(), ((Item)ItemRegistry.COOLING_COAT_1.get()).m_7968_(), ((Item)ItemRegistry.COOLING_COAT_2.get()).m_7968_(), ((Item)ItemRegistry.COOLING_COAT_3.get()).m_7968_(), ((Item)ItemRegistry.HEATING_COAT_1.get()).m_7968_(), ((Item)ItemRegistry.HEATING_COAT_2.get()).m_7968_(), ((Item)ItemRegistry.HEATING_COAT_3.get()).m_7968_(), ((Item)ItemRegistry.THERMAL_COAT_1.get()).m_7968_(), ((Item)ItemRegistry.THERMAL_COAT_2.get()).m_7968_(), ((Item)ItemRegistry.THERMAL_COAT_3.get()).m_7968_(), ((Item)ItemRegistry.SEASONAL_CALENDAR.get()).m_7968_(), ((Item)ItemRegistry.THERMOMETER.get()).m_7968_(), ((Item)ItemRegistry.NETHER_CHALICE.get()).m_7968_(), ((Item)ItemRegistry.SPONGE.get()).m_7968_(), ((Item)ItemRegistry.HEAT_RESISTANCE_RING.get()).m_7968_(), ((Item)ItemRegistry.COLD_RESISTANCE_RING.get()).m_7968_(), ((Item)ItemRegistry.THERMAL_RESISTANCE_RING.get()).m_7968_(), ((Item)ItemRegistry.FIRST_AID_SUPPLIES.get()).m_7968_(), ((Item)ItemRegistry.HEART_CONTAINER.get()).m_7968_(), ((Item)ItemRegistry.HEART_FRAGMENT.get()).m_7968_(), ((Item)ItemRegistry.SHIELD_CONTAINER.get()).m_7968_(), ((Block)BlockRegistry.COOLER.get()).m_5456_().m_7968_(), ((Block)BlockRegistry.HEATER.get()).m_5456_().m_7968_(), ((Block)BlockRegistry.ICE_FERN_GOLD.get()).m_5456_().m_7968_(), ((Block)BlockRegistry.SUN_FERN_GOLD.get()).m_5456_().m_7968_(), ((Block)BlockRegistry.SEWING_TABLE.get()).m_5456_().m_7968_()));
    }).m_257941_((Component)Component.m_237115_((String)"itemGroup.legendarysurvivaloverhaul")).m_257652_());

    public static void register(IEventBus eventBus) {
        ITEM_GROUPS.register(eventBus);
    }
}

