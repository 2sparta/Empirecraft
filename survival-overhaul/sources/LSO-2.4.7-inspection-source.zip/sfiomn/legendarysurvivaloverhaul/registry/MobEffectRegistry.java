/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.effect.MobEffectCategory
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.entity.ai.attributes.AttributeModifier$Operation
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.item.alchemy.Potion
 *  net.minecraft.world.item.alchemy.PotionUtils
 *  net.minecraft.world.item.alchemy.Potions
 *  net.minecraft.world.item.crafting.Ingredient
 *  net.minecraft.world.level.ItemLike
 *  net.minecraftforge.common.brewing.BrewingRecipeRegistry
 *  net.minecraftforge.common.crafting.StrictNBTIngredient
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package sfiomn.legendarysurvivaloverhaul.registry;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.common.brewing.BrewingRecipeRegistry;
import net.minecraftforge.common.crafting.StrictNBTIngredient;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;
import sfiomn.legendarysurvivaloverhaul.common.effects.ColdHungerEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.ColdImmunityEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.FrostbiteEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.HardFallingEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.HeadacheEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.HeatImmunityEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.HeatStrokeEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.HeatThirstEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.HydrationFillEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.PainKillerEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.PainkillerAddictionEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.RecoveryEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.SimpleAttributeEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.TemperatureImmunityEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.ThirstEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.VulnerabilityEffect;
import sfiomn.legendarysurvivaloverhaul.registry.AttributeRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;

public class MobEffectRegistry {
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create((IForgeRegistry)ForgeRegistries.MOB_EFFECTS, (String)"legendarysurvivaloverhaul");
    public static final DeferredRegister<Potion> TEMPERATURE_POTIONS = DeferredRegister.create((IForgeRegistry)ForgeRegistries.POTIONS, (String)"legendarysurvivaloverhaul");
    public static final DeferredRegister<Potion> THIRST_POTIONS = DeferredRegister.create((IForgeRegistry)ForgeRegistries.POTIONS, (String)"legendarysurvivaloverhaul");
    public static final RegistryObject<MobEffect> THIRST = EFFECTS.register("thirst", ThirstEffect::new);
    public static final RegistryObject<Potion> THIRST_POTION = THIRST_POTIONS.register("thirst", () -> new Potion("thirst", new MobEffectInstance[]{new MobEffectInstance((MobEffect)THIRST.get(), 3600, 0, false, true, true)}));
    public static final RegistryObject<Potion> THIRST_POTION_LONG = THIRST_POTIONS.register("thirst_long", () -> new Potion("thirst_long", new MobEffectInstance[]{new MobEffectInstance((MobEffect)THIRST.get(), 9600, 0, false, true, true)}));
    public static final RegistryObject<MobEffect> HYDRATION_FILL = EFFECTS.register("hydration_fill", HydrationFillEffect::new);
    public static final RegistryObject<Potion> HYDRATION_FILL_POTION = THIRST_POTIONS.register("hydration_fill", () -> new Potion("hydration_fill", new MobEffectInstance[]{new MobEffectInstance((MobEffect)HYDRATION_FILL.get(), 3600, 0, false, true, true)}));
    public static final RegistryObject<Potion> HYDRATION_FILL_POTION_LONG = THIRST_POTIONS.register("hydration_fill_long", () -> new Potion("hydration_fill_long", new MobEffectInstance[]{new MobEffectInstance((MobEffect)HYDRATION_FILL.get(), 9600, 0, false, true, true)}));
    public static final RegistryObject<MobEffect> HOT_FOOD = EFFECTS.register("hot_food", () -> new SimpleAttributeEffect(MobEffectCategory.BENEFICIAL, 0xFF0C0C, 1.0).m_19472_((Attribute)AttributeRegistry.HEATING_TEMPERATURE.get(), "dbac2b95-f979-4104-a4ba-3039c1015ae7", 1.0, AttributeModifier.Operation.ADDITION));
    public static final RegistryObject<MobEffect> HOT_DRINk = EFFECTS.register("hot_drink", () -> new SimpleAttributeEffect(MobEffectCategory.BENEFICIAL, 0xFF0C0C, 1.0).m_19472_((Attribute)AttributeRegistry.HEATING_TEMPERATURE.get(), "5f1f294d-86f4-42e8-ae78-67223f29e9e8", 1.0, AttributeModifier.Operation.ADDITION));
    public static final RegistryObject<MobEffect> COLD_FOOD = EFFECTS.register("cold_food", () -> new SimpleAttributeEffect(MobEffectCategory.BENEFICIAL, 0x11CCEE, -1.0).m_19472_((Attribute)AttributeRegistry.COOLING_TEMPERATURE.get(), "344cffd9-9a50-4bd5-9ac1-aa4830c3128a", -1.0, AttributeModifier.Operation.ADDITION));
    public static final RegistryObject<MobEffect> COLD_DRINK = EFFECTS.register("cold_drink", () -> new SimpleAttributeEffect(MobEffectCategory.BENEFICIAL, 0x11CCEE, -1.0).m_19472_((Attribute)AttributeRegistry.COOLING_TEMPERATURE.get(), "10db1b22-eda8-4cc2-90df-c1e3b06fa460", -1.0, AttributeModifier.Operation.ADDITION));
    public static final RegistryObject<MobEffect> HEAT_RESISTANCE = EFFECTS.register("heat_resistance", () -> new SimpleAttributeEffect(MobEffectCategory.BENEFICIAL, 16420407, 1.0).m_19472_((Attribute)AttributeRegistry.HEAT_RESISTANCE.get(), "fc0998d2-a273-4d8c-aaf4-39f8a25a3c8e", 1.0, AttributeModifier.Operation.ADDITION));
    public static final RegistryObject<MobEffect> COLD_RESISTANCE = EFFECTS.register("cold_resistance", () -> new SimpleAttributeEffect(MobEffectCategory.BENEFICIAL, 6466303, 1.0).m_19472_((Attribute)AttributeRegistry.COLD_RESISTANCE.get(), "cc64e9cb-10dd-4896-8ff6-5f6a21b949ff", 1.0, AttributeModifier.Operation.ADDITION));
    public static final RegistryObject<MobEffect> FROSTBITE = EFFECTS.register("frostbite", FrostbiteEffect::new);
    public static final RegistryObject<MobEffect> COLD_HUNGER = EFFECTS.register("cold_hunger", ColdHungerEffect::new);
    public static final RegistryObject<MobEffect> HEAT_STROKE = EFFECTS.register("heat_stroke", HeatStrokeEffect::new);
    public static final RegistryObject<MobEffect> HEAT_THIRST = EFFECTS.register("heat_thirst", HeatThirstEffect::new);
    public static final RegistryObject<MobEffect> COLD_IMMUNITY = EFFECTS.register("cold_immunity", ColdImmunityEffect::new);
    public static final RegistryObject<MobEffect> HEAT_IMMUNITY = EFFECTS.register("heat_immunity", HeatImmunityEffect::new);
    public static final RegistryObject<MobEffect> TEMPERATURE_IMMUNITY = EFFECTS.register("temperature_immunity", TemperatureImmunityEffect::new);
    public static final RegistryObject<Potion> HEAT_IMMUNITY_POTION = TEMPERATURE_POTIONS.register("heat_immunity", () -> new Potion("heat_immunity", new MobEffectInstance[]{new MobEffectInstance((MobEffect)HEAT_IMMUNITY.get(), 1800, 0, false, true, true)}));
    public static final RegistryObject<Potion> HEAT_IMMUNITY_POTION_LONG = TEMPERATURE_POTIONS.register("heat_immunity_long", () -> new Potion("heat_immunity_long", new MobEffectInstance[]{new MobEffectInstance((MobEffect)HEAT_IMMUNITY.get(), 2400, 0, false, true, true)}));
    public static final RegistryObject<Potion> COLD_IMMUNITY_POTION = TEMPERATURE_POTIONS.register("cold_immunity", () -> new Potion("cold_immunity", new MobEffectInstance[]{new MobEffectInstance((MobEffect)COLD_IMMUNITY.get(), 1800, 0, false, true, true)}));
    public static final RegistryObject<Potion> COLD_IMMUNITY_POTION_LONG = TEMPERATURE_POTIONS.register("cold_immunity_long", () -> new Potion("cold_immunity_long", new MobEffectInstance[]{new MobEffectInstance((MobEffect)COLD_IMMUNITY.get(), 2400, 0, false, true, true)}));
    public static final RegistryObject<Potion> HEAT_RESISTANCE_POTION = TEMPERATURE_POTIONS.register("heat_resistance", () -> new Potion("heat_resistance", new MobEffectInstance[]{new MobEffectInstance((MobEffect)HEAT_RESISTANCE.get(), 1800, 1, false, true, true)}));
    public static final RegistryObject<Potion> HEAT_RESISTANCE_POTION_LONG = TEMPERATURE_POTIONS.register("heat_resistance_long", () -> new Potion("heat_resistance_long", new MobEffectInstance[]{new MobEffectInstance((MobEffect)HEAT_RESISTANCE.get(), 2400, 1, false, true, true)}));
    public static final RegistryObject<Potion> COLD_RESISTANCE_POTION = TEMPERATURE_POTIONS.register("cold_resistance", () -> new Potion("cold_resistance", new MobEffectInstance[]{new MobEffectInstance((MobEffect)COLD_RESISTANCE.get(), 1800, 1, false, true, true)}));
    public static final RegistryObject<Potion> COLD_RESISTANCE_POTION_LONG = TEMPERATURE_POTIONS.register("cold_resistance_long", () -> new Potion("cold_resistance_long", new MobEffectInstance[]{new MobEffectInstance((MobEffect)COLD_RESISTANCE.get(), 2400, 1, false, true, true)}));
    public static final RegistryObject<Potion> TEMPERATURE_IMMUNITY_POTION = TEMPERATURE_POTIONS.register("temperature_immunity", () -> new Potion("temperature_immunity", new MobEffectInstance[]{new MobEffectInstance((MobEffect)TEMPERATURE_IMMUNITY.get(), 1800, 0, false, true, true)}));
    public static final RegistryObject<Potion> TEMPERATURE_IMMUNITY_POTION_LONG = TEMPERATURE_POTIONS.register("temperature_immunity_long", () -> new Potion("temperature_immunity_long", new MobEffectInstance[]{new MobEffectInstance((MobEffect)TEMPERATURE_IMMUNITY.get(), 2400, 0, false, true, true)}));
    public static final RegistryObject<MobEffect> PAINKILLER = EFFECTS.register("painkiller", PainKillerEffect::new);
    public static final RegistryObject<MobEffect> PAINKILLER_ADDICTION = EFFECTS.register("painkiller_addiction", PainkillerAddictionEffect::new);
    public static final RegistryObject<MobEffect> HARD_FALLING = EFFECTS.register("hard_falling", HardFallingEffect::new);
    public static final RegistryObject<MobEffect> VULNERABILITY = EFFECTS.register("vulnerability", VulnerabilityEffect::new);
    public static final RegistryObject<MobEffect> HEADACHE = EFFECTS.register("headache", HeadacheEffect::new);
    public static final RegistryObject<MobEffect> RECOVERY = EFFECTS.register("recovery", RecoveryEffect::new);

    public static void registerBrewingRecipes() {
        MobEffectRegistry.addBrewingRecipe(Potions.f_43602_, (Item)ItemRegistry.SUN_FERN.get(), (Potion)HEAT_RESISTANCE_POTION.get());
        MobEffectRegistry.addBrewingRecipe((Potion)HEAT_RESISTANCE_POTION.get(), Items.f_42451_, (Potion)HEAT_RESISTANCE_POTION_LONG.get());
        MobEffectRegistry.addBrewingRecipe(Potions.f_43602_, (Item)ItemRegistry.ICE_FERN.get(), (Potion)COLD_RESISTANCE_POTION.get());
        MobEffectRegistry.addBrewingRecipe((Potion)COLD_RESISTANCE_POTION.get(), Items.f_42451_, (Potion)COLD_RESISTANCE_POTION_LONG.get());
        MobEffectRegistry.addBrewingRecipe(Potions.f_43602_, (Item)ItemRegistry.SUN_FERN_GOLD.get(), (Potion)HEAT_IMMUNITY_POTION.get());
        MobEffectRegistry.addBrewingRecipe((Potion)HEAT_IMMUNITY_POTION.get(), Items.f_42451_, (Potion)HEAT_IMMUNITY_POTION_LONG.get());
        MobEffectRegistry.addBrewingRecipe(Potions.f_43602_, (Item)ItemRegistry.ICE_FERN_GOLD.get(), (Potion)COLD_IMMUNITY_POTION.get());
        MobEffectRegistry.addBrewingRecipe((Potion)COLD_IMMUNITY_POTION.get(), Items.f_42451_, (Potion)COLD_IMMUNITY_POTION_LONG.get());
        MobEffectRegistry.addBrewingRecipe((Potion)HEAT_IMMUNITY_POTION.get(), (Item)ItemRegistry.ICE_FERN_GOLD.get(), (Potion)TEMPERATURE_IMMUNITY_POTION.get());
        MobEffectRegistry.addBrewingRecipe((Potion)HEAT_IMMUNITY_POTION_LONG.get(), (Item)ItemRegistry.ICE_FERN_GOLD.get(), (Potion)TEMPERATURE_IMMUNITY_POTION_LONG.get());
        MobEffectRegistry.addBrewingRecipe((Potion)COLD_IMMUNITY_POTION.get(), (Item)ItemRegistry.SUN_FERN_GOLD.get(), (Potion)TEMPERATURE_IMMUNITY_POTION.get());
        MobEffectRegistry.addBrewingRecipe((Potion)COLD_IMMUNITY_POTION_LONG.get(), (Item)ItemRegistry.SUN_FERN_GOLD.get(), (Potion)TEMPERATURE_IMMUNITY_POTION_LONG.get());
        MobEffectRegistry.addBrewingRecipe((Potion)TEMPERATURE_IMMUNITY_POTION.get(), Items.f_42451_, (Potion)TEMPERATURE_IMMUNITY_POTION_LONG.get());
    }

    private static void addBrewingRecipe(Potion potionInput, Item ingredient, Potion potionResult) {
        BrewingRecipeRegistry.addRecipe((Ingredient)StrictNBTIngredient.of((ItemStack)PotionUtils.m_43549_((ItemStack)new ItemStack((ItemLike)Items.f_42589_), (Potion)potionInput)), (Ingredient)StrictNBTIngredient.of((ItemStack)new ItemStack((ItemLike)ingredient)), (ItemStack)PotionUtils.m_43549_((ItemStack)new ItemStack((ItemLike)Items.f_42589_), (Potion)potionResult));
    }

    private static void addBrewingRecipe(Potion potionInput, Item ingredient, Item itemResult) {
        BrewingRecipeRegistry.addRecipe((Ingredient)StrictNBTIngredient.of((ItemStack)PotionUtils.m_43549_((ItemStack)new ItemStack((ItemLike)Items.f_42589_), (Potion)potionInput)), (Ingredient)StrictNBTIngredient.of((ItemStack)new ItemStack((ItemLike)ingredient)), (ItemStack)new ItemStack((ItemLike)itemResult));
    }

    public static void register(IEventBus eventBus) {
        EFFECTS.register(eventBus);
        TEMPERATURE_POTIONS.register(eventBus);
        THIRST_POTIONS.register(eventBus);
    }
}

