/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.entity.BlockEntityType
 *  net.minecraft.world.level.block.entity.BlockEntityType$Builder
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package sfiomn.legendarysurvivaloverhaul.registry;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;
import sfiomn.legendarysurvivaloverhaul.common.blockentities.CoolerBlockEntity;
import sfiomn.legendarysurvivaloverhaul.common.blockentities.HeaterBlockEntity;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;

public class BlockEntityRegistry {
    public static DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create((IForgeRegistry)ForgeRegistries.BLOCK_ENTITY_TYPES, (String)"legendarysurvivaloverhaul");
    public static RegistryObject<BlockEntityType<HeaterBlockEntity>> HEATER_BLOCK_ENTITY = BLOCK_ENTITIES.register("legendarysurvivaloverhaulheater_block_entity", () -> BlockEntityType.Builder.m_155273_(HeaterBlockEntity::new, (Block[])new Block[]{(Block)BlockRegistry.HEATER.get()}).m_58966_(null));
    public static RegistryObject<BlockEntityType<CoolerBlockEntity>> COOLER_BLOCK_ENTITY = BLOCK_ENTITIES.register("legendarysurvivaloverhaulcooler_block_entity", () -> BlockEntityType.Builder.m_155273_(CoolerBlockEntity::new, (Block[])new Block[]{(Block)BlockRegistry.COOLER.get()}).m_58966_(null));

    public static void register(IEventBus eventBus) {
        BLOCK_ENTITIES.register(eventBus);
    }
}

