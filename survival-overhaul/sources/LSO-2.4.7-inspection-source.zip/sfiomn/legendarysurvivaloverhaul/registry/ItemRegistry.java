/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.chat.Component
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.item.ArmorItem
 *  net.minecraft.world.item.ArmorItem$Type
 *  net.minecraft.world.item.ArmorMaterial
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemNameBlockItem
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Rarity
 *  net.minecraft.world.item.TooltipFlag
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Block
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.registry;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.api.item.CoatEnum;
import sfiomn.legendarysurvivaloverhaul.common.items.CoatItem;
import sfiomn.legendarysurvivaloverhaul.common.items.HeartContainerItem;
import sfiomn.legendarysurvivaloverhaul.common.items.NetherChaliceItem;
import sfiomn.legendarysurvivaloverhaul.common.items.SeasonalCalendarItem;
import sfiomn.legendarysurvivaloverhaul.common.items.ShieldContainerItem;
import sfiomn.legendarysurvivaloverhaul.common.items.ThermometerItem;
import sfiomn.legendarysurvivaloverhaul.common.items.WearableCurioItem;
import sfiomn.legendarysurvivaloverhaul.common.items.armor.ArmorMaterialBase;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.CanteenItem;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.DrinkItem;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.JuiceItem;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.LargeCanteenItem;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.PurifiedWaterBottleItem;
import sfiomn.legendarysurvivaloverhaul.common.items.heal.BandageItem;
import sfiomn.legendarysurvivaloverhaul.common.items.heal.HealingHerbsItem;
import sfiomn.legendarysurvivaloverhaul.common.items.heal.Medkit;
import sfiomn.legendarysurvivaloverhaul.common.items.heal.MorphineItem;
import sfiomn.legendarysurvivaloverhaul.common.items.heal.PlasterItem;
import sfiomn.legendarysurvivaloverhaul.common.items.heal.TonicItem;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;

public class ItemRegistry {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create((IForgeRegistry)ForgeRegistries.ITEMS, (String)"legendarysurvivaloverhaul");
    public static final RegistryObject<Item> THERMOMETER = ITEMS.register("thermometer", () -> new ThermometerItem(new Item.Properties().m_41487_(1)));
    public static final RegistryObject<Item> SEASONAL_CALENDAR = ITEMS.register("seasonal_calendar", () -> new SeasonalCalendarItem(new Item.Properties()));
    public static final RegistryObject<Item> NETHER_CHALICE = ITEMS.register("nether_chalice", () -> new NetherChaliceItem(new Item.Properties().m_41487_(1).m_41497_(Rarity.EPIC)));
    public static final RegistryObject<Item> SPONGE = ITEMS.register("sponge", () -> new WearableCurioItem(new Item.Properties().m_41487_(1).m_41497_(Rarity.RARE)){

        public void m_7373_(ItemStack stack, @Nullable Level level, List<Component> tooltipComponents, TooltipFlag isAdvanced) {
            super.m_7373_(stack, level, tooltipComponents, isAdvanced);
            tooltipComponents.add((Component)Component.m_237115_((String)"tooltip.legendarysurvivaloverhaul.sponge.description"));
        }
    });
    public static final RegistryObject<Item> HEAT_RESISTANCE_RING = ITEMS.register("heat_resistance_ring", () -> new WearableCurioItem(new Item.Properties().m_41487_(1).m_41497_(Rarity.RARE)));
    public static final RegistryObject<Item> COLD_RESISTANCE_RING = ITEMS.register("cold_resistance_ring", () -> new WearableCurioItem(new Item.Properties().m_41487_(1).m_41497_(Rarity.RARE)));
    public static final RegistryObject<Item> THERMAL_RESISTANCE_RING = ITEMS.register("thermal_resistance_ring", () -> new WearableCurioItem(new Item.Properties().m_41487_(1).m_41497_(Rarity.EPIC)));
    public static final RegistryObject<Item> FIRST_AID_SUPPLIES = ITEMS.register("first_aid_supplies", () -> new WearableCurioItem(new Item.Properties().m_41487_(1).m_41497_(Rarity.RARE)){

        public void m_7373_(ItemStack stack, @Nullable Level level, List<Component> tooltipComponents, TooltipFlag isAdvanced) {
            super.m_7373_(stack, level, tooltipComponents, isAdvanced);
            tooltipComponents.add((Component)Component.m_237115_((String)"tooltip.legendarysurvivaloverhaul.first_aid_supplies.description"));
        }
    });
    public static final RegistryObject<Item> SNOW_HELMET = ITEMS.register("snow_helmet", () -> new ArmorItem((ArmorMaterial)ArmorMaterialBase.SNOW, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> SNOW_CHEST = ITEMS.register("snow_chestplate", () -> new ArmorItem((ArmorMaterial)ArmorMaterialBase.SNOW, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> SNOW_LEGGINGS = ITEMS.register("snow_leggings", () -> new ArmorItem((ArmorMaterial)ArmorMaterialBase.SNOW, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> SNOW_BOOTS = ITEMS.register("snow_boots", () -> new ArmorItem(ArmorMaterialBase.SNOW, ArmorItem.Type.BOOTS, new Item.Properties()){

        public boolean canWalkOnPowderedSnow(ItemStack stack, LivingEntity wearer) {
            return true;
        }
    });
    public static final RegistryObject<Item> DESERT_HELMET = ITEMS.register("desert_helmet", () -> new ArmorItem((ArmorMaterial)ArmorMaterialBase.DESERT, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> DESERT_CHEST = ITEMS.register("desert_chestplate", () -> new ArmorItem((ArmorMaterial)ArmorMaterialBase.DESERT, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> DESERT_LEGGINGS = ITEMS.register("desert_leggings", () -> new ArmorItem((ArmorMaterial)ArmorMaterialBase.DESERT, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> DESERT_BOOTS = ITEMS.register("desert_boots", () -> new ArmorItem((ArmorMaterial)ArmorMaterialBase.DESERT, ArmorItem.Type.BOOTS, new Item.Properties()));
    public static final RegistryObject<Item> COOLING_COAT_1 = ITEMS.register("cooling_coat_1", () -> new CoatItem(CoatEnum.COOLING_1, new Item.Properties().m_41497_(Rarity.COMMON)));
    public static final RegistryObject<Item> COOLING_COAT_2 = ITEMS.register("cooling_coat_2", () -> new CoatItem(CoatEnum.COOLING_2, new Item.Properties().m_41497_(Rarity.RARE)));
    public static final RegistryObject<Item> COOLING_COAT_3 = ITEMS.register("cooling_coat_3", () -> new CoatItem(CoatEnum.COOLING_3, new Item.Properties().m_41497_(Rarity.EPIC)));
    public static final RegistryObject<Item> HEATING_COAT_1 = ITEMS.register("heating_coat_1", () -> new CoatItem(CoatEnum.HEATING_1, new Item.Properties().m_41497_(Rarity.COMMON)));
    public static final RegistryObject<Item> HEATING_COAT_2 = ITEMS.register("heating_coat_2", () -> new CoatItem(CoatEnum.HEATING_2, new Item.Properties().m_41497_(Rarity.RARE)));
    public static final RegistryObject<Item> HEATING_COAT_3 = ITEMS.register("heating_coat_3", () -> new CoatItem(CoatEnum.HEATING_3, new Item.Properties().m_41497_(Rarity.EPIC)));
    public static final RegistryObject<Item> THERMAL_COAT_1 = ITEMS.register("thermal_coat_1", () -> new CoatItem(CoatEnum.THERMAL_1, new Item.Properties().m_41497_(Rarity.COMMON)));
    public static final RegistryObject<Item> THERMAL_COAT_2 = ITEMS.register("thermal_coat_2", () -> new CoatItem(CoatEnum.THERMAL_2, new Item.Properties().m_41497_(Rarity.RARE)));
    public static final RegistryObject<Item> THERMAL_COAT_3 = ITEMS.register("thermal_coat_3", () -> new CoatItem(CoatEnum.THERMAL_3, new Item.Properties().m_41497_(Rarity.EPIC)));
    public static final RegistryObject<Item> COLD_STRING = ITEMS.register("cold_string", () -> new Item(new Item.Properties().m_41497_(Rarity.COMMON)));
    public static final RegistryObject<Item> WARM_STRING = ITEMS.register("warm_string", () -> new Item(new Item.Properties().m_41497_(Rarity.COMMON)));
    public static final RegistryObject<Item> SUN_FERN_SEEDS = ITEMS.register("sun_fern_seeds", () -> new ItemNameBlockItem((Block)BlockRegistry.SUN_FERN_CROP.get(), new Item.Properties()));
    public static final RegistryObject<Item> SUN_FERN = ITEMS.register("sun_fern_leaf", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> SUN_FERN_GOLD = ITEMS.register("sun_fern_gold_leaf", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> ICE_FERN_SEEDS = ITEMS.register("ice_fern_seeds", () -> new ItemNameBlockItem((Block)BlockRegistry.ICE_FERN_CROP.get(), new Item.Properties()));
    public static final RegistryObject<Item> ICE_FERN = ITEMS.register("ice_fern_leaf", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> ICE_FERN_GOLD = ITEMS.register("ice_fern_gold_leaf", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> WATER_PURIFIER = ITEMS.register("water_purifier", () -> new WearableCurioItem(new Item.Properties().m_41487_(1).m_41497_(Rarity.RARE)){

        public void m_7373_(ItemStack stack, @Nullable Level level, List<Component> tooltipComponents, TooltipFlag isAdvanced) {
            super.m_7373_(stack, level, tooltipComponents, isAdvanced);
            tooltipComponents.add((Component)Component.m_237115_((String)"tooltip.legendarysurvivaloverhaul.water_purifier.description"));
        }
    });
    public static final RegistryObject<Item> CANTEEN = ITEMS.register("canteen", () -> new CanteenItem(new Item.Properties().m_41497_(Rarity.COMMON)));
    public static final RegistryObject<Item> LARGE_CANTEEN = ITEMS.register("large_canteen", () -> new LargeCanteenItem(new Item.Properties().m_41497_(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> APPLE_JUICE = ITEMS.register("apple_juice", () -> new JuiceItem(new Item.Properties()));
    public static final RegistryObject<Item> BEETROOT_JUICE = ITEMS.register("beetroot_juice", () -> new JuiceItem(new Item.Properties()));
    public static final RegistryObject<Item> CACTUS_JUICE = ITEMS.register("cactus_juice", () -> new JuiceItem(new Item.Properties()));
    public static final RegistryObject<Item> CARROT_JUICE = ITEMS.register("carrot_juice", () -> new JuiceItem(new Item.Properties()));
    public static final RegistryObject<Item> CHORUS_FRUIT_JUICE = ITEMS.register("chorus_fruit_juice", () -> new JuiceItem(new Item.Properties()));
    public static final RegistryObject<Item> GOLDEN_APPLE_JUICE = ITEMS.register("golden_apple_juice", () -> new JuiceItem(new Item.Properties().m_41497_(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> GOLDEN_CARROT_JUICE = ITEMS.register("golden_carrot_juice", () -> new JuiceItem(new Item.Properties().m_41497_(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> GLISTERING_MELON_JUICE = ITEMS.register("glistering_melon_juice", () -> new JuiceItem(new Item.Properties().m_41497_(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> MELON_JUICE = ITEMS.register("melon_juice", () -> new JuiceItem(new Item.Properties()));
    public static final RegistryObject<Item> PUMPKIN_JUICE = ITEMS.register("pumpkin_juice", () -> new JuiceItem(new Item.Properties()));
    public static final RegistryObject<Item> SWEET_BERRIES_JUICE = ITEMS.register("sweet_berries_juice", () -> new JuiceItem(new Item.Properties()));
    public static final RegistryObject<Item> GLOW_BERRIES_JUICE = ITEMS.register("glow_berries_juice", () -> new JuiceItem(new Item.Properties()));
    public static final RegistryObject<Item> PURIFIED_WATER_BOTTLE = ITEMS.register("purified_water_bottle", () -> new PurifiedWaterBottleItem(new Item.Properties()));
    public static final RegistryObject<Item> WATER_PLANT_BAG = ITEMS.register("water_plant_bag", () -> new DrinkItem(new Item.Properties()));
    public static final RegistryObject<Item> WATER_PLANT_SEEDS = ITEMS.register("water_plant_seeds", () -> new ItemNameBlockItem((Block)BlockRegistry.WATER_PLANT_CROP.get(), new Item.Properties()));
    public static final RegistryObject<Item> HEART_CONTAINER = ITEMS.register("heart_container", () -> new HeartContainerItem(new Item.Properties().m_41497_(Rarity.EPIC)));
    public static final RegistryObject<Item> HEART_FRAGMENT = ITEMS.register("heart_fragment", () -> new Item(new Item.Properties().m_41497_(Rarity.RARE)));
    public static final RegistryObject<Item> SHIELD_CONTAINER = ITEMS.register("shield_container", () -> new ShieldContainerItem(new Item.Properties().m_41497_(Rarity.EPIC)));
    public static final RegistryObject<Item> HEALING_HERBS = ITEMS.register("healing_herbs", () -> new HealingHerbsItem(new Item.Properties()));
    public static final RegistryObject<Item> PLASTER = ITEMS.register("plaster", () -> new PlasterItem(new Item.Properties()));
    public static final RegistryObject<Item> BANDAGE = ITEMS.register("bandage", () -> new BandageItem(new Item.Properties()));
    public static final RegistryObject<Item> TONIC = ITEMS.register("tonic", () -> new TonicItem(new Item.Properties().m_41497_(Rarity.RARE)));
    public static final RegistryObject<Item> MEDKIT = ITEMS.register("medkit", () -> new Medkit(new Item.Properties().m_41497_(Rarity.EPIC)));
    public static final RegistryObject<Item> MORPHINE = ITEMS.register("morphine", () -> new MorphineItem(new Item.Properties()));

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}

