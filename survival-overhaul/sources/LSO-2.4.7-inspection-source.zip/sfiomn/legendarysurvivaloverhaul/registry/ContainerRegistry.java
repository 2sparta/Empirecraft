/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.inventory.MenuType
 *  net.minecraftforge.common.extensions.IForgeMenuType
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package sfiomn.legendarysurvivaloverhaul.registry;

import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;
import sfiomn.legendarysurvivaloverhaul.common.containers.AbstractThermalContainer;
import sfiomn.legendarysurvivaloverhaul.common.containers.CoolerContainer;
import sfiomn.legendarysurvivaloverhaul.common.containers.HeaterContainer;
import sfiomn.legendarysurvivaloverhaul.common.containers.SewingTableContainer;

public class ContainerRegistry {
    public static final DeferredRegister<MenuType<?>> CONTAINERS = DeferredRegister.create((IForgeRegistry)ForgeRegistries.MENU_TYPES, (String)"legendarysurvivaloverhaul");
    public static final RegistryObject<MenuType<AbstractThermalContainer>> COOLER_CONTAINER = CONTAINERS.register("cooler_container", () -> IForgeMenuType.create(CoolerContainer::new));
    public static final RegistryObject<MenuType<AbstractThermalContainer>> HEATER_CONTAINER = CONTAINERS.register("heater_container", () -> IForgeMenuType.create(HeaterContainer::new));
    public static final RegistryObject<MenuType<SewingTableContainer>> SEWING_TABLE_CONTAINER = CONTAINERS.register("sewing_table_container", () -> IForgeMenuType.create(SewingTableContainer::new));

    public static void register(IEventBus eventBus) {
        CONTAINERS.register(eventBus);
    }
}

