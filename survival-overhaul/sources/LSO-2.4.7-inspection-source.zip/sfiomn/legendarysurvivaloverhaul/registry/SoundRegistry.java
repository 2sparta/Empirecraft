/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package sfiomn.legendarysurvivaloverhaul.registry;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;

public class SoundRegistry {
    public static final DeferredRegister<SoundEvent> SOUND_EVENTS = DeferredRegister.create((IForgeRegistry)ForgeRegistries.SOUND_EVENTS, (String)"legendarysurvivaloverhaul");
    public static final RegistryObject<SoundEvent> HEAT_STROKE_EARLY = SoundRegistry.registerSoundEvent("heat_stroke_early");
    public static final RegistryObject<SoundEvent> HEAT_STROKE = SoundRegistry.registerSoundEvent("heat_stroke");
    public static final RegistryObject<SoundEvent> PANTING = SoundRegistry.registerSoundEvent("panting");
    public static final RegistryObject<SoundEvent> FROSTBITE_EARLY = SoundRegistry.registerSoundEvent("frostbite_early");
    public static final RegistryObject<SoundEvent> FROSTBITE = SoundRegistry.registerSoundEvent("frostbite");
    public static final RegistryObject<SoundEvent> SHIVERING = SoundRegistry.registerSoundEvent("shivering");
    public static final RegistryObject<SoundEvent> SEWING_TABLE = SoundRegistry.registerSoundEvent("sewing_table");
    public static final RegistryObject<SoundEvent> COOLER_BLOCK = SoundRegistry.registerSoundEvent("cooler_block");
    public static final RegistryObject<SoundEvent> SELF_WATERING = SoundRegistry.registerSoundEvent("self_watering");
    public static final RegistryObject<SoundEvent> HEADSHOT = SoundRegistry.registerSoundEvent("headshot");
    public static final RegistryObject<SoundEvent> HEAL_BODY_PART = SoundRegistry.registerSoundEvent("heal_body_part");
    public static final RegistryObject<SoundEvent> HARD_FALLING_HURT = SoundRegistry.registerSoundEvent("hard_falling_hurt");
    public static final RegistryObject<SoundEvent> HEADACHE_HEARTBEAT = SoundRegistry.registerSoundEvent("headache_heartbeat");
    public static final RegistryObject<SoundEvent> HEART_CONTAINER = SoundRegistry.registerSoundEvent("heart_container");

    private static RegistryObject<SoundEvent> registerSoundEvent(String name) {
        return SOUND_EVENTS.register(name, () -> SoundEvent.m_262824_((ResourceLocation)new ResourceLocation("legendarysurvivaloverhaul", name)));
    }

    public static void register(IEventBus eventBus) {
        SOUND_EVENTS.register(eventBus);
    }
}

