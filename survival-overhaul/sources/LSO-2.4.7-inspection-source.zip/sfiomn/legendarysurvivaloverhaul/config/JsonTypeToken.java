/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.reflect.TypeToken
 */
package sfiomn.legendarysurvivaloverhaul.config;

import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;
import sfiomn.legendarysurvivaloverhaul.api.config.json_old.bodydamage.JsonBodyPartsDamageSource;
import sfiomn.legendarysurvivaloverhaul.api.config.json_old.bodydamage.JsonConsumableHeal;
import sfiomn.legendarysurvivaloverhaul.api.config.json_old.temperature.JsonBiomeIdentity;
import sfiomn.legendarysurvivaloverhaul.api.config.json_old.temperature.JsonBlockFluidTemperature;
import sfiomn.legendarysurvivaloverhaul.api.config.json_old.temperature.JsonConsumableTemperature;
import sfiomn.legendarysurvivaloverhaul.api.config.json_old.temperature.JsonFuelItem;
import sfiomn.legendarysurvivaloverhaul.api.config.json_old.temperature.JsonTemperature;
import sfiomn.legendarysurvivaloverhaul.api.config.json_old.temperature.JsonTemperatureResistance;
import sfiomn.legendarysurvivaloverhaul.api.config.json_old.thirst.JsonBlockFluidThirst;
import sfiomn.legendarysurvivaloverhaul.api.config.json_old.thirst.JsonConsumableThirst;
import sfiomn.legendarysurvivaloverhaul.config.JsonFileName;

public class JsonTypeToken {
    public static Type get(JsonFileName jcfn) {
        switch (jcfn) {
            case DIMENSION_TEMP: {
                return new TypeToken<Map<String, JsonTemperature>>(){}.getType();
            }
            case BIOME_TEMP: {
                return new TypeToken<Map<String, JsonBiomeIdentity>>(){}.getType();
            }
            case ITEM_TEMP: {
                return new TypeToken<Map<String, JsonTemperatureResistance>>(){}.getType();
            }
            case ENTITY_TEMP: {
                return new TypeToken<Map<String, JsonTemperature>>(){}.getType();
            }
            case BLOCK_TEMP: {
                return new TypeToken<Map<String, List<JsonBlockFluidTemperature>>>(){}.getType();
            }
            case ORIGINS_TEMP: {
                return new TypeToken<Map<String, JsonTemperatureResistance>>(){}.getType();
            }
            case FUEL: {
                return new TypeToken<Map<String, JsonFuelItem>>(){}.getType();
            }
            case CONSUMABLE_TEMP: {
                return new TypeToken<Map<String, List<JsonConsumableTemperature>>>(){}.getType();
            }
            case BLOCK_THIRST: {
                return new TypeToken<Map<String, List<JsonBlockFluidThirst>>>(){}.getType();
            }
            case CONSUMABLE_THIRST: {
                return new TypeToken<Map<String, List<JsonConsumableThirst>>>(){}.getType();
            }
            case CONSUMABLE_HEAL: {
                return new TypeToken<Map<String, JsonConsumableHeal>>(){}.getType();
            }
            case DAMAGE_SOURCE_BODY_PARTS: {
                return new TypeToken<Map<String, JsonBodyPartsDamageSource>>(){}.getType();
            }
        }
        return null;
    }
}

