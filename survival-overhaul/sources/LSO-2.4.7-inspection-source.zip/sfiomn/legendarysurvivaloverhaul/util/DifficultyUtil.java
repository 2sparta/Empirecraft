/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.util;

import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.util.EnumUtil;

public final class DifficultyUtil {
    private DifficultyUtil() {
    }

    public static boolean isModDangerous() {
        return Config.Baked.difficultyMode != EnumUtil.DifficultyMode.PEACEFUL;
    }

    public static boolean healthAboveDifficulty(Player player) {
        EnumUtil.DifficultyMode difficulty = Config.Baked.difficultyMode;
        return difficulty == EnumUtil.DifficultyMode.HARD || difficulty == EnumUtil.DifficultyMode.NORMAL && player.m_21223_() > 2.0f || (difficulty == EnumUtil.DifficultyMode.EASY || difficulty == EnumUtil.DifficultyMode.PEACEFUL) && player.m_21223_() > 10.0f;
    }
}

