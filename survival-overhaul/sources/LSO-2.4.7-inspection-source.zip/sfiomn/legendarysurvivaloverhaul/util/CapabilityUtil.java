/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 */
package sfiomn.legendarysurvivaloverhaul.util;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.bodydamage.BodyDamageCapability;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.bodydamage.BodyDamageProvider;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.food.FoodCapability;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.food.FoodProvider;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.health.HealthCapability;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.health.HealthProvider;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.temperature.TemperatureCapability;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.temperature.TemperatureItemCapability;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.temperature.TemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.thirst.ThirstCapability;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.thirst.ThirstProvider;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.wetness.WetnessCapability;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.wetness.WetnessProvider;

public final class CapabilityUtil {
    private CapabilityUtil() {
    }

    public static TemperatureCapability getTempCapability(Player player) {
        return (TemperatureCapability)player.getCapability(TemperatureProvider.TEMPERATURE_CAPABILITY).orElse((Object)new TemperatureCapability());
    }

    public static TemperatureItemCapability getTempItemCapability(ItemStack itemStack) {
        return (TemperatureItemCapability)itemStack.getCapability(TemperatureItemCapability.TemperatureItemProvider.TEMPERATURE_ITEM_CAPABILITY).orElse((Object)new TemperatureItemCapability());
    }

    public static HealthCapability getHealthCapability(Player player) {
        return (HealthCapability)player.getCapability(HealthProvider.HEALTH_CAPABILITY).orElse((Object)new HealthCapability());
    }

    public static WetnessCapability getWetnessCapability(Player player) {
        return (WetnessCapability)player.getCapability(WetnessProvider.WETNESS_CAPABILITY).orElse((Object)new WetnessCapability());
    }

    public static ThirstCapability getThirstCapability(Player player) {
        return (ThirstCapability)player.getCapability(ThirstProvider.THIRST_CAPABILITY).orElse((Object)new ThirstCapability());
    }

    public static FoodCapability getFoodCapability(Player player) {
        return (FoodCapability)player.getCapability(FoodProvider.FOOD_CAPABILITY).orElse((Object)new FoodCapability());
    }

    public static BodyDamageCapability getBodyDamageCapability(Player player) {
        return (BodyDamageCapability)player.getCapability(BodyDamageProvider.BODY_DAMAGE_CAPABILITY).orElse((Object)new BodyDamageCapability());
    }
}

