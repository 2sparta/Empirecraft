/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.state.BlockState
 */
package sfiomn.legendarysurvivaloverhaul.util;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import sfiomn.legendarysurvivaloverhaul.config.Config;

public class SpreadPoint {
    private final BlockPos pos;
    private final Direction originDirection;
    private final double spreadCapacity;
    private final double influenceDistance;
    private final Level level;
    private final BlockState blockState;
    private final boolean loaded;
    private boolean canSeeSky;
    private boolean isWater;

    public SpreadPoint(BlockPos pos, Direction originDirection, double spreadCapacity, double influenceDistance, Level level) {
        this.pos = pos;
        this.originDirection = originDirection;
        this.spreadCapacity = spreadCapacity;
        this.influenceDistance = influenceDistance;
        this.level = level;
        this.loaded = !level.m_151570_(pos) && level.m_46805_(pos);
        this.blockState = this.loaded ? level.m_8055_(pos) : Blocks.f_50016_.m_49966_();
        this.canSeeSky = false;
        this.isWater = false;
    }

    public double influenceDistance() {
        return this.influenceDistance;
    }

    public BlockPos position() {
        return this.pos;
    }

    public BlockState blockState() {
        return this.blockState;
    }

    public boolean isLoaded() {
        return this.loaded;
    }

    public Direction originalDirection() {
        return this.originDirection;
    }

    public double spreadCapacity() {
        return this.spreadCapacity;
    }

    public SpreadPoint spreadTo(BlockPos newBlockPos, Direction originDirection, float distance) {
        return new SpreadPoint(newBlockPos, originDirection, this.spreadCapacity - (double)distance * this.consumptionMultiplier(originDirection), this.influenceDistance + (double)distance, this.level);
    }

    public boolean isValidSpreadPoint(Direction originDirection) {
        if (this.spreadCapacity <= 0.0 || !this.loaded) {
            return false;
        }
        if (this.blockState.m_60795_()) {
            return true;
        }
        if (this.blockState.m_60713_(Blocks.f_49990_)) {
            this.isWater = true;
            return true;
        }
        return !this.blockState.m_60783_((BlockGetter)this.level, this.pos, originDirection.m_122424_());
    }

    public boolean isValidSpreadDirection(Direction direction) {
        return this.loaded && !this.blockState.m_60783_((BlockGetter)this.level, this.pos, direction);
    }

    public void setCanSeeSky(boolean canSeeSky) {
        this.canSeeSky = canSeeSky;
    }

    private double consumptionMultiplier(Direction originDirection) {
        boolean upDirection = originDirection.m_122436_().m_123342_() > 0;
        double consumptionMultiplier = 1.0;
        if (this.isWater) {
            consumptionMultiplier *= Config.Baked.tempInfluenceInWaterDistMultiplier;
        } else if (this.canSeeSky) {
            consumptionMultiplier *= Config.Baked.tempInfluenceOutsideDistMultiplier;
        }
        if (upDirection) {
            consumptionMultiplier *= Config.Baked.tempInfluenceUpDistMultiplier;
        }
        return 1.0 / consumptionMultiplier;
    }
}

