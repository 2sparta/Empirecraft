/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.BufferBuilder
 *  com.mojang.blaze3d.vertex.DefaultVertexFormat
 *  com.mojang.blaze3d.vertex.Tesselator
 *  com.mojang.blaze3d.vertex.VertexFormat$Mode
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.resources.ResourceLocation
 *  org.joml.Matrix4f
 */
package sfiomn.legendarysurvivaloverhaul.util;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;

public final class RenderUtil {
    private RenderUtil() {
    }

    public static void drawTexturedModelRect(Matrix4f matrix, float x, float y, int width, int height, int texX, int texY, int texWidth, int texHeight) {
        float f = 0.00390625f;
        float f1 = 0.00390625f;
        float z = 0.0f;
        Tesselator tesselator = Tesselator.m_85913_();
        BufferBuilder bufferBuilder = tesselator.m_85915_();
        bufferBuilder.m_166779_(VertexFormat.Mode.QUADS, DefaultVertexFormat.f_85819_);
        bufferBuilder.m_252986_(matrix, x, y + (float)height, z).m_7421_((float)texX * f, (float)(texY + texHeight) * f1).m_6122_(255, 255, 255, 122).m_5752_();
        bufferBuilder.m_252986_(matrix, x + (float)width, y + (float)height, z).m_7421_((float)(texX + texWidth) * f, (float)(texY + texHeight) * f1).m_6122_(255, 255, 255, 122).m_5752_();
        bufferBuilder.m_252986_(matrix, x + (float)width, y, z).m_7421_((float)(texX + texWidth) * f, (float)texY * f1).m_6122_(255, 255, 255, 122).m_5752_();
        bufferBuilder.m_252986_(matrix, x, y, z).m_7421_((float)texX * f, (float)texY * f1).m_6122_(255, 255, 255, 255).m_5752_();
        tesselator.m_85914_();
    }

    public static void drawTexturedModelRectWithAlpha(Matrix4f matrix, float x, float y, int width, int height, int texX, int texY, int texWidth, int texHeight, float alpha) {
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask((boolean)false);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        RenderUtil.drawTexturedModelRect(matrix, x, y, width, height, texX, texY, texWidth, texHeight);
        RenderSystem.depthMask((boolean)true);
        RenderSystem.enableDepthTest();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public static void renderTextureOverlay(GuiGraphics gui, ResourceLocation resourceLocation, int screenWidth, int screenHeight, float alpha) {
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask((boolean)false);
        gui.m_280246_(1.0f, 1.0f, 1.0f, alpha);
        gui.m_280398_(resourceLocation, 0, 0, -90, 0.0f, 0.0f, screenWidth, screenHeight, screenWidth, screenHeight);
        RenderSystem.depthMask((boolean)true);
        RenderSystem.enableDepthTest();
        gui.m_280246_(1.0f, 1.0f, 1.0f, 1.0f);
    }
}

