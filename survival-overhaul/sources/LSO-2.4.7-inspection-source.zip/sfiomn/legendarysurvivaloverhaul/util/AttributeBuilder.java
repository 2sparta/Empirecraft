/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.entity.ai.attributes.AttributeInstance
 *  net.minecraft.world.entity.ai.attributes.AttributeModifier
 *  net.minecraft.world.entity.ai.attributes.AttributeModifier$Operation
 *  net.minecraft.world.entity.player.Player
 *  net.minecraftforge.event.ItemAttributeModifierEvent
 */
package sfiomn.legendarysurvivaloverhaul.util;

import java.util.UUID;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.ItemAttributeModifierEvent;

public class AttributeBuilder {
    protected final Attribute attribute;
    protected final String descriptionId;

    public AttributeBuilder(Attribute attribute, String descriptionId) {
        this.attribute = attribute;
        this.descriptionId = descriptionId;
    }

    public void addModifier(ItemAttributeModifierEvent event, UUID uuid, double value) {
        event.addModifier(this.attribute, new AttributeModifier(uuid, this.descriptionId, value, AttributeModifier.Operation.ADDITION));
    }

    public void addModifier(Player player, UUID uuid, double value) {
        AttributeInstance instance = player.m_21051_(this.attribute);
        if (instance != null) {
            instance.m_22120_(uuid);
            instance.m_22125_(new AttributeModifier(uuid, this.descriptionId, value, AttributeModifier.Operation.ADDITION));
        }
    }

    public AttributeInstance getAttribute(Player player) {
        return player.m_21051_(this.attribute);
    }
}

