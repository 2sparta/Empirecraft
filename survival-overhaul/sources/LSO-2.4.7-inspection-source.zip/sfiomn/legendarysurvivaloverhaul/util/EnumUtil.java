/*
 * Decompiled with CFR 0.152.
 */
package sfiomn.legendarysurvivaloverhaul.util;

public class EnumUtil {

    public static enum temperatureDisplayMode {
        SYMBOL,
        NONE;

    }

    public static enum bodyPartHealthMode {
        SIMPLE,
        DYNAMIC;

    }

    public static enum limbRegenerationMode {
        SIMPLE,
        PLAYER_DYNAMIC,
        LIMB_DYNAMIC;

    }

    public static enum brokenHeartsPerInjuredLimbMode {
        SIMPLE,
        PLAYER_DYNAMIC,
        LIMB_DYNAMIC;

    }

    public static enum DifficultyMode {
        PEACEFUL,
        EASY,
        NORMAL,
        HARD;

    }

    public static enum CompassInfo {
        FULL,
        HORIZONTAL,
        NONE;

    }
}

