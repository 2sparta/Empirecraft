/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Holder
 *  net.minecraft.core.Registry
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.damagesource.DamageType
 *  net.minecraft.world.level.Level
 */
package sfiomn.legendarysurvivaloverhaul.util;

import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.level.Level;

public class DamageSourceUtil {
    private DamageSourceUtil() {
    }

    private static Registry<DamageType> damageTypes(Level level) {
        return level.m_9598_().m_175515_(Registries.f_268580_);
    }

    public static DamageSource getDamageSource(Level level, ResourceKey<DamageType> damageType) {
        return new DamageSource((Holder)DamageSourceUtil.damageTypes(level).m_246971_(damageType));
    }
}

