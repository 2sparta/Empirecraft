/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.entity.player.Player
 *  net.minecraftforge.common.ForgeMod
 *  net.minecraftforge.network.NetworkDirection
 *  net.minecraftforge.network.NetworkEvent$Context
 */
package sfiomn.legendarysurvivaloverhaul.network.packets;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonThirstBlock;
import sfiomn.legendarysurvivaloverhaul.api.thirst.ThirstUtil;
import sfiomn.legendarysurvivaloverhaul.network.NetworkHandler;

public class DrinkBlockFluidMessage {
    public static void encode(DrinkBlockFluidMessage message, FriendlyByteBuf buffer) {
    }

    public static DrinkBlockFluidMessage decode(FriendlyByteBuf buffer) {
        return new DrinkBlockFluidMessage();
    }

    public static void handle(DrinkBlockFluidMessage message, Supplier<NetworkEvent.Context> supplier) {
        ServerPlayer player;
        NetworkEvent.Context context = supplier.get();
        if (context.getDirection() == NetworkDirection.PLAY_TO_SERVER && (player = context.getSender()) != null) {
            context.enqueueWork(() -> DrinkBlockFluidMessage.DrinkWaterOnServer(player));
        }
        supplier.get().setPacketHandled(true);
    }

    public static void DrinkWaterOnServer(ServerPlayer player) {
        JsonThirstBlock jsonFluidThirst = ThirstUtil.getFluidThirstLookedAt((Player)player, Math.max(3.0, player.m_21133_((Attribute)ForgeMod.BLOCK_REACH.get()) / 2.0));
        if (jsonFluidThirst == null) {
            return;
        }
        ThirstUtil.takeDrink((Player)player, jsonFluidThirst.hydration, jsonFluidThirst.saturation, jsonFluidThirst.effects);
    }

    public static void sendToServer() {
        DrinkBlockFluidMessage messageDrinkToServer = new DrinkBlockFluidMessage();
        NetworkHandler.INSTANCE.sendToServer((Object)messageDrinkToServer);
    }
}

