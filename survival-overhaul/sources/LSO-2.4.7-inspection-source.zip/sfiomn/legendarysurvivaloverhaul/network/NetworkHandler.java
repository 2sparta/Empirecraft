/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.network.NetworkRegistry
 *  net.minecraftforge.network.simple.SimpleChannel
 */
package sfiomn.legendarysurvivaloverhaul.network;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import sfiomn.legendarysurvivaloverhaul.network.packets.BodyPartHealingTimeMessage;
import sfiomn.legendarysurvivaloverhaul.network.packets.DrinkBlockFluidMessage;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncBodyDamageHealingConsumablesPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncBodyPartResistanceItemsPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncBodyPartsDamageSourcesPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncTemperatureBiomesPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncTemperatureBlocksPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncTemperatureConsumableBlocksPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncTemperatureConsumablesPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncTemperatureDimensionsPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncTemperatureFuelItemsPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncTemperatureItemsPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncTemperatureMountsPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncTemperatureOriginsPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncThirstBlocksPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncThirstConsumablesPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.UpdateBodyDamagePacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.UpdateHeartsPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.UpdateTemperaturesPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.UpdateThirstPacket;
import sfiomn.legendarysurvivaloverhaul.network.packets.UpdateWetnessPacket;

public class NetworkHandler {
    private static final String PROTOCOL_VERSION = "1";
    public static final SimpleChannel INSTANCE = NetworkRegistry.newSimpleChannel((ResourceLocation)new ResourceLocation("legendarysurvivaloverhaul", "main"), () -> "1", "1"::equals, "1"::equals);

    public static void register() {
        int id = -1;
        INSTANCE.registerMessage(id++, UpdateTemperaturesPacket.class, UpdateTemperaturesPacket::encode, UpdateTemperaturesPacket::decode, UpdateTemperaturesPacket::handle);
        INSTANCE.registerMessage(id++, UpdateWetnessPacket.class, UpdateWetnessPacket::encode, UpdateWetnessPacket::decode, UpdateWetnessPacket::handle);
        INSTANCE.registerMessage(id++, UpdateThirstPacket.class, UpdateThirstPacket::encode, UpdateThirstPacket::decode, UpdateThirstPacket::handle);
        INSTANCE.registerMessage(id++, UpdateHeartsPacket.class, UpdateHeartsPacket::encode, UpdateHeartsPacket::decode, UpdateHeartsPacket::handle);
        INSTANCE.registerMessage(id++, UpdateBodyDamagePacket.class, UpdateBodyDamagePacket::encode, UpdateBodyDamagePacket::decode, UpdateBodyDamagePacket::handle);
        INSTANCE.registerMessage(id++, DrinkBlockFluidMessage.class, DrinkBlockFluidMessage::encode, DrinkBlockFluidMessage::decode, DrinkBlockFluidMessage::handle);
        INSTANCE.registerMessage(id++, BodyPartHealingTimeMessage.class, BodyPartHealingTimeMessage::encode, BodyPartHealingTimeMessage::decode, BodyPartHealingTimeMessage::handle);
        INSTANCE.registerMessage(id++, SyncTemperatureConsumablesPacket.class, SyncTemperatureConsumablesPacket::encode, SyncTemperatureConsumablesPacket::decode, SyncTemperatureConsumablesPacket::handle);
        INSTANCE.registerMessage(id++, SyncTemperatureConsumableBlocksPacket.class, SyncTemperatureConsumableBlocksPacket::encode, SyncTemperatureConsumableBlocksPacket::decode, SyncTemperatureConsumableBlocksPacket::handle);
        INSTANCE.registerMessage(id++, SyncTemperatureBlocksPacket.class, SyncTemperatureBlocksPacket::encode, SyncTemperatureBlocksPacket::decode, SyncTemperatureBlocksPacket::handle);
        INSTANCE.registerMessage(id++, SyncTemperatureItemsPacket.class, SyncTemperatureItemsPacket::encode, SyncTemperatureItemsPacket::decode, SyncTemperatureItemsPacket::handle);
        INSTANCE.registerMessage(id++, SyncTemperatureBiomesPacket.class, SyncTemperatureBiomesPacket::encode, SyncTemperatureBiomesPacket::decode, SyncTemperatureBiomesPacket::handle);
        INSTANCE.registerMessage(id++, SyncTemperatureFuelItemsPacket.class, SyncTemperatureFuelItemsPacket::encode, SyncTemperatureFuelItemsPacket::decode, SyncTemperatureFuelItemsPacket::handle);
        INSTANCE.registerMessage(id++, SyncTemperatureMountsPacket.class, SyncTemperatureMountsPacket::encode, SyncTemperatureMountsPacket::decode, SyncTemperatureMountsPacket::handle);
        INSTANCE.registerMessage(id++, SyncTemperatureDimensionsPacket.class, SyncTemperatureDimensionsPacket::encode, SyncTemperatureDimensionsPacket::decode, SyncTemperatureDimensionsPacket::handle);
        INSTANCE.registerMessage(id++, SyncTemperatureOriginsPacket.class, SyncTemperatureOriginsPacket::encode, SyncTemperatureOriginsPacket::decode, SyncTemperatureOriginsPacket::handle);
        INSTANCE.registerMessage(id++, SyncThirstBlocksPacket.class, SyncThirstBlocksPacket::encode, SyncThirstBlocksPacket::decode, SyncThirstBlocksPacket::handle);
        INSTANCE.registerMessage(id++, SyncThirstConsumablesPacket.class, SyncThirstConsumablesPacket::encode, SyncThirstConsumablesPacket::decode, SyncThirstConsumablesPacket::handle);
        INSTANCE.registerMessage(id++, SyncBodyDamageHealingConsumablesPacket.class, SyncBodyDamageHealingConsumablesPacket::encode, SyncBodyDamageHealingConsumablesPacket::decode, SyncBodyDamageHealingConsumablesPacket::handle);
        INSTANCE.registerMessage(id++, SyncBodyPartsDamageSourcesPacket.class, SyncBodyPartsDamageSourcesPacket::encode, SyncBodyPartsDamageSourcesPacket::decode, SyncBodyPartsDamageSourcesPacket::handle);
        INSTANCE.registerMessage(id++, SyncBodyPartResistanceItemsPacket.class, SyncBodyPartResistanceItemsPacket::encode, SyncBodyPartResistanceItemsPacket::decode, SyncBodyPartResistanceItemsPacket::handle);
    }
}

