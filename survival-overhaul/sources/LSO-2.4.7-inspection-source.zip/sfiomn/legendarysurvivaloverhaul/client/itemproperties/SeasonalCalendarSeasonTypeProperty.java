/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.client.renderer.item.ClampedItemPropertyFunction
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.biome.Biome
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.client.itemproperties;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.item.ClampedItemPropertyFunction;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.common.integration.sereneseasons.SereneSeasonsUtil;

public class SeasonalCalendarSeasonTypeProperty
implements ClampedItemPropertyFunction {
    @OnlyIn(value=Dist.CLIENT)
    public float m_142187_(@NotNull ItemStack itemStack, @Nullable ClientLevel clientLevel, @Nullable LivingEntity entity, int i) {
        LivingEntity holder;
        ClientLevel level = clientLevel;
        Object object = holder = entity != null ? entity : itemStack.m_41795_();
        if (level == null && holder != null) {
            level = holder.m_9236_();
        }
        if (level == null || holder == null) {
            return 0.9f;
        }
        try {
            float d0 = 0.0f;
            if (LegendarySurvivalOverhaul.sereneSeasonsLoaded) {
                if (!SereneSeasonsUtil.hasSeasons((Level)level)) {
                    return 0.9f;
                }
                SereneSeasonsUtil.SeasonType seasonType = SereneSeasonsUtil.getSeasonType((Holder<Biome>)level.m_204166_(holder.m_20183_()));
                d0 = seasonType.propertyValue;
            } else if (LegendarySurvivalOverhaul.eclipticSeasonsLoaded) {
                d0 = 0.3f;
            }
            return d0;
        }
        catch (NullPointerException e) {
            return 0.9f;
        }
    }
}

