/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.client.renderer.item.ClampedItemPropertyFunction
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.client.itemproperties;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.item.ClampedItemPropertyFunction;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureEnum;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureUtil;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.temperature.TemperatureItemCapability;
import sfiomn.legendarysurvivaloverhaul.util.CapabilityUtil;

public class ThermometerProperty
implements ClampedItemPropertyFunction {
    @OnlyIn(value=Dist.CLIENT)
    public float m_142187_(@NotNull ItemStack itemStack, @Nullable ClientLevel clientLevel, @Nullable LivingEntity entity, int i) {
        LivingEntity holder;
        ClientLevel level = clientLevel;
        Object object = holder = entity != null ? entity : itemStack.m_41795_();
        if (level == null && holder != null) {
            level = holder.m_9236_();
        }
        if (level == null) {
            return 0.5f;
        }
        try {
            TemperatureItemCapability tempItemCap = CapabilityUtil.getTempItemCapability(itemStack);
            if (holder != null && tempItemCap.shouldUpdate(level.m_46467_())) {
                tempItemCap.updateWorldTemperature((Level)level, (Entity)holder, level.m_46467_());
            }
            return Mth.m_14091_((float)(TemperatureUtil.clampTemperature((int)tempItemCap.getWorldTemperatureLevel()) / TemperatureEnum.getMax()), (float)1.0333333f);
        }
        catch (NullPointerException e) {
            return 0.5f;
        }
    }
}

