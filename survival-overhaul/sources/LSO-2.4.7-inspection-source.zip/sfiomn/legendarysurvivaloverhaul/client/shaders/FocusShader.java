/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.shaders.Uniform
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.PostChain
 *  net.minecraft.client.renderer.PostPass
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.fml.util.ObfuscationReflectionHelper
 */
package sfiomn.legendarysurvivaloverhaul.client.shaders;

import com.mojang.blaze3d.shaders.Uniform;
import java.lang.reflect.Field;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;

public class FocusShader {
    public static final ResourceLocation BLUR_SHADER = new ResourceLocation("shaders/post/blobs2.json");
    private static final Field shaders = ObfuscationReflectionHelper.findField(PostChain.class, (String)"f_110009_");

    public void render(float intensity) {
        if (intensity > 0.0f) {
            PostChain currentEffect = Minecraft.m_91087_().f_91063_.m_109149_();
            if (currentEffect == null || !currentEffect.m_110022_().equals("minecraft:shaders/post/blobs2.json")) {
                try {
                    Minecraft.m_91087_().f_91063_.m_109128_(BLUR_SHADER);
                }
                catch (NullPointerException e) {
                    return;
                }
            }
            this.updateIntensity(intensity);
        }
    }

    public void stopRender() {
        PostChain currentEffect = Minecraft.m_91087_().f_91063_.m_109149_();
        if (currentEffect != null && currentEffect.m_110022_().equals("minecraft:shaders/post/blobs2.json")) {
            Minecraft.m_91087_().f_91063_.m_109086_();
        }
    }

    @OnlyIn(value=Dist.CLIENT)
    public void updateIntensity(float intensity) {
        Uniform shaderRadius;
        try {
            shaderRadius = ((PostPass)((List)shaders.get(Minecraft.m_91087_().f_91063_.m_109149_())).get(0)).m_110074_().m_108952_("Radius");
        }
        catch (IllegalAccessException | IllegalArgumentException | NullPointerException e) {
            shaderRadius = null;
        }
        if (shaderRadius != null) {
            shaderRadius.m_5985_(intensity);
        }
    }
}

