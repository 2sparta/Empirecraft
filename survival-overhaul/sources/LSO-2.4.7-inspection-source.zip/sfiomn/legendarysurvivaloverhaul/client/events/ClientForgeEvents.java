/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraft.client.gui.screens.TitleScreen
 *  net.minecraft.client.player.LocalPlayer
 *  net.minecraft.network.chat.Component
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.item.MapItem
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.saveddata.maps.MapItemSavedData
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.client.event.CustomizeGuiOverlayEvent$DebugText
 *  net.minecraftforge.client.event.RenderGuiOverlayEvent$Pre
 *  net.minecraftforge.client.event.RenderLevelStageEvent
 *  net.minecraftforge.client.event.RenderLevelStageEvent$Stage
 *  net.minecraftforge.client.gui.overlay.VanillaGuiOverlay
 *  net.minecraftforge.common.ForgeMod
 *  net.minecraftforge.event.TickEvent$ClientTickEvent
 *  net.minecraftforge.event.TickEvent$Phase
 *  net.minecraftforge.event.entity.EntityJoinLevelEvent
 *  net.minecraftforge.event.entity.player.BonemealEvent
 *  net.minecraftforge.event.entity.player.PlayerInteractEvent$RightClickEmpty
 *  net.minecraftforge.event.entity.player.PlayerInteractEvent$RightClickItem
 *  net.minecraftforge.eventbus.api.EventPriority
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 *  net.minecraftforge.registries.ForgeRegistries
 *  sereneseasons.api.SSItems
 */
package sfiomn.legendarysurvivaloverhaul.client.events;

import java.util.ListIterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.CustomizeGuiOverlayEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.player.BonemealEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import sereneseasons.api.SSItems;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonThirstBlock;
import sfiomn.legendarysurvivaloverhaul.api.thirst.ThirstUtil;
import sfiomn.legendarysurvivaloverhaul.client.ClientHooks;
import sfiomn.legendarysurvivaloverhaul.client.effects.TemperatureBreathEffect;
import sfiomn.legendarysurvivaloverhaul.client.integration.sereneseasons.RenderSeasonCards;
import sfiomn.legendarysurvivaloverhaul.client.render.RenderBlurOverlay;
import sfiomn.legendarysurvivaloverhaul.client.render.RenderBodyDamageGui;
import sfiomn.legendarysurvivaloverhaul.client.render.RenderTemperatureGui;
import sfiomn.legendarysurvivaloverhaul.client.render.RenderTemperatureOverlay;
import sfiomn.legendarysurvivaloverhaul.client.render.RenderThirstGui;
import sfiomn.legendarysurvivaloverhaul.client.render.RenderWetnessGui;
import sfiomn.legendarysurvivaloverhaul.client.screens.WarningDataPackScreen;
import sfiomn.legendarysurvivaloverhaul.client.sounds.TemperatureBreathSound;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.thirst.ThirstCapability;
import sfiomn.legendarysurvivaloverhaul.common.events.CommonForgeEvents;
import sfiomn.legendarysurvivaloverhaul.common.integration.curios.CuriosUtil;
import sfiomn.legendarysurvivaloverhaul.common.integration.sereneseasons.SereneSeasonsUtil;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.config.json_old.JsonConfigRegistration;
import sfiomn.legendarysurvivaloverhaul.network.packets.DrinkBlockFluidMessage;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.KeyMappingRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;
import sfiomn.legendarysurvivaloverhaul.util.CapabilityUtil;
import sfiomn.legendarysurvivaloverhaul.util.ItemUtil;
import sfiomn.legendarysurvivaloverhaul.util.WorldUtil;

@Mod.EventBusSubscriber(modid="legendarysurvivaloverhaul", bus=Mod.EventBusSubscriber.Bus.FORGE, value={Dist.CLIENT})
public class ClientForgeEvents {
    public static boolean hasOpened = false;
    public static int warningPageDelay = 40;

    @SubscribeEvent
    public static void onItemRightClick(PlayerInteractEvent.RightClickItem event) {
        String deathLocation;
        LocalPlayer player = Minecraft.m_91087_().f_91074_;
        if (player == null) {
            return;
        }
        Item heldItem = event.getItemStack().m_41720_();
        if (LegendarySurvivalOverhaul.sereneSeasonsLoaded && heldItem == SSItems.CALENDAR) {
            player.m_5661_(SereneSeasonsUtil.seasonTooltip(player.m_20183_(), player.m_9236_()), true);
        } else if (heldItem == Items.f_42524_) {
            player.m_5661_((Component)Component.m_237113_((String)WorldUtil.timeInGame(Minecraft.m_91087_())), true);
        } else if (heldItem == Items.f_42522_) {
            String compassLocation = ItemUtil.compassLocation((Entity)player);
            if (!compassLocation.isEmpty()) {
                player.m_5661_((Component)Component.m_237113_((String)compassLocation), true);
            }
        } else if (Config.Baked.showCoordinateOnMap && heldItem == Items.f_42573_) {
            MapItemSavedData mapData = MapItem.m_42853_((ItemStack)event.getItemStack(), (Level)event.getLevel());
            if (mapData != null) {
                player.m_5661_((Component)Component.m_237110_((String)"message.legendarysurvivaloverhaul.filled_map.destination", (Object[])new Object[]{mapData.f_256718_, mapData.f_256789_}), true);
            }
        } else if (heldItem == Items.f_220211_ && !(deathLocation = ItemUtil.compassDeathLocation((Player)player)).isEmpty()) {
            player.m_5661_((Component)Component.m_237113_((String)deathLocation), true);
        }
    }

    @SubscribeEvent(priority=EventPriority.HIGH)
    public static void onApplyBonemeal(BonemealEvent event) {
        Block plant = event.getBlock().m_60734_();
        if (event.getEntity() == null || ForgeRegistries.BLOCKS.getKey((Object)plant) == null) {
            return;
        }
        if (LegendarySurvivalOverhaul.sereneSeasonsLoaded && !SereneSeasonsUtil.plantCanGrow(event.getLevel(), event.getPos(), event.getBlock())) {
            event.getEntity().m_5661_((Component)Component.m_237115_((String)"message.legendarysurvivaloverhaul.bonemeal.not_correct_season"), true);
        }
    }

    @SubscribeEvent
    public static void onRightClickEmpty(PlayerInteractEvent.RightClickEmpty event) {
        JsonThirstBlock jsonFluidThirst;
        Player player;
        ThirstCapability thirstCapability;
        if (ClientForgeEvents.shouldApplyThirst(event.getEntity()) && event.getHand() == InteractionHand.MAIN_HAND && event.getEntity().m_21205_().m_41619_() && !(thirstCapability = CapabilityUtil.getThirstCapability(player = event.getEntity())).isHydrationLevelAtMax() && (jsonFluidThirst = ThirstUtil.getFluidThirstLookedAt(player, Math.max(3.0, player.m_21133_((Attribute)ForgeMod.BLOCK_REACH.get()) / 2.0))) != null && (jsonFluidThirst.hydration != 0 || jsonFluidThirst.saturation != 0.0f)) {
            CommonForgeEvents.playerDrinkEffect(event.getEntity());
            DrinkBlockFluidMessage.sendToServer();
        }
    }

    @SubscribeEvent
    public static void preRenderGameOverlay(RenderGuiOverlayEvent.Pre event) {
        if (event.getOverlay() == VanillaGuiOverlay.FOOD_LEVEL.type() && Minecraft.m_91087_().f_91074_ != null && Minecraft.m_91087_().f_91074_.m_21023_((MobEffect)MobEffectRegistry.COLD_HUNGER.get())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onRenderOverlayEventHideDebugInfo(CustomizeGuiOverlayEvent.DebugText event) {
        Object line;
        LocalPlayer player = Minecraft.m_91087_().f_91074_;
        if (player == null || player.m_7500_() || player.m_5833_() || !Config.Baked.hideInfoFromDebug) {
            return;
        }
        ListIterator<Object> it = event.getRight().listIterator();
        while (it.hasNext()) {
            line = (String)it.next();
            if (!((String)line).contains("Targeted")) continue;
            line = ((String)line).split(":")[0] + ":";
            it.remove();
            it.add(line);
        }
        it = event.getLeft().listIterator();
        while (it.hasNext()) {
            line = (String)it.next();
            if (((String)line).contains("XYZ:")) {
                line = Component.m_237115_((String)"message.legendarysurvivaloverhaul.warning_use_compass").getString();
                it.remove();
                it.add(line);
            }
            if (!((String)line).startsWith("Chunk:") && !((String)line).startsWith("Block:") && !((String)line).startsWith("Facing:")) continue;
            it.remove();
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            LocalPlayer player = Minecraft.m_91087_().f_91074_;
            if (!Minecraft.m_91087_().m_91104_() && player != null) {
                if (Config.Baked.temperatureEnabled) {
                    RenderTemperatureGui.updateTimer();
                    RenderTemperatureOverlay.updateTemperatureEffect((Player)player);
                    if (Config.Baked.coldBreathEffectThreshold != -1000.0) {
                        TemperatureBreathEffect.tickPlay((Player)player);
                    }
                    if (Config.Baked.breathingSoundEnabled) {
                        TemperatureBreathSound.tickPlay((Player)player);
                    }
                }
                if (Config.Baked.wetnessEnabled) {
                    RenderWetnessGui.updateTimer();
                }
                if (ClientForgeEvents.shouldApplyThirst((Player)player) && Config.Baked.lowHydrationEffect) {
                    RenderBlurOverlay.updateBlurIntensity((Player)player);
                }
                if (LegendarySurvivalOverhaul.sereneSeasonsLoaded && Config.Baked.ssSeasonCardsEnabled) {
                    RenderSeasonCards.updateSeasonCardFading((Player)player);
                }
                if (Config.Baked.localizedBodyDamageEnabled) {
                    RenderBodyDamageGui.updateFlashingTimer();
                    if (KeyMappingRegistry.showBodyHealth.m_90859_()) {
                        ClientHooks.openBodyHealthScreen((Player)player);
                    }
                }
                if (Config.Baked.thirstEnabled && Config.Baked.showDrinkPreview) {
                    RenderThirstGui.updateTimer();
                }
                if (LegendarySurvivalOverhaul.curiosLoaded && player.f_19797_ % 10 == 0) {
                    CuriosUtil.isThermometerEquipped = CuriosUtil.isCurioItemEquipped((Player)player, (Item)ItemRegistry.THERMOMETER.get());
                }
            }
        }
    }

    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void onClientTickLowest(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END && Minecraft.m_91087_().f_91080_ instanceof TitleScreen && (warningPageDelay = warningPageDelay > 0 ? warningPageDelay - 1 : 0) == 0 & !hasOpened && JsonConfigRegistration.customDatapackFolder.toFile().exists()) {
            Minecraft.m_91087_().m_91152_((Screen)new WarningDataPackScreen());
            hasOpened = true;
        }
    }

    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        LocalPlayer player = Minecraft.m_91087_().f_91074_;
        if (player != null && event.getStage() == RenderLevelStageEvent.Stage.AFTER_WEATHER && Config.Baked.lowHydrationEffect && ClientForgeEvents.shouldApplyThirst((Player)player)) {
            RenderBlurOverlay.render((Player)player);
        }
    }

    @SubscribeEvent
    public static void onPlayerJoinWorld(EntityJoinLevelEvent event) {
        if (event.getLevel().f_46443_ && event.getEntity() instanceof Player && LegendarySurvivalOverhaul.sereneSeasonsLoaded) {
            RenderSeasonCards.init();
        }
    }

    private static boolean shouldApplyThirst(Player player) {
        return Config.Baked.thirstEnabled && ThirstUtil.isThirstActive(player);
    }
}

