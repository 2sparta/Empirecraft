/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.particles.ParticleType
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.client.event.RegisterClientTooltipComponentFactoriesEvent
 *  net.minecraftforge.client.event.RegisterGuiOverlaysEvent
 *  net.minecraftforge.client.event.RegisterParticleProvidersEvent
 *  net.minecraftforge.client.gui.overlay.VanillaGuiOverlay
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 */
package sfiomn.legendarysurvivaloverhaul.client.events;

import net.minecraft.core.particles.ParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientTooltipComponentFactoriesEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import sfiomn.legendarysurvivaloverhaul.client.integration.sereneseasons.RenderSeasonCards;
import sfiomn.legendarysurvivaloverhaul.client.particles.BreathParticle;
import sfiomn.legendarysurvivaloverhaul.client.particles.FernBlossomParticle;
import sfiomn.legendarysurvivaloverhaul.client.render.RenderBodyDamageGui;
import sfiomn.legendarysurvivaloverhaul.client.render.RenderHealthGui;
import sfiomn.legendarysurvivaloverhaul.client.render.RenderTemperatureGui;
import sfiomn.legendarysurvivaloverhaul.client.render.RenderTemperatureOverlay;
import sfiomn.legendarysurvivaloverhaul.client.render.RenderThirstGui;
import sfiomn.legendarysurvivaloverhaul.client.render.RenderTooltipFrame;
import sfiomn.legendarysurvivaloverhaul.client.render.RenderWetnessGui;
import sfiomn.legendarysurvivaloverhaul.client.tooltips.HydrationClientTooltipComponent;
import sfiomn.legendarysurvivaloverhaul.client.tooltips.HydrationTooltipComponent;
import sfiomn.legendarysurvivaloverhaul.registry.ParticleTypeRegistry;

@Mod.EventBusSubscriber(modid="legendarysurvivaloverhaul", bus=Mod.EventBusSubscriber.Bus.MOD, value={Dist.CLIENT})
public class ClientModBusEvents {
    @SubscribeEvent
    public static void registerGuiOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAbove(VanillaGuiOverlay.PLAYER_HEALTH.id(), "health_overhaul", RenderHealthGui.HEALTH_GUI);
        event.registerBelow(VanillaGuiOverlay.FOOD_LEVEL.id(), "cold_hunger", RenderTemperatureGui.FOOD_BAR_COLD_EFFECT_GUI);
        event.registerAbove(VanillaGuiOverlay.FOOD_LEVEL.id(), "thirst", RenderThirstGui.THIRST_GUI);
        event.registerAbove(VanillaGuiOverlay.FOOD_LEVEL.id(), "temperature", RenderTemperatureGui.TEMPERATURE_GUI);
        event.registerAbove(VanillaGuiOverlay.FOOD_LEVEL.id(), "wetness", RenderWetnessGui.WETNESS_GUI);
        event.registerAbove(VanillaGuiOverlay.FOOD_LEVEL.id(), "body_damage", RenderBodyDamageGui.BODY_DAMAGE_GUI);
        event.registerAbove(VanillaGuiOverlay.FROSTBITE.id(), "temperature_overlay", RenderTemperatureOverlay.TEMPERATURE_OVERLAY);
        event.registerAbove(VanillaGuiOverlay.ITEM_NAME.id(), "item_frame_tooltip", RenderTooltipFrame.TOOLTIP_ITEM_FRAME);
        event.registerAbove(VanillaGuiOverlay.ITEM_NAME.id(), "season_card", RenderSeasonCards.SEASON_CARD_GUI);
    }

    @SubscribeEvent
    public static void onTooltipRegistration(RegisterClientTooltipComponentFactoriesEvent event) {
        event.register(HydrationTooltipComponent.class, component -> new HydrationClientTooltipComponent(component.hydration, component.saturation));
    }

    @SubscribeEvent
    public static void registerParticleFactories(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet((ParticleType)ParticleTypeRegistry.SUN_FERN_BLOSSOM.get(), FernBlossomParticle.Factory::new);
        event.registerSpriteSet((ParticleType)ParticleTypeRegistry.ICE_FERN_BLOSSOM.get(), FernBlossomParticle.Factory::new);
        event.registerSpriteSet((ParticleType)ParticleTypeRegistry.COLD_BREATH.get(), BreathParticle.Factory::new);
    }
}

