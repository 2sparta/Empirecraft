/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.resources.sounds.AbstractTickableSoundInstance
 *  net.minecraft.client.resources.sounds.SoundInstance
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.client.sounds;

import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;

public class DynamicPositionSound
extends AbstractTickableSoundInstance {
    private final Player player;
    private int time;

    public DynamicPositionSound(SoundEvent soundEvent, Player player) {
        super(soundEvent, SoundSource.PLAYERS, SoundInstance.m_235150_());
        this.player = player;
        this.f_119578_ = false;
        this.f_119573_ = 1.0f;
        this.time = 60;
    }

    public void m_7788_() {
        if (this.player.m_6084_() && this.time-- >= 0) {
            this.f_119575_ = this.player.m_20185_();
            this.f_119576_ = this.player.m_20186_();
            this.f_119577_ = this.player.m_20189_();
        } else {
            this.m_119609_();
        }
    }
}

