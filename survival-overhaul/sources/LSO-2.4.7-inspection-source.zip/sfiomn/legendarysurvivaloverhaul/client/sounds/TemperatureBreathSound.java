/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.resources.sounds.SoundInstance
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Position
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.entity.player.Player
 *  org.apache.commons.lang3.RandomUtils
 */
package sfiomn.legendarysurvivaloverhaul.client.sounds;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Position;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.player.Player;
import org.apache.commons.lang3.RandomUtils;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureEnum;
import sfiomn.legendarysurvivaloverhaul.client.sounds.DynamicPositionSound;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.SoundRegistry;
import sfiomn.legendarysurvivaloverhaul.util.CapabilityUtil;

public class TemperatureBreathSound {
    private static int delay = 200 + RandomUtils.nextInt((int)0, (int)200);
    private static boolean reset;

    public static void tickPlay(Player player) {
        if (player == null || !player.m_6084_() || player.m_5833_() || player.m_7500_() || !player.m_9236_().m_8055_(BlockPos.m_274446_((Position)player.m_146892_())).m_60795_()) {
            return;
        }
        TemperatureEnum temperatureEnum = CapabilityUtil.getTempCapability(player).getTemperatureEnum();
        boolean isFrostbite = temperatureEnum == TemperatureEnum.FROSTBITE;
        boolean isHeatStroke = temperatureEnum == TemperatureEnum.HEAT_STROKE;
        boolean hasColdImmunity = player.m_21023_((MobEffect)MobEffectRegistry.COLD_IMMUNITY.get());
        boolean hasHeatImmunity = player.m_21023_((MobEffect)MobEffectRegistry.HEAT_IMMUNITY.get());
        if (isFrostbite && hasColdImmunity || isHeatStroke && hasHeatImmunity || !isFrostbite && !isHeatStroke) {
            TemperatureBreathSound.reset(player);
            return;
        }
        reset = false;
        if (delay-- <= 0) {
            delay = 200 + player.m_217043_().m_188503_(200);
            if (isFrostbite) {
                Minecraft.m_91087_().m_91106_().m_120367_((SoundInstance)new DynamicPositionSound((SoundEvent)SoundRegistry.SHIVERING.get(), player));
            } else {
                Minecraft.m_91087_().m_91106_().m_120367_((SoundInstance)new DynamicPositionSound((SoundEvent)SoundRegistry.PANTING.get(), player));
            }
        }
    }

    public static void reset(Player player) {
        if (!reset) {
            delay = 200 + player.m_217043_().m_188503_(200);
            reset = true;
        }
    }
}

