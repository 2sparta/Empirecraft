/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.player.LocalPlayer
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.world.entity.player.Player
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.client.gui.overlay.IGuiOverlay
 */
package sfiomn.legendarysurvivaloverhaul.client.render;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureEnum;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.temperature.TemperatureCapability;
import sfiomn.legendarysurvivaloverhaul.common.effects.FrostbiteEffect;
import sfiomn.legendarysurvivaloverhaul.common.effects.HeatStrokeEffect;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.registry.SoundRegistry;
import sfiomn.legendarysurvivaloverhaul.util.CapabilityUtil;
import sfiomn.legendarysurvivaloverhaul.util.MathUtil;
import sfiomn.legendarysurvivaloverhaul.util.RenderUtil;

@OnlyIn(value=Dist.CLIENT)
public class RenderTemperatureOverlay {
    private static TemperatureCapability TEMPERATURE_CAP = null;
    private static final ResourceLocation FROSTBITE_EFFECT = new ResourceLocation("legendarysurvivaloverhaul", "textures/gui/freeze_effect.png");
    private static final ResourceLocation HEAT_STROKE_EFFECT = new ResourceLocation("legendarysurvivaloverhaul", "textures/gui/heat_effect.png");
    private static ResourceLocation temperatureEffect = null;
    private static float fadeLevel = 0.0f;
    private static boolean triggerTemperatureSoundEffect;
    public static IGuiOverlay TEMPERATURE_OVERLAY;

    public static void updateTemperatureEffect(Player player) {
        if (player != null && player.m_6084_()) {
            float targetFadeLevel;
            boolean heatstrokeLimit;
            if (TEMPERATURE_CAP == null || player.f_19797_ % 20 == 0) {
                TEMPERATURE_CAP = CapabilityUtil.getTempCapability(player);
            }
            float temperature = TEMPERATURE_CAP.getTemperatureLevel();
            TemperatureEnum tempEnum = TEMPERATURE_CAP.getTemperatureEnum();
            boolean frostbiteLimit = temperature <= TemperatureEnum.FROSTBITE.getValue() + 1.0f;
            boolean bl = heatstrokeLimit = temperature >= TemperatureEnum.HEAT_STROKE.getValue() - 1.0f;
            if (Config.Baked.coldTemperatureOverlay && tempEnum == TemperatureEnum.FROSTBITE && !FrostbiteEffect.playerIsImmuneToFrost(player)) {
                temperatureEffect = FROSTBITE_EFFECT;
                if (frostbiteLimit) {
                    targetFadeLevel = 0.75f;
                    if (triggerTemperatureSoundEffect) {
                        triggerTemperatureSoundEffect = false;
                        player.m_5496_((SoundEvent)SoundRegistry.FROSTBITE.get(), 1.0f, 1.0f);
                    }
                } else {
                    targetFadeLevel = 0.35f;
                    triggerTemperatureSoundEffect = true;
                    if (fadeLevel == 0.0f) {
                        player.m_5496_((SoundEvent)SoundRegistry.FROSTBITE_EARLY.get(), 1.0f, 1.0f);
                    }
                }
            } else if (Config.Baked.heatTemperatureOverlay && tempEnum == TemperatureEnum.HEAT_STROKE && !HeatStrokeEffect.playerIsImmuneToHeat(player)) {
                temperatureEffect = HEAT_STROKE_EFFECT;
                if (heatstrokeLimit) {
                    targetFadeLevel = 0.6f;
                    if (triggerTemperatureSoundEffect) {
                        triggerTemperatureSoundEffect = false;
                        player.m_5496_((SoundEvent)SoundRegistry.HEAT_STROKE.get(), 1.0f, 1.0f);
                    }
                } else {
                    targetFadeLevel = 0.25f;
                    triggerTemperatureSoundEffect = true;
                    if (fadeLevel == 0.0f) {
                        player.m_5496_((SoundEvent)SoundRegistry.HEAT_STROKE_EARLY.get(), 1.0f, 1.0f);
                    }
                }
            } else {
                triggerTemperatureSoundEffect = true;
                targetFadeLevel = 0.0f;
            }
            if (targetFadeLevel > fadeLevel) {
                fadeLevel = Math.min(targetFadeLevel, fadeLevel + MathUtil.round(0.05f, 2));
            }
            if (targetFadeLevel < fadeLevel) {
                fadeLevel = Math.max(targetFadeLevel, fadeLevel - MathUtil.round(0.05f, 2));
            }
            if (fadeLevel == 0.0f) {
                temperatureEffect = null;
            }
        }
    }

    static {
        TEMPERATURE_OVERLAY = (forgeGui, guiGraphics, partialTicks, width, height) -> {
            LocalPlayer player;
            if (Config.Baked.temperatureEnabled && temperatureEffect != null && (player = forgeGui.getMinecraft().f_91074_) != null && temperatureEffect != null && !player.m_7500_() && !player.m_5833_()) {
                forgeGui.setupOverlayRenderState(true, false);
                RenderUtil.renderTextureOverlay(guiGraphics, temperatureEffect, width, height, fadeLevel);
            }
        };
    }
}

