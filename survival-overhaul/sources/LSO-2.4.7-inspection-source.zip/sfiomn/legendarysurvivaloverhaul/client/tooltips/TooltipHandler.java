/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.util.Either
 *  net.minecraft.ChatFormatting
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraft.network.chat.Component
 *  net.minecraft.network.chat.ComponentContents
 *  net.minecraft.network.chat.FormattedText
 *  net.minecraft.network.chat.MutableComponent
 *  net.minecraft.network.chat.Style
 *  net.minecraft.network.chat.TextColor
 *  net.minecraft.network.chat.contents.TranslatableContents
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.effect.MobEffectUtil
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.inventory.tooltip.TooltipComponent
 *  net.minecraft.world.item.ArmorItem
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.enchantment.Enchantment
 *  net.minecraft.world.item.enchantment.EnchantmentHelper
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.client.event.RenderTooltipEvent$GatherComponents
 *  net.minecraftforge.event.entity.player.ItemTooltipEvent
 *  net.minecraftforge.eventbus.api.EventPriority
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 *  net.minecraftforge.registries.ForgeRegistries
 */
package sfiomn.legendarysurvivaloverhaul.client.tooltips;

import com.mojang.datafixers.util.Either;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentContents;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectUtil;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderTooltipEvent;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonHealingConsumable;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonMobEffect;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureConsumable;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonThirstConsumable;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.BodyDamageDataManager;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.TemperatureDataManager;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.ThirstDataManager;
import sfiomn.legendarysurvivaloverhaul.api.item.CoatEnum;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureUtil;
import sfiomn.legendarysurvivaloverhaul.client.tooltips.HydrationTooltipComponent;
import sfiomn.legendarysurvivaloverhaul.common.integration.artifacts.ArtifactsUtil;
import sfiomn.legendarysurvivaloverhaul.common.integration.beachparty.BeachpartyUtil;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.CanteenItem;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.registry.AttributeRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.EnchantmentRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;
import sfiomn.legendarysurvivaloverhaul.util.MathUtil;

@Mod.EventBusSubscriber(modid="legendarysurvivaloverhaul", value={Dist.CLIENT}, bus=Mod.EventBusSubscriber.Bus.FORGE)
public class TooltipHandler {
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void onTooltip(ItemTooltipEvent event) {
        ItemStack stack = event.getItemStack();
        ResourceLocation itemRegistryName = ForgeRegistries.ITEMS.getKey((Object)stack.m_41720_());
        if (!stack.m_41619_() && itemRegistryName != null) {
            List tooltips = event.getToolTip();
            for (Component component : tooltips) {
                if (!(component instanceof MutableComponent)) continue;
                MutableComponent mutableComponent = (MutableComponent)component;
                if (TooltipHandler.componentHasOneOfKeys(component, ((Attribute)AttributeRegistry.HEATING_TEMPERATURE.get()).m_22087_(), ((Attribute)AttributeRegistry.HEAT_RESISTANCE.get()).m_22087_())) {
                    mutableComponent.m_130948_(Style.f_131099_.m_131148_(TextColor.m_131266_((int)16420407)));
                }
                if (TooltipHandler.componentHasOneOfKeys(component, ((Attribute)AttributeRegistry.COOLING_TEMPERATURE.get()).m_22087_(), ((Attribute)AttributeRegistry.COLD_RESISTANCE.get()).m_22087_())) {
                    mutableComponent.m_130948_(Style.f_131099_.m_131148_(TextColor.m_131266_((int)6466303)));
                }
                if (!TooltipHandler.componentHasOneOfKeys(component, ((Attribute)AttributeRegistry.THERMAL_RESISTANCE.get()).m_22087_())) continue;
                mutableComponent.m_130948_(Style.f_131099_.m_131148_(TextColor.m_131266_((int)0x9933FF)));
            }
            if (Config.Baked.temperatureEnabled) {
                TooltipHandler.mergeHandModifierSections(tooltips);
                if (stack.m_41720_() instanceof ArmorItem) {
                    TooltipHandler.addCoatTemperatureOnArmorText(stack, tooltips);
                }
                TooltipHandler.addFoodEffectText(stack, tooltips);
            }
            if (Config.Baked.localizedBodyDamageEnabled) {
                TooltipHandler.addHealingText(stack, tooltips);
            }
            if (LegendarySurvivalOverhaul.beachpartyLoaded) {
                TooltipHandler.addShadeText(stack, tooltips);
            }
        }
    }

    private static void mergeHandModifierSections(List<Component> tooltips) {
        int mainHandHeader = -1;
        int offHandHeader = -1;
        for (int i = 0; i < tooltips.size(); ++i) {
            String key = TooltipHandler.getTranslationKey(tooltips.get(i));
            if ("item.modifiers.mainhand".equals(key)) {
                mainHandHeader = i;
                continue;
            }
            if (!"item.modifiers.offhand".equals(key)) continue;
            offHandHeader = i;
        }
        if (mainHandHeader == -1 || offHandHeader == -1 || mainHandHeader > offHandHeader) {
            return;
        }
        String[] lsoAttributeKeys = new String[]{((Attribute)AttributeRegistry.HEATING_TEMPERATURE.get()).m_22087_(), ((Attribute)AttributeRegistry.COOLING_TEMPERATURE.get()).m_22087_(), ((Attribute)AttributeRegistry.HEAT_RESISTANCE.get()).m_22087_(), ((Attribute)AttributeRegistry.COLD_RESISTANCE.get()).m_22087_(), ((Attribute)AttributeRegistry.THERMAL_RESISTANCE.get()).m_22087_()};
        List<Component> mainHandLines = TooltipHandler.getAttributeSection(tooltips, mainHandHeader);
        List<Component> offHandLines = TooltipHandler.getAttributeSection(tooltips, offHandHeader);
        if (offHandLines.isEmpty() || mainHandLines.size() != offHandLines.size()) {
            return;
        }
        for (int i = 0; i < offHandLines.size(); ++i) {
            if (!TooltipHandler.componentHasOneOfKeys(offHandLines.get(i), lsoAttributeKeys)) {
                return;
            }
            if (offHandLines.get(i).getString().equals(mainHandLines.get(i).getString())) continue;
            return;
        }
        int removeFrom = offHandHeader;
        if (removeFrom > 0 && tooltips.get(removeFrom - 1).getString().isEmpty()) {
            --removeFrom;
        }
        tooltips.subList(removeFrom, offHandHeader + 1 + offHandLines.size()).clear();
        tooltips.set(mainHandHeader, (Component)Component.m_237115_((String)"tooltip.legendarysurvivaloverhaul.modifiers.hand").m_130940_(ChatFormatting.GRAY));
    }

    private static List<Component> getAttributeSection(List<Component> tooltips, int headerIndex) {
        String key;
        ArrayList<Component> lines = new ArrayList<Component>();
        for (int i = headerIndex + 1; i < tooltips.size() && (key = TooltipHandler.getTranslationKey(tooltips.get(i))) != null && key.startsWith("attribute.modifier."); ++i) {
            lines.add(tooltips.get(i));
        }
        return lines;
    }

    private static String getTranslationKey(Component component) {
        ComponentContents componentContents = component.m_214077_();
        if (componentContents instanceof TranslatableContents) {
            TranslatableContents translatableContents = (TranslatableContents)componentContents;
            return translatableContents.m_237508_();
        }
        return null;
    }

    @SubscribeEvent
    public static void onRenderTooltip(RenderTooltipEvent.GatherComponents event) {
        if (event.isCanceled()) {
            return;
        }
        Minecraft mc = Minecraft.m_91087_();
        Screen gui = mc.f_91080_;
        if (gui == null) {
            return;
        }
        if (Config.Baked.thirstEnabled && Config.Baked.showHydrationTooltip) {
            TooltipHandler.addHydrationTooltip(event.getItemStack(), event.getTooltipElements());
        }
    }

    private static boolean componentHasOneOfKeys(Component component, String ... keys) {
        TranslatableContents translatableContents;
        ComponentContents componentContents;
        if (component != null && (componentContents = component.m_214077_()) instanceof TranslatableContents && (translatableContents = (TranslatableContents)componentContents).m_237523_() != null) {
            return Arrays.stream(translatableContents.m_237523_()).anyMatch(s -> {
                MutableComponent mutableComponent;
                ComponentContents patt7557$temp;
                if (s instanceof MutableComponent && (patt7557$temp = (mutableComponent = (MutableComponent)s).m_214077_()) instanceof TranslatableContents) {
                    TranslatableContents translatableContents1 = (TranslatableContents)patt7557$temp;
                    for (String key : keys) {
                        if (!translatableContents1.m_237508_().equals(key)) continue;
                        return true;
                    }
                    return false;
                }
                return false;
            });
        }
        return false;
    }

    private static void addCoatTemperatureOnArmorText(ItemStack stack, List<Component> tooltips) {
        String coatId = TemperatureUtil.getArmorCoatTag(stack);
        CoatEnum coat = CoatEnum.getFromId(coatId);
        if (coat == null) {
            return;
        }
        MutableComponent text = Component.m_237115_((String)("tooltip.legendarysurvivaloverhaul.armor_coat." + coatId));
        text = Component.m_237113_((String)"").m_130940_(ChatFormatting.BLUE).m_7220_((Component)text);
        tooltips.add((Component)text);
    }

    private static void addFoodEffectText(ItemStack stack, List<Component> tooltips) {
        ResourceLocation itemRegistryName = ForgeRegistries.ITEMS.getKey((Object)stack.m_41720_());
        List<JsonTemperatureConsumable> jtcs = TemperatureDataManager.getConsumable(itemRegistryName);
        if (jtcs != null) {
            for (JsonTemperatureConsumable jtc : jtcs) {
                MobEffectInstance effectInstance = new MobEffectInstance(jtc.getEffect(), jtc.duration, Math.abs(jtc.temperatureLevel));
                MutableComponent mutableComponent = Component.m_237115_((String)effectInstance.m_19576_());
                if (Math.abs(jtc.temperatureLevel) > 1) {
                    mutableComponent = Component.m_237110_((String)"potion.withAmplifier", (Object[])new Object[]{mutableComponent, Component.m_237115_((String)("potion.potency." + (Math.abs(jtc.temperatureLevel) - 1)))});
                }
                if (jtc.duration > 20) {
                    mutableComponent = Component.m_237110_((String)"potion.withDuration", (Object[])new Object[]{mutableComponent, MobEffectUtil.m_267641_((MobEffectInstance)effectInstance, (float)1.0f)});
                }
                if (jtc.getEffect() == MobEffectRegistry.COLD_FOOD.get() || jtc.getEffect() == MobEffectRegistry.COLD_DRINK.get()) {
                    tooltips.add((Component)mutableComponent.m_130948_(Style.f_131099_.m_131148_(TextColor.m_131266_((int)6466303))));
                }
                if (jtc.getEffect() != MobEffectRegistry.HOT_FOOD.get() && jtc.getEffect() != MobEffectRegistry.HOT_DRINk.get()) continue;
                tooltips.add((Component)mutableComponent.m_130948_(Style.f_131099_.m_131148_(TextColor.m_131266_((int)16420407))));
            }
        }
    }

    private static void addHealingText(ItemStack stack, List<Component> tooltips) {
        ResourceLocation itemRegistryName = ForgeRegistries.ITEMS.getKey((Object)stack.m_41720_());
        JsonHealingConsumable jsonConsumableHeal = BodyDamageDataManager.getHealingItem(itemRegistryName);
        if (jsonConsumableHeal != null) {
            if (jsonConsumableHeal.healingCharges > 0) {
                tooltips.add((Component)Component.m_237110_((String)"tooltip.legendarysurvivaloverhaul.body_heal_item.body_part", (Object[])new Object[]{jsonConsumableHeal.healingCharges}).m_130940_(ChatFormatting.BLUE));
            } else if (jsonConsumableHeal.healingCharges == 0) {
                tooltips.add((Component)Component.m_237115_((String)"tooltip.legendarysurvivaloverhaul.body_heal_item.whole_body").m_130940_(ChatFormatting.BLUE));
            }
            tooltips.add((Component)Component.m_237110_((String)"tooltip.legendarysurvivaloverhaul.body_heal_item.healing_value", (Object[])new Object[]{Float.valueOf(jsonConsumableHeal.healingValue), Float.valueOf(MathUtil.round((float)jsonConsumableHeal.healingTime / 20.0f, 1))}).m_130940_(ChatFormatting.BLUE));
            MutableComponent mutableComponent = Component.m_237115_((String)((MobEffect)MobEffectRegistry.RECOVERY.get()).m_19481_());
            if (jsonConsumableHeal.recoveryEffectDuration > 0) {
                if (jsonConsumableHeal.recoveryEffectAmplifier > 0) {
                    mutableComponent = Component.m_237110_((String)"potion.withAmplifier", (Object[])new Object[]{mutableComponent, Component.m_237115_((String)("potion.potency." + jsonConsumableHeal.recoveryEffectAmplifier))});
                }
                MobEffectInstance mei = new MobEffectInstance((MobEffect)MobEffectRegistry.RECOVERY.get(), jsonConsumableHeal.recoveryEffectDuration, jsonConsumableHeal.recoveryEffectAmplifier);
                mutableComponent = Component.m_237110_((String)"potion.withDuration", (Object[])new Object[]{mutableComponent, MobEffectUtil.m_267641_((MobEffectInstance)mei, (float)1.0f)});
                tooltips.add((Component)mutableComponent.m_130948_(Style.f_131099_.m_131140_(ChatFormatting.BLUE)));
            }
        }
    }

    private static void addShadeText(ItemStack stack, List<Component> tooltips) {
        ResourceLocation itemRegistryName = ForgeRegistries.ITEMS.getKey((Object)stack.m_41720_());
        if (itemRegistryName != null && (BeachpartyUtil.canProvideShade(itemRegistryName) || ArtifactsUtil.canProvideShade(itemRegistryName))) {
            tooltips.add((Component)Component.m_237115_((String)"tooltip.legendarysurvivaloverhaul.provides_shade").m_130940_(ChatFormatting.WHITE));
        }
    }

    private static void addHydrationTooltip(ItemStack stack, List<Either<FormattedText, TooltipComponent>> tooltips) {
        JsonThirstConsumable jsonThirstConsumable = ThirstDataManager.getConsumable(stack);
        HydrationTooltipComponent hydrationTooltipComponent = null;
        ArrayList<MutableComponent> hydrationEffectComponents = new ArrayList<MutableComponent>();
        if (jsonThirstConsumable != null) {
            int refreshingLevel;
            int hydration = jsonThirstConsumable.hydration;
            float saturation = jsonThirstConsumable.saturation;
            if (stack.m_41720_() instanceof CanteenItem && CanteenItem.canDrink(stack) && (refreshingLevel = EnchantmentHelper.m_44843_((Enchantment)((Enchantment)EnchantmentRegistry.REFRESHING.get()), (ItemStack)stack)) > 0) {
                hydration += refreshingLevel;
                saturation += (float)Math.max(0, refreshingLevel - 1);
            }
            hydrationTooltipComponent = new HydrationTooltipComponent(hydration, saturation);
            for (JsonMobEffect effect : jsonThirstConsumable.effects) {
                if (!(effect.chance > 0.0f) || effect.duration <= 0 || effect.name.isEmpty()) continue;
                hydrationEffectComponents.add(TooltipHandler.getHydrationEffectTooltip(effect.chance, effect.name, effect.amplifier, effect.duration));
            }
        }
        if (hydrationTooltipComponent != null) {
            tooltips.add((Either<FormattedText, TooltipComponent>)Either.right(hydrationTooltipComponent));
        }
        for (MutableComponent hydrationEffectComponent : hydrationEffectComponents) {
            if (hydrationEffectComponent == null) continue;
            tooltips.add((Either<FormattedText, TooltipComponent>)Either.left((Object)hydrationEffectComponent));
        }
    }

    private static MutableComponent getHydrationEffectTooltip(double effectChance, String effectName, int amplifier, int duration) {
        MobEffect effect = null;
        if (effectName != null && !effectName.isEmpty() && effectChance > 0.0) {
            effect = (MobEffect)ForgeRegistries.MOB_EFFECTS.getValue(new ResourceLocation(effectName));
        }
        if (effect == null) {
            return null;
        }
        MobEffectInstance effectInstance = new MobEffectInstance(effect, duration, amplifier, false, true);
        MutableComponent mutableComponent = Component.m_237115_((String)effectInstance.m_19576_());
        if (effectInstance.m_19564_() > 1) {
            mutableComponent = Component.m_237110_((String)"potion.withAmplifier", (Object[])new Object[]{mutableComponent, Component.m_237115_((String)("potion.potency." + effectInstance.m_19564_()))});
        }
        if (effectInstance.m_19557_() > 20) {
            mutableComponent = Component.m_237110_((String)"potion.withDuration", (Object[])new Object[]{mutableComponent, MobEffectUtil.m_267641_((MobEffectInstance)effectInstance, (float)1.0f)});
        }
        if (effectChance < 1.0) {
            mutableComponent = Component.m_237110_((String)"tooltip.legendarysurvivaloverhaul.potion_with_effectChance", (Object[])new Object[]{(int)(effectChance * 100.0), mutableComponent});
        }
        return mutableComponent.m_130948_(Style.f_131099_.m_131140_(ChatFormatting.BLUE));
    }
}

