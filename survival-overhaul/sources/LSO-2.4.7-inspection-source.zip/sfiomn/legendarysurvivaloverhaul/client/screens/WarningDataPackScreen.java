/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.booleans.BooleanConsumer
 *  net.minecraft.Util
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.screens.ConfirmScreen
 *  net.minecraft.network.chat.Component
 */
package sfiomn.legendarysurvivaloverhaul.client.screens;

import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.network.chat.Component;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;

public class WarningDataPackScreen
extends ConfirmScreen {
    public WarningDataPackScreen() {
        super(WarningDataPackScreen.getButtonEffect(), (Component)Component.m_237115_((String)"screen.legendarysurvivaloverhaul.datapack_transfer.title"), (Component)Component.m_237115_((String)"screen.legendarysurvivaloverhaul.datapack_transfer.text"), (Component)Component.m_237115_((String)"screen.legendarysurvivaloverhaul.datapack_transfer.open_folder"), (Component)Component.m_237115_((String)"menu.returnToGame"));
    }

    private static BooleanConsumer getButtonEffect() {
        return confirmButton -> {
            if (confirmButton) {
                Util.m_137581_().m_137644_(LegendarySurvivalOverhaul.modConfigPath.toFile());
            } else {
                Minecraft.m_91087_().m_91152_(null);
            }
        };
    }
}

