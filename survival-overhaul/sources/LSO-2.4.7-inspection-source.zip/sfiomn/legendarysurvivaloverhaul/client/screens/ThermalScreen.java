/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.gui.screens.inventory.AbstractContainerScreen
 *  net.minecraft.client.renderer.GameRenderer
 *  net.minecraft.network.chat.Component
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.player.Inventory
 *  net.minecraft.world.inventory.AbstractContainerMenu
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.client.screens;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.api.block.ThermalTypeEnum;
import sfiomn.legendarysurvivaloverhaul.common.containers.AbstractThermalContainer;

@OnlyIn(value=Dist.CLIENT)
public class ThermalScreen
extends AbstractContainerScreen<AbstractThermalContainer> {
    public static final ResourceLocation HEATER_SCREEN = new ResourceLocation("legendarysurvivaloverhaul", "textures/gui/heater_screen.png");
    public static final ResourceLocation COOLER_SCREEN = new ResourceLocation("legendarysurvivaloverhaul", "textures/gui/cooler_screen.png");
    public static final int FUEL_LEVEL_WIDTH = 29;
    public static final int FUEL_LEVEL_HEIGHT = 27;

    public ThermalScreen(AbstractThermalContainer screenContainer, Inventory playerInventory, Component titleIn) {
        super((AbstractContainerMenu)screenContainer, playerInventory, titleIn);
    }

    protected void m_7856_() {
        super.m_7856_();
        this.f_97731_ = 10000;
        this.f_97729_ = 10000;
    }

    public void m_88315_(@NotNull GuiGraphics gui, int mouseX, int mouseY, float partialTicks) {
        this.m_280273_(gui);
        super.m_88315_(gui, mouseX, mouseY, partialTicks);
        this.m_280072_(gui, mouseX, mouseY);
    }

    protected void m_7286_(GuiGraphics gui, float partialTicks, int x, int y) {
        if (this.f_96541_ == null) {
            return;
        }
        RenderSystem.setShader(GameRenderer::m_172817_);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        ResourceLocation TEXTURE = ((AbstractThermalContainer)this.f_97732_).getThermalType() == ThermalTypeEnum.HEATING ? HEATER_SCREEN : COOLER_SCREEN;
        RenderSystem.setShaderTexture((int)0, (ResourceLocation)TEXTURE);
        gui.m_280218_(TEXTURE, this.f_97735_, this.f_97736_, 0, 0, this.f_97726_, this.f_97727_);
        int fuelTimeHeight = (int)(((AbstractThermalContainer)this.f_97732_).getFuelTimeScale() * 27.0f);
        gui.m_280218_(TEXTURE, this.f_97735_ + 73, this.f_97736_ + 35 + (27 - fuelTimeHeight), 176, 24 + (27 - fuelTimeHeight), 29, fuelTimeHeight);
        if (((AbstractThermalContainer)this.f_97732_).isPowered()) {
            gui.m_280218_(TEXTURE, this.f_97735_ + 137, this.f_97736_ + 37, 176, 0, 12, 24);
        }
    }
}

