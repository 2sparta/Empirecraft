/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.gui.screens.inventory.AbstractContainerScreen
 *  net.minecraft.client.renderer.GameRenderer
 *  net.minecraft.client.renderer.Rect2i
 *  net.minecraft.network.chat.Component
 *  net.minecraft.network.chat.MutableComponent
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.player.Inventory
 *  net.minecraft.world.inventory.AbstractContainerMenu
 *  net.minecraft.world.item.ArmorItem
 *  net.minecraft.world.item.Item
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package sfiomn.legendarysurvivaloverhaul.client.screens;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import sfiomn.legendarysurvivaloverhaul.common.containers.SewingTableContainer;

@OnlyIn(value=Dist.CLIENT)
public class SewingTableScreen
extends AbstractContainerScreen<SewingTableContainer> {
    public static final ResourceLocation SEWING_TABLE_SCREEN = new ResourceLocation("legendarysurvivaloverhaul", "textures/gui/sewing_table_screen.png");
    Rect2i craftDisabledArea;

    public SewingTableScreen(SewingTableContainer screenContainer, Inventory playerInventory, Component titleIn) {
        super((AbstractContainerMenu)screenContainer, playerInventory, titleIn);
    }

    protected void m_7856_() {
        super.m_7856_();
        this.craftDisabledArea = new Rect2i(this.f_97735_ + 93, this.f_97736_ + 41, 13, 13);
    }

    public void m_88315_(GuiGraphics gui, int mouseX, int mouseY, float partialTicks) {
        this.m_280273_(gui);
        super.m_88315_(gui, mouseX, mouseY, partialTicks);
        this.m_280072_(gui, mouseX, mouseY);
    }

    protected void m_7286_(GuiGraphics gui, float partialTicks, int x, int y) {
        if (this.f_96541_ == null) {
            return;
        }
        RenderSystem.setShader(GameRenderer::m_172817_);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        gui.m_280218_(SEWING_TABLE_SCREEN, this.f_97735_, this.f_97736_, 0, 0, this.f_97726_, this.f_97727_);
        if (((SewingTableContainer)this.f_97732_).m_38853_(0).m_7993_().m_41720_() instanceof ArmorItem && ((SewingTableContainer)this.f_97732_).m_38853_(1).m_7993_().m_41720_() instanceof Item && !((SewingTableContainer)this.f_97732_).m_38853_(2).m_6657_()) {
            gui.m_280218_(SEWING_TABLE_SCREEN, this.f_97735_ + 93, this.f_97736_ + 41, 176, 0, 13, 13);
        }
    }

    protected void m_280072_(GuiGraphics gui, int mouseX, int mouseY) {
        super.m_280072_(gui, mouseX, mouseY);
        if (Minecraft.m_91087_().f_91074_ == null) {
            return;
        }
        if (Minecraft.m_91087_().f_91080_ == null) {
            return;
        }
        if (this.craftDisabledArea.m_110087_(mouseX, mouseY) && ((SewingTableContainer)this.f_97732_).m_38853_(0).m_7993_().m_41720_() instanceof ArmorItem && ((SewingTableContainer)this.f_97732_).m_38853_(1).m_7993_().m_41720_() instanceof Item && !((SewingTableContainer)this.f_97732_).m_38853_(2).m_6657_()) {
            MutableComponent tooltipText = Component.m_237115_((String)"tooltip.legendarysurvivaloverhaul.sewing_table.disabled");
            gui.m_280557_(Minecraft.m_91087_().f_91062_, (Component)tooltipText, mouseX, mouseY);
        }
    }
}

