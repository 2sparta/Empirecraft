/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.client.screens.BodyHealthScreen;

public class ClientHooks {
    public static void openBodyHealthScreen(Player player, ResourceLocation itemRegistryName, InteractionHand hand, boolean alreadyConsumed, int healingCharges, float healingValue, int healingTime) {
        Minecraft.m_91087_().m_91152_((Screen)new BodyHealthScreen(player, itemRegistryName, hand, alreadyConsumed, healingCharges, healingValue, healingTime));
    }

    public static void openBodyHealthScreen(Player player) {
        ClientHooks.openBodyHealthScreen(player, null, null, false, 0, 0.0f, 0);
    }
}

