/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.client.particle.Particle
 *  net.minecraft.client.particle.ParticleProvider
 *  net.minecraft.client.particle.ParticleRenderType
 *  net.minecraft.client.particle.SpriteSet
 *  net.minecraft.client.particle.TextureSheetParticle
 *  net.minecraft.core.particles.SimpleParticleType
 *  net.minecraft.util.Mth
 */
package sfiomn.legendarysurvivaloverhaul.client.particles;

import javax.annotation.Nullable;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;

public class FernBlossomParticle
extends TextureSheetParticle {
    protected final SpriteSet animatedSprite;
    private float angle;

    protected FernBlossomParticle(SpriteSet animatedSprite, ClientLevel level, double x, double y, double z, double xd, double yd, double zd) {
        super(level, x, y, z, xd, yd, zd);
        this.m_108339_(animatedSprite);
        this.animatedSprite = animatedSprite;
        this.angle = this.f_107223_.m_188501_() * ((float)Math.PI * 2);
        this.f_107225_ = this.f_107223_.m_188503_(75) + 75;
        this.f_107663_ *= (float)(2.0 + (double)this.f_107223_.m_188501_() * 0.5);
        this.f_107215_ = xd;
        this.f_107216_ = yd + this.f_107223_.m_188500_() * 0.05;
        this.f_107217_ = zd;
        this.f_107227_ = 1.0f;
        this.f_107228_ = 1.0f;
        this.f_107229_ = 1.0f;
    }

    public void m_5989_() {
        super.m_5989_();
        if (this.f_107224_ % 5 == 0) {
            this.angle = (float)(Math.random() * 6.28318530718);
        }
        this.f_107215_ += Math.cos(this.angle) * 5.0E-4;
        this.f_107217_ += Math.sin(this.angle) * 5.0E-4;
        this.m_108339_(this.animatedSprite);
        this.fadeOut();
    }

    private void fadeOut() {
        this.f_107230_ = (float)this.f_107224_ / (float)this.f_107225_ < 0.5f ? 1.0f : 1.0f - ((float)this.f_107224_ / (float)this.f_107225_ - 0.5f) * 2.0f;
    }

    protected int m_6355_(float partialTick) {
        float f = (float)this.f_107225_ / ((float)this.f_107224_ + (float)this.f_107225_ * 0.5f + partialTick);
        f = Mth.m_14036_((float)f, (float)0.0f, (float)0.5f);
        int i = super.m_6355_(partialTick);
        int j = i & 0xFF;
        int k = i >> 16 & 0xFF;
        if ((j += (int)(f * 15.0f * 16.0f)) > 240) {
            j = 240;
        }
        return j | k << 16;
    }

    public ParticleRenderType m_7556_() {
        return ParticleRenderType.f_107431_;
    }

    public static class Factory
    implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet animatedSprite;

        public Factory(SpriteSet animatedSprite) {
            this.animatedSprite = animatedSprite;
        }

        @Nullable
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double xd, double yd, double zd) {
            return new FernBlossomParticle(this.animatedSprite, level, x, y, z, xd, yd, zd);
        }
    }
}

