/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Position
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.phys.Vec3
 *  org.apache.commons.lang3.RandomUtils
 */
package sfiomn.legendarysurvivaloverhaul.client.effects;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Position;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.apache.commons.lang3.RandomUtils;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureUtil;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.registry.ParticleTypeRegistry;

public class TemperatureBreathEffect {
    private static int delay = 200 + RandomUtils.nextInt((int)0, (int)200);
    private static int particleTicks;
    private static boolean reset;
    private static int updateTempTicks;
    private static float temperature;

    public static void tickPlay(Player player) {
        if (player == null || !player.m_6084_() || player.m_5833_() || player.m_7500_() || !player.m_9236_().m_8055_(BlockPos.m_274446_((Position)player.m_146892_())).m_60795_()) {
            return;
        }
        if (updateTempTicks-- < 0) {
            updateTempTicks = 20;
            temperature = TemperatureUtil.getWorldTemperature(player.m_9236_(), player.m_20183_());
        }
        if ((double)temperature >= Config.Baked.coldBreathEffectThreshold) {
            TemperatureBreathEffect.reset(player);
            return;
        }
        reset = false;
        if (delay-- <= 0) {
            delay = 200 + player.m_217043_().m_188503_(200);
            particleTicks = 17;
        }
        if (particleTicks > 0) {
            --particleTicks;
            Vec3 eyePosition = player.m_146892_().m_82492_(0.0, 0.2, 0.0);
            if (player.m_6047_()) {
                eyePosition = eyePosition.m_82492_(0.0, 0.25, 0.0);
            }
            for (int i = 0; i < 3; ++i) {
                Vec3 trajectory = player.m_20154_().m_82524_((player.m_9236_().f_46441_.m_188501_() - 0.5f) * 0.1f).m_82541_();
                Vec3 origin = eyePosition.m_82549_(trajectory.m_82490_(0.5));
                player.m_9236_().m_7106_((ParticleOptions)ParticleTypeRegistry.COLD_BREATH.get(), origin.f_82479_, origin.f_82480_, origin.f_82481_, trajectory.f_82479_, trajectory.f_82480_, trajectory.f_82481_);
            }
        }
    }

    public static void reset(Player player) {
        if (!reset) {
            delay = 200 + player.m_217043_().m_188503_(200);
            reset = true;
        }
    }
}

