/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.event.TickEvent$Phase
 */
package sfiomn.legendarysurvivaloverhaul.api.temperature;

import java.util.List;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureEnum;

public interface ITemperatureCapability {
    public float getTemperatureLevel();

    public float getTargetTemperatureLevel();

    public int getTemperatureTickTimer();

    public int getFreezeTickTimer();

    public TemperatureEnum getTemperatureEnum();

    public List<Integer> getTemperatureImmunities();

    public void setTemperatureLevel(float var1);

    public void setTargetTemperatureLevel(float var1);

    public void setTemperatureTickTimer(int var1);

    public void setFreezeTickTimer(int var1);

    public void addTemperatureLevel(float var1);

    public void addTemperatureTickTimer(int var1);

    public void addFreezeTickTimer(int var1);

    public void addTemperatureImmunityId(int var1);

    public void removeTemperatureImmunityId(int var1);

    public void tickUpdate(Player var1, Level var2, TickEvent.Phase var3);

    public void tickClient(Player var1, TickEvent.Phase var2);

    public boolean isDirty();

    public void setClean();

    public int getPacketTimer();
}

