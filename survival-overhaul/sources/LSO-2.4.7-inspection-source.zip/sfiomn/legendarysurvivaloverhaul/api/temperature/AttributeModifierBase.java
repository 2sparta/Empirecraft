/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.ItemStack
 */
package sfiomn.legendarysurvivaloverhaul.api.temperature;

import net.minecraft.world.item.ItemStack;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureResistance;

public class AttributeModifierBase {
    public JsonTemperatureResistance getItemAttributes(ItemStack stack) {
        return new JsonTemperatureResistance();
    }
}

