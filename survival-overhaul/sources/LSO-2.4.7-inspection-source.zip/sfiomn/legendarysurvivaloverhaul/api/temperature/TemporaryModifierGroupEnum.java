/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.registries.RegistryObject
 */
package sfiomn.legendarysurvivaloverhaul.api.temperature;

import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.RegistryObject;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public enum TemporaryModifierGroupEnum {
    FOOD(MobEffectRegistry.HOT_FOOD, MobEffectRegistry.COLD_FOOD),
    DRINK(MobEffectRegistry.HOT_DRINk, MobEffectRegistry.COLD_DRINK);

    public final RegistryObject<MobEffect> hotEffect;
    public final RegistryObject<MobEffect> coldEffect;

    private TemporaryModifierGroupEnum(RegistryObject<MobEffect> hotEffect, RegistryObject<MobEffect> coldEffect) {
        this.hotEffect = hotEffect;
        this.coldEffect = coldEffect;
    }

    public static TemporaryModifierGroupEnum get(String name) {
        for (TemporaryModifierGroupEnum t : TemporaryModifierGroupEnum.values()) {
            if (!t.name().equalsIgnoreCase(name)) continue;
            return t;
        }
        throw new IllegalArgumentException();
    }
}

