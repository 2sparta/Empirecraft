/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.state.BlockState
 */
package sfiomn.legendarysurvivaloverhaul.api.temperature;

import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureEnum;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureImmunityEnum;

public interface ITemperatureUtil {
    public float getPlayerTargetTemperature(Player var1);

    public float getWorldTemperature(Level var1, BlockPos var2);

    public float clampTemperature(float var1);

    public void applyConsumableTemperature(Player var1, ResourceLocation var2);

    public void applyConsumableBlockTemperature(Player var1, BlockState var2);

    public TemperatureEnum getTemperatureEnum(float var1);

    public boolean hasImmunity(Player var1, TemperatureImmunityEnum var2);

    public void addImmunity(Player var1, TemperatureImmunityEnum var2);

    public void removeImmunity(Player var1, TemperatureImmunityEnum var2);

    public void addTemperatureModifier(Player var1, double var2, UUID var4);

    public void addHeatResistanceModifier(Player var1, double var2, UUID var4);

    public void addColdResistanceModifier(Player var1, double var2, UUID var4);

    public void addThermalResistanceModifier(Player var1, double var2, UUID var4);

    public void setArmorCoatTag(ItemStack var1, String var2);

    public String getArmorCoatTag(ItemStack var1);

    public void removeArmorCoatTag(ItemStack var1);
}

