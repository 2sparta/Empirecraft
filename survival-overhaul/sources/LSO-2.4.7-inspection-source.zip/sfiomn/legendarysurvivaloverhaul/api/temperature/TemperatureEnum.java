/*
 * Decompiled with CFR 0.152.
 */
package sfiomn.legendarysurvivaloverhaul.api.temperature;

public enum TemperatureEnum {
    FROSTBITE(5.0f),
    COLD(10.0f),
    NORMAL(20.0f),
    HOT(30.0f),
    HEAT_STROKE(35.0f);

    private final float value;

    private TemperatureEnum(float value) {
        this.value = value;
    }

    public static TemperatureEnum get(float temperature) {
        if (temperature < (TemperatureEnum.FROSTBITE.value + TemperatureEnum.COLD.value) / 2.0f) {
            return FROSTBITE;
        }
        if (temperature < (TemperatureEnum.COLD.value + TemperatureEnum.NORMAL.value) / 2.0f) {
            return COLD;
        }
        if (temperature < (TemperatureEnum.NORMAL.value + TemperatureEnum.HOT.value) / 2.0f) {
            return NORMAL;
        }
        if (temperature < (TemperatureEnum.HOT.value + TemperatureEnum.HEAT_STROKE.value) / 2.0f) {
            return HOT;
        }
        return HEAT_STROKE;
    }

    public float getValue() {
        return this.value;
    }

    public static float getMin() {
        return 0.0f;
    }

    public static float getMax() {
        return 40.0f;
    }
}

