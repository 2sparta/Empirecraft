/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.state.BlockState
 */
package sfiomn.legendarysurvivaloverhaul.api.temperature;

import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import sfiomn.legendarysurvivaloverhaul.api.temperature.ITemperatureUtil;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureEnum;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureImmunityEnum;

public class TemperatureUtil {
    public static ITemperatureUtil internal;

    public static float getPlayerTargetTemperature(Player player) {
        return internal.getPlayerTargetTemperature(player);
    }

    public static float getWorldTemperature(Level world, BlockPos pos) {
        return internal.getWorldTemperature(world, pos);
    }

    public static float clampTemperature(float temperature) {
        return internal.clampTemperature(temperature);
    }

    public static TemperatureEnum getTemperatureEnum(float temperature) {
        return internal.getTemperatureEnum(temperature);
    }

    public static boolean hasImmunity(Player player, TemperatureImmunityEnum immunity) {
        return internal.hasImmunity(player, immunity);
    }

    public static void addImmunity(Player player, TemperatureImmunityEnum immunity) {
        internal.addImmunity(player, immunity);
    }

    public static void removeImmunity(Player player, TemperatureImmunityEnum immunity) {
        internal.removeImmunity(player, immunity);
    }

    public static void applyConsumableTemperature(Player player, ResourceLocation itemRegistryName) {
        internal.applyConsumableTemperature(player, itemRegistryName);
    }

    public static void applyConsumableBlockTemperature(Player player, BlockState blockState) {
        internal.applyConsumableBlockTemperature(player, blockState);
    }

    public static void addTemperatureModifier(Player player, double temperature, UUID uuid) {
        internal.addTemperatureModifier(player, temperature, uuid);
    }

    public static void addHeatResistanceModifier(Player player, double resistance, UUID uuid) {
        internal.addHeatResistanceModifier(player, resistance, uuid);
    }

    public static void addColdResistanceModifier(Player player, double resistance, UUID uuid) {
        internal.addColdResistanceModifier(player, resistance, uuid);
    }

    public static void addThermalResistanceModifier(Player player, double resistance, UUID uuid) {
        internal.addThermalResistanceModifier(player, resistance, uuid);
    }

    public static void setArmorCoatTag(ItemStack stack, String coatId) {
        internal.setArmorCoatTag(stack, coatId);
    }

    public static String getArmorCoatTag(ItemStack stack) {
        return internal.getArmorCoatTag(stack);
    }

    public static void removeArmorCoatTag(ItemStack stack) {
        internal.removeArmorCoatTag(stack);
    }
}

