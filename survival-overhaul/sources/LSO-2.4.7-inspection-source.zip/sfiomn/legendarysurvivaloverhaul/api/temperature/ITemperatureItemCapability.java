/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.Level
 */
package sfiomn.legendarysurvivaloverhaul.api.temperature;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

public interface ITemperatureItemCapability {
    public float getWorldTemperatureLevel();

    public void setWorldTemperatureLevel(float var1);

    public boolean shouldUpdate(long var1);

    public void updateWorldTemperature(Level var1, Entity var2, long var3);
}

