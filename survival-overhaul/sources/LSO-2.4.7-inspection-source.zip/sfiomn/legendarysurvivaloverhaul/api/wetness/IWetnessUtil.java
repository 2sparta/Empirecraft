/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.api.wetness;

import net.minecraft.world.entity.player.Player;

public interface IWetnessUtil {
    public void addWetness(Player var1, int var2);

    public void deactivateWetness(Player var1);

    public void activateWetness(Player var1);

    public boolean isWetnessActive(Player var1);
}

