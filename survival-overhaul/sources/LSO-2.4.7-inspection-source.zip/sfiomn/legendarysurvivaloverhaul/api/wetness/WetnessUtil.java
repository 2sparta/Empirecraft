/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.api.wetness;

import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.api.wetness.IWetnessUtil;

public class WetnessUtil {
    public static IWetnessUtil internal;

    public static void addWetness(Player player, int wetness) {
        internal.addWetness(player, wetness);
    }

    public static void deactivateWetness(Player player) {
        internal.deactivateWetness(player);
    }

    public static void activateWetness(Player player) {
        internal.activateWetness(player);
    }

    public static boolean isWetnessActive(Player player) {
        return internal.isWetnessActive(player);
    }
}

