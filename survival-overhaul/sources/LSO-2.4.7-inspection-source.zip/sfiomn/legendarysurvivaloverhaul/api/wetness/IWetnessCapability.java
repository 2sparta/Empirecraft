/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.event.TickEvent$Phase
 */
package sfiomn.legendarysurvivaloverhaul.api.wetness;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;

public interface IWetnessCapability {
    public int getWetness();

    public int getWetnessTickTimer();

    public void setWetness(int var1);

    public void setWetnessTickTimer(int var1);

    public void addWetness(int var1);

    public void addWetnessTickTimer(int var1);

    public boolean isDirty();

    public void setClean();

    public void setDirty();

    public void tickUpdate(Player var1, Level var2, TickEvent.Phase var3);

    public int getPacketTimer();
}

