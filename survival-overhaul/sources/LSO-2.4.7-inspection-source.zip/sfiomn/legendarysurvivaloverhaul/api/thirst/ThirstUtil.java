/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.api.thirst;

import java.util.List;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonMobEffect;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonThirstBlock;
import sfiomn.legendarysurvivaloverhaul.api.thirst.HydrationEnum;
import sfiomn.legendarysurvivaloverhaul.api.thirst.IThirstUtil;

public class ThirstUtil {
    public static IThirstUtil internal;

    public static void takeDrink(Player player, ItemStack itemStack) {
        internal.takeDrink(player, itemStack);
    }

    public static void takeDrink(Player player, int hydration, float saturation, List<JsonMobEffect> effects) {
        internal.takeDrink(player, hydration, saturation, effects);
    }

    public static void takeDrink(Player player, int hydration, float saturation) {
        internal.takeDrink(player, hydration, saturation);
    }

    public static void addExhaustion(Player player, float exhaustion) {
        internal.addExhaustion(player, exhaustion);
    }

    public static JsonThirstBlock getFluidThirstLookedAt(Player player, double finalDistance) {
        return internal.getFluidThirstLookedAt(player, finalDistance);
    }

    public static JsonThirstBlock getBlockThirstLookedAt(Player player, double finalDistance) {
        return internal.getBlockThirstLookedAt(player, finalDistance);
    }

    public static void setHydrationEnumTag(ItemStack stack, HydrationEnum hydrationEnum) {
        internal.setHydrationEnumTag(stack, hydrationEnum);
    }

    @Nullable
    public static HydrationEnum getHydrationEnumTag(ItemStack stack) {
        return internal.getHydrationEnumTag(stack);
    }

    public static void removeHydrationEnumTag(ItemStack stack) {
        internal.removeHydrationEnumTag(stack);
    }

    public static void setCapacityTag(ItemStack stack, int capacity) {
        internal.setCapacityTag(stack, capacity);
    }

    public static int getCapacityTag(ItemStack stack) {
        return internal.getCapacityTag(stack);
    }

    public static void removeCapacityTag(ItemStack stack) {
        internal.removeCapacityTag(stack);
    }

    public static void deactivateThirst(Player player) {
        internal.deactivateThirst(player);
    }

    public static void activateThirst(Player player) {
        internal.activateThirst(player);
    }

    public static boolean isThirstActive(Player player) {
        return internal.isThirstActive(player);
    }
}

