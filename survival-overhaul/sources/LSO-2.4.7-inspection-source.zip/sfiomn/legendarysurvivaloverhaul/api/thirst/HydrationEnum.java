/*
 * Decompiled with CFR 0.152.
 */
package sfiomn.legendarysurvivaloverhaul.api.thirst;

public enum HydrationEnum {
    NORMAL("normal"),
    RAIN("rain"),
    POTION("potion"),
    PURIFIED("purified");

    private final String name;

    private HydrationEnum(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public static HydrationEnum getByName(String name) {
        for (HydrationEnum hydrationEnum : HydrationEnum.values()) {
            if (!hydrationEnum.getName().equals(name)) continue;
            return hydrationEnum;
        }
        return null;
    }

    public String toString() {
        return this.getName();
    }
}

