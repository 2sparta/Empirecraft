/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.event.TickEvent$Phase
 */
package sfiomn.legendarysurvivaloverhaul.api.thirst;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;

public interface IThirstCapability {
    public float getThirstExhaustion();

    public int getHydrationLevel();

    public float getSaturationLevel();

    public int getTickTimer();

    public int getThirstDamageTickTimer();

    public int getThirstDamageCounter();

    public void setExhaustion(float var1);

    public void setHydrationLevel(int var1);

    public void setSaturation(float var1);

    public void setTickTimer(int var1);

    public void setThirstDamageTickTimer(int var1);

    public void setThirstDamageCounter(int var1);

    public void addThirstExhaustion(float var1);

    public void addHydrationLevel(int var1);

    public void addSaturationLevel(float var1);

    public void addTickTimer(int var1);

    public void addThirstDamageTickTimer(int var1);

    public void addThirstDamageCounter(int var1);

    public boolean isHydrationLevelAtMax();

    public boolean hasShownBlurWarning();

    public void setShownBlurWarning(boolean var1);

    public boolean isDirty();

    public void setClean();

    public void setDirty();

    public void tickUpdate(Player var1, Level var2, TickEvent.Phase var3);

    public int getPacketTimer();
}

