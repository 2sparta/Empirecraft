/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 */
package sfiomn.legendarysurvivaloverhaul.api.thirst;

import java.util.List;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonMobEffect;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonThirstBlock;
import sfiomn.legendarysurvivaloverhaul.api.thirst.HydrationEnum;

public interface IThirstUtil {
    public void takeDrink(Player var1, ItemStack var2);

    public void takeDrink(Player var1, int var2, float var3, List<JsonMobEffect> var4);

    public void takeDrink(Player var1, int var2, float var3);

    public void addExhaustion(Player var1, float var2);

    public JsonThirstBlock getFluidThirstLookedAt(Player var1, double var2);

    public JsonThirstBlock getBlockThirstLookedAt(Player var1, double var2);

    public void setHydrationEnumTag(ItemStack var1, HydrationEnum var2);

    public HydrationEnum getHydrationEnumTag(ItemStack var1);

    public void removeHydrationEnumTag(ItemStack var1);

    public void setCapacityTag(ItemStack var1, int var2);

    public int getCapacityTag(ItemStack var1);

    public void removeCapacityTag(ItemStack var1);

    public void deactivateThirst(Player var1);

    public void activateThirst(Player var1);

    public boolean isThirstActive(Player var1);
}

