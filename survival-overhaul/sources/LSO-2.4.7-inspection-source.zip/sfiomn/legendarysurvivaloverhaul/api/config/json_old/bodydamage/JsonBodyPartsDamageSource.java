/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.api.config.json_old.bodydamage;

import com.google.gson.annotations.SerializedName;
import java.util.List;
import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyPartEnum;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.DamageDistributionEnum;

public class JsonBodyPartsDamageSource {
    @SerializedName(value="bodyParts")
    public List<BodyPartEnum> bodyParts;
    @SerializedName(value="damageDistribution")
    public DamageDistributionEnum damageDistribution;

    public JsonBodyPartsDamageSource(DamageDistributionEnum damageDistribution, List<BodyPartEnum> bodyParts) {
        this.damageDistribution = damageDistribution;
        this.bodyParts = bodyParts;
    }

    public List<BodyPartEnum> getBodyParts(Player player) {
        return this.damageDistribution.getBodyParts(player, this.bodyParts);
    }
}

