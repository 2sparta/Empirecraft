/*
 * Decompiled with CFR 0.152.
 */
package sfiomn.legendarysurvivaloverhaul.api.config.json_old;

public class JsonPropertyValue {
    public String name;
    public String value;

    public JsonPropertyValue(String name, String value) {
        this.name = name;
        this.value = value;
    }
}

