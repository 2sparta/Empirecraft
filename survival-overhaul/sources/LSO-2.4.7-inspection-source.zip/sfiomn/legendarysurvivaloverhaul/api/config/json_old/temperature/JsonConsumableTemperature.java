/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.registries.RegistryObject
 */
package sfiomn.legendarysurvivaloverhaul.api.config.json_old.temperature;

import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.RegistryObject;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class JsonConsumableTemperature {
    public TemporaryModifierGroupEnum group;
    public int temperatureLevel;
    public int duration;
    private RegistryObject<MobEffect> effect;
    private RegistryObject<MobEffect> oppositeEffect;

    public JsonConsumableTemperature(TemporaryModifierGroupEnum group, int temperatureLevel, int duration) {
        this.temperatureLevel = temperatureLevel;
        this.duration = duration;
        this.group = group;
        this.effect = null;
        this.oppositeEffect = null;
        if (temperatureLevel > 0) {
            this.effect = group.hotEffect;
            this.oppositeEffect = group.coldEffect;
        } else if (temperatureLevel < 0) {
            this.effect = group.coldEffect;
            this.oppositeEffect = group.hotEffect;
        }
    }

    public MobEffect getEffect() {
        return (MobEffect)this.effect.get();
    }

    public MobEffect getOppositeEffect() {
        return (MobEffect)this.oppositeEffect.get();
    }
}

