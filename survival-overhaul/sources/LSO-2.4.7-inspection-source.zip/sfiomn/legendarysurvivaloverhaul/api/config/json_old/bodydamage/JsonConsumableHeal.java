/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package sfiomn.legendarysurvivaloverhaul.api.config.json_old.bodydamage;

import com.google.gson.annotations.SerializedName;

public class JsonConsumableHeal {
    @SerializedName(value="healingCharges")
    public int healingCharges;
    @SerializedName(value="healingValue")
    public float healingValue;
    @SerializedName(value="healingTime")
    public int healingTime;

    public JsonConsumableHeal(int healingCharges, float healingValue, int healingTime) {
        this.healingCharges = healingCharges;
        this.healingValue = healingValue;
        this.healingTime = healingTime;
    }
}

