/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package sfiomn.legendarysurvivaloverhaul.api.config.json_old.temperature;

import com.google.gson.annotations.SerializedName;
import sfiomn.legendarysurvivaloverhaul.api.block.ThermalTypeEnum;

public class JsonFuelItem {
    @SerializedName(value="thermalType")
    public ThermalTypeEnum thermalType;
    @SerializedName(value="fuelValue")
    public int fuelValue;

    public JsonFuelItem(ThermalTypeEnum thermalType, int fuelValue) {
        this.thermalType = thermalType;
        this.fuelValue = fuelValue;
    }
}

