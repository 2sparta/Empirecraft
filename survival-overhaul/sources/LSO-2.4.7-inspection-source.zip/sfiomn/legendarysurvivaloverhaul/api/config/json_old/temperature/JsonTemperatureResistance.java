/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package sfiomn.legendarysurvivaloverhaul.api.config.json_old.temperature;

import com.google.gson.annotations.SerializedName;

public class JsonTemperatureResistance {
    @SerializedName(value="temperature")
    public float temperature;
    @SerializedName(value="heat_resistance")
    public float heatResistance;
    @SerializedName(value="cold_resistance")
    public float coldResistance;
    @SerializedName(value="thermal_resistance")
    public float thermalResistance;

    public JsonTemperatureResistance() {
        this(0.0f, 0.0f, 0.0f, 0.0f);
    }

    public JsonTemperatureResistance(float temperature) {
        this(temperature, 0.0f, 0.0f, 0.0f);
    }

    public JsonTemperatureResistance(float temperature, float heatResistance, float coldResistance, float thermalResistance) {
        this.temperature = temperature;
        this.heatResistance = heatResistance;
        this.coldResistance = coldResistance;
        this.thermalResistance = thermalResistance;
    }

    public void add(JsonTemperatureResistance config) {
        this.temperature += config.temperature;
        this.heatResistance += config.heatResistance;
        this.coldResistance += config.coldResistance;
        this.thermalResistance += config.thermalResistance;
    }
}

