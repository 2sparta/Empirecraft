/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package sfiomn.legendarysurvivaloverhaul.api.config.json_old.temperature;

import com.google.gson.annotations.SerializedName;

public class JsonTemperature {
    @SerializedName(value="temperature")
    public float temperature;

    public JsonTemperature(float temperature) {
        this.temperature = temperature;
    }
}

