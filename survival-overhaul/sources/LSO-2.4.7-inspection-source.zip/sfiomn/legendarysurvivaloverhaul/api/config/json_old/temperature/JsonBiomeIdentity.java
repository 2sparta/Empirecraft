/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package sfiomn.legendarysurvivaloverhaul.api.config.json_old.temperature;

import com.google.gson.annotations.SerializedName;

public class JsonBiomeIdentity {
    @SerializedName(value="temperature")
    public float temperature;
    @SerializedName(value="isDry")
    public boolean isDry;

    public JsonBiomeIdentity(float temperature) {
        this(temperature, false);
    }

    public JsonBiomeIdentity(float temperature, boolean isDry) {
        this.temperature = temperature;
        this.isDry = isDry;
    }
}

