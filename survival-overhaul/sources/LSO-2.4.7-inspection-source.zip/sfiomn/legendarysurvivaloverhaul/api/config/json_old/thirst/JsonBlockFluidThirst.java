/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.material.FluidState
 */
package sfiomn.legendarysurvivaloverhaul.api.config.json_old.thirst;

import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.FluidState;
import sfiomn.legendarysurvivaloverhaul.api.config.json_old.JsonPropertyValue;
import sfiomn.legendarysurvivaloverhaul.api.config.json_old.thirst.JsonEffectParameter;

public class JsonBlockFluidThirst {
    @SerializedName(value="hydration")
    public int hydration;
    @SerializedName(value="saturation")
    public float saturation;
    @SerializedName(value="effects")
    public List<JsonEffectParameter> effects;
    @SerializedName(value="properties")
    public Map<String, String> properties;

    public JsonBlockFluidThirst(int hydration, float saturation, JsonEffectParameter[] effects, JsonPropertyValue ... properties) {
        this.hydration = hydration;
        this.saturation = saturation;
        this.effects = new ArrayList<JsonEffectParameter>();
        this.effects.addAll(Arrays.asList(effects));
        this.properties = new HashMap<String, String>();
        for (JsonPropertyValue prop : properties) {
            this.properties.put(prop.name, prop.value);
        }
    }

    public JsonPropertyValue[] getPropertyArray() {
        ArrayList<JsonPropertyValue> jpvList = new ArrayList<JsonPropertyValue>();
        for (Map.Entry<String, String> entry : this.properties.entrySet()) {
            jpvList.add(new JsonPropertyValue(entry.getKey(), entry.getValue()));
        }
        return jpvList.toArray(new JsonPropertyValue[0]);
    }

    public boolean isDefault() {
        return this.properties.isEmpty();
    }

    public boolean matchesState(BlockState blockState) {
        for (Property property : blockState.m_61147_()) {
            String name = property.m_61708_();
            if (this.properties.containsKey(name)) {
                String stateValue = blockState.m_61143_(property).toString();
                if (this.properties.get(name).equalsIgnoreCase(stateValue)) continue;
                return false;
            }
            return false;
        }
        return true;
    }

    public boolean matchesState(FluidState fluidState) {
        for (Property property : fluidState.m_61147_()) {
            String name = property.m_61708_();
            if (this.properties.containsKey(name)) {
                String stateValue = fluidState.m_61143_(property).toString();
                if (this.properties.get(name).equalsIgnoreCase(stateValue)) continue;
                return false;
            }
            return false;
        }
        return true;
    }

    public boolean matchesProperties(JsonPropertyValue ... props) {
        if (props.length != this.properties.keySet().size()) {
            return false;
        }
        for (JsonPropertyValue prop : props) {
            if (!this.properties.containsKey(prop.name)) {
                return false;
            }
            if (prop.value.equals(this.properties.get(prop.name))) continue;
            return false;
        }
        return true;
    }
}

