/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package sfiomn.legendarysurvivaloverhaul.api.config.json_old.thirst;

import com.google.gson.annotations.SerializedName;

public class JsonEffectParameter {
    @SerializedName(value="chance")
    public float chance;
    @SerializedName(value="effect")
    public String name;
    @SerializedName(value="duration")
    public int duration;
    @SerializedName(value="amplifier")
    public int amplifier;

    public JsonEffectParameter(String name, float chance, int duration, int amplifier) {
        this.name = name;
        this.chance = chance < 0.0f ? 0.0f : (chance > 1.0f ? 1.0f : chance);
        this.duration = Math.max(duration, 0);
        this.amplifier = Math.max(amplifier, 0);
    }
}

