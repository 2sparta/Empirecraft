/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.api.health;

import java.util.UUID;
import net.minecraft.world.entity.player.Player;

public interface IHealthUtil {
    public void updatePlayerMaxHealthAttribute(Player var1);

    public double getPlayerMaxHealth(Player var1);

    public double getPlayerStableMaxHealth(Player var1);

    public int getEffectiveBrokenHearts(Player var1);

    public void initializeHealthAttributes(Player var1);

    public float hurtPlayer(Player var1, float var2);

    public void loseHearth(Player var1, int var2);

    public void updateBrokenHearts(Player var1, UUID var2, int var3);
}

