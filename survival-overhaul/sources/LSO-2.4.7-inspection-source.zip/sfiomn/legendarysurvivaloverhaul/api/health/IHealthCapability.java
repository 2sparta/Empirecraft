/*
 * Decompiled with CFR 0.152.
 */
package sfiomn.legendarysurvivaloverhaul.api.health;

public interface IHealthCapability {
    public void addAdditionalHealth(float var1);

    public void addShieldHealth(float var1);

    public void setAdditionalHealth(float var1);

    public void setShieldHealth(float var1);

    public float getAdditionalHealth();

    public float getShieldHealth();

    public boolean isDirty();

    public void setClean();

    public int getPacketTimer();
}

