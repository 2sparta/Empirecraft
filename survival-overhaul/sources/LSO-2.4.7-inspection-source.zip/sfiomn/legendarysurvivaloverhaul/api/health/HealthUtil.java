/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.api.health;

import java.util.UUID;
import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.api.health.IHealthUtil;

public class HealthUtil {
    public static IHealthUtil internal;

    public static void updatePlayerMaxHealthAttribute(Player player) {
        internal.updatePlayerMaxHealthAttribute(player);
    }

    public static double getPlayerMaxHealth(Player player) {
        return internal.getPlayerMaxHealth(player);
    }

    public static double getPlayerStableMaxHealth(Player player) {
        return internal.getPlayerStableMaxHealth(player);
    }

    public static int getEffectiveBrokenHearts(Player player) {
        return internal.getEffectiveBrokenHearts(player);
    }

    public static void initializeHealthAttributes(Player player) {
        internal.initializeHealthAttributes(player);
    }

    public static float hurtPlayer(Player player, float damageValue) {
        return internal.hurtPlayer(player, damageValue);
    }

    public static void loseHearth(Player player, int amountLost) {
        internal.loseHearth(player, amountLost);
    }

    public static void updateBrokenHearts(Player player, UUID attributeUuid, int brokenHearts) {
        internal.updateBrokenHearts(player, attributeUuid, brokenHearts);
    }
}

