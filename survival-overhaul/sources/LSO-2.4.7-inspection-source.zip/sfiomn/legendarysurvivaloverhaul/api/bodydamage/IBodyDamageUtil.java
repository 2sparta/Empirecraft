/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  org.apache.commons.lang3.tuple.Pair
 */
package sfiomn.legendarysurvivaloverhaul.api.bodydamage;

import java.util.List;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.apache.commons.lang3.tuple.Pair;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyPartEnum;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.MalusBodyPartEnum;

public interface IBodyDamageUtil {
    public void applyConsumableHealing(Player var1, ItemStack var2, boolean var3);

    public List<Pair<MobEffect, Integer>> getEffects(MalusBodyPartEnum var1, float var2);

    public MobEffectInstance getPlayerPassiveLimbRegenerationEffect(Player var1);

    public boolean hasPlayerFirstAidSuppliesBoostingEffect(Player var1);

    public void applyHealingTimeBodyPart(Player var1, BodyPartEnum var2, float var3, int var4);

    public void healBodyPart(Player var1, BodyPartEnum var2, float var3);

    public void hurtBodyPart(Player var1, BodyPartEnum var2, float var3);

    public void balancedHurtBodyParts(Player var1, List<BodyPartEnum> var2, float var3);

    public void randomHurtBodyParts(Player var1, List<BodyPartEnum> var2, float var3);

    public float getHealthRatio(Player var1, BodyPartEnum var2);

    public float getTotalRemainingHealing(Player var1, BodyPartEnum var2);

    public float getMaxHealth(Player var1, BodyPartEnum var2);

    public void updatePlayerBrokenHeartAttribute(Player var1);
}

