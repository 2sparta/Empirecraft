/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.api.bodydamage;

import java.util.Collections;
import java.util.List;
import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyPartEnum;

public enum DamageDistributionEnum {
    NONE,
    ONE_OF,
    ALL;


    public List<BodyPartEnum> getBodyParts(Player player, List<BodyPartEnum> bodyParts) {
        if (this == ONE_OF) {
            return Collections.singletonList(bodyParts.get(player.m_217043_().m_188503_(bodyParts.size())));
        }
        return bodyParts;
    }

    public static DamageDistributionEnum get(String name) {
        for (DamageDistributionEnum b : DamageDistributionEnum.values()) {
            if (!b.name().equalsIgnoreCase(name)) continue;
            return b;
        }
        throw new IllegalArgumentException();
    }
}

