/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.event.TickEvent$Phase
 */
package sfiomn.legendarysurvivaloverhaul.api.bodydamage;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyPartEnum;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.MalusBodyPartEnum;

public interface IBodyDamageCapability {
    public int getExpectedBrokenHearts();

    public float getBodyPartDamage(BodyPartEnum var1);

    public float getBodyPartHealthRatio(BodyPartEnum var1);

    public float getBodyPartMaxHealth(BodyPartEnum var1);

    public void setBodyPartDamage(BodyPartEnum var1, float var2);

    public void setBodyPartMaxHealth(BodyPartEnum var1, float var2);

    public void healWithFoodExhaustion(Player var1, BodyPartEnum var2, float var3);

    public void heal(BodyPartEnum var1, float var2);

    public void hurt(BodyPartEnum var1, float var2);

    public void applyHealingTime(BodyPartEnum var1, int var2, float var3);

    public int getRemainingHealingTicks(BodyPartEnum var1);

    public float getHealingPerTicks(BodyPartEnum var1);

    public void updateBrokenHearts(Player var1);

    public boolean isWoundedBelow(float var1);

    public float getHealthRatioForMalusBodyPart(MalusBodyPartEnum var1);

    public void setManualDirty();

    public boolean isDirty();

    public void setClean();

    public int getPacketTimer();

    public int getHealthBlinkTimer();

    public void tickUpdate(Player var1, Level var2, TickEvent.Phase var3);
}

