/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  org.apache.commons.lang3.tuple.Pair
 */
package sfiomn.legendarysurvivaloverhaul.api.bodydamage;

import java.util.List;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.apache.commons.lang3.tuple.Pair;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyPartEnum;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.IBodyDamageUtil;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.MalusBodyPartEnum;

public class BodyDamageUtil {
    public static IBodyDamageUtil internal;

    public static void applyConsumableHealing(Player player, ItemStack itemStack, boolean itemAlreadyConsumed) {
        internal.applyConsumableHealing(player, itemStack, itemAlreadyConsumed);
    }

    public static List<Pair<MobEffect, Integer>> getEffects(MalusBodyPartEnum bodyPart, float headHealthRatio) {
        return internal.getEffects(bodyPart, headHealthRatio);
    }

    public static MobEffectInstance getPlayerPassiveLimbRegenerationEffect(Player player) {
        return internal.getPlayerPassiveLimbRegenerationEffect(player);
    }

    public static boolean hasPlayerFirstAidSuppliesBoostingEffect(Player player) {
        return internal.hasPlayerFirstAidSuppliesBoostingEffect(player);
    }

    public static void applyHealingTimeBodyPart(Player player, BodyPartEnum bodyPart, float healingValue, int healingTime) {
        internal.applyHealingTimeBodyPart(player, bodyPart, healingValue, healingTime);
    }

    public static void healBodyPart(Player player, BodyPartEnum bodyPart, float healingValue) {
        internal.healBodyPart(player, bodyPart, healingValue);
    }

    public static void hurtBodyPart(Player player, BodyPartEnum bodyPart, float damageValue) {
        internal.hurtBodyPart(player, bodyPart, damageValue);
    }

    public static void balancedHurtBodyParts(Player player, List<BodyPartEnum> bodyParts, float damageValue) {
        internal.balancedHurtBodyParts(player, bodyParts, damageValue);
    }

    public static void randomHurtBodyParts(Player player, List<BodyPartEnum> bodyParts, float damageValue) {
        internal.randomHurtBodyParts(player, bodyParts, damageValue);
    }

    public static float getHealthRatio(Player player, BodyPartEnum bodyPart) {
        return internal.getHealthRatio(player, bodyPart);
    }

    public static float getTotalRemainingHealing(Player player, BodyPartEnum bodyPart) {
        return internal.getTotalRemainingHealing(player, bodyPart);
    }

    public static float getMaxHealth(Player player, BodyPartEnum bodyPart) {
        return internal.getMaxHealth(player, bodyPart);
    }

    public static void updatePlayerBrokenHeartAttribute(Player player) {
        internal.updatePlayerBrokenHeartAttribute(player);
    }
}

