/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.data.worldgen.BootstapContext
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.damagesource.DamageEffects
 *  net.minecraft.world.damagesource.DamageScaling
 *  net.minecraft.world.damagesource.DamageType
 *  net.minecraft.world.entity.Entity
 */
package sfiomn.legendarysurvivaloverhaul.api;

import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstapContext;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageEffects;
import net.minecraft.world.damagesource.DamageScaling;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import sfiomn.legendarysurvivaloverhaul.util.DamageSourceUtil;

public class ModDamageTypes {
    public static final ResourceKey<DamageType> HYPOTHERMIA = ModDamageTypes.registerKey("hypothermia");
    public static final ResourceKey<DamageType> HYPERTHERMIA = ModDamageTypes.registerKey("hyperthermia");
    public static final ResourceKey<DamageType> DEHYDRATION = ModDamageTypes.registerKey("dehydration");

    public static ResourceKey<DamageType> registerKey(String name) {
        return ResourceKey.m_135785_((ResourceKey)Registries.f_268580_, (ResourceLocation)new ResourceLocation("legendarysurvivaloverhaul", name));
    }

    public static void hyperthermia(Entity entity, float amount) {
        entity.m_6469_(DamageSourceUtil.getDamageSource(entity.m_9236_(), HYPERTHERMIA), amount);
    }

    public static void hypothermia(Entity entity, float amount) {
        entity.m_6469_(DamageSourceUtil.getDamageSource(entity.m_9236_(), HYPOTHERMIA), amount);
    }

    public static void dehydration(Entity entity, float amount) {
        entity.m_6469_(DamageSourceUtil.getDamageSource(entity.m_9236_(), DEHYDRATION), amount);
    }

    public static void bootstrap(BootstapContext<DamageType> context) {
        context.m_255272_(HYPOTHERMIA, (Object)new DamageType("legendarysurvivaloverhaul.hypothermia", DamageScaling.NEVER, 0.1f, DamageEffects.FREEZING));
        context.m_255272_(HYPERTHERMIA, (Object)new DamageType("legendarysurvivaloverhaul.hyperthermia", DamageScaling.NEVER, 0.1f, DamageEffects.BURNING));
        context.m_255272_(DEHYDRATION, (Object)new DamageType("legendarysurvivaloverhaul.dehydration", DamageScaling.NEVER, 0.1f, DamageEffects.POKING));
    }
}

