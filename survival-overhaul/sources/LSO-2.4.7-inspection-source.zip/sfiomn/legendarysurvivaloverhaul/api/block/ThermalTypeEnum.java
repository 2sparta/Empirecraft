/*
 * Decompiled with CFR 0.152.
 */
package sfiomn.legendarysurvivaloverhaul.api.block;

public enum ThermalTypeEnum {
    COOLING(-1.0f),
    HEATING(1.0f),
    BROKEN(0.0f);

    private final float temperature;

    private ThermalTypeEnum(float temperature) {
        this.temperature = temperature;
    }

    public float getTemperatureLevel() {
        return this.temperature;
    }

    public static ThermalTypeEnum get(String name) {
        for (ThermalTypeEnum t : ThermalTypeEnum.values()) {
            if (!t.name().equalsIgnoreCase(name)) continue;
            return t;
        }
        throw new IllegalArgumentException();
    }
}

