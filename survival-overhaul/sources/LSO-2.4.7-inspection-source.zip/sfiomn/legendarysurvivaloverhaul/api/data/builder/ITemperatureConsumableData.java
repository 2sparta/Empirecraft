/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.api.data.builder;

import com.google.gson.JsonObject;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableBlockData;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public interface ITemperatureConsumableData {
    public ITemperatureConsumableData group(TemporaryModifierGroupEnum var1);

    public ITemperatureConsumableData temperatureLevel(int var1);

    public ITemperatureConsumableData duration(int var1);

    public ITemperatureConsumableBlockData asBlock();

    public ITemperatureConsumableData copy();

    public JsonObject build();
}

