/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.api.data.builder;

import com.google.gson.JsonObject;

public interface ITemperatureBlockData {
    public ITemperatureBlockData temperature(float var1);

    public ITemperatureBlockData addProperty(String var1, String var2);

    public ITemperatureBlockData copy();

    public JsonObject build();
}

