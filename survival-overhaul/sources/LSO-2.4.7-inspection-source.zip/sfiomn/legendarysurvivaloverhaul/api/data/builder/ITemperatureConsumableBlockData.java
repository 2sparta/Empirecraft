/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.api.data.builder;

import com.google.gson.JsonObject;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public interface ITemperatureConsumableBlockData {
    public ITemperatureConsumableBlockData group(TemporaryModifierGroupEnum var1);

    public ITemperatureConsumableBlockData temperatureLevel(int var1);

    public ITemperatureConsumableBlockData duration(int var1);

    public ITemperatureConsumableBlockData addProperty(String var1, String var2);

    public ITemperatureConsumableBlockData copy();

    public JsonObject build();
}

