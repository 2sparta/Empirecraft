/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  net.minecraft.world.effect.MobEffect
 */
package sfiomn.legendarysurvivaloverhaul.api.data.builder;

import com.google.gson.JsonObject;
import net.minecraft.world.effect.MobEffect;

public interface IThirstData {
    public IThirstData hydration(int var1);

    public IThirstData saturation(float var1);

    public IThirstData addEffect(MobEffect var1, int var2, float var3, int var4);

    public IThirstData addEffect(MobEffect var1, int var2, int var3);

    public IThirstData addEffect(MobEffect var1, int var2, float var3);

    public IThirstData addEffect(MobEffect var1, int var2);

    public IThirstData addProperty(String var1, String var2);

    public IThirstData copy();

    public JsonObject build();
}

