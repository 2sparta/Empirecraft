/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.api.data.builder;

import com.google.gson.JsonObject;
import sfiomn.legendarysurvivaloverhaul.api.block.ThermalTypeEnum;

public interface ITemperatureFuelItemData {
    public ITemperatureFuelItemData thermalType(ThermalTypeEnum var1);

    public ITemperatureFuelItemData duration(int var1);

    public JsonObject build();
}

