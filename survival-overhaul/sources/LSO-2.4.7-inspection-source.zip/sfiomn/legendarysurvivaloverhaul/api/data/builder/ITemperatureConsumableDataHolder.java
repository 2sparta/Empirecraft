/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 */
package sfiomn.legendarysurvivaloverhaul.api.data.builder;

import com.google.gson.JsonArray;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableData;

public interface ITemperatureConsumableDataHolder {
    public ITemperatureConsumableDataHolder addTemperature(ITemperatureConsumableData var1);

    public JsonArray build();
}

