/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.api.data.builder;

import com.google.gson.JsonObject;
import java.util.List;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyPartEnum;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.DamageDistributionEnum;

public interface IBodyPartsDamageSourceData {
    public IBodyPartsDamageSourceData damageDistribution(DamageDistributionEnum var1);

    public IBodyPartsDamageSourceData addBodyPart(BodyPartEnum var1);

    public IBodyPartsDamageSourceData addBodyParts(List<BodyPartEnum> var1);

    public JsonObject build();
}

