/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.api.data.builder;

import com.google.gson.JsonObject;

public interface ITemperatureBiomeOverrideData {
    public ITemperatureBiomeOverrideData temperature(float var1);

    public ITemperatureBiomeOverrideData isDry(boolean var1);

    public JsonObject build();
}

