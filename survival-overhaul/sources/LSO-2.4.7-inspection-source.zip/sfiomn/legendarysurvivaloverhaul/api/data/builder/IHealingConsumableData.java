/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.api.data.builder;

import com.google.gson.JsonObject;

public interface IHealingConsumableData {
    public IHealingConsumableData healingCharges(int var1);

    public IHealingConsumableData healingValue(float var1);

    public IHealingConsumableData duration(int var1);

    public IHealingConsumableData recoveryEffectDuration(int var1);

    public IHealingConsumableData recoveryEffectAmplifier(int var1);

    public JsonObject build();
}

