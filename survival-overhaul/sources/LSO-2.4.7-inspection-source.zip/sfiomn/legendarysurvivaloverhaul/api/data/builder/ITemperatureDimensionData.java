/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.api.data.builder;

import com.google.gson.JsonObject;

public interface ITemperatureDimensionData {
    public ITemperatureDimensionData temperature(float var1);

    public ITemperatureDimensionData seaLevelHeight(int var1);

    public ITemperatureDimensionData hasAltitude();

    public ITemperatureDimensionData temperatureTimeCycleTicks(int var1);

    public JsonObject build();
}

