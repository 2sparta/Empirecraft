/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.api.data.builder;

import com.google.gson.JsonObject;

public interface IBodyPartResistanceData {
    public IBodyPartResistanceData bodyResistance(float var1);

    public IBodyPartResistanceData headResistance(float var1);

    public IBodyPartResistanceData chestResistance(float var1);

    public IBodyPartResistanceData rightArmResistance(float var1);

    public IBodyPartResistanceData leftArmResistance(float var1);

    public IBodyPartResistanceData legsResistance(float var1);

    public IBodyPartResistanceData feetResistance(float var1);

    public JsonObject build();
}

