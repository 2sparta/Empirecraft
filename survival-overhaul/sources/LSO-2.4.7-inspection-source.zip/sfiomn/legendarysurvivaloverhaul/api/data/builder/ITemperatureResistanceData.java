/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.api.data.builder;

import com.google.gson.JsonObject;

public interface ITemperatureResistanceData {
    public ITemperatureResistanceData temperature(float var1);

    public ITemperatureResistanceData heatResistance(float var1);

    public ITemperatureResistanceData coldResistance(float var1);

    public ITemperatureResistanceData thermalResistance(float var1);

    public JsonObject build();
}

