/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package sfiomn.legendarysurvivaloverhaul.api.data.json;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public class JsonTemperatureDimension {
    public static final Codec<JsonTemperatureDimension> CODEC = RecordCodecBuilder.create(inst -> inst.group((App)Codec.FLOAT.fieldOf("temperature").forGetter(d -> Float.valueOf(d.temperature)), (App)Codec.INT.optionalFieldOf("sea_level_height", (Object)64).forGetter(d -> d.seaLevelHeight), (App)Codec.BOOL.optionalFieldOf("has_altitude", (Object)true).forGetter(d -> d.hasAltitude), (App)Codec.INT.optionalFieldOf("temperatureTimeCycleTicks", (Object)0).forGetter(d -> d.temperatureTimeCycleTicks)).apply((Applicative)inst, JsonTemperatureDimension::new));
    public float temperature;
    public int seaLevelHeight;
    public boolean hasAltitude;
    public int temperatureTimeCycleTicks;

    public JsonTemperatureDimension(float temperature, int seaLevelHeight, boolean hasAltitude, int temperatureTimeCycleTicks) {
        this.temperature = temperature;
        this.seaLevelHeight = seaLevelHeight;
        this.hasAltitude = hasAltitude;
        this.temperatureTimeCycleTicks = Math.max(temperatureTimeCycleTicks, 0);
    }
}

