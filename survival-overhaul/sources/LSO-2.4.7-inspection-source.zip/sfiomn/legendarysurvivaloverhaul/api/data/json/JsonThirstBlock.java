/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.material.FluidState
 */
package sfiomn.legendarysurvivaloverhaul.api.data.json;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.FluidState;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonMobEffect;

public class JsonThirstBlock {
    public static final Codec<JsonThirstBlock> CODEC = RecordCodecBuilder.create(inst -> inst.group((App)Codec.INT.fieldOf("hydration").forGetter(c -> c.hydration), (App)Codec.FLOAT.fieldOf("saturation").forGetter(c -> Float.valueOf(c.saturation)), (App)JsonMobEffect.LIST_CODEC.optionalFieldOf("effects", new ArrayList()).forGetter(c -> c.effects), (App)Codec.unboundedMap((Codec)Codec.STRING, (Codec)Codec.STRING).optionalFieldOf("properties", new HashMap()).forGetter(c -> c.properties)).apply((Applicative)inst, JsonThirstBlock::new));
    public static final Codec<List<JsonThirstBlock>> LIST_CODEC = CODEC.listOf();
    public int hydration;
    public float saturation;
    public List<JsonMobEffect> effects;
    public Map<String, String> properties;

    public JsonThirstBlock(int hydration, float saturation, List<JsonMobEffect> effects, Map<String, String> properties) {
        this.hydration = hydration;
        this.saturation = saturation;
        this.effects = new ArrayList<JsonMobEffect>();
        this.effects.addAll(effects);
        this.properties = new HashMap<String, String>();
        this.properties.putAll(properties);
    }

    public boolean isDefault() {
        return this.properties.isEmpty();
    }

    public boolean matchesState(BlockState blockState) {
        for (Property property : blockState.m_61147_()) {
            String name = property.m_61708_();
            if (!this.properties.containsKey(name)) continue;
            String stateValue = blockState.m_61143_(property).toString();
            if (this.properties.get(name).equalsIgnoreCase(stateValue)) continue;
            return false;
        }
        return true;
    }

    public boolean matchesState(FluidState fluidState) {
        for (Property property : fluidState.m_61147_()) {
            String name = property.m_61708_();
            if (!this.properties.containsKey(name)) continue;
            String stateValue = fluidState.m_61143_(property).toString();
            if (this.properties.get(name).equalsIgnoreCase(stateValue)) continue;
            return false;
        }
        return true;
    }
}

