/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.api.data.json;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyPartEnum;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.DamageDistributionEnum;

public class JsonBodyPartsDamageSource {
    public static final Codec<JsonBodyPartsDamageSource> CODEC = RecordCodecBuilder.create(inst -> inst.group((App)Codec.STRING.fieldOf("damage_distribution").forGetter(d -> d.damageDistribution.name()), (App)Codec.STRING.listOf().fieldOf("body_parts").forGetter(d -> d.bodyParts.stream().map(Enum::name).toList())).apply((Applicative)inst, JsonBodyPartsDamageSource::new));
    public List<BodyPartEnum> bodyParts;
    public DamageDistributionEnum damageDistribution;

    public JsonBodyPartsDamageSource(String damageDistribution, List<String> bodyParts) {
        this.damageDistribution = DamageDistributionEnum.get(damageDistribution);
        this.bodyParts = bodyParts.stream().map(BodyPartEnum::get).toList();
    }

    public List<BodyPartEnum> getBodyParts(Player player) {
        return this.damageDistribution.getBodyParts(player, this.bodyParts);
    }
}

