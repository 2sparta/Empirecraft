/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package sfiomn.legendarysurvivaloverhaul.api.data.json;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import sfiomn.legendarysurvivaloverhaul.api.block.ThermalTypeEnum;

public class JsonTemperatureFuelItem {
    public static final Codec<JsonTemperatureFuelItem> CODEC = RecordCodecBuilder.create(inst -> inst.group((App)Codec.STRING.fieldOf("thermal_type").forGetter(d -> d.thermalType.name()), (App)Codec.INT.fieldOf("duration").forGetter(d -> d.duration)).apply((Applicative)inst, JsonTemperatureFuelItem::new));
    public ThermalTypeEnum thermalType;
    public int duration;

    public JsonTemperatureFuelItem(String thermalType, int duration) {
        this.thermalType = ThermalTypeEnum.get(thermalType);
        this.duration = duration;
    }
}

