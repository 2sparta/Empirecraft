/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package sfiomn.legendarysurvivaloverhaul.api.data.json;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyPartEnum;

public class JsonBodyPartResistance {
    public static final Codec<JsonBodyPartResistance> CODEC = RecordCodecBuilder.create(inst -> inst.group((App)Codec.FLOAT.optionalFieldOf("body_resistance", (Object)Float.valueOf(0.0f)).forGetter(c -> Float.valueOf(c.bodyResistance)), (App)Codec.FLOAT.optionalFieldOf("head_resistance", (Object)Float.valueOf(0.0f)).forGetter(c -> Float.valueOf(c.headResistance)), (App)Codec.FLOAT.optionalFieldOf("chest_resistance", (Object)Float.valueOf(0.0f)).forGetter(c -> Float.valueOf(c.chestResistance)), (App)Codec.FLOAT.optionalFieldOf("right_arm_resistance", (Object)Float.valueOf(0.0f)).forGetter(c -> Float.valueOf(c.rightArmResistance)), (App)Codec.FLOAT.optionalFieldOf("left_arm_resistance", (Object)Float.valueOf(0.0f)).forGetter(c -> Float.valueOf(c.leftArmResistance)), (App)Codec.FLOAT.optionalFieldOf("legs_resistance", (Object)Float.valueOf(0.0f)).forGetter(c -> Float.valueOf(c.legsResistance)), (App)Codec.FLOAT.optionalFieldOf("feet_resistance", (Object)Float.valueOf(0.0f)).forGetter(c -> Float.valueOf(c.feetResistance))).apply((Applicative)inst, JsonBodyPartResistance::new));
    public float bodyResistance;
    public float headResistance;
    public float chestResistance;
    public float rightArmResistance;
    public float leftArmResistance;
    public float legsResistance;
    public float feetResistance;

    public JsonBodyPartResistance(float bodyResistance, float headResistance, float chestResistance, float rightArmResistance, float leftArmResistance, float legsResistance, float feetResistance) {
        this.bodyResistance = bodyResistance;
        this.headResistance = headResistance;
        this.chestResistance = chestResistance;
        this.rightArmResistance = rightArmResistance;
        this.leftArmResistance = leftArmResistance;
        this.legsResistance = legsResistance;
        this.feetResistance = feetResistance;
    }

    public float getBodyPartResistance(BodyPartEnum bodyPartEnum) {
        return switch (bodyPartEnum) {
            default -> throw new IncompatibleClassChangeError();
            case BodyPartEnum.HEAD -> this.headResistance;
            case BodyPartEnum.CHEST -> this.chestResistance;
            case BodyPartEnum.RIGHT_ARM -> this.rightArmResistance;
            case BodyPartEnum.LEFT_ARM -> this.leftArmResistance;
            case BodyPartEnum.RIGHT_LEG, BodyPartEnum.LEFT_LEG -> this.legsResistance;
            case BodyPartEnum.RIGHT_FOOT, BodyPartEnum.LEFT_FOOT -> this.feetResistance;
        };
    }
}

