/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package sfiomn.legendarysurvivaloverhaul.api.data.json;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public class JsonTemperatureBiomeOverride {
    public static final Codec<JsonTemperatureBiomeOverride> CODEC = RecordCodecBuilder.create(inst -> inst.group((App)Codec.FLOAT.fieldOf("temperature").forGetter(d -> Float.valueOf(d.temperature)), (App)Codec.BOOL.fieldOf("is_dry").forGetter(d -> d.isDry)).apply((Applicative)inst, JsonTemperatureBiomeOverride::new));
    public float temperature;
    public boolean isDry;

    public JsonTemperatureBiomeOverride(float temperature, boolean isDry) {
        this.temperature = temperature;
        this.isDry = isDry;
    }
}

