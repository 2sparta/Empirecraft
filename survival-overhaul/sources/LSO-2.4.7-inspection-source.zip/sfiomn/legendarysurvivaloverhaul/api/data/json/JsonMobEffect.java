/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package sfiomn.legendarysurvivaloverhaul.api.data.json;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;

public class JsonMobEffect {
    public static final Codec<JsonMobEffect> CODEC = RecordCodecBuilder.create(inst -> inst.group((App)Codec.STRING.fieldOf("effect").forGetter(m -> m.name), (App)Codec.FLOAT.optionalFieldOf("chance", (Object)Float.valueOf(1.0f)).forGetter(m -> Float.valueOf(m.chance)), (App)Codec.INT.fieldOf("duration").forGetter(m -> m.duration), (App)Codec.INT.optionalFieldOf("amplifier", (Object)0).forGetter(m -> m.amplifier)).apply((Applicative)inst, JsonMobEffect::new));
    public static final Codec<List<JsonMobEffect>> LIST_CODEC = CODEC.listOf();
    public float chance;
    public String name;
    public int duration;
    public int amplifier;

    public JsonMobEffect(String name, float chance, int duration, int amplifier) {
        this.name = name;
        this.chance = chance < 0.0f ? 0.0f : (chance > 1.0f ? 1.0f : chance);
        this.duration = Math.max(duration, 0);
        this.amplifier = Math.max(amplifier, 0);
    }
}

