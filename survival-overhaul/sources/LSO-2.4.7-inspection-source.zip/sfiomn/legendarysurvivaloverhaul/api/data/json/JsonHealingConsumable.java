/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package sfiomn.legendarysurvivaloverhaul.api.data.json;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public class JsonHealingConsumable {
    public static final Codec<JsonHealingConsumable> CODEC = RecordCodecBuilder.create(inst -> inst.group((App)Codec.INT.fieldOf("healing_charges").forGetter(d -> d.healingCharges), (App)Codec.FLOAT.fieldOf("healing_value").forGetter(d -> Float.valueOf(d.healingValue)), (App)Codec.INT.fieldOf("healing_time").forGetter(d -> d.healingTime), (App)Codec.INT.optionalFieldOf("recovery_effect_duration", (Object)0).forGetter(d -> d.recoveryEffectDuration), (App)Codec.INT.optionalFieldOf("recovery_effect_amplifier", (Object)0).forGetter(d -> d.recoveryEffectAmplifier)).apply((Applicative)inst, JsonHealingConsumable::new));
    public int healingCharges;
    public float healingValue;
    public int healingTime;
    public int recoveryEffectDuration;
    public int recoveryEffectAmplifier;

    public JsonHealingConsumable(int healingCharges, float healingValue, int healingTime, int recoveryEffectDuration, int recoveryEffectAmplifier) {
        this.healingCharges = healingCharges;
        this.healingValue = healingValue;
        this.healingTime = healingTime;
        this.recoveryEffectDuration = recoveryEffectDuration;
        this.recoveryEffectAmplifier = recoveryEffectAmplifier;
    }
}

