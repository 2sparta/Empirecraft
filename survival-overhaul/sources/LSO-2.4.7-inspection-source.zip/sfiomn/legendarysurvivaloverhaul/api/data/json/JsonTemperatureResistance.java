/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package sfiomn.legendarysurvivaloverhaul.api.data.json;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public class JsonTemperatureResistance {
    public static final Codec<JsonTemperatureResistance> CODEC = RecordCodecBuilder.create(inst -> inst.group((App)Codec.FLOAT.optionalFieldOf("temperature", (Object)Float.valueOf(0.0f)).forGetter(c -> Float.valueOf(c.temperature)), (App)Codec.FLOAT.optionalFieldOf("heat_resistance", (Object)Float.valueOf(0.0f)).forGetter(c -> Float.valueOf(c.heatResistance)), (App)Codec.FLOAT.optionalFieldOf("cold_resistance", (Object)Float.valueOf(0.0f)).forGetter(c -> Float.valueOf(c.coldResistance)), (App)Codec.FLOAT.optionalFieldOf("thermal_resistance", (Object)Float.valueOf(0.0f)).forGetter(c -> Float.valueOf(c.thermalResistance))).apply((Applicative)inst, JsonTemperatureResistance::new));
    public float temperature;
    public float heatResistance;
    public float coldResistance;
    public float thermalResistance;

    public JsonTemperatureResistance() {
        this(0.0f, 0.0f, 0.0f, 0.0f);
    }

    public JsonTemperatureResistance(float temperature) {
        this(temperature, 0.0f, 0.0f, 0.0f);
    }

    public JsonTemperatureResistance(float temperature, float heatResistance, float coldResistance, float thermalResistance) {
        this.temperature = temperature;
        this.heatResistance = heatResistance;
        this.coldResistance = coldResistance;
        this.thermalResistance = thermalResistance;
    }

    public void add(JsonTemperatureResistance config) {
        this.temperature += config.temperature;
        this.heatResistance += config.heatResistance;
        this.coldResistance += config.coldResistance;
        this.thermalResistance += config.thermalResistance;
    }
}

