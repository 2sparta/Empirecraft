/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.api.data.manager;

import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonBodyPartResistance;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonBodyPartsDamageSource;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonHealingConsumable;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.IBodyPartsDamageSourceManager;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.IBodyResistanceItemManager;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.IHealingConsumableManager;

public class BodyDamageDataManager {
    public static IBodyPartsDamageSourceManager internalBodyPartsDamageSource;
    public static IHealingConsumableManager internalHealingConsumable;
    public static IBodyResistanceItemManager internalBodyResistanceItem;

    @Nullable
    public static JsonBodyPartsDamageSource getBodyParts(String damageSourceName) {
        return internalBodyPartsDamageSource.get(damageSourceName.toLowerCase());
    }

    @Nullable
    public static JsonHealingConsumable getHealingItem(ResourceLocation itemRegistryName) {
        return internalHealingConsumable.get(itemRegistryName);
    }

    @Nullable
    public static JsonBodyPartResistance getBodyResistanceItem(ResourceLocation itemRegistryName) {
        return internalBodyResistanceItem.get(itemRegistryName);
    }
}

