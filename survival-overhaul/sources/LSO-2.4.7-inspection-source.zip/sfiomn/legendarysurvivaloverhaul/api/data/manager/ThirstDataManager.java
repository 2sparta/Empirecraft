/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.material.FluidState
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.api.data.manager;

import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonThirstBlock;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonThirstConsumable;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.IThirstBlockManager;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.IThirstConsumableManager;

public class ThirstDataManager {
    public static IThirstBlockManager internalBlock;
    public static IThirstConsumableManager internalConsumable;

    @Nullable
    public static List<JsonThirstBlock> getBlock(ResourceLocation blockRegistryName) {
        return internalBlock.get(blockRegistryName);
    }

    @Nullable
    public static JsonThirstBlock getBlock(BlockState block) {
        return internalBlock.get(block);
    }

    @Nullable
    public static JsonThirstBlock getBlock(FluidState fluid) {
        return internalBlock.get(fluid);
    }

    @Nullable
    public static List<JsonThirstConsumable> getConsumable(ResourceLocation itemRegistryName) {
        return internalConsumable.get(itemRegistryName);
    }

    @Nullable
    public static JsonThirstConsumable getConsumable(ItemStack itemStack) {
        return internalConsumable.get(itemStack);
    }
}

