/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.material.FluidState
 */
package sfiomn.legendarysurvivaloverhaul.api.data.manager;

import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonThirstBlock;

public interface IThirstBlockManager {
    public List<JsonThirstBlock> get(ResourceLocation var1);

    public JsonThirstBlock get(BlockState var1);

    public JsonThirstBlock get(FluidState var1);
}

