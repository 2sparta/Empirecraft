/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 */
package sfiomn.legendarysurvivaloverhaul.api.data.manager;

import java.util.List;
import net.minecraft.resources.ResourceLocation;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureConsumable;

public interface ITemperatureConsumableManager {
    public List<JsonTemperatureConsumable> get(ResourceLocation var1);
}

