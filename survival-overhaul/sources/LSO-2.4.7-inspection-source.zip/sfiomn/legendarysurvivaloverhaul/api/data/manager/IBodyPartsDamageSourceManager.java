/*
 * Decompiled with CFR 0.152.
 */
package sfiomn.legendarysurvivaloverhaul.api.data.manager;

import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonBodyPartsDamageSource;

public interface IBodyPartsDamageSourceManager {
    public JsonBodyPartsDamageSource get(String var1);
}

