/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.api.data.manager;

import java.util.List;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureBiomeOverride;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureBlock;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureConsumable;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureConsumableBlock;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureDimension;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureFuelItem;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureResistance;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.ITemperatureBiomeManager;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.ITemperatureBlockManager;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.ITemperatureConsumableBlockManager;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.ITemperatureConsumableManager;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.ITemperatureDimensionManager;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.ITemperatureFuelItemManager;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.ITemperatureItemManager;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.ITemperatureMountManager;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.ITemperatureOriginManager;

public class TemperatureDataManager {
    public static ITemperatureBlockManager internalBlock;
    public static ITemperatureConsumableManager internalConsumable;
    public static ITemperatureConsumableBlockManager internalConsumableBlock;
    public static ITemperatureItemManager internalItem;
    public static ITemperatureBiomeManager internalBiome;
    public static ITemperatureFuelItemManager internalFuelItem;
    public static ITemperatureDimensionManager internalDimension;
    public static ITemperatureMountManager internalMount;
    public static ITemperatureOriginManager internalOrigin;

    public static List<JsonTemperatureBlock> getBlock(ResourceLocation blockRegistryName) {
        return internalBlock.get(blockRegistryName);
    }

    public static List<JsonTemperatureConsumable> getConsumable(ResourceLocation itemRegistryName) {
        return internalConsumable.get(itemRegistryName);
    }

    public static List<JsonTemperatureConsumableBlock> getConsumableBlock(ResourceLocation itemRegistryName) {
        return internalConsumableBlock.get(itemRegistryName);
    }

    @Nullable
    public static JsonTemperatureResistance getItem(ResourceLocation itemRegistryName) {
        return internalItem.get(itemRegistryName);
    }

    @Nullable
    public static JsonTemperatureBiomeOverride getBiome(ResourceLocation biomeRegistryName) {
        return internalBiome.get(biomeRegistryName);
    }

    @Nullable
    public static JsonTemperatureFuelItem getFuelItem(ResourceLocation itemRegistryName) {
        return internalFuelItem.get(itemRegistryName);
    }

    @Nullable
    public static JsonTemperatureDimension getDimension(ResourceLocation dimensionRegistryName) {
        return internalDimension.get(dimensionRegistryName);
    }

    @Nullable
    public static JsonTemperatureResistance getMount(ResourceLocation mountRegistryName) {
        return internalMount.get(mountRegistryName);
    }

    @Nullable
    public static JsonTemperatureResistance getOrigin(ResourceLocation originRegistryName) {
        return internalOrigin.get(originRegistryName);
    }
}

