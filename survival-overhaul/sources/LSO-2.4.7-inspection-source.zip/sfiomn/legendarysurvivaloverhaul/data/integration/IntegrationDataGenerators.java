/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.DataGenerator
 *  net.minecraft.data.DataProvider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 *  net.minecraftforge.data.event.GatherDataEvent
 *  net.minecraftforge.fml.ModList
 */
package sfiomn.legendarysurvivaloverhaul.data.integration;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.data.event.GatherDataEvent;
import net.minecraftforge.fml.ModList;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.AlexsMobsTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.AquamiraeTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.ArtifactsTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.AtmosphericBodyDamageProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.BeachPartyTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.BeachPartyThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.BetterEndForgeTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.BetterEndTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.BopTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.BornInChaosTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.BreweryTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.BreweryThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.BrewinAndChewinTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.BrewinAndChewinThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.BrewinCompatDelightTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.BrewinCompatDelightThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.BygTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CallOfYucatanTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CampingTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CandlelightTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CandlelightThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CataclysmTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.ConfectioneryThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CornExpansionThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CrabbersDelightTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CrabbersDelightThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CreateTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CreateThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CrockpotTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CrockpotThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CuriosBlockTagProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CuriosItemTagProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.CuriosProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.DecorativeBlocksTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.EcologicsThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.EndergeticTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.EndermanOverhaulTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.FarmAndCharmTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.FarmAndCharmThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.FarmersDelightTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.FarmersDelightThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.FarmersRespiteTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.FarmersRespiteThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.GraveyardTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.HardcoreTorchesTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.HearthAndHarvestTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.HearthAndHarvestThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.HerbalBrewsTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.HerbalBrewsThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.IceAndFireBodyDamageProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.IceAndFireTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.InfernalExpansionTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.IronsSpellbooksTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.LegendaryAdditionsTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.LegendaryCreaturesBodyDamageProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.LegendaryCreaturesTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.MeadowTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.MeadowThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.MedsAndHerbsBodyDamageProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.NeapolitanTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.NeapolitanThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.NetherVineryTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.NetherVineryThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.OriginsTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.PeculiarsTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.PeculiarsThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.QuarkTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.RealisticTorchesTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.RusticDelightTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.RusticDelightThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.SeasonalsTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.SeasonalsThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.SupplementariesBodyDamageProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.SupplementariesTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.SupplementariesThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.SurvivalInstinctBodyDamageProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.SurvivalInstinctThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.TerraFirmaCraftTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.UpgradeAquaticThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.ValhelsiaStructuresTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.VineryTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.VineryThirstProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.WardrobeTemperatureProvider;
import sfiomn.legendarysurvivaloverhaul.data.integration.providers.WilderNatureTemperatureProvider;

public final class IntegrationDataGenerators {
    public static void addIntegrationProviders(GatherDataEvent event, DataGenerator gen, PackOutput packOutput, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper existingFileHelper) {
        gen.addProvider(event.includeServer(), (DataProvider)new AlexsMobsTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new AquamiraeTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new ArtifactsTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new AtmosphericBodyDamageProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new BeachPartyTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new BeachPartyThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new BetterEndForgeTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new BetterEndTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new BopTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new BornInChaosTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new BreweryTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new BreweryThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new BrewinAndChewinTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new BrewinAndChewinThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new BrewinCompatDelightTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new BrewinCompatDelightThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new BygTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new CallOfYucatanTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new CampingTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new CandlelightTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new CandlelightThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new CataclysmTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new ConfectioneryThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new CornExpansionThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new CrabbersDelightTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new CrabbersDelightThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new CreateTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new CreateThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new CrockpotTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new CrockpotThirstProvider(packOutput, lookupProvider, existingFileHelper));
        if (ModList.get().isLoaded("curios")) {
            gen.addProvider(event.includeServer(), (DataProvider)new CuriosProvider(packOutput, existingFileHelper, lookupProvider));
            CuriosBlockTagProvider blockTagProvider = (CuriosBlockTagProvider)gen.addProvider(event.includeServer(), (DataProvider)new CuriosBlockTagProvider(packOutput, lookupProvider, existingFileHelper));
            gen.addProvider(event.includeServer(), (DataProvider)new CuriosItemTagProvider(packOutput, lookupProvider, blockTagProvider.m_274426_(), existingFileHelper));
        }
        gen.addProvider(event.includeServer(), (DataProvider)new DecorativeBlocksTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new EcologicsThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new EndergeticTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new EndermanOverhaulTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new FarmAndCharmTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new FarmAndCharmThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new FarmersDelightTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new FarmersDelightThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new FarmersRespiteTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new FarmersRespiteThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new GraveyardTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new HardcoreTorchesTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new HearthAndHarvestTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new HearthAndHarvestThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new HerbalBrewsTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new HerbalBrewsThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new IceAndFireBodyDamageProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new IceAndFireTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new InfernalExpansionTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new IronsSpellbooksTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new LegendaryAdditionsTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new LegendaryCreaturesBodyDamageProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new LegendaryCreaturesTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new MeadowTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new MeadowThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new MedsAndHerbsBodyDamageProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new NeapolitanTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new NeapolitanThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new NetherVineryTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new NetherVineryThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new OriginsTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new PeculiarsTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new PeculiarsThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new QuarkTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new RealisticTorchesTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new RusticDelightTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new RusticDelightThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new SeasonalsTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new SeasonalsThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new SupplementariesBodyDamageProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new SupplementariesTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new SupplementariesThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new SurvivalInstinctBodyDamageProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new SurvivalInstinctThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new TerraFirmaCraftTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new UpgradeAquaticThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new ValhelsiaStructuresTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new VineryTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new VineryThirstProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new WardrobeTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
        gen.addProvider(event.includeServer(), (DataProvider)new WilderNatureTemperatureProvider(packOutput, lookupProvider, existingFileHelper));
    }
}

