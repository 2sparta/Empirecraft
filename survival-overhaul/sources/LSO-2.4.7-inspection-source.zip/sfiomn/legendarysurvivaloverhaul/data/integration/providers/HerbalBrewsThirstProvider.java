/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;

public class HerbalBrewsThirstProvider
extends ThirstDataProvider {
    public HerbalBrewsThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("herbalbrews", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("green_tea").addThirst(this.thirstData(5, 3.0f));
        this.consumable("black_tea").addThirst(this.thirstData(5, 3.0f));
        this.consumable("hibiscus_tea").addThirst(this.thirstData(6, 4.0f));
        this.consumable("lavender_tea").addThirst(this.thirstData(7, 5.0f));
        this.consumable("coffee").addThirst(this.thirstData(5, 3.5f));
        this.consumable("milk_coffee").addThirst(this.thirstData(6, 4.0f));
        this.consumable("rooibos_tea").addThirst(this.thirstData(9, 7.0f));
        this.consumable("oolong_tea").addThirst(this.thirstData(10, 10.0f));
        this.consumable("yerba_mate_tea").addThirst(this.thirstData(12, 12.0f));
        this.consumable("flask").addThirst(this.thirstData(7, 4.5f));
    }
}

