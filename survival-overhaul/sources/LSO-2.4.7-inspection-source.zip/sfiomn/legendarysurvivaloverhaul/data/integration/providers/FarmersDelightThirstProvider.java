/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;

public class FarmersDelightThirstProvider
extends ThirstDataProvider {
    public FarmersDelightThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("farmersdelight", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("tomato").addThirst(this.thirstData(4, 0.0f));
        this.consumable("milk_bottle").addThirst(this.thirstData(6, 1.0f));
        this.consumable("apple_cider").addThirst(this.thirstData(5, 2.0f));
        this.consumable("hot_cocoa").addThirst(this.thirstData(6, 3.0f));
        this.consumable("melon_juice").addThirst(this.thirstData(8, 4.0f));
        this.consumable("tomato_sauce").addThirst(this.thirstData(6, 0.0f));
        this.consumable("melon_popsicle").addThirst(this.thirstData(4, 1.0f));
        this.consumable("fruit_salad").addThirst(this.thirstData(6, 2.0f));
        this.consumable("chicken_soup").addThirst(this.thirstData(4, 2.0f));
        this.consumable("vegetable_soup").addThirst(this.thirstData(4, 2.0f));
        this.consumable("pumpkin_soup").addThirst(this.thirstData(7, 3.0f));
    }
}

