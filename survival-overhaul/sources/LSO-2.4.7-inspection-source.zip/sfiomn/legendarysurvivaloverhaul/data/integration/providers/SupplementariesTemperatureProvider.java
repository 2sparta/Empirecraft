/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureBlockData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class SupplementariesTemperatureProvider
extends TemperatureDataProvider {
    public SupplementariesTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("supplementaries", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.block("fire_pit").addTemperature(this.temperatureBlock(12.5f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        ITemperatureBlockData candleOn = this.temperatureBlock(1.5f).addProperty("lit", "true");
        ITemperatureBlockData candleOff = this.temperatureBlock(0.0f).addProperty("lit", "false");
        this.block("candle_holder").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_white").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_light_gray").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_gray").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_black").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_brown").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_red").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_orange").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_yellow").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_lime").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_green").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_cyan").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_light_blue").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_blue").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_purple").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_magenta").addTemperature(candleOn).addTemperature(candleOff);
        this.block("candle_holder_pink").addTemperature(candleOn).addTemperature(candleOff);
        ITemperatureBlockData sconceOn = this.temperatureBlock(2.5f).addProperty("lit", "true");
        ITemperatureBlockData sconceOff = this.temperatureBlock(0.0f).addProperty("lit", "false");
        this.block("sconce").addTemperature(sconceOn).addTemperature(sconceOff);
        this.block("sconce_lever").addTemperature(sconceOn).addTemperature(sconceOff);
        ITemperatureBlockData soulSconceOn = this.temperatureBlock(-2.5f).addProperty("lit", "true");
        ITemperatureBlockData soulSconceOff = this.temperatureBlock(0.0f).addProperty("lit", "false");
        this.block("soul_sconce").addTemperature(soulSconceOn).addTemperature(soulSconceOff);
        this.item("sconce").temperature(1.5f);
        this.item("sconce_lever").temperature(1.5f);
        this.item("soul_sconce").temperature(-1.5f);
    }
}

