/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class HearthAndHarvestThirstProvider
extends ThirstDataProvider {
    public HearthAndHarvestThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("hearthandharvest", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("goat_milk_bottle").addThirst(this.thirstData(6, 1.0f));
        this.consumable("mead").addThirst(this.thirstData(7, 4.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f));
        this.consumable("blueberries").addThirst(this.thirstData(4, 0.0f));
        this.consumable("blueberry_juice").addThirst(this.thirstData(6, 3.0f));
        this.consumable("blueberry_wine").addThirst(this.thirstData(7, 4.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f));
        this.consumable("cherry").addThirst(this.thirstData(4, 0.0f));
        this.consumable("cherry_juice").addThirst(this.thirstData(6, 3.0f));
        this.consumable("cherry_wine").addThirst(this.thirstData(7, 4.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f));
        this.consumable("green_grapes").addThirst(this.thirstData(4, 0.0f));
        this.consumable("green_grape_juice").addThirst(this.thirstData(6, 3.0f));
        this.consumable("green_grape_wine").addThirst(this.thirstData(7, 4.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f));
        this.consumable("raspberry").addThirst(this.thirstData(4, 0.0f));
        this.consumable("raspberry_juice").addThirst(this.thirstData(6, 3.0f));
        this.consumable("raspberry_wine").addThirst(this.thirstData(7, 4.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f));
        this.consumable("red_grapes").addThirst(this.thirstData(4, 0.0f));
        this.consumable("red_grape_juice").addThirst(this.thirstData(6, 3.0f));
        this.consumable("red_grape_wine").addThirst(this.thirstData(7, 4.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f));
        this.consumable("sweet_berry_wine").addThirst(this.thirstData(7, 4.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f));
    }
}

