/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class RusticDelightTemperatureProvider
extends TemperatureDataProvider {
    public RusticDelightTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("rusticdelight", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        ITemperatureConsumableData coffee = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(2).duration(2400);
        this.consumable("dark_coffee").addTemperature(coffee);
        this.consumable("coffee").addTemperature(coffee);
        this.consumable("milk_coffee").addTemperature(coffee);
        this.consumable("syrup_coffee").addTemperature(coffee);
        this.consumable("chocolate_coffee").addTemperature(coffee);
        this.consumable("honey_coffee").addTemperature(coffee);
        this.consumable("bell_pepper_green").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-1).duration(2400));
        this.consumable("bell_pepper_yellow").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-1).duration(2400));
        this.consumable("bell_pepper_red").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-1).duration(2400));
        this.consumable("potato_salad").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-1).duration(2400));
        this.consumable("sweet_salad").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-1).duration(2400));
    }
}

