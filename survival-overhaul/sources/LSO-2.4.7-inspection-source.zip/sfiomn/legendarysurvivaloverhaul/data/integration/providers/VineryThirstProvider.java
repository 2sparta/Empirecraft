/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class VineryThirstProvider
extends ThirstDataProvider {
    public VineryThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("vinery", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("rotten_cherry").addThirst(this.thirstData(-4, 0.0f));
        IThirstData grape_hydration = this.thirstData(4, 0.0f);
        IThirstData grape_hydration2 = this.thirstData(6, 2.0f);
        this.consumable("cherry").addThirst(grape_hydration);
        this.consumable("red_grape").addThirst(grape_hydration);
        this.consumable("white_grape").addThirst(grape_hydration);
        this.consumable("savanna_grapes_red").addThirst(grape_hydration);
        this.consumable("savanna_grapes_white").addThirst(grape_hydration);
        this.consumable("taiga_grapes_red").addThirst(grape_hydration);
        this.consumable("taiga_grapes_white").addThirst(grape_hydration);
        this.consumable("jungle_grapes_red").addThirst(grape_hydration2);
        this.consumable("jungle_grapes_white").addThirst(grape_hydration2);
        IThirstData juice_hydration = this.thirstData(7, 3.0f);
        IThirstData juice_hydration2 = this.thirstData(9, 5.0f);
        this.consumable("red_grapejuice").addThirst(juice_hydration);
        this.consumable("white_grapejuice").addThirst(juice_hydration);
        this.consumable("red_savanna_grapejuice").addThirst(juice_hydration);
        this.consumable("white_savanna_grapejuice").addThirst(juice_hydration);
        this.consumable("red_taiga_grapejuice").addThirst(juice_hydration);
        this.consumable("white_taiga_grapejuice").addThirst(juice_hydration);
        this.consumable("red_jungle_grapejuice").addThirst(juice_hydration2);
        this.consumable("white_jungle_grapejuice").addThirst(juice_hydration2);
        this.consumable("apple_juice").addThirst(grape_hydration2);
        IThirstData vinery_hydration1 = this.thirstData(7, 5.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 400, 0.3f);
        IThirstData vinery_hydration2 = this.thirstData(9, 6.5f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 500, 0.3f);
        this.consumable("apple_cider").addThirst(vinery_hydration1);
        this.consumable("apple_wine").addThirst(vinery_hydration1);
        this.consumable("noir_wine").addThirst(vinery_hydration1);
        this.consumable("glowing_wine").addThirst(vinery_hydration1);
        this.consumable("red_wine").addThirst(vinery_hydration1);
        this.consumable("cherry_wine").addThirst(vinery_hydration1);
        this.consumable("creepers_crush").addThirst(vinery_hydration1);
        this.consumable("kelp_cider").addThirst(vinery_hydration1);
        this.consumable("jo_special_mixture").addThirst(vinery_hydration1);
        this.consumable("eiswein").addThirst(vinery_hydration1);
        this.consumable("villagers_fright").addThirst(vinery_hydration1);
        this.consumable("clark_wine").addThirst(vinery_hydration1);
        this.consumable("magnetic_wine").addThirst(vinery_hydration1);
        this.consumable("mead").addThirst(vinery_hydration2);
        this.consumable("solaris_wine").addThirst(vinery_hydration2);
        this.consumable("strad_wine").addThirst(vinery_hydration2);
        this.consumable("lilitu_wine").addThirst(vinery_hydration2);
        this.consumable("aegis_wine").addThirst(vinery_hydration2);
        this.consumable("bolvar_wine").addThirst(vinery_hydration2);
        this.consumable("stal_wine").addThirst(vinery_hydration2);
        this.consumable("chenet_wine").addThirst(vinery_hydration2);
        this.consumable("bottle_mojang_noir").addThirst(this.thirstData(8, 5.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.3f));
        IThirstData vinery_hydration3 = this.thirstData(9, 8.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 800, 0.4f);
        this.consumable("mellohi_wine").addThirst(vinery_hydration3);
        this.consumable("cristel_wine").addThirst(vinery_hydration3);
        this.consumable("chorus_wine").addThirst(vinery_hydration3);
        this.consumable("jellie_wine").addThirst(this.thirstData(12, 10.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 1000, 0.3f));
    }
}

