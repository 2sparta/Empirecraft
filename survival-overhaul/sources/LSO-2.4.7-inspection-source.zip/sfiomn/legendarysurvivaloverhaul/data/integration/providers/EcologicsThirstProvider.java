/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class EcologicsThirstProvider
extends ThirstDataProvider {
    public EcologicsThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("ecologics", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("coconut_slice").addThirst(this.thirstData(3, 0.5f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f));
        this.consumable("prickly_pear").addThirst(this.thirstData(2, 0.5f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f));
        this.consumable("tropical_stew").addThirst(this.thirstData(3, 0.5f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.4f));
    }
}

