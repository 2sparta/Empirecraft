/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.BodyDamageDataProvider;

public class SurvivalInstinctBodyDamageProvider
extends BodyDamageDataProvider {
    public SurvivalInstinctBodyDamageProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("survival_instinct", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("adrenaline_injector").healingCharges(1).healingValue(1.0f).duration(100);
        this.consumable("adrenaline_syringe").healingCharges(1).healingValue(1.0f).duration(100);
        this.consumable("bandage").healingCharges(3).healingValue(3.0f).duration(300);
        this.consumable("blood_syringe").healingCharges(1).healingValue(4.0f).duration(375);
        this.consumable("homemade_bandage").healingCharges(3).healingValue(3.0f).duration(300);
        this.consumable("medkit_bag").healingCharges(6).healingValue(8.0f).duration(400);
        this.consumable("medkit_bag").healingCharges(6).healingValue(8.0f).duration(400);
        this.consumable("morphine_injector").healingCharges(1).healingValue(2.0f).duration(150);
        this.consumable("morphine_syringe").healingCharges(1).healingValue(2.0f).duration(150);
    }
}

