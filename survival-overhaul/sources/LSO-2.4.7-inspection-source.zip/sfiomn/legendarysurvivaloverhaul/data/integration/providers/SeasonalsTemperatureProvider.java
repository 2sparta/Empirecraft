/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class SeasonalsTemperatureProvider
extends TemperatureDataProvider {
    public SeasonalsTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("seasonals", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("pumpkin_ice_cream").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-3).duration(3600));
        this.consumable("sweet_berry_ice_cream").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-3).duration(3600));
        this.consumable("pumpkin_milkshake").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-3).duration(3600));
        this.consumable("sweet_berry_milkshake").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-3).duration(3600));
    }
}

