/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class FarmAndCharmTemperatureProvider
extends TemperatureDataProvider {
    public FarmAndCharmTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("farm_and_charm", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("farmer_salad").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-1).duration(2400));
        this.consumable("goulash").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(3).duration(4800));
        this.consumable("chicken_wrapped_in_bacon").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(1).duration(4800));
        this.consumableAndConsumableBlock("stuffed_rabbit", this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(1).duration(2400));
        this.consumableAndConsumableBlock("stuffed_chicken", this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(1).duration(2400));
        this.consumableAndConsumableBlock("farmers_breakfast", this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(1).duration(7200));
        this.consumable("sausage_with_oat_patty").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(2).duration(4800));
        ITemperatureConsumableData soupTemperatureData = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(2).duration(3600);
        this.consumable("simple_tomato_soup").addTemperature(soupTemperatureData);
        this.consumable("barley_soup").addTemperature(soupTemperatureData);
        this.consumable("onion_soup").addTemperature(soupTemperatureData);
        this.consumable("potato_soup").addTemperature(soupTemperatureData);
        this.consumable("strawberry_tea").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-2).duration(3600));
        this.consumable("nettle_tea").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-2).duration(3600));
        this.consumable("ribwort_tea").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-2).duration(3600));
        this.consumable("strawberry_tea_cup").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400));
        this.consumable("nettle_tea_cup").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400));
        this.consumable("ribwort_tea_cup").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400));
        this.block("roaster").addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false")).addTemperature(this.temperatureBlock(4.0f).addProperty("lit", "true"));
        this.block("cooking_pot").addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false")).addTemperature(this.temperatureBlock(3.0f).addProperty("lit", "true"));
        this.block("stove").addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false")).addTemperature(this.temperatureBlock(6.0f).addProperty("lit", "true"));
    }
}

