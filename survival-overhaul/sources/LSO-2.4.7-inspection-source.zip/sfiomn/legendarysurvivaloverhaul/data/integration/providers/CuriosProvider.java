/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.common.data.ExistingFileHelper
 *  top.theillusivec4.curios.api.CuriosDataProvider
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.data.ExistingFileHelper;
import top.theillusivec4.curios.api.CuriosDataProvider;

public class CuriosProvider
extends CuriosDataProvider {
    public CuriosProvider(PackOutput output, ExistingFileHelper fileHelper, CompletableFuture<HolderLookup.Provider> registries) {
        super("legendarysurvivaloverhaul", output, fileHelper, registries);
    }

    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        String beltSlotId = "belt";
        String necklaceSlotId = "necklace";
        String headSlotId = "head";
        String bodySlotId = "body";
        String charmSlotId = "charm";
        String ringSlotId = "ring";
        this.createSlot(beltSlotId).icon(new ResourceLocation("curios:slot/empty_belt_slot"));
        this.createSlot(necklaceSlotId).icon(new ResourceLocation("curios:slot/empty_necklace_slot"));
        this.createSlot(headSlotId).icon(new ResourceLocation("curios:slot/empty_head_slot"));
        this.createSlot(bodySlotId).icon(new ResourceLocation("curios:slot/empty_body_slot"));
        this.createSlot(charmSlotId).icon(new ResourceLocation("curios:slot/empty_charm_slot"));
        this.createSlot(ringSlotId).icon(new ResourceLocation("curios:slot/empty_ring_slot"));
        this.createEntities("player").addPlayer().addSlots(new String[]{beltSlotId, necklaceSlotId, headSlotId, bodySlotId, charmSlotId, ringSlotId});
    }
}

