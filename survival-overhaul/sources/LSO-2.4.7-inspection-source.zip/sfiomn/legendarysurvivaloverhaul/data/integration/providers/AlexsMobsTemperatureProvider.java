/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class AlexsMobsTemperatureProvider
extends TemperatureDataProvider {
    public AlexsMobsTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("alexsmobs", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.item("roadrunner_boots").heatResistance(1.0f);
        this.item("crocodile_chestplate").coldResistance(1.0f);
        this.item("centipede_leggings").heatResistance(1.0f);
        this.item("frontier_cap").coldResistance(4.0f);
        this.item("sombrero").heatResistance(4.0f);
        this.item("emu_leggings").heatResistance(1.5f);
        this.item("froststalker_helmet").heatResistance(3.0f);
        this.item("unsettling_kimono").heatResistance(2.0f);
    }
}

