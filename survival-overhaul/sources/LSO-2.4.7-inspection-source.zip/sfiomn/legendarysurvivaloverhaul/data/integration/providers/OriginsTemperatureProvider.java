/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class OriginsTemperatureProvider
extends TemperatureDataProvider {
    public OriginsTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("origins", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.origin("blazeborn").temperature(-5.0f).heatResistance(15.0f).coldResistance(-2.0f);
        this.origin("merling").coldResistance(3.0f);
        this.origin("arachnid").heatResistance(-5.0f);
        this.origin("feline").thermalResistance(2.0f);
        this.origin("enderian").coldResistance(10.0f);
    }
}

