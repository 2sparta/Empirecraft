/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class BeachPartyTemperatureProvider
extends TemperatureDataProvider {
    public BeachPartyTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("beachparty", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("sweetberry_icecream").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-2).duration(1200));
        this.consumable("coconut_icecream").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-2).duration(1200));
        this.consumable("chocolate_icecream").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-2).duration(1200));
        this.consumable("icecream_coconut").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-2).duration(1200));
        this.consumable("icecream_cactus").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-2).duration(1200));
        this.consumable("icecream_chocolate").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-2).duration(1200));
        this.consumable("icecream_sweetberries").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-2).duration(1200));
        this.consumable("icecream_melon").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-2).duration(1200));
        this.consumable("coconut_cocktail").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400));
        this.consumable("sweetberries_cocktail").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400));
        this.consumable("cocoa_cocktail").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-2).duration(2400));
        this.consumable("pumpkin_cocktail").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400));
        this.consumable("melon_cocktail").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400));
        this.consumable("honey_cocktail").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400));
        this.consumable("refreshing_drink").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400));
        this.consumable("sweetberry_milkshake").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-3).duration(4800));
        this.consumable("coconut_milkshake").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-2).duration(1800));
        this.consumable("chocolate_milkshake").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-2).duration(1800));
        this.item("beach_hat").heatResistance(2.5f);
        this.item("trunks").heatResistance(3.0f);
        this.item("bikini").heatResistance(3.0f);
        this.item("crocs").heatResistance(0.5f);
        this.item("palm_torch_item").temperature(1.5f);
        this.item("tall_palm_torch").temperature(2.0f);
        this.block("palm_torch_item").addTemperature(this.temperatureBlock(1.5f));
        this.block("tall_palm_torch").addTemperature(this.temperatureBlock(2.0f));
    }
}

