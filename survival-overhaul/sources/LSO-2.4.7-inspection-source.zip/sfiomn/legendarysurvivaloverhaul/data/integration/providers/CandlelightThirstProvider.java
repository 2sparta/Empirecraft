/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class CandlelightThirstProvider
extends ThirstDataProvider {
    public CandlelightThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("candlelight", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("mozzarella").addThirst(this.thirstData(2, 0.0f));
        IThirstData soupThirstData = this.thirstData(4, 2.0f);
        this.consumable("tomato_soup").addThirst(soupThirstData);
        this.consumable("mushroom_soup").addThirst(soupThirstData);
        IThirstData sinkThirst = this.thirstData(3, 0.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 300, 0.75f).addProperty("filled", "true");
        this.block("cobblestone_kitchen_sink").addThirst(sinkThirst);
        this.block("sandstone_kitchen_sink").addThirst(sinkThirst);
        this.block("stone_bricks_kitchen_sink").addThirst(sinkThirst);
        this.block("deepslate_kitchen_sink").addThirst(sinkThirst);
        this.block("granite_kitchen_sink").addThirst(sinkThirst);
        this.block("end_kitchen_sink").addThirst(sinkThirst);
        this.block("mud_kitchen_sink").addThirst(sinkThirst);
        this.block("quartz_kitchen_sink").addThirst(sinkThirst);
        this.block("mud_kitchen_sink").addThirst(sinkThirst);
        this.block("mud_kitchen_sink").addThirst(sinkThirst);
        this.block("quartz_kitchen_sink").addThirst(sinkThirst);
        this.block("red_nether_bricks_kitchen_sink").addThirst(sinkThirst);
        this.block("basalt_kitchen_sink").addThirst(sinkThirst);
        this.block("bamboo_kitchen_sink").addThirst(sinkThirst);
    }
}

