/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class CallOfYucatanTemperatureProvider
extends TemperatureDataProvider {
    public CallOfYucatanTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("call_of_yucutan", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.item("jades_helmet").heatResistance(0.5f);
        this.item("jades_chestplate").coldResistance(1.5f);
        this.item("jades_leggings").coldResistance(1.5f);
        this.item("jades_boots").coldResistance(0.5f);
        this.block("bone_torch_ground").addTemperature(this.temperatureBlock(1.5f));
        this.item("bone_torch_ground").temperature(1.5f);
        this.block("golden_torch_ground").addTemperature(this.temperatureBlock(1.5f));
        this.item("golden_torch_ground").temperature(1.5f);
    }
}

