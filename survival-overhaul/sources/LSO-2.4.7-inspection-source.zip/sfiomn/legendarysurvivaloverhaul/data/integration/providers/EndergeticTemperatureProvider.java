/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class EndergeticTemperatureProvider
extends TemperatureDataProvider {
    public EndergeticTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("endergetic", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.block("ender_fire").addTemperature(this.temperatureBlock(-7.0f));
        this.block("ender_campfire").addTemperature(this.temperatureBlock(-10.0f));
        this.block("ender_torch").addTemperature(this.temperatureBlock(-1.5f));
        this.block("ender_wall_torch").addTemperature(this.temperatureBlock(-1.5f));
    }
}

