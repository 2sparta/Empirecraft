/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;

public class FarmAndCharmThirstProvider
extends ThirstDataProvider {
    public FarmAndCharmThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("farm_and_charm", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("tomato").addThirst(this.thirstData(4, 0.0f));
        this.consumable("strawberry").addThirst(this.thirstData(2, 0.0f));
        IThirstData teaThirstData = this.thirstData(7, 5.0f);
        this.consumable("strawberry_tea").addThirst(teaThirstData);
        this.consumable("nettle_tea").addThirst(teaThirstData);
        this.consumable("ribwort_tea").addThirst(teaThirstData);
        this.consumable("strawberry_tea_cup").addThirst(teaThirstData);
        this.consumable("nettle_tea_cup").addThirst(teaThirstData);
        this.consumable("ribwort_tea_cup").addThirst(teaThirstData);
        IThirstData soupThirstData = this.thirstData(4, 2.0f);
        this.consumable("simple_tomato_soup").addThirst(soupThirstData);
        this.consumable("barley_soup").addThirst(soupThirstData);
        this.consumable("onion_soup").addThirst(soupThirstData);
        this.consumable("potato_soup").addThirst(soupThirstData);
        this.consumable("goulash").addThirst(soupThirstData);
    }
}

