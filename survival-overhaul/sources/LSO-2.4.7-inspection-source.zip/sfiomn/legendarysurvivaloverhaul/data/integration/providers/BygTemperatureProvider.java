/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class BygTemperatureProvider
extends TemperatureDataProvider {
    public BygTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("byg", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.block("boric_fire").addTemperature(this.temperatureBlock(5.0f));
        this.block("boric_campfire").addTemperature(this.temperatureBlock(10.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("cryptic_fire").addTemperature(this.temperatureBlock(5.0f));
        this.block("cryptic_campfire").addTemperature(this.temperatureBlock(7.5f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
    }
}

