/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;

public class NeapolitanThirstProvider
extends ThirstDataProvider {
    public NeapolitanThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("neapolitan", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("chocolate_milkshake").addThirst(this.thirstData(4, 1.0f));
        this.consumable("vanilla_milkshake").addThirst(this.thirstData(4, 1.0f));
        this.consumable("strawberry_milkshake").addThirst(this.thirstData(4, 1.0f));
        this.consumable("banana_milkshake").addThirst(this.thirstData(4, 1.0f));
    }
}

