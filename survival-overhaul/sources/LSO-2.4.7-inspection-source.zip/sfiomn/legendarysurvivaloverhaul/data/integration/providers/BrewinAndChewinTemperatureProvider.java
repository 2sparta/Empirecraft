/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class BrewinAndChewinTemperatureProvider
extends TemperatureDataProvider {
    public BrewinAndChewinTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("brewinandchewin", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        ITemperatureConsumableData drinkTemperature = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400);
        this.consumable("beer").addTemperature(drinkTemperature);
        this.consumable("bloody_mary").addTemperature(drinkTemperature);
        this.consumable("mead").addTemperature(drinkTemperature);
        this.consumable("pale_jane").addTemperature(drinkTemperature);
        this.consumable("steel_toe_stout").addTemperature(drinkTemperature);
        this.consumable("strongroot_ale").addTemperature(drinkTemperature);
        ITemperatureConsumableData drinkTemperature2 = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-2).duration(2400);
        this.consumable("glittering_grenadine").addTemperature(drinkTemperature2);
        this.consumable("kombucha").addTemperature(drinkTemperature2);
        this.consumable("egg_grog").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(1).duration(2400));
        this.consumable("vodka").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(1).duration(2400));
        this.consumable("dread_nog").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(2).duration(2400));
        this.consumable("red_rum").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(3).duration(2400));
        this.consumable("saccharine_rum").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(3).duration(2400));
        this.consumable("fiery_fondue").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(3).duration(3600));
        this.block("fiery_fondue_pot").addTemperature(this.temperatureBlock(5.0f).addProperty("level", "3")).addTemperature(this.temperatureBlock(4.0f).addProperty("level", "2")).addTemperature(this.temperatureBlock(2.0f).addProperty("level", "1")).addTemperature(this.temperatureBlock(0.0f).addProperty("level", "0"));
    }
}

