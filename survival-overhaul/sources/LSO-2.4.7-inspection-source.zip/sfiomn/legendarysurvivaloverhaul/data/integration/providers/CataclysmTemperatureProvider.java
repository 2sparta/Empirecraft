/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class CataclysmTemperatureProvider
extends TemperatureDataProvider {
    public CataclysmTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("cataclysm", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.item("bone_reptile_helmet").coldResistance(1.5f);
        this.item("bone_reptile_chestplate").coldResistance(2.0f);
        this.item("ignitium_helmet").coldResistance(1.5f);
        this.item("ignitium_chestplate").coldResistance(3.0f);
        this.item("ignitium_elytra_chestplate").coldResistance(3.0f);
        this.item("ignitium_leggings").coldResistance(2.0f);
        this.item("ignitium_boots").coldResistance(1.5f);
        this.item("monstrous_helm").coldResistance(1.0f);
        this.item("bloom_stone_pauldrons").heatResistance(1.0f);
    }
}

