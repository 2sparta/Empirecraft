/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.block.ThermalTypeEnum;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class IceAndFireTemperatureProvider
extends TemperatureDataProvider {
    public IceAndFireTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("iceandfire", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.mount("hippocampus").coldResistance(4.0f);
        this.mount("ice_dragon").temperature(-7.0f);
        this.mount("fire_dragon").temperature(10.0f);
        this.mount("lightning_dragon").temperature(10.0f);
        this.block("chared_cobblestone").addTemperature(this.temperatureBlock(6.0f));
        this.block("chared_dirt").addTemperature(this.temperatureBlock(6.0f));
        this.block("chared_dirt_path").addTemperature(this.temperatureBlock(6.0f));
        this.block("chared_grass").addTemperature(this.temperatureBlock(6.0f));
        this.block("chared_gravel").addTemperature(this.temperatureBlock(6.0f));
        this.block("chared_stone").addTemperature(this.temperatureBlock(6.0f));
        this.block("dragonforge_fire_brick").addTemperature(this.temperatureBlock(12.0f));
        this.block("dragonforge_fire_core").addTemperature(this.temperatureBlock(16.0f));
        this.block("dragonforge_fire_core_disabled").addTemperature(this.temperatureBlock(12.0f));
        this.block("dragonforge_fire_input").addTemperature(this.temperatureBlock(12.0f));
        this.block("dragonforge_ice_brick").addTemperature(this.temperatureBlock(-12.0f));
        this.block("dragonforge_ice_core").addTemperature(this.temperatureBlock(-16.0f));
        this.block("dragonforge_ice_core_disabled").addTemperature(this.temperatureBlock(-12.0f));
        this.block("dragonforge_ice_input").addTemperature(this.temperatureBlock(-12.0f));
        this.block("dragonscale_blue").addTemperature(this.temperatureBlock(-8.0f));
        this.block("dragonscale_bronze").addTemperature(this.temperatureBlock(8.0f));
        this.block("dragonscale_gray").addTemperature(this.temperatureBlock(8.0f));
        this.block("dragonscale_green").addTemperature(this.temperatureBlock(8.0f));
        this.block("dragonscale_red").addTemperature(this.temperatureBlock(8.0f));
        this.block("dragonscale_sapphire").addTemperature(this.temperatureBlock(-8.0f));
        this.block("dragonscale_silver").addTemperature(this.temperatureBlock(-8.0f));
        this.block("dragonscale_white").addTemperature(this.temperatureBlock(-8.0f));
        this.block("frozen_cobblestone").addTemperature(this.temperatureBlock(-6.0f));
        this.block("frozen_dirt").addTemperature(this.temperatureBlock(-6.0f));
        this.block("frozen_dirt_path").addTemperature(this.temperatureBlock(-6.0f));
        this.block("frozen_grass").addTemperature(this.temperatureBlock(-6.0f));
        this.block("frozen_gravel").addTemperature(this.temperatureBlock(-6.0f));
        this.block("frozen_splinters").addTemperature(this.temperatureBlock(-6.0f));
        this.block("frozen_stone").addTemperature(this.temperatureBlock(-6.0f));
        this.block("dragon_ice").addTemperature(this.temperatureBlock(-6.0f));
        this.item("dragon_ice").temperature(-4.0f);
        this.block("dread_torch").addTemperature(this.temperatureBlock(-1.0f));
        this.item("dread_torch").temperature(-1.0f);
        this.fuelItem("dragon_ice").thermalType(ThermalTypeEnum.COOLING).duration(400);
        this.fuelItem("dread_shard").thermalType(ThermalTypeEnum.COOLING).duration(3600);
        this.item("armor_silver_metal_helmet").heatResistance(0.5f);
        this.item("armor_silver_metal_chestplate").heatResistance(1.5f);
        this.item("armor_silver_metal_leggings").heatResistance(1.0f);
        this.item("armor_silver_metal_boots").heatResistance(1.0f);
        this.item("armor_copper_metal_helmet").heatResistance(0.5f);
        this.item("armor_copper_metal_chestplate").heatResistance(0.5f);
        this.item("armor_copper_metal_leggings").heatResistance(0.5f);
        this.item("armor_copper_metal_boots").heatResistance(0.5f);
        this.item("sheep_helmet").coldResistance(2.0f);
        this.item("sheep_chestplate").coldResistance(3.5f);
        this.item("sheep_leggings").coldResistance(3.0f);
        this.item("sheep_boots").coldResistance(1.0f);
        this.item("deathworm_yellow_helmet").heatResistance(0.5f);
        this.item("deathworm_yellow_chestplate").heatResistance(1.5f);
        this.item("deathworm_yellow_leggings").heatResistance(1.0f);
        this.item("deathworm_yellow_boots").heatResistance(1.0f);
        this.item("deathworm_white_helmet").heatResistance(0.5f);
        this.item("deathworm_white_chestplate").heatResistance(1.5f);
        this.item("deathworm_white_leggings").heatResistance(1.0f);
        this.item("deathworm_white_boots").heatResistance(1.0f);
        this.item("deathworm_red_helmet").heatResistance(0.5f);
        this.item("deathworm_red_chestplate").heatResistance(1.5f);
        this.item("deathworm_red_leggings").heatResistance(1.0f);
        this.item("deathworm_red_boots").heatResistance(1.0f);
        this.item("dragonsteel_ice_helmet").heatResistance(3.0f);
        this.item("dragonsteel_ice_chestplate").heatResistance(5.0f);
        this.item("dragonsteel_ice_leggings").heatResistance(4.5f);
        this.item("dragonsteel_ice_boots").heatResistance(2.5f);
        this.item("dragonsteel_fire_helmet").coldResistance(3.0f);
        this.item("dragonsteel_fire_chestplate").coldResistance(5.0f);
        this.item("dragonsteel_fire_leggings").coldResistance(4.5f);
        this.item("dragonsteel_fire_boots").coldResistance(2.5f);
        this.item("dragonsteel_lightning_helmet").thermalResistance(1.5f);
        this.item("dragonsteel_lightning_chestplate").thermalResistance(2.5f);
        this.item("dragonsteel_lightning_leggings").thermalResistance(2.0f);
        this.item("dragonsteel_lightning_boots").thermalResistance(1.5f);
        this.item("armor_red_helmet").coldResistance(1.0f);
        this.item("armor_red_chestplate").coldResistance(2.0f);
        this.item("armor_red_leggings").coldResistance(1.5f);
        this.item("armor_red_boots").coldResistance(1.5f);
        this.item("armor_bronze_helmet").coldResistance(1.0f);
        this.item("armor_bronze_chestplate").coldResistance(2.0f);
        this.item("armor_bronze_leggings").coldResistance(1.5f);
        this.item("armor_bronze_boots").coldResistance(1.5f);
        this.item("armor_green_helmet").coldResistance(1.0f);
        this.item("armor_green_chestplate").coldResistance(2.0f);
        this.item("armor_green_leggings").coldResistance(1.5f);
        this.item("armor_green_boots").coldResistance(1.5f);
        this.item("armor_gray_helmet").coldResistance(1.0f);
        this.item("armor_gray_chestplate").coldResistance(2.0f);
        this.item("armor_gray_leggings").coldResistance(1.5f);
        this.item("armor_gray_boots").coldResistance(1.5f);
        this.item("armor_blue_helmet").heatResistance(1.0f);
        this.item("armor_blue_chestplate").heatResistance(2.0f);
        this.item("armor_blue_leggings").heatResistance(1.5f);
        this.item("armor_blue_boots").heatResistance(1.5f);
        this.item("armor_silver_helmet").heatResistance(1.0f);
        this.item("armor_silver_chestplate").heatResistance(2.0f);
        this.item("armor_silver_leggings").heatResistance(1.5f);
        this.item("armor_silver_boots").heatResistance(1.5f);
        this.item("armor_white_helmet").heatResistance(1.0f);
        this.item("armor_white_chestplate").heatResistance(2.0f);
        this.item("armor_white_leggings").heatResistance(1.5f);
        this.item("armor_white_boots").heatResistance(1.5f);
        this.item("armor_sapphire_helmet").heatResistance(1.0f);
        this.item("armor_sapphire_chestplate").heatResistance(2.0f);
        this.item("armor_sapphire_leggings").heatResistance(1.5f);
        this.item("armor_sapphire_boots").heatResistance(1.5f);
        this.item("armor_amythest_helmet").thermalResistance(0.5f);
        this.item("armor_amythest_chestplate").thermalResistance(1.0f);
        this.item("armor_amythest_leggings").thermalResistance(1.0f);
        this.item("armor_amythest_boots").thermalResistance(0.5f);
        this.item("armor_copper_helmet").thermalResistance(0.5f);
        this.item("armor_copper_chestplate").thermalResistance(1.0f);
        this.item("armor_copper_leggings").thermalResistance(1.0f);
        this.item("armor_copper_boots").thermalResistance(0.5f);
        this.item("armor_black_helmet").thermalResistance(0.5f);
        this.item("armor_black_chestplate").thermalResistance(1.0f);
        this.item("armor_black_leggings").thermalResistance(1.0f);
        this.item("armor_black_boots").thermalResistance(0.5f);
        this.item("armor_electric_helmet").thermalResistance(0.5f);
        this.item("armor_electric_chestplate").thermalResistance(1.0f);
        this.item("armor_electric_leggings").thermalResistance(1.0f);
        this.item("armor_electric_boots").thermalResistance(0.5f);
        this.item("tide_red_helmet").coldResistance(1.0f);
        this.item("tide_red_chestplate").coldResistance(2.0f);
        this.item("tide_red_leggings").coldResistance(1.5f);
        this.item("tide_red_boots").coldResistance(1.5f);
        this.item("tide_blue_helmet").coldResistance(1.0f);
        this.item("tide_blue_chestplate").coldResistance(2.0f);
        this.item("tide_blue_leggings").coldResistance(1.5f);
        this.item("tide_blue_boots").coldResistance(1.5f);
        this.item("tide_bronze_helmet").coldResistance(1.0f);
        this.item("tide_bronze_chestplate").coldResistance(2.0f);
        this.item("tide_bronze_leggings").coldResistance(1.5f);
        this.item("tide_bronze_boots").coldResistance(1.5f);
        this.item("tide_green_helmet").coldResistance(1.0f);
        this.item("tide_green_chestplate").coldResistance(2.0f);
        this.item("tide_green_leggings").coldResistance(1.5f);
        this.item("tide_green_boots").coldResistance(1.5f);
        this.item("tide_deepblue_helmet").coldResistance(1.0f);
        this.item("tide_deepblue_chestplate").coldResistance(2.0f);
        this.item("tide_deepblue_leggings").coldResistance(1.5f);
        this.item("tide_deepblue_boots").coldResistance(1.5f);
        this.item("tide_purple_helmet").coldResistance(1.0f);
        this.item("tide_purple_chestplate").coldResistance(2.0f);
        this.item("tide_purple_leggings").coldResistance(1.5f);
        this.item("tide_purple_boots").coldResistance(1.5f);
        this.item("tide_teal_helmet").coldResistance(1.0f);
        this.item("tide_teal_chestplate").coldResistance(2.0f);
        this.item("tide_teal_leggings").coldResistance(1.5f);
        this.item("tide_teal_boots").coldResistance(1.5f);
    }
}

