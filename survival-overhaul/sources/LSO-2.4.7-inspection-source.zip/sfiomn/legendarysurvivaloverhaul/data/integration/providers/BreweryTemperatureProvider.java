/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class BreweryTemperatureProvider
extends TemperatureDataProvider {
    public BreweryTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("brewery", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumableAndConsumableBlock("fried_chicken", this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(1).duration(2400));
        this.consumableAndConsumableBlock("pork_knuckle", this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(1).duration(2400));
        this.consumableAndConsumableBlock("half_chicken", this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(1).duration(2400));
        this.consumableAndConsumableBlock("potato_salad", this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-1).duration(2400));
        ITemperatureConsumableData whiskeyTemperature = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(1).duration(2400);
        this.consumableAndConsumableBlock("whiskey_jojannik", whiskeyTemperature);
        this.consumableAndConsumableBlock("whiskey_lilitusinglemalt", whiskeyTemperature);
        this.consumableAndConsumableBlock("whiskey_cristelwalker", whiskeyTemperature);
        this.consumableAndConsumableBlock("whiskey_maggoallan", whiskeyTemperature);
        this.consumableAndConsumableBlock("whiskey_carrasconlabel", whiskeyTemperature);
        this.consumableAndConsumableBlock("whiskey_ak", whiskeyTemperature);
        this.consumableAndConsumableBlock("whiskey_highland_hearth", whiskeyTemperature);
        this.consumableAndConsumableBlock("whiskey_smokey_reverie", whiskeyTemperature);
        this.consumableAndConsumableBlock("whiskey_jamesons_malt", whiskeyTemperature);
        ITemperatureConsumableData beerTemperature = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400);
        this.consumableAndConsumableBlock("beer_wheat", beerTemperature);
        this.consumableAndConsumableBlock("beer_barley", beerTemperature);
        this.consumableAndConsumableBlock("beer_hops", beerTemperature);
        this.consumableAndConsumableBlock("beer_nettle", beerTemperature);
        this.consumableAndConsumableBlock("beer_oat", beerTemperature);
        this.consumableAndConsumableBlock("beer_haley", beerTemperature);
        this.item("brewfest_hat").heatResistance(1.0f);
        this.item("brewfest_regalia").heatResistance(1.5f);
        this.item("brewfest_trousers").heatResistance(1.0f);
        this.item("brewfest_boots").heatResistance(0.5f);
        this.item("brewfest_hat_red").heatResistance(1.0f);
        this.item("brewfest_blouse").heatResistance(1.5f);
        this.item("brewfest_dress").heatResistance(1.0f);
        this.item("brewfest_shoes").heatResistance(0.5f);
    }
}

