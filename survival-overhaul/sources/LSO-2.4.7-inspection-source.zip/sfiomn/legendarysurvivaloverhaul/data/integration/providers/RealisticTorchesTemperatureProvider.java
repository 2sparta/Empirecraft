/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class RealisticTorchesTemperatureProvider
extends TemperatureDataProvider {
    public RealisticTorchesTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("realistictorches", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.block("torch").addTemperature(this.temperatureBlock(1.5f).addProperty("litstate", "2")).addTemperature(this.temperatureBlock(0.75f).addProperty("litstate", "1")).addTemperature(this.temperatureBlock(0.0f).addProperty("litstate", "0"));
        this.block("torch_wall").addTemperature(this.temperatureBlock(1.5f).addProperty("litstate", "2")).addTemperature(this.temperatureBlock(0.75f).addProperty("litstate", "1")).addTemperature(this.temperatureBlock(0.0f).addProperty("litstate", "0"));
    }
}

