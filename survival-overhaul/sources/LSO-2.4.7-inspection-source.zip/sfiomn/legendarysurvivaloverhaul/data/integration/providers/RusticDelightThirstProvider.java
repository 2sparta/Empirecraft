/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;

public class RusticDelightThirstProvider
extends ThirstDataProvider {
    public RusticDelightThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("rusticdelight", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("bell_pepper_green").addThirst(this.thirstData(4, 0.0f));
        this.consumable("bell_pepper_yellow").addThirst(this.thirstData(4, 0.0f));
        this.consumable("bell_pepper_red").addThirst(this.thirstData(4, 0.0f));
        this.consumable("syrup").addThirst(this.thirstData(2, 1.0f));
        this.consumable("dark_coffee").addThirst(this.thirstData(4, 3.5f));
        this.consumable("coffee").addThirst(this.thirstData(5, 3.5f));
        this.consumable("milk_coffee").addThirst(this.thirstData(6, 4.0f));
        this.consumable("syrup_coffee").addThirst(this.thirstData(6, 4.0f));
        this.consumable("chocolate_coffee").addThirst(this.thirstData(7, 4.5f));
        this.consumable("honey_coffee").addThirst(this.thirstData(7, 4.5f));
    }
}

