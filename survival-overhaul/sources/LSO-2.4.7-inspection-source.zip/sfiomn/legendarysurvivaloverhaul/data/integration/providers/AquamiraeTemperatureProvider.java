/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class AquamiraeTemperatureProvider
extends TemperatureDataProvider {
    public AquamiraeTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("aquamirae", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.item("terrible_helmet").heatResistance(1.0f);
        this.item("terrible_chestplate").heatResistance(1.5f);
        this.item("terrible_leggings").heatResistance(1.5f);
        this.item("terrible_boots").heatResistance(1.0f);
        this.item("abyssal_heaume").coldResistance(1.0f);
        this.item("abyssal_brigantine").coldResistance(2.0f);
        this.item("abyssal_leggings").coldResistance(1.0f);
        this.item("abyssal_boots").coldResistance(1.0f);
        this.item("three_bolt_helmet").coldResistance(1.0f);
        this.item("three_bolt_suit").coldResistance(1.0f);
        this.item("three_bolt_leggings").coldResistance(1.0f);
        this.item("three_bolt_boots").coldResistance(1.0f);
    }
}

