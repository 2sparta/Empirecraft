/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class NetherVineryTemperatureProvider
extends TemperatureDataProvider {
    public NetherVineryTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("nethervinery", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("blazewine_pinot").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(1).duration(2400));
        this.consumable("lava_fizz").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(2).duration(3600));
        this.consumable("improved_lava_fizz").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(2).duration(4800));
        this.consumable("nether_fizz").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-2).duration(3600));
        this.consumable("improved_nether_fizz").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-2).duration(4800));
    }
}

