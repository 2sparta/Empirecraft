/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class BrewinCompatDelightThirstProvider
extends ThirstDataProvider {
    public BrewinCompatDelightThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("brewincompatdelight", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("brass_monkey").addThirst(this.thirstData(4, 0.0f));
        IThirstData beer = this.thirstData(8, 6.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f);
        this.consumable("beer_knees").addThirst(beer);
        this.consumable("brass_monkey").addThirst(beer);
        IThirstData cocktail = this.thirstData(9, 5.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 500, 0.3f);
        this.consumable("aqua_velva").addThirst(cocktail);
        this.consumable("blue_curacao").addThirst(cocktail);
        this.consumable("china_blue").addThirst(cocktail);
        this.consumable("gin_and_juice").addThirst(cocktail);
        this.consumable("gin_and_tonic").addThirst(cocktail);
        this.consumable("half_and_half").addThirst(cocktail);
        this.consumable("margarita").addThirst(cocktail);
        this.consumable("mojito").addThirst(cocktail);
        this.consumable("pina_colada").addThirst(cocktail);
        this.consumable("salted_margarita").addThirst(cocktail);
        this.consumable("singapore_sling").addThirst(cocktail);
        this.consumable("tequila_sunrise").addThirst(cocktail);
        IThirstData wine = this.thirstData(7, 5.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 400, 0.3f);
        this.consumable("mulled_wine").addThirst(wine);
        this.consumable("peach_wine").addThirst(wine);
        this.consumable("red_wine").addThirst(wine);
        this.consumable("sweet_red_wine").addThirst(wine);
        this.consumable("white_wine").addThirst(wine);
        IThirstData alcohol = this.thirstData(5, 5.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 800, 0.4f);
        this.consumable("gin").addThirst(alcohol);
        this.consumable("kraken_rum").addThirst(alcohol);
        this.consumable("screwdriver").addThirst(alcohol);
        this.consumable("tequila").addThirst(alcohol);
        IThirstData soft = this.thirstData(5, 2.0f);
        this.consumable("hard_lemonade").addThirst(soft);
        this.consumable("hard_cider").addThirst(soft);
        this.consumable("lemon_lime").addThirst(soft);
        this.consumable("mermaid_lemonade").addThirst(soft);
        this.consumable("tonic_water").addThirst(soft);
    }
}

