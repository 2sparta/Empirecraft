/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class FarmersRespiteThirstProvider
extends ThirstDataProvider {
    public FarmersRespiteThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("farmersrespite", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("coffee").addThirst(this.thirstData(5, 3.5f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f));
        this.consumable("long_coffee").addThirst(this.thirstData(7, 5.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f));
        this.consumable("strong_coffee").addThirst(this.thirstData(5, 3.5f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.4f));
        this.consumable("long_apple_cider").addThirst(this.thirstData(10, 4.0f));
        this.consumable("strong_apple_cider").addThirst(this.thirstData(5, 2.0f));
        this.consumable("strong_hot_cocoa").addThirst(this.thirstData(6, 3.0f));
        this.consumable("strong_melon_juice").addThirst(this.thirstData(8, 4.0f));
        IThirstData teaTemperature = this.thirstData(5, 3.0f);
        this.consumable("black_tea").addThirst(teaTemperature);
        this.consumable("dandelion_tea").addThirst(teaTemperature);
        this.consumable("gamblers_tea").addThirst(teaTemperature.copy().addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.5f));
        this.consumable("green_tea").addThirst(teaTemperature);
        this.consumable("yellow_tea").addThirst(teaTemperature);
        this.consumable("rose_hip_tea").addThirst(teaTemperature);
        this.consumable("purulent_tea").addThirst(teaTemperature);
        IThirstData longTeaTemperature = this.thirstData(7, 4.0f);
        this.consumable("long_black_tea").addThirst(longTeaTemperature);
        this.consumable("long_dandelion_tea").addThirst(longTeaTemperature);
        this.consumable("long_gamblers_tea").addThirst(longTeaTemperature.copy().addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.5f));
        this.consumable("long_green_tea").addThirst(longTeaTemperature);
        this.consumable("long_yellow_tea").addThirst(longTeaTemperature);
        this.consumable("long_rose_hip_tea").addThirst(longTeaTemperature);
        this.consumable("long_purulent_tea").addThirst(longTeaTemperature);
        IThirstData strongTeaTemperature = this.thirstData(5, 3.0f);
        this.consumable("strong_black_tea").addThirst(strongTeaTemperature);
        this.consumable("long_dandelion_tea").addThirst(strongTeaTemperature);
        this.consumable("strong_gamblers_tea").addThirst(strongTeaTemperature.copy().addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.5f));
        this.consumable("strong_green_tea").addThirst(strongTeaTemperature);
        this.consumable("strong_yellow_tea").addThirst(strongTeaTemperature);
        this.consumable("strong_rose_hip_tea").addThirst(strongTeaTemperature);
        this.consumable("strong_purulent_tea").addThirst(strongTeaTemperature);
    }
}

