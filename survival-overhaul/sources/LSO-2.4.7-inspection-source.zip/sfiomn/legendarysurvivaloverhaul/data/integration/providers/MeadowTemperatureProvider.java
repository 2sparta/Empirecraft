/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class MeadowTemperatureProvider
extends TemperatureDataProvider {
    public MeadowTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("meadow", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.block("stove_tiles_wood").addTemperature(this.temperatureBlock(6.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("stove_tiles_lid").addTemperature(this.temperatureBlock(6.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("cooking_cauldron").addTemperature(this.temperatureBlock(4.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("fondue").addTemperature(this.temperatureBlock(4.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("frame").addTemperature(this.temperatureBlock(10.0f));
        this.block("oil_lantern").addTemperature(this.temperatureBlock(1.5f));
        this.item("oil_lantern").temperature(1.5f);
        this.item("fur_helmet").heatResistance(2.0f);
        this.item("fur_chestplate").heatResistance(3.5f);
        this.item("fur_leggings").heatResistance(3.0f);
        this.item("fur_boots").heatResistance(1.0f);
        this.consumable("sausage_with_cheese").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(2).duration(2400));
        this.consumable("roasted_ham").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(2).duration(3600));
    }
}

