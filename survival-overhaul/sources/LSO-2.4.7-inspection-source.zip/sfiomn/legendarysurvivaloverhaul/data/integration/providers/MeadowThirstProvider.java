/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class MeadowThirstProvider
extends ThirstDataProvider {
    public MeadowThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("meadow", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        IThirstData dirtyWater = this.thirstData(3, 0.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 300, 0.75f);
        this.block("wooden_water_cauldron").addThirst(dirtyWater);
        IThirstData milkThirstData = this.thirstData(5, 2.0f);
        this.consumable("wooden_milk_bucket").addThirst(milkThirstData);
        this.consumable("wooden_sheep_milk_bucket").addThirst(milkThirstData);
        this.consumable("wooden_buffalo_milk_bucket").addThirst(milkThirstData);
        this.consumable("wooden_goat_milk_bucket").addThirst(milkThirstData);
        this.consumable("wooden_warped_milk_bucket").addThirst(milkThirstData);
        this.consumable("wooden_grain_milk_bucket").addThirst(milkThirstData);
        this.consumable("wooden_amethyst_milk_bucket").addThirst(milkThirstData);
    }
}

