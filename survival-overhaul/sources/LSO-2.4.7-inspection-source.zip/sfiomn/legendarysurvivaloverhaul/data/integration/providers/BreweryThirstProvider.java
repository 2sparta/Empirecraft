/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class BreweryThirstProvider
extends ThirstDataProvider {
    public BreweryThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("brewery", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        IThirstData whiskey_hydration = this.thirstData(5, 5.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 800, 0.4f);
        this.consumableAndBlock("whiskey_jojannik", whiskey_hydration);
        this.consumableAndBlock("whiskey_lilitusinglemalt", whiskey_hydration);
        this.consumableAndBlock("whiskey_cristelwalker", whiskey_hydration);
        this.consumableAndBlock("whiskey_maggoallan", whiskey_hydration);
        this.consumableAndBlock("whiskey_carrasconlabel", whiskey_hydration);
        this.consumableAndBlock("whiskey_ak", whiskey_hydration);
        this.consumableAndBlock("whiskey_highland_hearth", whiskey_hydration);
        this.consumableAndBlock("whiskey_smokey_reverie", whiskey_hydration);
        this.consumableAndBlock("whiskey_jamesons_malt", whiskey_hydration);
        IThirstData beer_hydration = this.thirstData(8, 6.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f);
        this.consumableAndBlock("beer_wheat", beer_hydration);
        this.consumableAndBlock("beer_barley", beer_hydration);
        this.consumableAndBlock("beer_hops", beer_hydration);
        this.consumableAndBlock("beer_nettle", beer_hydration);
        this.consumableAndBlock("beer_oat", beer_hydration);
        this.consumableAndBlock("beer_haley", beer_hydration);
    }
}

