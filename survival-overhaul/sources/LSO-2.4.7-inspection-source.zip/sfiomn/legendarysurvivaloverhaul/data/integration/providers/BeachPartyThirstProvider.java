/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;

public class BeachPartyThirstProvider
extends ThirstDataProvider {
    public BeachPartyThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("beachparty", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("coconut_open").addThirst(this.thirstData(3, 0.0f));
        this.consumable("coconut_cocktail").addThirst(this.thirstData(4, 2.0f));
        this.consumable("sweetberries_cocktail").addThirst(this.thirstData(4, 4.0f));
        this.consumable("cocoa_cocktail").addThirst(this.thirstData(6, 3.0f));
        this.consumable("pumpkin_cocktail").addThirst(this.thirstData(6, 3.0f));
        this.consumable("melon_cocktail").addThirst(this.thirstData(8, 4.0f));
        this.consumable("honey_cocktail").addThirst(this.thirstData(9, 6.0f));
        this.consumable("refreshing_drink").addThirst(this.thirstData(10, 8.0f));
        this.consumable("sweetberry_milkshake").addThirst(this.thirstData(6, 4.0f));
        this.consumable("coconut_milkshake").addThirst(this.thirstData(6, 4.0f));
        this.consumable("chocolate_milkshake").addThirst(this.thirstData(8, 6.0f));
    }
}

