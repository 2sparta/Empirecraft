/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class SurvivalInstinctThirstProvider
extends ThirstDataProvider {
    public SurvivalInstinctThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("survival_instinct", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        IThirstData beer_hydration = this.thirstData(8, 6.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f);
        this.consumable("beer").addThirst(beer_hydration);
        IThirstData alcohol = this.thirstData(5, 5.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 800, 0.4f);
        this.consumable("tequila").addThirst(alcohol);
        this.consumable("whiskey").addThirst(alcohol);
        IThirstData wine = this.thirstData(7, 5.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 400, 0.3f);
        this.consumable("wine").addThirst(wine);
        this.consumable("bean_can").addThirst(this.thirstData(3, 1.0f));
        this.consumable("cod_can").addThirst(this.thirstData(4, 1.0f));
        this.consumable("sardine_can").addThirst(this.thirstData(4, 1.0f));
        this.consumable("tuna_can").addThirst(this.thirstData(4, 1.0f));
        this.consumable("fruit_can").addThirst(this.thirstData(6, 2.0f));
        this.consumable("tomato_soup").addThirst(this.thirstData(6, 2.0f));
        this.consumable("military_can").addThirst(this.thirstData(4, 2.0f));
        this.consumable("milk").addThirst(this.thirstData(9, 4.0f));
        this.consumable("orange_juice").addThirst(this.thirstData(9, 4.0f));
        this.consumable("blue_soda").addThirst(this.thirstData(8, 3.5f));
        this.consumable("red_soda").addThirst(this.thirstData(8, 3.5f));
        this.consumable("lemon_soda").addThirst(this.thirstData(8, 3.5f));
        this.consumable("energy_can").addThirst(this.thirstData(8, 3.5f));
        this.consumable("monster_can").addThirst(this.thirstData(11, 4.0f));
        this.consumable("gallon_of_milk").addThirst(this.thirstData(10, 5.0f));
        this.consumable("gallon_of_water").addThirst(this.thirstData(10, 5.0f));
    }
}

