/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;

public class CrockpotThirstProvider
extends ThirstDataProvider {
    public CrockpotThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("crockpot", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("asparagus_soup").addThirst(this.thirstData(4, 2.0f));
        this.consumable("bone_soup").addThirst(this.thirstData(4, 2.0f));
        this.consumable("gazpacho").addThirst(this.thirstData(4, 2.0f));
        this.consumable("iced_tea").addThirst(this.thirstData(8, 5.0f));
        this.consumable("tea").addThirst(this.thirstData(6, 3.0f));
        this.consumable("hot_cocoa").addThirst(this.thirstData(4, 2.0f));
        this.consumable("fruit_medley").addThirst(this.thirstData(6, 3.0f));
        this.consumable("veg_stinger").addThirst(this.thirstData(6, 3.0f));
    }
}

