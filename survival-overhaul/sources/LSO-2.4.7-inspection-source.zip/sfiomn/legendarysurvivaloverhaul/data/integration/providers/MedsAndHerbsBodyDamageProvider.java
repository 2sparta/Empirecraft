/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.BodyDamageDataProvider;

public class MedsAndHerbsBodyDamageProvider
extends BodyDamageDataProvider {
    public MedsAndHerbsBodyDamageProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("meds_and_herbs", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("medkit_novice").healingCharges(0).healingValue(3.0f).duration(400);
        this.consumable("medkit_advanced").healingCharges(0).healingValue(5.0f).duration(800);
        this.consumable("medkit_expert").healingCharges(0).healingValue(8.0f).duration(600);
    }
}

