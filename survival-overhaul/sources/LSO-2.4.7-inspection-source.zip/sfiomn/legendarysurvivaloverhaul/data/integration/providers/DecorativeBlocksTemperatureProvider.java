/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class DecorativeBlocksTemperatureProvider
extends TemperatureDataProvider {
    public DecorativeBlocksTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("decorative_blocks", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.block("brazier").addTemperature(this.temperatureBlock(12.5f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("soul_brazier").addTemperature(this.temperatureBlock(-12.5f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
    }
}

