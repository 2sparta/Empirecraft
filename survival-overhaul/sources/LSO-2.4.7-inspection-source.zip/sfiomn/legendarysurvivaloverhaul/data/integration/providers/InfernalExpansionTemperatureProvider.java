/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class InfernalExpansionTemperatureProvider
extends TemperatureDataProvider {
    public InfernalExpansionTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("infernalexp", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.block("fire_glow").addTemperature(this.temperatureBlock(7.0f));
        this.block("campfire_glow").addTemperature(this.temperatureBlock(10.0f));
        this.block("torch_glow").addTemperature(this.temperatureBlock(1.5f));
        this.block("torch_glow_wall").addTemperature(this.temperatureBlock(1.5f));
    }
}

