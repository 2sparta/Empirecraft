/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;

public class MinersDelightThirstProvider
extends ThirstDataProvider {
    public MinersDelightThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("miners_delight", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("milk_cup").addThirst(this.thirstData(4, 1.0f));
        IThirstData lowThirst = this.thirstData(4, 1.0f);
        this.consumable("beetroot_soup_cup").addThirst(lowThirst);
        this.consumable("mushroom_stew_cup").addThirst(lowThirst);
        this.consumable("cave_soup_cup").addThirst(lowThirst);
        this.consumable("bat_soup_cup").addThirst(lowThirst);
        this.consumable("insect_stew_cup").addThirst(lowThirst);
        IThirstData midThirst = this.thirstData(5, 2.0f);
        this.consumable("fish_stew_cup").addThirst(midThirst);
        this.consumable("rabbit_stew_cup").addThirst(midThirst);
        this.consumable("beef_stew_cup").addThirst(midThirst);
        this.consumable("vegetable_soup_cup").addThirst(lowThirst);
        IThirstData highThirst = this.thirstData(5, 3.0f);
        this.consumable("baked_cod_stew_cup").addThirst(highThirst);
        this.consumable("noodle_soup_cup").addThirst(highThirst);
        this.consumable("chicken_soup_cup").addThirst(highThirst);
        this.consumable("pumpkin_soup_cup").addThirst(highThirst);
        this.consumable("cave_soup").addThirst(highThirst);
        this.consumable("bat_soup").addThirst(highThirst);
        this.consumable("insect_stew").addThirst(highThirst);
    }
}

