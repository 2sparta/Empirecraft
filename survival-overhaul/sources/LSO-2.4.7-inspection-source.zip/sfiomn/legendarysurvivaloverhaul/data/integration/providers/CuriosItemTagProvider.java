/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.data.PackOutput
 *  net.minecraft.data.tags.ItemTagsProvider
 *  net.minecraft.data.tags.TagsProvider$TagLookup
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.level.block.Block
 *  net.minecraftforge.common.data.ExistingFileHelper
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.PackOutput;
import net.minecraft.data.tags.ItemTagsProvider;
import net.minecraft.data.tags.TagsProvider;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.common.data.ExistingFileHelper;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;

public class CuriosItemTagProvider
extends ItemTagsProvider {
    public static final TagKey<Item> BELT_TAG = TagKey.m_203882_((ResourceKey)Registries.f_256913_, (ResourceLocation)new ResourceLocation("curios", "belt"));
    public static final TagKey<Item> NECKLACE_TAG = TagKey.m_203882_((ResourceKey)Registries.f_256913_, (ResourceLocation)new ResourceLocation("curios", "necklace"));
    public static final TagKey<Item> HEAD_TAG = TagKey.m_203882_((ResourceKey)Registries.f_256913_, (ResourceLocation)new ResourceLocation("curios", "head"));
    public static final TagKey<Item> BODY_TAG = TagKey.m_203882_((ResourceKey)Registries.f_256913_, (ResourceLocation)new ResourceLocation("curios", "body"));
    public static final TagKey<Item> CHARM_TAG = TagKey.m_203882_((ResourceKey)Registries.f_256913_, (ResourceLocation)new ResourceLocation("curios", "charm"));
    public static final TagKey<Item> RING_TAG = TagKey.m_203882_((ResourceKey)Registries.f_256913_, (ResourceLocation)new ResourceLocation("curios", "ring"));

    public CuriosItemTagProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, CompletableFuture<TagsProvider.TagLookup<Block>> p_275322_, @Nullable ExistingFileHelper existingFileHelper) {
        super(output, lookupProvider, p_275322_, "curios", existingFileHelper);
    }

    protected void m_6577_(HolderLookup.Provider provider) {
        this.m_206424_(BELT_TAG).m_255245_((Object)((Item)ItemRegistry.THERMOMETER.get()));
        this.m_206424_(NECKLACE_TAG).m_255245_((Object)((Item)ItemRegistry.NETHER_CHALICE.get()));
        this.m_206424_(HEAD_TAG).m_255245_((Object)((Item)ItemRegistry.WATER_PURIFIER.get()));
        this.m_206424_(BODY_TAG).m_255245_((Object)((Item)ItemRegistry.SPONGE.get()));
        this.m_206424_(CHARM_TAG).m_255245_((Object)((Item)ItemRegistry.FIRST_AID_SUPPLIES.get()));
        this.m_206424_(RING_TAG).m_255245_((Object)((Item)ItemRegistry.HEAT_RESISTANCE_RING.get())).m_255245_((Object)((Item)ItemRegistry.COLD_RESISTANCE_RING.get())).m_255245_((Object)((Item)ItemRegistry.THERMAL_RESISTANCE_RING.get()));
    }
}

