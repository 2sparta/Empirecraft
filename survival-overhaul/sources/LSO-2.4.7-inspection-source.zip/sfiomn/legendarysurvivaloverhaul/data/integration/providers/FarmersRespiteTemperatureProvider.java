/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class FarmersRespiteTemperatureProvider
extends TemperatureDataProvider {
    public FarmersRespiteTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("farmersrespite", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("coffee").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(2).duration(2400));
        this.consumable("long_coffee").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(2).duration(4800));
        this.consumable("strong_coffee").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(3).duration(2400));
        this.consumable("strong_hot_cocoa").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(4).duration(3600));
        this.consumable("strong_melon_juice").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-2).duration(2400));
        ITemperatureConsumableData teaTemperature = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(1).duration(2400);
        this.consumable("black_tea").addTemperature(teaTemperature);
        this.consumable("dandelion_tea").addTemperature(teaTemperature);
        this.consumable("gamblers_tea").addTemperature(teaTemperature);
        this.consumable("green_tea").addTemperature(teaTemperature);
        this.consumable("yellow_tea").addTemperature(teaTemperature);
        this.consumable("rose_hip_tea").addTemperature(teaTemperature);
        this.consumable("purulent_tea").addTemperature(teaTemperature);
        ITemperatureConsumableData longTeaTemperature = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(1).duration(4800);
        this.consumable("long_black_tea").addTemperature(longTeaTemperature);
        this.consumable("long_dandelion_tea").addTemperature(longTeaTemperature);
        this.consumable("long_gamblers_tea").addTemperature(longTeaTemperature);
        this.consumable("long_green_tea").addTemperature(longTeaTemperature);
        this.consumable("long_yellow_tea").addTemperature(longTeaTemperature);
        this.consumable("long_rose_hip_tea").addTemperature(longTeaTemperature);
        this.consumable("long_purulent_tea").addTemperature(longTeaTemperature);
        ITemperatureConsumableData strongTeaTemperature = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(2).duration(2400);
        this.consumable("strong_black_tea").addTemperature(strongTeaTemperature);
        this.consumable("long_dandelion_tea").addTemperature(strongTeaTemperature);
        this.consumable("strong_gamblers_tea").addTemperature(strongTeaTemperature);
        this.consumable("strong_green_tea").addTemperature(strongTeaTemperature);
        this.consumable("strong_yellow_tea").addTemperature(strongTeaTemperature);
        this.consumable("strong_rose_hip_tea").addTemperature(strongTeaTemperature);
        this.consumable("strong_purulent_tea").addTemperature(strongTeaTemperature);
        this.consumable("blazing_chili").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(3).duration(4800));
        this.block("kettle").addTemperature(this.temperatureBlock(0.0f).addProperty("lid", "false")).addTemperature(this.temperatureBlock(4.0f).addProperty("lid", "true"));
    }
}

