/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.block.ThermalTypeEnum;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class BetterEndForgeTemperatureProvider
extends TemperatureDataProvider {
    public BetterEndForgeTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("betterendforge", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.fuelItem("coal_block").thermalType(ThermalTypeEnum.HEATING).duration(5400);
        this.fuelItem("charcoal_block").thermalType(ThermalTypeEnum.HEATING).duration(5400);
        this.biome("sulphur_springs").temperature(1.1f);
        this.biome("ice_starfield").temperature(0.1f);
    }
}

