/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureBlockData;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class CandlelightTemperatureProvider
extends TemperatureDataProvider {
    public CandlelightTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("candlelight", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("beetroot_salad").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-1).duration(2400));
        this.consumable("salad").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-1).duration(2400));
        this.consumable("fresh_garden_salad").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-1).duration(2400));
        this.consumableAndConsumableBlock("tomato_mozzarella_salad", this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-1).duration(2400));
        this.consumable("harvest_plate").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-1).duration(2400));
        this.consumable("fricasse").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(1).duration(2400));
        this.consumable("roastbeef_carrots").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(1).duration(2400));
        this.consumable("bolognese").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(1).duration(2400));
        this.consumableAndConsumableBlock("beef_wellington", this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(2).duration(2400));
        this.consumableAndConsumableBlock("lasagne", this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(2).duration(2400));
        this.consumable("pasta_with_bolognese").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(2).duration(2400));
        this.consumable("beef_with_mushroom_in_wine_and_potatoes").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(3).duration(4800));
        ITemperatureConsumableData soupTemperatureData = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(2).duration(3600);
        this.consumable("tomato_soup").addTemperature(soupTemperatureData);
        this.consumable("mushroom_soup").addTemperature(soupTemperatureData);
        ITemperatureBlockData stoveTemp = this.temperatureBlock(6.0f).addProperty("lit", "true");
        ITemperatureBlockData stoveTempOff = this.temperatureBlock(0.0f).addProperty("lit", "false");
        this.block("cobblestone_stove").addTemperature(stoveTemp).addTemperature(stoveTempOff);
        this.block("sandstone_stove").addTemperature(stoveTemp).addTemperature(stoveTempOff);
        this.block("stone_bricks_stove").addTemperature(stoveTemp).addTemperature(stoveTempOff);
        this.block("deepslate_stove").addTemperature(stoveTemp).addTemperature(stoveTempOff);
        this.block("granit_stove").addTemperature(stoveTemp).addTemperature(stoveTempOff);
        this.block("end_stove").addTemperature(stoveTemp).addTemperature(stoveTempOff);
        this.block("mud_stove").addTemperature(stoveTemp).addTemperature(stoveTempOff);
        this.block("quartz_stove").addTemperature(stoveTemp).addTemperature(stoveTempOff);
        this.block("red_nether_bricks_stove").addTemperature(stoveTemp).addTemperature(stoveTempOff);
        this.block("basalt_stove").addTemperature(stoveTemp).addTemperature(stoveTempOff);
        this.block("bamboo_stove").addTemperature(stoveTemp).addTemperature(stoveTempOff);
        this.item("flower_crown").heatResistance(1.0f);
        this.item("necktie").heatResistance(1.0f);
        this.item("dress").heatResistance(1.5f);
        this.item("shirt").heatResistance(1.5f);
        this.item("cooking_hat").heatResistance(1.0f);
        this.item("chefs_jacket").heatResistance(1.5f);
        this.item("chefs_pants").heatResistance(1.0f);
        this.item("chefs_boots").heatResistance(0.5f);
        this.item("trousers_and_vest").heatResistance(1.0f);
    }
}

