/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class HardcoreTorchesTemperatureProvider
extends TemperatureDataProvider {
    public HardcoreTorchesTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("hardcore_torches", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.block("hardcore_campfire").addTemperature(this.temperatureBlock(10.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("lit_wall_torch").addTemperature(this.temperatureBlock(1.5f));
        this.block("lit_torch").addTemperature(this.temperatureBlock(1.5f));
        this.item("lit_torch").temperature(1.5f);
        this.block("smoldering_wall_torch").addTemperature(this.temperatureBlock(0.75f));
        this.block("smoldering_torch").addTemperature(this.temperatureBlock(0.75f));
        this.item("smoldering_torch").temperature(0.75f);
    }
}

