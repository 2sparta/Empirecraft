/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class TerraFirmaCraftTemperatureProvider
extends TemperatureDataProvider {
    public TerraFirmaCraftTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("tfc", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.block("firepit").addTemperature(this.temperatureBlock(8.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("pot").addTemperature(this.temperatureBlock(8.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("charcoal_forge").addTemperature(this.temperatureBlock(15.0f).addProperty("heat_level", "6")).addTemperature(this.temperatureBlock(13.0f).addProperty("heat_level", "5")).addTemperature(this.temperatureBlock(11.0f).addProperty("heat_level", "4")).addTemperature(this.temperatureBlock(9.0f).addProperty("heat_level", "3")).addTemperature(this.temperatureBlock(6.0f).addProperty("heat_level", "2")).addTemperature(this.temperatureBlock(3.0f).addProperty("heat_level", "1")).addTemperature(this.temperatureBlock(0.0f).addProperty("heat_level", "0"));
    }
}

