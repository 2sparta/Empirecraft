/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.block.ThermalTypeEnum;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class BetterEndTemperatureProvider
extends TemperatureDataProvider {
    public BetterEndTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("betterend", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.fuelItem("charcoal_block").thermalType(ThermalTypeEnum.HEATING).duration(5400);
        this.fuelItem("emerald_ice").thermalType(ThermalTypeEnum.COOLING).duration(1800);
        this.fuelItem("dense_emerald_ice").thermalType(ThermalTypeEnum.COOLING).duration(3600);
        this.fuelItem("ancient_emerald_ice").thermalType(ThermalTypeEnum.COOLING).duration(16200);
        this.item("emerald_ice").temperature(-2.0f);
        this.item("dense_emerald_ice").temperature(-3.0f);
        this.item("ancient_emerald_ice").temperature(-4.0f);
        this.item("aeternium_helmet").heatResistance(2.0f);
        this.item("aeternium_chestplate").heatResistance(3.0f);
        this.item("aeternium_leggings").heatResistance(2.5f);
        this.item("aeternium_boots").heatResistance(2.0f);
        this.item("crystalite_helmet").heatResistance(1.5f);
        this.item("crystalite_chestplate").heatResistance(2.0f);
        this.item("crystalite_leggings").heatResistance(2.0f);
        this.item("crystalite_boots").heatResistance(1.0f);
        this.item("terminite_helmet").heatResistance(1.0f);
        this.item("terminite_chestplate").heatResistance(1.5f);
        this.item("crystalite_leggings").heatResistance(1.0f);
        this.item("crystalite_boots").heatResistance(1.0f);
        this.item("thallasium_helmet").heatResistance(0.5f);
        this.item("thallasium_chestplate").heatResistance(1.0f);
        this.item("thallasium_leggings").heatResistance(0.5f);
        this.item("thallasium_boots").heatResistance(0.5f);
        this.item("cincinnasite_helmet").heatResistance(1.0f);
        this.item("cincinnasite_chestplate").heatResistance(2.0f);
        this.item("cincinnasite_leggings").heatResistance(2.0f);
        this.item("cincinnasite_boots").heatResistance(1.0f);
        this.item("nether_ruby_helmet").coldResistance(1.0f);
        this.item("nether_ruby_chestplate").coldResistance(2.0f);
        this.item("nether_ruby_leggings").coldResistance(2.0f);
        this.item("nether_ruby_boots").coldResistance(1.0f);
        this.item("flaming_ruby_helmet").coldResistance(1.5f);
        this.item("flaming_ruby_chestplate").coldResistance(2.5f);
        this.item("flaming_ruby_leggings").coldResistance(2.5f);
        this.item("flaming_ruby_boots").coldResistance(1.5f);
    }
}

