/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class NetherVineryThirstProvider
extends ThirstDataProvider {
    public NetherVineryThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("nethervinery", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable("crimson_grape").addThirst(this.thirstData(2, 0.0f));
        this.consumable("warped_grape").addThirst(this.thirstData(2, 0.0f));
        IThirstData vinery_hydration = this.thirstData(5, 4.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f);
        IThirstData vinery2_hydration = this.thirstData(7, 5.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f);
        this.consumable("blazewine_pinot").addThirst(vinery_hydration);
        this.consumable("ghastly_grenache").addThirst(vinery_hydration);
        this.consumable("netherite_nectar").addThirst(vinery2_hydration);
        this.consumable("lava_fizz").addThirst(vinery_hydration);
        this.consumable("nether_fizz").addThirst(vinery_hydration);
        this.consumable("improved_lava_fizz").addThirst(vinery2_hydration);
        this.consumable("improved_nether_fizz").addThirst(vinery2_hydration);
    }
}

