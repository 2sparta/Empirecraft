/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class BrewinCompatDelightTemperatureProvider
extends TemperatureDataProvider {
    public BrewinCompatDelightTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("brewincompatdelight", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        ITemperatureConsumableData beer = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400);
        this.consumable("beer_knees").addTemperature(beer);
        this.consumable("brass_monkey").addTemperature(beer);
        ITemperatureConsumableData cocktail = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-2).duration(2400);
        this.consumable("aqua_velva").addTemperature(cocktail);
        this.consumable("blue_curacao").addTemperature(cocktail);
        this.consumable("china_blue").addTemperature(cocktail);
        this.consumable("gin_and_juice").addTemperature(cocktail);
        this.consumable("gin_and_tonic").addTemperature(cocktail);
        this.consumable("half_and_half").addTemperature(cocktail);
        this.consumable("margarita").addTemperature(cocktail);
        this.consumable("mojito").addTemperature(cocktail);
        this.consumable("pina_colada").addTemperature(cocktail);
        this.consumable("salted_margarita").addTemperature(cocktail);
        this.consumable("singapore_sling").addTemperature(cocktail);
        this.consumable("tequila_sunrise").addTemperature(cocktail);
        ITemperatureConsumableData wine = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400);
        this.consumable("mulled_wine").addTemperature(wine);
        this.consumable("peach_wine").addTemperature(wine);
        this.consumable("red_wine").addTemperature(wine);
        this.consumable("sweet_red_wine").addTemperature(wine);
        this.consumable("white_wine").addTemperature(wine);
        ITemperatureConsumableData alcohol = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(2).duration(2400);
        this.consumable("gin").addTemperature(alcohol);
        this.consumable("kraken_rum").addTemperature(alcohol);
        this.consumable("screwdriver").addTemperature(alcohol);
        this.consumable("tequila").addTemperature(alcohol);
        ITemperatureConsumableData soft = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(2400);
        this.consumable("hard_lemonade").addTemperature(soft);
        this.consumable("hard_cider").addTemperature(soft);
        this.consumable("lemon_lime").addTemperature(soft);
        this.consumable("mermaid_lemonade").addTemperature(soft);
        this.consumable("tonic_water").addTemperature(soft);
    }
}

