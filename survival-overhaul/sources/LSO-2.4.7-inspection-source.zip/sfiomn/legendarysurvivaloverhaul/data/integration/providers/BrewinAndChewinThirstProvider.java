/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class BrewinAndChewinThirstProvider
extends ThirstDataProvider {
    public BrewinAndChewinThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("brewinandchewin", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        IThirstData drink0 = this.thirstData(3, 2.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.3f);
        this.consumable("saccharine_rum").addThirst(drink0);
        IThirstData drink1 = this.thirstData(8, 6.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f);
        this.consumable("beer").addThirst(drink1);
        this.consumable("bloody_mary").addThirst(drink1);
        this.consumable("dread_nog").addThirst(drink1);
        this.consumable("egg_grog").addThirst(drink1);
        this.consumable("mead").addThirst(drink1);
        this.consumable("steel_toe_stout").addThirst(drink1);
        this.consumable("strongroot_ale").addThirst(drink1);
        IThirstData drink2 = this.thirstData(10, 6.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600, 0.2f);
        this.consumable("glittering_grenadine").addThirst(drink2);
        this.consumable("kombucha").addThirst(drink2);
        IThirstData drink3 = this.thirstData(5, 4.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 1000, 0.4f);
        this.consumable("pale_jane").addThirst(drink3);
        this.consumable("vodka").addThirst(drink3);
        this.consumable("red_rum").addThirst(drink3);
        this.consumable("rice_wine").addThirst(drink3);
        this.consumable("salty_folly").addThirst(drink3);
        this.consumable("withering_dross").addThirst(this.thirstData(12, 7.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 1200));
    }
}

