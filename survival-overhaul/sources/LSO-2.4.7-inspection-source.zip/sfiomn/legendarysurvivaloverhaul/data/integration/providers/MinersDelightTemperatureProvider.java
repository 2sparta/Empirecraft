/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class MinersDelightTemperatureProvider
extends TemperatureDataProvider {
    public MinersDelightTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("miners_delight", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        ITemperatureConsumableData soupTemperature = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(1).duration(2400);
        this.consumable("beetroot_soup_cup").addTemperature(soupTemperature);
        this.consumable("cave_soup_cup").addTemperature(soupTemperature);
        this.consumable("bat_soup_cup").addTemperature(soupTemperature);
        this.consumable("vegetable_soup_cup").addTemperature(soupTemperature);
        this.consumable("noodle_soup_cup").addTemperature(soupTemperature);
        this.consumable("chicken_soup_cup").addTemperature(soupTemperature);
        this.consumable("pumpkin_soup_cup").addTemperature(soupTemperature);
        ITemperatureConsumableData soupTemperature2 = this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(2).duration(2400);
        this.consumable("cave_soup").addTemperature(soupTemperature2);
        this.consumable("bat_soup").addTemperature(soupTemperature2);
        ITemperatureConsumableData stewTemperature = this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(1).duration(2400);
        this.consumable("mushroom_stew_cup").addTemperature(stewTemperature);
        this.consumable("insect_stew_cup").addTemperature(stewTemperature);
        this.consumable("fish_stew_cup").addTemperature(stewTemperature);
        this.consumable("rabbit_stew_cup").addTemperature(stewTemperature);
        this.consumable("beef_stew_cup").addTemperature(stewTemperature);
        this.consumable("baked_cod_stew_cup").addTemperature(stewTemperature);
        ITemperatureConsumableData stewTemperature2 = this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(2).duration(2400);
        this.consumable("insect_stew").addTemperature(stewTemperature2);
    }
}

