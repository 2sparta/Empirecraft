/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class IronsSpellbooksTemperatureProvider
extends TemperatureDataProvider {
    public IronsSpellbooksTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("irons_spellbooks", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.item("pyromancer_helmet").coldResistance(1.5f);
        this.item("pyromancer_chestplate").coldResistance(2.5f);
        this.item("pyromancer_leggings").coldResistance(2.0f);
        this.item("pyromancer_boots").coldResistance(1.5f);
        this.item("cryomancer_helmet").heatResistance(1.5f);
        this.item("cryomancer_chestplate").heatResistance(2.5f);
        this.item("cryomancer_leggings").heatResistance(2.0f);
        this.item("cryomancer_boots").heatResistance(1.5f);
        this.item("netherite_mage_helmet").coldResistance(2.0f);
        this.item("netherite_mage_chestplate").coldResistance(3.5f);
        this.item("netherite_mage_leggings").coldResistance(2.5f);
        this.item("netherite_mage_boots").coldResistance(2.0f);
    }
}

