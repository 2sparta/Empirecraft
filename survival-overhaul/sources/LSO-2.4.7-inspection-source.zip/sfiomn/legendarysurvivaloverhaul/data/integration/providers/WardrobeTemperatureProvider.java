/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.integration.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;

public class WardrobeTemperatureProvider
extends TemperatureDataProvider {
    public WardrobeTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("wardrobe", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.item("taiga_helmet").coldResistance(2.0f);
        this.item("taiga_chestplate").coldResistance(3.5f);
        this.item("taiga_leggings").coldResistance(3.0f);
        this.item("taiga_boots").coldResistance(1.0f);
        this.item("snowy_helmet").coldResistance(2.0f);
        this.item("snowy_chestplate").coldResistance(3.5f);
        this.item("snowy_leggings").coldResistance(3.0f);
        this.item("snowy_boots").coldResistance(1.0f);
        this.item("desert_helmet").heatResistance(2.0f);
        this.item("desert_chestplate").heatResistance(3.0f);
        this.item("desert_leggings").heatResistance(2.0f);
        this.item("desert_boots").heatResistance(1.0f);
        this.item("jungle_chestplate").heatResistance(5.0f);
        this.item("jungle_leggings").heatResistance(3.0f);
        this.item("jungle_boots").heatResistance(2.0f);
        this.item("savanna_chestplate").heatResistance(4.0f);
        this.item("savanna_leggings").heatResistance(2.5f);
        this.item("savanna_boots").heatResistance(1.5f);
        this.item("wool_vest_chestplate").coldResistance(2.0f);
        this.item("chiton").heatResistance(2.0f);
        this.item("farmers_hat_helmet").heatResistance(3.5f);
    }
}

