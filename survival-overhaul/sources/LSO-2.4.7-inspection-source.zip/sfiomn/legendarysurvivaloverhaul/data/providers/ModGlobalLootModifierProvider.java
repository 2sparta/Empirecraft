/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.data.PackOutput
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.level.storage.loot.predicates.LootItemCondition
 *  net.minecraftforge.common.data.GlobalLootModifierProvider
 *  net.minecraftforge.common.loot.IGlobalLootModifier
 *  net.minecraftforge.common.loot.LootTableIdCondition
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.data.GlobalLootModifierProvider;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootTableIdCondition;
import sfiomn.legendarysurvivaloverhaul.common.loot_modifiers.AdditionalLootTable;
import sfiomn.legendarysurvivaloverhaul.data.loot.ModBarteringLootTables;
import sfiomn.legendarysurvivaloverhaul.data.loot.ModChestLootTables;
import sfiomn.legendarysurvivaloverhaul.data.loot.ModEntityLootTables;
import sfiomn.legendarysurvivaloverhaul.data.loot.ModFishingLootTables;

public class ModGlobalLootModifierProvider
extends GlobalLootModifierProvider {
    public ModGlobalLootModifierProvider(PackOutput output) {
        super(output, "legendarysurvivaloverhaul");
    }

    protected void start() {
        for (ResourceLocation lootTable : ModChestLootTables.chestInjectedLootTables.keySet()) {
            this.add(lootTable.m_135815_(), (IGlobalLootModifier)new AdditionalLootTable(new LootItemCondition[]{LootTableIdCondition.builder((ResourceLocation)lootTable).m_6409_()}, new ResourceLocation("legendarysurvivaloverhaul", "inject/" + lootTable.m_135815_()), false));
        }
        for (ResourceLocation lootTable : ModEntityLootTables.entityInjectedLootTables) {
            this.add(lootTable.m_135815_(), (IGlobalLootModifier)new AdditionalLootTable(new LootItemCondition[]{LootTableIdCondition.builder((ResourceLocation)lootTable).m_6409_()}, new ResourceLocation("legendarysurvivaloverhaul", "inject/" + lootTable.m_135815_()), false));
        }
        for (ResourceLocation lootTable : ModFishingLootTables.fishingInjectedLootTables) {
            this.add(lootTable.m_135815_(), (IGlobalLootModifier)new AdditionalLootTable(new LootItemCondition[]{LootTableIdCondition.builder((ResourceLocation)lootTable).m_6409_()}, new ResourceLocation("legendarysurvivaloverhaul", "inject/" + lootTable.m_135815_()), false));
        }
        for (ResourceLocation lootTable : ModBarteringLootTables.barteringInjectedLootTables) {
            this.add(lootTable.m_135815_(), (IGlobalLootModifier)new AdditionalLootTable(new LootItemCondition[]{LootTableIdCondition.builder((ResourceLocation)lootTable).m_6409_()}, new ResourceLocation("legendarysurvivaloverhaul", "inject/" + lootTable.m_135815_()), false));
        }
    }
}

