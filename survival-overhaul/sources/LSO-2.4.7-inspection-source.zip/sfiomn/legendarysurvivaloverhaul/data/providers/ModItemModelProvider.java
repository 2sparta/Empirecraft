/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.data.PackOutput
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.item.Item
 *  net.minecraftforge.client.model.generators.ItemModelBuilder
 *  net.minecraftforge.client.model.generators.ItemModelProvider
 *  net.minecraftforge.client.model.generators.ModelFile
 *  net.minecraftforge.client.model.generators.ModelFile$UncheckedModelFile
 *  net.minecraftforge.common.data.ExistingFileHelper
 *  net.minecraftforge.registries.RegistryObject
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraftforge.client.model.generators.ItemModelBuilder;
import net.minecraftforge.client.model.generators.ItemModelProvider;
import net.minecraftforge.client.model.generators.ModelFile;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.registries.RegistryObject;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;

public class ModItemModelProvider
extends ItemModelProvider {
    public ModItemModelProvider(PackOutput output, ExistingFileHelper existingFileHelper) {
        super(output, "legendarysurvivaloverhaul", existingFileHelper);
    }

    protected void registerModels() {
        this.simpleJuiceItem(ItemRegistry.APPLE_JUICE);
        this.simpleJuiceItem(ItemRegistry.BEETROOT_JUICE);
        this.simpleJuiceItem(ItemRegistry.CACTUS_JUICE);
        this.simpleJuiceItem(ItemRegistry.CARROT_JUICE);
        this.simpleJuiceItem(ItemRegistry.CHORUS_FRUIT_JUICE);
        this.simpleJuiceItem(ItemRegistry.GLISTERING_MELON_JUICE);
        this.simpleJuiceItem(ItemRegistry.GOLDEN_APPLE_JUICE);
        this.simpleJuiceItem(ItemRegistry.GOLDEN_CARROT_JUICE);
        this.simpleJuiceItem(ItemRegistry.MELON_JUICE);
        this.simpleJuiceItem(ItemRegistry.PUMPKIN_JUICE);
        this.simpleJuiceItem(ItemRegistry.SWEET_BERRIES_JUICE);
        this.simpleJuiceItem(ItemRegistry.GLOW_BERRIES_JUICE);
        this.simpleJuiceItem(ItemRegistry.GOLDEN_APPLE_JUICE);
        this.simpleHealingItem(ItemRegistry.BANDAGE);
        this.simpleHealingItem(ItemRegistry.HEALING_HERBS);
        this.simpleHealingItem(ItemRegistry.MEDKIT);
        this.simpleHealingItem(ItemRegistry.MORPHINE);
        this.simpleHealingItem(ItemRegistry.PLASTER);
        this.simpleHealingItem(ItemRegistry.TONIC);
        this.canteenItem(ItemRegistry.CANTEEN);
        this.canteenItem(ItemRegistry.LARGE_CANTEEN);
        this.simpleItem(ItemRegistry.PURIFIED_WATER_BOTTLE);
        this.simpleItem(ItemRegistry.ICE_FERN);
        this.simpleItem(ItemRegistry.ICE_FERN_SEEDS);
        this.simpleItem(ItemRegistry.ICE_FERN_GOLD);
        this.simpleItem(ItemRegistry.SUN_FERN);
        this.simpleItem(ItemRegistry.SUN_FERN_SEEDS);
        this.simpleItem(ItemRegistry.SUN_FERN_GOLD);
        this.simpleItem(ItemRegistry.WATER_PLANT_BAG);
        this.simpleItem(ItemRegistry.WATER_PLANT_SEEDS);
        this.simpleItem(ItemRegistry.COLD_STRING);
        this.simpleItem(ItemRegistry.WARM_STRING);
        this.simpleItem(ItemRegistry.NETHER_CHALICE);
        this.simpleItem(ItemRegistry.SPONGE);
        this.simpleItem(ItemRegistry.WATER_PURIFIER);
        this.simpleItem(ItemRegistry.HEAT_RESISTANCE_RING);
        this.simpleItem(ItemRegistry.COLD_RESISTANCE_RING);
        this.simpleItem(ItemRegistry.THERMAL_RESISTANCE_RING);
        this.simpleItem(ItemRegistry.FIRST_AID_SUPPLIES);
        this.simpleItem(ItemRegistry.HEART_CONTAINER);
        this.simpleItem(ItemRegistry.HEART_FRAGMENT);
        this.simpleItem(ItemRegistry.SHIELD_CONTAINER);
        this.simpleCoatItem(ItemRegistry.COOLING_COAT_1);
        this.simpleCoatItem(ItemRegistry.COOLING_COAT_2);
        this.simpleCoatItem(ItemRegistry.COOLING_COAT_3);
        this.simpleCoatItem(ItemRegistry.HEATING_COAT_1);
        this.simpleCoatItem(ItemRegistry.HEATING_COAT_2);
        this.simpleCoatItem(ItemRegistry.HEATING_COAT_3);
        this.simpleCoatItem(ItemRegistry.THERMAL_COAT_1);
        this.simpleCoatItem(ItemRegistry.THERMAL_COAT_2);
        this.simpleCoatItem(ItemRegistry.THERMAL_COAT_3);
        this.simpleArmorItem(ItemRegistry.DESERT_BOOTS);
        this.simpleArmorItem(ItemRegistry.DESERT_CHEST);
        this.simpleArmorItem(ItemRegistry.DESERT_HELMET);
        this.simpleArmorItem(ItemRegistry.DESERT_LEGGINGS);
        this.simpleArmorItem(ItemRegistry.SNOW_BOOTS);
        this.simpleArmorItem(ItemRegistry.SNOW_CHEST);
        this.simpleArmorItem(ItemRegistry.SNOW_HELMET);
        this.simpleArmorItem(ItemRegistry.SNOW_LEGGINGS);
        for (int i = 0; i < 30; ++i) {
            String jsonName = String.format("%02d", i);
            this.singleTexture("item/thermometer/thermometer_" + jsonName, new ResourceLocation("item/generated"), "layer0", new ResourceLocation("legendarysurvivaloverhaul", "item/thermometer/thermometer_" + jsonName));
        }
        String[] serene_seasons = new String[]{"autumn", "dry", "spring", "summer", "wet", "winter"};
        for (int i = 1; i < 4; ++i) {
            for (String season : serene_seasons) {
                String jsonName = season + i;
                this.singleTexture("item/seasonal_calendar/serene_seasons/seasonal_calendar_" + jsonName, new ResourceLocation("item/generated"), "layer0", new ResourceLocation("legendarysurvivaloverhaul", "item/seasonal_calendar/serene_seasons/" + jsonName));
            }
        }
        String[] ecliptic_seasons = new String[]{"autumn", "spring", "summer", "winter"};
        for (int i = 1; i < 7; ++i) {
            for (String season : ecliptic_seasons) {
                String jsonName = season + i;
                this.singleTexture("item/seasonal_calendar/ecliptic_seasons/seasonal_calendar_" + jsonName, new ResourceLocation("item/generated"), "layer0", new ResourceLocation("legendarysurvivaloverhaul", "item/seasonal_calendar/ecliptic_seasons/" + jsonName));
            }
        }
        this.singleTexture("item/seasonal_calendar/seasonal_calendar_null", new ResourceLocation("item/generated"), "layer0", new ResourceLocation("legendarysurvivaloverhaul", "item/seasonal_calendar/calendar_null"));
    }

    private void simpleItem(RegistryObject<Item> item) {
        this.singleTexture(item.getId().m_135815_(), new ResourceLocation("item/generated"), "layer0", new ResourceLocation("legendarysurvivaloverhaul", "item/" + item.getId().m_135815_()));
    }

    private void simpleItem(String jsonName) {
        this.singleTexture(jsonName, new ResourceLocation("item/generated"), "layer0", new ResourceLocation("legendarysurvivaloverhaul", "item/" + jsonName));
    }

    private void simpleArmorItem(RegistryObject<Item> item) {
        this.singleTexture(item.getId().m_135815_(), new ResourceLocation("item/generated"), "layer0", new ResourceLocation("legendarysurvivaloverhaul", "item/armor/" + item.getId().m_135815_()));
    }

    private void simpleCoatItem(RegistryObject<Item> item) {
        this.singleTexture(item.getId().m_135815_(), new ResourceLocation("item/generated"), "layer0", new ResourceLocation("legendarysurvivaloverhaul", "item/coat/" + item.getId().m_135815_()));
    }

    private void simpleHealingItem(RegistryObject<Item> item) {
        this.singleTexture(item.getId().m_135815_(), new ResourceLocation("item/generated"), "layer0", new ResourceLocation("legendarysurvivaloverhaul", "item/healing/" + item.getId().m_135815_()));
    }

    private void simpleJuiceItem(RegistryObject<Item> item) {
        this.singleTexture(item.getId().m_135815_(), new ResourceLocation("item/generated"), "layer0", new ResourceLocation("legendarysurvivaloverhaul", "item/juice/" + item.getId().m_135815_()));
    }

    private void simplePaddingItem(RegistryObject<Item> item) {
        this.singleTexture(item.getId().m_135815_(), new ResourceLocation("item/generated"), "layer0", new ResourceLocation("legendarysurvivaloverhaul", "item/padding/" + item.getId().m_135815_()));
    }

    private void canteenItem(RegistryObject<Item> canteenItem) {
        ((ItemModelBuilder)((ItemModelBuilder)this.withExistingParent(canteenItem.getId().m_135815_(), new ResourceLocation("item/generated"))).texture("layer0", new ResourceLocation("legendarysurvivaloverhaul", "item/" + canteenItem.getId().m_135815_()))).override().predicate(new ResourceLocation("legendarysurvivaloverhaul", "thirstenum"), 0.3f).model((ModelFile)new ModelFile.UncheckedModelFile(new ResourceLocation("legendarysurvivaloverhaul", "item/" + canteenItem.getId().m_135815_() + "_purified"))).end();
        this.simpleItem(canteenItem.getId().m_135815_() + "_purified");
    }
}

