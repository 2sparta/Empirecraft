/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.data.tags.DamageTypeTagsProvider
 *  net.minecraft.tags.DamageTypeTags
 *  net.minecraftforge.common.data.ExistingFileHelper
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.data.tags.DamageTypeTagsProvider;
import net.minecraft.tags.DamageTypeTags;
import net.minecraftforge.common.data.ExistingFileHelper;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.api.ModDamageTypes;

public class ModDamageTypeTagsProvider
extends DamageTypeTagsProvider {
    public ModDamageTypeTagsProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, @Nullable ExistingFileHelper existingFileHelper) {
        super(output, lookupProvider, "legendarysurvivaloverhaul", existingFileHelper);
    }

    protected void m_6577_(// Could not load outer class - annotation placement on inner may be incorrect
     @NotNull HolderLookup.Provider lookupProvider) {
        this.m_206424_(DamageTypeTags.f_268490_).m_176839_(ModDamageTypes.HYPOTHERMIA.m_135782_()).m_176839_(ModDamageTypes.HYPERTHERMIA.m_135782_()).m_176839_(ModDamageTypes.DEHYDRATION.m_135782_());
        this.m_206424_(DamageTypeTags.f_268413_).m_176839_(ModDamageTypes.HYPOTHERMIA.m_135782_()).m_176839_(ModDamageTypes.HYPERTHERMIA.m_135782_()).m_176839_(ModDamageTypes.DEHYDRATION.m_135782_());
        this.m_206424_(DamageTypeTags.f_268630_).m_176839_(ModDamageTypes.HYPOTHERMIA.m_135782_()).m_176839_(ModDamageTypes.HYPERTHERMIA.m_135782_()).m_176839_(ModDamageTypes.DEHYDRATION.m_135782_());
    }
}

