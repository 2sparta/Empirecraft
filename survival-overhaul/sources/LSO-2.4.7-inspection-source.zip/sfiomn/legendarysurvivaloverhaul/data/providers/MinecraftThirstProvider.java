/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class MinecraftThirstProvider
extends ThirstDataProvider {
    public MinecraftThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("minecraft", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.block("rain").addThirst(this.thirstData(1, 0.0f));
        IThirstData dirtyWater = this.thirstData(3, 0.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 300, 0.75f);
        this.block("flowing_water").addThirst(dirtyWater);
        this.block(Blocks.f_49990_).addThirst(dirtyWater);
        this.block(Blocks.f_152476_).addThirst(dirtyWater);
        this.consumable(Items.f_42589_).addThirst(dirtyWater.addProperty("Potion", "minecraft:water")).addThirst(dirtyWater.addProperty("Potion", "minecraft:mundane")).addThirst(dirtyWater.addProperty("Potion", "minecraft:thick")).addThirst(dirtyWater.addProperty("Potion", "minecraft:awkward")).addThirst(this.thirstData(0, 0.0f).addProperty("Potion", "minecraft:empty")).addThirst(this.thirstData(6, 1.5f));
        this.consumable(Items.f_42575_).addThirst(this.thirstData(2, 1.0f));
        this.consumable(Items.f_42410_).addThirst(this.thirstData(2, 0.5f));
        this.consumable(Items.f_151079_).addThirst(this.thirstData(2, 0.5f));
        this.consumable(Items.f_42780_).addThirst(this.thirstData(2, 0.5f));
        this.consumable(Items.f_42583_).addThirst(this.thirstData(-4, 0.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600));
        this.consumable(Items.f_42591_).addThirst(this.thirstData(-4, 0.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 600));
        this.consumable(Items.f_42455_).addThirst(this.thirstData(5, 1.0f));
    }
}

