/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Direction
 *  net.minecraft.data.PackOutput
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.DoublePlantBlock
 *  net.minecraft.world.level.block.state.properties.BlockStateProperties
 *  net.minecraft.world.level.block.state.properties.DoubleBlockHalf
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraftforge.client.model.generators.BlockModelBuilder
 *  net.minecraftforge.client.model.generators.BlockStateProvider
 *  net.minecraftforge.client.model.generators.ConfiguredModel
 *  net.minecraftforge.client.model.generators.ModelFile
 *  net.minecraftforge.client.model.generators.ModelFile$UncheckedModelFile
 *  net.minecraftforge.client.model.generators.VariantBlockStateBuilder
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import net.minecraft.core.Direction;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraftforge.client.model.generators.BlockModelBuilder;
import net.minecraftforge.client.model.generators.BlockStateProvider;
import net.minecraftforge.client.model.generators.ConfiguredModel;
import net.minecraftforge.client.model.generators.ModelFile;
import net.minecraftforge.client.model.generators.VariantBlockStateBuilder;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.common.blocks.IceFernBlock;
import sfiomn.legendarysurvivaloverhaul.common.blocks.SunFernBlock;
import sfiomn.legendarysurvivaloverhaul.common.blocks.ThermalBlock;
import sfiomn.legendarysurvivaloverhaul.common.blocks.WaterPlantBlock;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;

public class ModBlockStateProvider
extends BlockStateProvider {
    public static final ResourceLocation COOLER_OFF = new ResourceLocation("legendarysurvivaloverhaul", "block/cooler_off");
    public static final ResourceLocation COOLER_ON = new ResourceLocation("legendarysurvivaloverhaul", "block/cooler_on");
    public static final ResourceLocation HEATER_BASE_OFF = new ResourceLocation("legendarysurvivaloverhaul", "block/heater_base_off");
    public static final ResourceLocation HEATER_BASE_ON = new ResourceLocation("legendarysurvivaloverhaul", "block/heater_base_on");
    public static final ResourceLocation HEATER_TOP = new ResourceLocation("legendarysurvivaloverhaul", "block/heater_top");
    public static final ResourceLocation SEWING_TABLE = new ResourceLocation("legendarysurvivaloverhaul", "block/sewing_table");

    public ModBlockStateProvider(PackOutput output, ExistingFileHelper exFileHelper) {
        super(output, "legendarysurvivaloverhaul", exFileHelper);
    }

    protected void registerStatesAndModels() {
        this.simpleBlockItem((Block)BlockRegistry.COOLER.get(), (ModelFile)new ModelFile.UncheckedModelFile(COOLER_OFF));
        this.getVariantBuilder((Block)BlockRegistry.COOLER.get()).forAllStates(state -> {
            if (((Boolean)state.m_61143_((Property)BlockStateProperties.f_61443_)).booleanValue()) {
                return ConfiguredModel.builder().modelFile((ModelFile)new ModelFile.UncheckedModelFile(COOLER_ON)).rotationY((int)((Direction)state.m_61143_((Property)ThermalBlock.FACING)).m_122435_()).build();
            }
            return ConfiguredModel.builder().modelFile((ModelFile)new ModelFile.UncheckedModelFile(COOLER_OFF)).rotationY((int)((Direction)state.m_61143_((Property)ThermalBlock.FACING)).m_122435_()).build();
        });
        this.simpleBlockItem((Block)BlockRegistry.HEATER.get(), (ModelFile)new ModelFile.UncheckedModelFile(this.modLoc("block/heater_off_full_block")));
        this.getVariantBuilder((Block)BlockRegistry.HEATER.get()).forAllStates(state -> {
            if (((Boolean)state.m_61143_((Property)BlockStateProperties.f_61443_)).booleanValue()) {
                return ConfiguredModel.builder().modelFile((ModelFile)new ModelFile.UncheckedModelFile(HEATER_BASE_ON)).rotationY((int)((Direction)state.m_61143_((Property)ThermalBlock.FACING)).m_122435_()).build();
            }
            return ConfiguredModel.builder().modelFile((ModelFile)new ModelFile.UncheckedModelFile(HEATER_BASE_OFF)).rotationY((int)((Direction)state.m_61143_((Property)ThermalBlock.FACING)).m_122435_()).build();
        });
        this.getVariantBuilder((Block)BlockRegistry.HEATER_TOP.get()).forAllStates(state -> ConfiguredModel.builder().modelFile((ModelFile)new ModelFile.UncheckedModelFile(HEATER_TOP)).rotationY((int)((Direction)state.m_61143_((Property)ThermalBlock.FACING)).m_122435_()).build());
        this.simpleBlockItem((Block)BlockRegistry.SEWING_TABLE.get(), (ModelFile)new ModelFile.UncheckedModelFile(SEWING_TABLE));
        this.getVariantBuilder((Block)BlockRegistry.SEWING_TABLE.get()).forAllStates(state -> ConfiguredModel.builder().modelFile((ModelFile)new ModelFile.UncheckedModelFile(SEWING_TABLE)).rotationY((int)((Direction)state.m_61143_((Property)ThermalBlock.FACING)).m_122435_()).build());
        VariantBlockStateBuilder iceFernBuilder = this.getVariantBuilder((Block)BlockRegistry.ICE_FERN_CROP.get());
        IceFernBlock.AGE.m_6908_().forEach(age -> {
            if (age < 3) {
                iceFernBuilder.partialState().with((Property)IceFernBlock.AGE, (Comparable)age).modelForState().modelFile((ModelFile)((BlockModelBuilder)((BlockModelBuilder)this.models().crop("ice_fern_" + age, this.modLoc("block/ice_fern_" + age))).texture("particle", this.modLoc("block/ice_fern_" + age))).renderType("cutout")).addModel();
            } else {
                iceFernBuilder.partialState().with((Property)IceFernBlock.AGE, (Comparable)age).modelForState().modelFile((ModelFile)new ModelFile.UncheckedModelFile(this.modLoc("block/ice_fern_mature"))).addModel();
            }
        });
        this.simpleBlockWithItem((Block)BlockRegistry.ICE_FERN_GOLD.get(), (ModelFile)new ModelFile.UncheckedModelFile(this.modLoc("block/ice_fern_gold")));
        VariantBlockStateBuilder sunFernBuilder = this.getVariantBuilder((Block)BlockRegistry.SUN_FERN_CROP.get());
        SunFernBlock.AGE.m_6908_().forEach(age -> {
            if (age < 3) {
                sunFernBuilder.partialState().with((Property)SunFernBlock.AGE, (Comparable)age).modelForState().modelFile((ModelFile)((BlockModelBuilder)((BlockModelBuilder)this.models().crop("sun_fern_" + age, this.modLoc("block/sun_fern_" + age))).texture("particle", this.modLoc("block/sun_fern_" + age))).renderType("cutout")).addModel();
            } else {
                sunFernBuilder.partialState().with((Property)SunFernBlock.AGE, (Comparable)age).modelForState().modelFile((ModelFile)new ModelFile.UncheckedModelFile(this.modLoc("block/sun_fern_mature"))).addModel();
            }
        });
        this.simpleBlockWithItem((Block)BlockRegistry.SUN_FERN_GOLD.get(), (ModelFile)new ModelFile.UncheckedModelFile(this.modLoc("block/sun_fern_gold")));
        VariantBlockStateBuilder waterPlantBuilder = this.getVariantBuilder((Block)BlockRegistry.WATER_PLANT_CROP.get());
        WaterPlantBlock.AGE.m_6908_().forEach(age -> {
            waterPlantBuilder.partialState().with((Property)DoublePlantBlock.f_52858_, (Comparable)DoubleBlockHalf.LOWER).with((Property)WaterPlantBlock.AGE, (Comparable)age).modelForState().modelFile((ModelFile)((BlockModelBuilder)((BlockModelBuilder)this.models().cross("water_plant_bottom_" + age, this.modLoc("block/water_plant_bottom_" + age))).texture("particle", this.modLoc("block/water_plant_bottom_" + age))).renderType("cutout")).addModel();
            waterPlantBuilder.partialState().with((Property)DoublePlantBlock.f_52858_, (Comparable)DoubleBlockHalf.UPPER).with((Property)WaterPlantBlock.AGE, (Comparable)age).modelForState().modelFile((ModelFile)((BlockModelBuilder)((BlockModelBuilder)this.models().cross("water_plant_top_" + age, this.modLoc("block/water_plant_top_" + age))).texture("particle", this.modLoc("block/water_plant_top_" + age))).renderType("cutout")).addModel();
        });
    }
}

