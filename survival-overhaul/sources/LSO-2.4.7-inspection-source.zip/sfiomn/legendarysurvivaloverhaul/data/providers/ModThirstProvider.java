/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.item.Item
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.ThirstDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.thirst.HydrationEnum;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class ModThirstProvider
extends ThirstDataProvider {
    public ModThirstProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("legendarysurvivaloverhaul", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable((Item)ItemRegistry.APPLE_JUICE.get()).addThirst(this.thirstData(6, 3.0f));
        this.consumable((Item)ItemRegistry.BEETROOT_JUICE.get()).addThirst(this.thirstData(8, 4.0f));
        this.consumable((Item)ItemRegistry.CACTUS_JUICE.get()).addThirst(this.thirstData(9, 3.0f));
        this.consumable((Item)ItemRegistry.CARROT_JUICE.get()).addThirst(this.thirstData(4, 2.0f));
        this.consumable((Item)ItemRegistry.CHORUS_FRUIT_JUICE.get()).addThirst(this.thirstData(12, 14.0f));
        this.consumable((Item)ItemRegistry.GOLDEN_APPLE_JUICE.get()).addThirst(this.thirstData(10, 12.0f));
        this.consumable((Item)ItemRegistry.GOLDEN_CARROT_JUICE.get()).addThirst(this.thirstData(8, 6.0f));
        this.consumable((Item)ItemRegistry.GLISTERING_MELON_JUICE.get()).addThirst(this.thirstData(6, 6.0f));
        this.consumable((Item)ItemRegistry.MELON_JUICE.get()).addThirst(this.thirstData(7, 4.0f));
        this.consumable((Item)ItemRegistry.PUMPKIN_JUICE.get()).addThirst(this.thirstData(6, 3.5f));
        this.consumable((Item)ItemRegistry.GLOW_BERRIES_JUICE.get()).addThirst(this.thirstData(4, 6.0f));
        this.consumable((Item)ItemRegistry.SWEET_BERRIES_JUICE.get()).addThirst(this.thirstData(9, 5.0f));
        this.consumable((Item)ItemRegistry.PURIFIED_WATER_BOTTLE.get()).addThirst(this.thirstData(6, 1.5f));
        this.consumable((Item)ItemRegistry.WATER_PLANT_BAG.get()).addThirst(this.thirstData(3, 0.0f));
        IThirstData dirtyWaterCanteen = this.thirstData(3, 0.0f).addEffect((MobEffect)MobEffectRegistry.THIRST.get(), 300, 0.75f).addProperty("legendarysurvivaloverhaul:HydrationPurity", HydrationEnum.NORMAL.getName());
        IThirstData purifiedWaterCanteen = this.thirstData(6, 1.5f).addProperty("legendarysurvivaloverhaul:HydrationPurity", HydrationEnum.PURIFIED.getName());
        this.consumable((Item)ItemRegistry.CANTEEN.get()).addThirst(dirtyWaterCanteen).addThirst(purifiedWaterCanteen);
        this.consumable((Item)ItemRegistry.LARGE_CANTEEN.get()).addThirst(dirtyWaterCanteen).addThirst(purifiedWaterCanteen);
    }
}

