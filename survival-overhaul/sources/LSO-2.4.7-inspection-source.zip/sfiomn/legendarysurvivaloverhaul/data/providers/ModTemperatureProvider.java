/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.level.block.Block
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;
import sfiomn.legendarysurvivaloverhaul.common.blocks.IceFernBlock;
import sfiomn.legendarysurvivaloverhaul.common.blocks.SunFernBlock;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;

public class ModTemperatureProvider
extends TemperatureDataProvider {
    public ModTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("legendarysurvivaloverhaul", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.block((Block)BlockRegistry.COOLER.get()).addTemperature(this.temperatureBlock(-15.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block((Block)BlockRegistry.HEATER.get()).addTemperature(this.temperatureBlock(15.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block((Block)BlockRegistry.ICE_FERN_CROP.get()).addTemperature(this.temperatureBlock(-1.5f).addProperty(IceFernBlock.AGE.m_61708_(), String.valueOf(3)));
        this.block((Block)BlockRegistry.SUN_FERN_CROP.get()).addTemperature(this.temperatureBlock(1.5f).addProperty(SunFernBlock.AGE.m_61708_(), String.valueOf(3)));
        this.block((Block)BlockRegistry.ICE_FERN_GOLD.get()).addTemperature(this.temperatureBlock(-1.5f).addProperty(IceFernBlock.AGE.m_61708_(), String.valueOf(3)));
        this.block((Block)BlockRegistry.SUN_FERN_GOLD.get()).addTemperature(this.temperatureBlock(1.5f).addProperty(SunFernBlock.AGE.m_61708_(), String.valueOf(3)));
        this.item((Item)ItemRegistry.SNOW_BOOTS.get()).coldResistance(0.5f);
        this.item((Item)ItemRegistry.SNOW_LEGGINGS.get()).coldResistance(2.5f);
        this.item((Item)ItemRegistry.SNOW_CHEST.get()).coldResistance(3.0f);
        this.item((Item)ItemRegistry.SNOW_HELMET.get()).coldResistance(1.5f);
        this.item((Item)ItemRegistry.DESERT_BOOTS.get()).heatResistance(0.5f);
        this.item((Item)ItemRegistry.DESERT_LEGGINGS.get()).heatResistance(2.5f);
        this.item((Item)ItemRegistry.DESERT_CHEST.get()).heatResistance(3.0f);
        this.item((Item)ItemRegistry.DESERT_HELMET.get()).heatResistance(1.5f);
        this.item((Item)ItemRegistry.NETHER_CHALICE.get()).temperature(2.0f);
        this.item((Item)ItemRegistry.HEAT_RESISTANCE_RING.get()).heatResistance(3.0f);
        this.item((Item)ItemRegistry.COLD_RESISTANCE_RING.get()).coldResistance(3.0f);
        this.item((Item)ItemRegistry.THERMAL_RESISTANCE_RING.get()).thermalResistance(3.0f);
        this.consumable((Item)ItemRegistry.MELON_JUICE.get()).addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-1).duration(1200));
        this.consumable((Item)ItemRegistry.GLISTERING_MELON_JUICE.get()).addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(-2).duration(3600));
    }
}

