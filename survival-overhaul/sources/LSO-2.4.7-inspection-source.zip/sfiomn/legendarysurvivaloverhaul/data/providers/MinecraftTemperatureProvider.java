/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.block.ThermalTypeEnum;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.TemperatureDataProvider;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class MinecraftTemperatureProvider
extends TemperatureDataProvider {
    public MinecraftTemperatureProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("minecraft", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.dimension("overworld").temperature(20.0f).hasAltitude().seaLevelHeight(64).temperatureTimeCycleTicks(24000);
        this.dimension("the_end").temperature(-13.0f);
        this.dimension("the_nether").temperature(27.0f);
        this.block("campfire").addTemperature(this.temperatureBlock(10.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("soul_campfire").addTemperature(this.temperatureBlock(-10.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("furnace").addTemperature(this.temperatureBlock(6.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("blast_furnace").addTemperature(this.temperatureBlock(6.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("smoker").addTemperature(this.temperatureBlock(6.0f).addProperty("lit", "true")).addTemperature(this.temperatureBlock(0.0f).addProperty("lit", "false"));
        this.block("torch").addTemperature(this.temperatureBlock(1.5f));
        this.block("wall_torch").addTemperature(this.temperatureBlock(1.5f));
        this.block("soul_torch").addTemperature(this.temperatureBlock(-1.5f));
        this.block("soul_wall_torch").addTemperature(this.temperatureBlock(-1.5f));
        this.block("fire").addTemperature(this.temperatureBlock(7.0f));
        this.block("soul_fire").addTemperature(this.temperatureBlock(-7.0f));
        this.block("magma_block").addTemperature(this.temperatureBlock(12.0f));
        this.block("jack_o_lantern").addTemperature(this.temperatureBlock(3.0f));
        this.block("lava").addTemperature(this.temperatureBlock(12.5f));
        this.block("flowing_lava").addTemperature(this.temperatureBlock(12.5f));
        this.item("lava_bucket").temperature(6.0f);
        this.item("magma_block").temperature(6.0f);
        this.item("torch").temperature(1.0f);
        this.item("soul_torch").temperature(-1.0f);
        this.item("ice").temperature(-1.0f);
        this.item("packed_ice").temperature(-2.0f);
        this.item("blue_ice").temperature(-3.0f);
        this.item("leather_boots").coldResistance(0.5f);
        this.item("leather_leggings").coldResistance(1.0f);
        this.item("leather_chestplate").coldResistance(1.5f);
        this.item("leather_helmet").coldResistance(1.0f);
        this.item("golden_boots").coldResistance(0.5f);
        this.item("golden_leggings").coldResistance(1.0f);
        this.item("golden_chestplate").coldResistance(1.0f);
        this.item("golden_helmet").coldResistance(0.5f);
        this.item("iron_boots").heatResistance(0.5f);
        this.item("iron_leggings").heatResistance(1.0f);
        this.item("iron_chestplate").heatResistance(1.0f);
        this.item("iron_helmet").heatResistance(0.5f);
        this.item("diamond_boots").heatResistance(1.0f);
        this.item("diamond_leggings").heatResistance(1.0f);
        this.item("diamond_chestplate").heatResistance(1.5f);
        this.item("diamond_helmet").heatResistance(0.5f);
        this.item("netherite_boots").coldResistance(1.5f);
        this.item("netherite_leggings").coldResistance(1.5f);
        this.item("netherite_chestplate").coldResistance(2.0f);
        this.item("netherite_helmet").coldResistance(1.0f);
        this.mount("strider").heatResistance(7.0f);
        this.consumable("mushroom_stew").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(1).duration(1200));
        this.consumable("mushroom_stew").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.DRINK).temperatureLevel(1).duration(1200));
        this.consumable("rabbit_stew").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(2).duration(1200));
        this.consumable("suspicious_stew").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(1).duration(1200));
        this.consumable("melon_slice").addTemperature(this.temperatureConsumable(TemporaryModifierGroupEnum.FOOD).temperatureLevel(-1).duration(1200));
        this.biome("crimson_forest").temperature(0.75f).isDry(false);
        this.biome("warped_forest").temperature(0.75f).isDry(false);
        this.biome("nether_wastes").temperature(1.0f).isDry(false);
        this.biome("soul_sand_valley").temperature(1.0f).isDry(false);
        this.biome("basalt_deltas").temperature(1.45f).isDry(false);
        this.biome("frozen_ocean").temperature(-0.5f).isDry(false);
        this.biome("deep_frozen_ocean").temperature(-0.5f).isDry(false);
        this.fuelItem("coal").thermalType(ThermalTypeEnum.HEATING).duration(600);
        this.fuelItem("charcoal").thermalType(ThermalTypeEnum.HEATING).duration(600);
        this.fuelItem("coal_block").thermalType(ThermalTypeEnum.HEATING).duration(2700);
        this.fuelItem("ice").thermalType(ThermalTypeEnum.COOLING).duration(400);
        this.fuelItem("snowball").thermalType(ThermalTypeEnum.COOLING).duration(400);
        this.fuelItem("snow_block").thermalType(ThermalTypeEnum.COOLING).duration(600);
        this.fuelItem("blue_ice").thermalType(ThermalTypeEnum.COOLING).duration(16200);
        this.fuelItem("packed_ice").thermalType(ThermalTypeEnum.COOLING).duration(1800);
    }
}

