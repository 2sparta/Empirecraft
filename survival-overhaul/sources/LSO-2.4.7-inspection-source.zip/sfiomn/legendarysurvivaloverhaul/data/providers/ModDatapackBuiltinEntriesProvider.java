/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.core.RegistrySetBuilder
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.data.PackOutput
 *  net.minecraftforge.common.data.DatapackBuiltinEntriesProvider
 *  net.minecraftforge.registries.ForgeRegistries$Keys
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.RegistrySetBuilder;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.DatapackBuiltinEntriesProvider;
import net.minecraftforge.registries.ForgeRegistries;
import sfiomn.legendarysurvivaloverhaul.api.ModDamageTypes;
import sfiomn.legendarysurvivaloverhaul.common.level.gen.ModBiomeModifiers;
import sfiomn.legendarysurvivaloverhaul.common.level.gen.ModConfiguredFeatures;
import sfiomn.legendarysurvivaloverhaul.common.level.gen.ModPlacedFeatures;

public class ModDatapackBuiltinEntriesProvider
extends DatapackBuiltinEntriesProvider {
    public static final RegistrySetBuilder BUILDER = new RegistrySetBuilder().m_254916_(Registries.f_268580_, ModDamageTypes::bootstrap).m_254916_(Registries.f_256911_, ModConfiguredFeatures::bootstrap).m_254916_(Registries.f_256988_, ModPlacedFeatures::bootstrap).m_254916_(ForgeRegistries.Keys.BIOME_MODIFIERS, ModBiomeModifiers::bootstrap);

    public ModDatapackBuiltinEntriesProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> registries) {
        super(output, registries, BUILDER, Set.of("legendarysurvivaloverhaul"));
    }
}

