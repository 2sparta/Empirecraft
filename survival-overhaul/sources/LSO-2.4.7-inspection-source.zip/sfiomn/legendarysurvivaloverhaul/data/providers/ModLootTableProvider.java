/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.data.PackOutput
 *  net.minecraft.data.loot.LootTableProvider
 *  net.minecraft.data.loot.LootTableProvider$SubProviderEntry
 *  net.minecraft.world.level.storage.loot.parameters.LootContextParamSets
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import java.util.List;
import java.util.Set;
import net.minecraft.data.PackOutput;
import net.minecraft.data.loot.LootTableProvider;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import sfiomn.legendarysurvivaloverhaul.data.loot.ModBarteringLootTables;
import sfiomn.legendarysurvivaloverhaul.data.loot.ModBlockLootTables;
import sfiomn.legendarysurvivaloverhaul.data.loot.ModChestLootTables;
import sfiomn.legendarysurvivaloverhaul.data.loot.ModEntityLootTables;
import sfiomn.legendarysurvivaloverhaul.data.loot.ModFishingLootTables;

public class ModLootTableProvider {
    public static LootTableProvider createLootTables(PackOutput output) {
        return new LootTableProvider(output, Set.of(), List.of(new LootTableProvider.SubProviderEntry(ModBlockLootTables::new, LootContextParamSets.f_81421_), new LootTableProvider.SubProviderEntry(ModChestLootTables::new, LootContextParamSets.f_81411_), new LootTableProvider.SubProviderEntry(ModEntityLootTables::new, LootContextParamSets.f_81415_), new LootTableProvider.SubProviderEntry(ModFishingLootTables::new, LootContextParamSets.f_81414_), new LootTableProvider.SubProviderEntry(ModBarteringLootTables::new, LootContextParamSets.f_81417_)));
    }
}

