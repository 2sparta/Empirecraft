/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.item.Item
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.DamageDistributionEnum;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.BodyDamageDataProvider;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;

public class ModBodyDamageProvider
extends BodyDamageDataProvider {
    public ModBodyDamageProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("legendarysurvivaloverhaul", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable((Item)ItemRegistry.HEALING_HERBS.get()).healingCharges(1).healingValue(2.0f).duration(600).recoveryEffectDuration(600);
        this.consumable((Item)ItemRegistry.PLASTER.get()).healingCharges(1).healingValue(3.0f).duration(400).recoveryEffectDuration(1200);
        this.consumable((Item)ItemRegistry.BANDAGE.get()).healingCharges(3).healingValue(3.0f).duration(300).recoveryEffectDuration(1200).recoveryEffectAmplifier(1);
        this.consumable((Item)ItemRegistry.TONIC.get()).healingCharges(0).healingValue(5.0f).duration(600).recoveryEffectDuration(1400).recoveryEffectAmplifier(1);
        this.consumable((Item)ItemRegistry.MEDKIT.get()).healingCharges(0).healingValue(8.0f).duration(400).recoveryEffectDuration(1400).recoveryEffectAmplifier(2);
        this.damageSource("legendarysurvivaloverhaul.hypothermia").damageDistribution(DamageDistributionEnum.NONE);
        this.damageSource("legendarysurvivaloverhaul.hyperthermia").damageDistribution(DamageDistributionEnum.NONE);
        this.damageSource("legendarysurvivaloverhaul.dehydration").damageDistribution(DamageDistributionEnum.NONE);
    }
}

