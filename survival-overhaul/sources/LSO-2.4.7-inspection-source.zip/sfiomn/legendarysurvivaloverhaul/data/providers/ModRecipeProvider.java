/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  net.minecraft.advancements.CriterionTriggerInstance
 *  net.minecraft.data.PackOutput
 *  net.minecraft.data.recipes.FinishedRecipe
 *  net.minecraft.data.recipes.RecipeCategory
 *  net.minecraft.data.recipes.RecipeProvider
 *  net.minecraft.data.recipes.ShapedRecipeBuilder
 *  net.minecraft.data.recipes.ShapelessRecipeBuilder
 *  net.minecraft.data.recipes.SimpleCookingRecipeBuilder
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.tags.ItemTags
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.item.crafting.Ingredient
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.block.Block
 *  net.minecraftforge.common.Tags$Items
 *  net.minecraftforge.common.crafting.PartialNBTIngredient
 *  net.minecraftforge.common.crafting.conditions.IConditionBuilder
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import com.google.gson.JsonObject;
import java.util.function.Consumer;
import net.minecraft.advancements.CriterionTriggerInstance;
import net.minecraft.data.PackOutput;
import net.minecraft.data.recipes.FinishedRecipe;
import net.minecraft.data.recipes.RecipeCategory;
import net.minecraft.data.recipes.RecipeProvider;
import net.minecraft.data.recipes.ShapedRecipeBuilder;
import net.minecraft.data.recipes.ShapelessRecipeBuilder;
import net.minecraft.data.recipes.SimpleCookingRecipeBuilder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.common.Tags;
import net.minecraftforge.common.crafting.PartialNBTIngredient;
import net.minecraftforge.common.crafting.conditions.IConditionBuilder;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.api.thirst.HydrationEnum;
import sfiomn.legendarysurvivaloverhaul.data.recipes.PurificationRecipeBuilder;
import sfiomn.legendarysurvivaloverhaul.data.recipes.SewingRecipeBuilder;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;

public class ModRecipeProvider
extends RecipeProvider
implements IConditionBuilder {
    public ModRecipeProvider(PackOutput generator) {
        super(generator);
    }

    protected void m_245200_(@NotNull Consumer<FinishedRecipe> consumer) {
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.COMBAT, (ItemLike)((ItemLike)ItemRegistry.DESERT_HELMET.get())).m_126130_("r#r").m_126130_("r r").m_126127_(Character.valueOf('#'), (ItemLike)Items.f_42454_).m_126127_(Character.valueOf('r'), (ItemLike)Items.f_42401_).m_126145_("desert_armor").m_126132_(ModRecipeProvider.m_176602_((ItemLike)Items.f_42454_), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_42454_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.COMBAT, (ItemLike)((ItemLike)ItemRegistry.DESERT_BOOTS.get())).m_126130_("r r").m_126130_("# #").m_126127_(Character.valueOf('#'), (ItemLike)Items.f_42454_).m_126127_(Character.valueOf('r'), (ItemLike)Items.f_42401_).m_126145_("desert_armor").m_126132_(ModRecipeProvider.m_176602_((ItemLike)Items.f_42454_), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_42454_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.COMBAT, (ItemLike)((ItemLike)ItemRegistry.DESERT_CHEST.get())).m_126130_("r r").m_126130_("#r#").m_126130_("###").m_126127_(Character.valueOf('#'), (ItemLike)Items.f_42454_).m_126127_(Character.valueOf('r'), (ItemLike)Items.f_42401_).m_126132_(ModRecipeProvider.m_176602_((ItemLike)Items.f_42454_), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_42454_)).m_126145_("desert_armor").m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.COMBAT, (ItemLike)((ItemLike)ItemRegistry.DESERT_LEGGINGS.get())).m_126130_("###").m_126130_("###").m_126130_("r r").m_126127_(Character.valueOf('#'), (ItemLike)Items.f_42454_).m_126127_(Character.valueOf('r'), (ItemLike)Items.f_42401_).m_126132_(ModRecipeProvider.m_176602_((ItemLike)Items.f_42454_), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_42454_)).m_126145_("desert_armor").m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.COMBAT, (ItemLike)((ItemLike)ItemRegistry.SNOW_HELMET.get())).m_126130_("w#w").m_126130_("w w").m_126127_(Character.valueOf('#'), (ItemLike)Items.f_42454_).m_206416_(Character.valueOf('w'), ItemTags.f_13167_).m_126145_("snow_Armor").m_126132_("has_wool", (CriterionTriggerInstance)ModRecipeProvider.m_206406_((TagKey)ItemTags.f_13167_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.COMBAT, (ItemLike)((ItemLike)ItemRegistry.SNOW_BOOTS.get())).m_126130_("w w").m_126130_("w w").m_206416_(Character.valueOf('w'), ItemTags.f_13167_).m_126145_("snow_Armor").m_126132_("has_wool", (CriterionTriggerInstance)ModRecipeProvider.m_206406_((TagKey)ItemTags.f_13167_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.COMBAT, (ItemLike)((ItemLike)ItemRegistry.SNOW_CHEST.get())).m_126130_("w w").m_126130_("www").m_126130_("w#w").m_126127_(Character.valueOf('#'), (ItemLike)Items.f_42454_).m_206416_(Character.valueOf('w'), ItemTags.f_13167_).m_126145_("snow_Armor").m_126132_("has_wool", (CriterionTriggerInstance)ModRecipeProvider.m_206406_((TagKey)ItemTags.f_13167_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.COMBAT, (ItemLike)((ItemLike)ItemRegistry.SNOW_LEGGINGS.get())).m_126130_("www").m_126130_("w w").m_126130_("w w").m_206416_(Character.valueOf('w'), ItemTags.f_13167_).m_126145_("snow_Armor").m_126132_("has_wool", (CriterionTriggerInstance)ModRecipeProvider.m_206406_((TagKey)ItemTags.f_13167_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.COOLING_COAT_1.get())).m_126130_(" is").m_126130_("isc").m_126130_("scc").m_126127_(Character.valueOf('i'), (ItemLike)Items.f_42416_).m_126127_(Character.valueOf('c'), (ItemLike)ItemRegistry.COLD_STRING.get()).m_126127_(Character.valueOf('s'), (ItemLike)Items.f_42398_).m_126145_("cooling_coat").m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.COLD_STRING.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.COLD_STRING.get()))).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.COOLING_COAT_2.get())).m_126130_(" db").m_126130_("db#").m_126130_("b##").m_126127_(Character.valueOf('d'), (ItemLike)Items.f_42415_).m_126127_(Character.valueOf('b'), (ItemLike)Items.f_42585_).m_126127_(Character.valueOf('#'), (ItemLike)ItemRegistry.COOLING_COAT_1.get()).m_126145_("cooling_coat").m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.COLD_STRING.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.COLD_STRING.get()))).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.COOLING_COAT_3.get())).m_126130_(" ne").m_126130_("ne#").m_126130_("e##").m_126127_(Character.valueOf('n'), (ItemLike)Items.f_42418_).m_126127_(Character.valueOf('e'), (ItemLike)Items.f_42001_).m_126127_(Character.valueOf('#'), (ItemLike)ItemRegistry.COOLING_COAT_2.get()).m_126145_("cooling_coat").m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.COLD_STRING.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.COLD_STRING.get()))).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.HEATING_COAT_1.get())).m_126130_(" is").m_126130_("isw").m_126130_("sww").m_126127_(Character.valueOf('i'), (ItemLike)Items.f_42416_).m_126127_(Character.valueOf('w'), (ItemLike)ItemRegistry.WARM_STRING.get()).m_126127_(Character.valueOf('s'), (ItemLike)Items.f_42398_).m_126145_("heating_coat").m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.WARM_STRING.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.WARM_STRING.get()))).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.HEATING_COAT_2.get())).m_126130_(" db").m_126130_("db#").m_126130_("b##").m_126127_(Character.valueOf('d'), (ItemLike)Items.f_42415_).m_126127_(Character.valueOf('b'), (ItemLike)Items.f_42585_).m_126127_(Character.valueOf('#'), (ItemLike)ItemRegistry.HEATING_COAT_1.get()).m_126145_("heating_coat").m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.WARM_STRING.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.WARM_STRING.get()))).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.HEATING_COAT_3.get())).m_126130_(" ne").m_126130_("ne#").m_126130_("e##").m_126127_(Character.valueOf('n'), (ItemLike)Items.f_42418_).m_126127_(Character.valueOf('e'), (ItemLike)Items.f_42001_).m_126127_(Character.valueOf('#'), (ItemLike)ItemRegistry.HEATING_COAT_2.get()).m_126145_("heating_coat").m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.WARM_STRING.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.WARM_STRING.get()))).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.THERMAL_COAT_1.get())).m_126130_(" cs").m_126130_(" sh").m_126130_("   ").m_126127_(Character.valueOf('c'), (ItemLike)ItemRegistry.COOLING_COAT_1.get()).m_126127_(Character.valueOf('s'), (ItemLike)Items.f_42398_).m_126127_(Character.valueOf('h'), (ItemLike)ItemRegistry.HEATING_COAT_1.get()).m_126145_("thermal_coat").m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.COOLING_COAT_1.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.COOLING_COAT_1.get()))).m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.HEATING_COAT_1.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.HEATING_COAT_1.get()))).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.THERMAL_COAT_2.get())).m_126130_(" cb").m_126130_(" bh").m_126130_("   ").m_126127_(Character.valueOf('c'), (ItemLike)ItemRegistry.COOLING_COAT_2.get()).m_126127_(Character.valueOf('b'), (ItemLike)Items.f_42585_).m_126127_(Character.valueOf('h'), (ItemLike)ItemRegistry.HEATING_COAT_2.get()).m_126145_("thermal_coat").m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.COOLING_COAT_2.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.COOLING_COAT_2.get()))).m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.HEATING_COAT_2.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.HEATING_COAT_2.get()))).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.THERMAL_COAT_3.get())).m_126130_(" ce").m_126130_(" eh").m_126130_("   ").m_126127_(Character.valueOf('c'), (ItemLike)ItemRegistry.COOLING_COAT_3.get()).m_126127_(Character.valueOf('e'), (ItemLike)Items.f_42001_).m_126127_(Character.valueOf('h'), (ItemLike)ItemRegistry.HEATING_COAT_3.get()).m_126145_("thermal_coat").m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.COOLING_COAT_3.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.COOLING_COAT_3.get()))).m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.HEATING_COAT_3.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.HEATING_COAT_3.get()))).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.DECORATIONS, (ItemLike)((ItemLike)BlockRegistry.COOLER.get())).m_126130_("psp").m_126130_("prp").m_126130_("ppp").m_126127_(Character.valueOf('s'), (ItemLike)Items.f_41981_).m_206416_(Character.valueOf('p'), ItemTags.f_13168_).m_126127_(Character.valueOf('r'), (ItemLike)Items.f_42451_).m_126132_(ModRecipeProvider.m_176602_((ItemLike)Items.f_41905_), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_41905_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.DECORATIONS, (ItemLike)((ItemLike)BlockRegistry.HEATER.get())).m_126130_(" i ").m_126130_("ici").m_126130_("iwi").m_126127_(Character.valueOf('i'), (ItemLike)Items.f_42416_).m_126127_(Character.valueOf('c'), (ItemLike)Items.f_42781_).m_126127_(Character.valueOf('w'), (ItemLike)Items.f_42200_).m_126132_(ModRecipeProvider.m_176602_((ItemLike)Items.f_42781_), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_42781_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.TOOLS, (ItemLike)((ItemLike)ItemRegistry.SEASONAL_CALENDAR.get())).m_126130_("ppp").m_126130_("pcp").m_126130_("ppp").m_126127_(Character.valueOf('p'), (ItemLike)Items.f_42516_).m_126127_(Character.valueOf('c'), (ItemLike)Items.f_42524_).m_126132_(ModRecipeProvider.m_176602_((ItemLike)Items.f_42516_), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_42516_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.TOOLS, (ItemLike)((ItemLike)ItemRegistry.THERMOMETER.get())).m_126130_("#g#").m_126130_("#r#").m_126130_("i#i").m_206416_(Character.valueOf('#'), Tags.Items.GLASS).m_126127_(Character.valueOf('g'), (ItemLike)Items.f_42417_).m_126127_(Character.valueOf('i'), (ItemLike)Items.f_42416_).m_126127_(Character.valueOf('r'), (ItemLike)Items.f_42451_).m_126132_("has_glass", (CriterionTriggerInstance)ModRecipeProvider.m_206406_((TagKey)Tags.Items.GLASS)).m_126132_("has_iron", (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_42416_)).m_126132_("has_redstone", (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_42451_)).m_126132_("has_gold_ingot", (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_42417_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.DECORATIONS, (ItemLike)((ItemLike)BlockRegistry.SEWING_TABLE.get())).m_126130_("iii").m_126130_("r i").m_126130_("ppp").m_126127_(Character.valueOf('i'), (ItemLike)Items.f_42416_).m_126127_(Character.valueOf('r'), (ItemLike)Items.f_42451_).m_206416_(Character.valueOf('p'), ItemTags.f_13168_).m_126132_("has_planks", (CriterionTriggerInstance)ModRecipeProvider.m_206406_((TagKey)ItemTags.f_13168_)).m_126132_("has_iron", (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_42416_)).m_126132_("has_redstone", (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_42451_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.FOOD, (ItemLike)((ItemLike)ItemRegistry.HEART_CONTAINER.get())).m_126130_("hhh").m_126130_("hhh").m_126130_("hhh").m_126127_(Character.valueOf('h'), (ItemLike)ItemRegistry.HEART_FRAGMENT.get()).m_126132_("has_heart_fragment", (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.HEART_FRAGMENT.get()))).m_176498_(consumer);
        CompoundTag nbt = new CompoundTag();
        nbt.m_128359_("Potion", "legendarysurvivaloverhaul:temperature_immunity");
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.THERMAL_RESISTANCE_RING.get())).m_126130_(" wh").m_126130_("stw").m_126130_("cs ").m_126127_(Character.valueOf('w'), (ItemLike)ItemRegistry.WARM_STRING.get()).m_126127_(Character.valueOf('s'), (ItemLike)ItemRegistry.COLD_STRING.get()).m_126124_(Character.valueOf('t'), (Ingredient)PartialNBTIngredient.of((CompoundTag)nbt, (ItemLike[])new ItemLike[]{Items.f_42589_})).m_126127_(Character.valueOf('h'), (ItemLike)ItemRegistry.HEAT_RESISTANCE_RING.get()).m_126127_(Character.valueOf('c'), (ItemLike)ItemRegistry.COLD_RESISTANCE_RING.get()).m_126132_("has_heat_resistance_ring", (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.HEAT_RESISTANCE_RING.get()))).m_126132_("has_cold_resistance_ring", (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.COLD_RESISTANCE_RING.get()))).m_176498_(consumer);
        ModRecipeProvider.juice(consumer, (ItemLike)Items.f_42410_, (Item)ItemRegistry.APPLE_JUICE.get());
        ModRecipeProvider.juice(consumer, (ItemLike)Items.f_42732_, (Item)ItemRegistry.BEETROOT_JUICE.get());
        ModRecipeProvider.juice(consumer, (ItemLike)Items.f_41982_, (Item)ItemRegistry.CACTUS_JUICE.get());
        ModRecipeProvider.juice(consumer, (ItemLike)Items.f_42619_, (Item)ItemRegistry.CARROT_JUICE.get());
        ModRecipeProvider.juice(consumer, (ItemLike)Items.f_42730_, (Item)ItemRegistry.CHORUS_FRUIT_JUICE.get());
        ModRecipeProvider.juice(consumer, (ItemLike)Items.f_42546_, (Item)ItemRegistry.GLISTERING_MELON_JUICE.get());
        ModRecipeProvider.juice(consumer, (ItemLike)Items.f_42436_, (Item)ItemRegistry.GOLDEN_APPLE_JUICE.get());
        ModRecipeProvider.juice(consumer, (ItemLike)Items.f_42677_, (Item)ItemRegistry.GOLDEN_CARROT_JUICE.get());
        ModRecipeProvider.juice(consumer, (ItemLike)Items.f_42575_, (Item)ItemRegistry.MELON_JUICE.get());
        ModRecipeProvider.juice(consumer, (ItemLike)Items.f_42046_, (Item)ItemRegistry.PUMPKIN_JUICE.get());
        ModRecipeProvider.juice(consumer, (ItemLike)Items.f_42780_, (Item)ItemRegistry.SWEET_BERRIES_JUICE.get());
        ModRecipeProvider.juice(consumer, (ItemLike)Items.f_151079_, (Item)ItemRegistry.GLOW_BERRIES_JUICE.get());
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.CANTEEN.get())).m_126130_(" i ").m_126130_("l l").m_126130_("lll").m_126127_(Character.valueOf('i'), (ItemLike)Items.f_42416_).m_126127_(Character.valueOf('l'), (ItemLike)Items.f_42454_).m_126145_("drink").m_126132_(ModRecipeProvider.m_176602_((ItemLike)Items.f_42454_), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_42454_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.LARGE_CANTEEN.get())).m_126130_(" n ").m_126130_("l l").m_126130_("lll").m_126127_(Character.valueOf('n'), (ItemLike)Items.f_42419_).m_126127_(Character.valueOf('l'), (ItemLike)Items.f_42454_).m_126145_("healing").m_126132_(ModRecipeProvider.m_176602_((ItemLike)Items.f_42454_), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)Items.f_42454_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.FOOD, (ItemLike)((ItemLike)ItemRegistry.HEALING_HERBS.get())).m_126130_("ff ").m_126130_("ss ").m_126130_("   ").m_206416_(Character.valueOf('f'), ItemTags.f_13149_).m_206416_(Character.valueOf('s'), Tags.Items.SEEDS).m_126145_("healing").m_126132_("has_flower", (CriterionTriggerInstance)ModRecipeProvider.m_206406_((TagKey)ItemTags.f_13149_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.PLASTER.get())).m_126130_("ss ").m_126130_("ww ").m_126130_("   ").m_126127_(Character.valueOf('s'), (ItemLike)Items.f_42401_).m_206416_(Character.valueOf('w'), ItemTags.f_13167_).m_126145_("healing").m_126132_("has_wool", (CriterionTriggerInstance)ModRecipeProvider.m_206406_((TagKey)ItemTags.f_13167_)).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.MEDKIT.get())).m_126130_("sis").m_126130_("gbg").m_126130_("www").m_126127_(Character.valueOf('s'), (ItemLike)Items.f_42401_).m_126127_(Character.valueOf('i'), (ItemLike)Items.f_42416_).m_126127_(Character.valueOf('g'), (ItemLike)Items.f_42417_).m_126127_(Character.valueOf('b'), (ItemLike)ItemRegistry.BANDAGE.get()).m_206416_(Character.valueOf('w'), ItemTags.f_13167_).m_126145_("healing").m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.BANDAGE.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.BANDAGE.get()))).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.MORPHINE.get())).m_126130_("  n").m_126130_(" t ").m_126130_("g  ").m_126127_(Character.valueOf('n'), (ItemLike)Items.f_42749_).m_126127_(Character.valueOf('t'), (ItemLike)ItemRegistry.TONIC.get()).m_206416_(Character.valueOf('g'), Tags.Items.GLASS).m_126145_("healing").m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.PLASTER.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.PLASTER.get()))).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.BANDAGE.get())).m_126130_("  p").m_126130_(" h ").m_126130_("p  ").m_126127_(Character.valueOf('p'), (ItemLike)ItemRegistry.PLASTER.get()).m_126127_(Character.valueOf('h'), (ItemLike)ItemRegistry.HEALING_HERBS.get()).m_126145_("healing").m_126132_("has_plaster", (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.PLASTER.get()))).m_176498_(consumer);
        ShapedRecipeBuilder.m_245327_((RecipeCategory)RecipeCategory.MISC, (ItemLike)((ItemLike)ItemRegistry.TONIC.get())).m_126130_(" h ").m_126130_("gbg").m_126130_(" g ").m_126127_(Character.valueOf('h'), (ItemLike)ItemRegistry.HEALING_HERBS.get()).m_126127_(Character.valueOf('b'), (ItemLike)Items.f_42590_).m_126127_(Character.valueOf('g'), (ItemLike)Items.f_42417_).m_126145_("healing").m_126132_(ModRecipeProvider.m_176602_((ItemLike)((ItemLike)ItemRegistry.HEALING_HERBS.get())), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)((ItemLike)ItemRegistry.HEALING_HERBS.get()))).m_176498_(consumer);
        nbt = new CompoundTag();
        nbt.m_128359_("Potion", "minecraft:water");
        ModRecipeProvider.smelting(consumer, (Ingredient)PartialNBTIngredient.of((CompoundTag)nbt, (ItemLike[])new ItemLike[]{Items.f_42589_}), (ItemLike)ItemRegistry.PURIFIED_WATER_BOTTLE.get(), 1.0f, 200, "purified_water_bottle");
        ModRecipeProvider.blasting(consumer, (Ingredient)PartialNBTIngredient.of((CompoundTag)nbt, (ItemLike[])new ItemLike[]{Items.f_42589_}), (ItemLike)ItemRegistry.PURIFIED_WATER_BOTTLE.get(), 1.0f, 60, "purified_water_bottle");
        nbt = new CompoundTag();
        nbt.m_128359_("legendarysurvivaloverhaul:HydrationPurity", HydrationEnum.NORMAL.getName());
        ModRecipeProvider.purification_smelting(consumer, (Ingredient)PartialNBTIngredient.of((CompoundTag)nbt, (ItemLike[])new ItemLike[]{(ItemLike)ItemRegistry.CANTEEN.get()}), (ItemLike)ItemRegistry.CANTEEN.get(), 1.0f, 240, "purified_canteen");
        ModRecipeProvider.purification_smelting(consumer, (Ingredient)PartialNBTIngredient.of((CompoundTag)nbt, (ItemLike[])new ItemLike[]{(ItemLike)ItemRegistry.LARGE_CANTEEN.get()}), (ItemLike)ItemRegistry.LARGE_CANTEEN.get(), 1.0f, 240, "purified_large_canteen");
        ModRecipeProvider.purification_blasting(consumer, (Ingredient)PartialNBTIngredient.of((CompoundTag)nbt, (ItemLike[])new ItemLike[]{(ItemLike)ItemRegistry.CANTEEN.get()}), (ItemLike)ItemRegistry.CANTEEN.get(), 1.0f, 80, "purified_canteen");
        ModRecipeProvider.purification_blasting(consumer, (Ingredient)PartialNBTIngredient.of((CompoundTag)nbt, (ItemLike[])new ItemLike[]{(ItemLike)ItemRegistry.LARGE_CANTEEN.get()}), (ItemLike)ItemRegistry.LARGE_CANTEEN.get(), 1.0f, 80, "purified_large_canteen");
        ModRecipeProvider.sewing(consumer, Ingredient.m_43929_((ItemLike[])new ItemLike[]{Items.f_42401_}), Ingredient.m_43929_((ItemLike[])new ItemLike[]{(ItemLike)ItemRegistry.ICE_FERN.get()}), new ItemStack((ItemLike)ItemRegistry.COLD_STRING.get()), "cold_string");
        ModRecipeProvider.sewing(consumer, Ingredient.m_43929_((ItemLike[])new ItemLike[]{Items.f_42401_}), Ingredient.m_43929_((ItemLike[])new ItemLike[]{(ItemLike)ItemRegistry.SUN_FERN.get()}), new ItemStack((ItemLike)ItemRegistry.WARM_STRING.get()), "warm_string");
    }

    protected static void smelting(@NotNull Consumer<FinishedRecipe> consumer, Ingredient input, ItemLike result, float experience, int cookingTime, String recipeName) {
        SimpleCookingRecipeBuilder.m_246179_((Ingredient)input, (RecipeCategory)RecipeCategory.MISC, (ItemLike)result, (float)experience, (int)cookingTime).m_126132_(ModRecipeProvider.m_176602_((ItemLike)input.m_43908_()[0].m_41720_()), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)input.m_43908_()[0].m_41720_())).m_176500_(consumer, "legendarysurvivaloverhaul:" + recipeName + "_from_smelting_" + ModRecipeProvider.m_176632_((ItemLike)input.m_43908_()[0].m_41720_()));
    }

    protected static void purification_smelting(@NotNull Consumer<FinishedRecipe> consumer, Ingredient input, ItemLike result, float experience, int cookingTime, String recipeName) {
        PurificationRecipeBuilder.smelting(input, RecipeCategory.MISC, result, experience, cookingTime).unlockedBy(ModRecipeProvider.m_176602_((ItemLike)input.m_43908_()[0].m_41720_()), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)input.m_43908_()[0].m_41720_())).group("purification").save(consumer, "legendarysurvivaloverhaul:" + recipeName + "_from_purification_smelting_" + ModRecipeProvider.m_176632_((ItemLike)input.m_43908_()[0].m_41720_()));
    }

    protected static void blasting(@NotNull Consumer<FinishedRecipe> consumer, Ingredient input, ItemLike result, float experience, int cookingTime, String recipeName) {
        SimpleCookingRecipeBuilder.m_245681_((Ingredient)input, (RecipeCategory)RecipeCategory.MISC, (ItemLike)result, (float)experience, (int)cookingTime).m_126132_(ModRecipeProvider.m_176602_((ItemLike)input.m_43908_()[0].m_41720_()), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)input.m_43908_()[0].m_41720_())).m_176500_(consumer, "legendarysurvivaloverhaul:" + recipeName + "_from_blasting_" + ModRecipeProvider.m_176632_((ItemLike)input.m_43908_()[0].m_41720_()));
    }

    protected static void purification_blasting(@NotNull Consumer<FinishedRecipe> consumer, Ingredient input, ItemLike result, float experience, int cookingTime, String recipeName) {
        PurificationRecipeBuilder.blasting(input, RecipeCategory.MISC, result, experience, cookingTime).unlockedBy(ModRecipeProvider.m_176602_((ItemLike)input.m_43908_()[0].m_41720_()), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)input.m_43908_()[0].m_41720_())).group("purification").save(consumer, "legendarysurvivaloverhaul:" + recipeName + "_from_purification_blasting_" + ModRecipeProvider.m_176632_((ItemLike)input.m_43908_()[0].m_41720_()));
    }

    protected static void sewing(@NotNull Consumer<FinishedRecipe> consumer, Ingredient input, Ingredient addition, ItemStack result, String recipeName) {
        String nbt;
        String additionName = "";
        if (addition instanceof PartialNBTIngredient && (nbt = ((JsonObject)addition.m_43942_()).get("nbt").getAsString()).contains("Potion")) {
            additionName = nbt.split("Potion:")[1].split(":")[1];
            additionName = additionName.substring(0, additionName.length() - 2);
        }
        if (additionName.isEmpty()) {
            additionName = ModRecipeProvider.m_176632_((ItemLike)addition.m_43908_()[0].m_41720_());
        }
        SewingRecipeBuilder.sewingRecipe(input, addition, result, RecipeCategory.MISC).unlockedBy("has_coat", (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)addition.m_43908_()[0].m_41720_())).unlockedBy(ModRecipeProvider.m_176602_((ItemLike)((Block)BlockRegistry.SEWING_TABLE.get()).m_5456_()), (CriterionTriggerInstance)ModRecipeProvider.m_125979_((Block)((Block)BlockRegistry.SEWING_TABLE.get()))).save(consumer, "legendarysurvivaloverhaul:" + recipeName + "_from_sewing_" + ModRecipeProvider.m_176632_((ItemLike)input.m_43908_()[0].m_41720_()) + "_" + additionName);
    }

    protected static void juice(@NotNull Consumer<FinishedRecipe> consumer, ItemLike fruit, Item juice) {
        ShapelessRecipeBuilder.m_245498_((RecipeCategory)RecipeCategory.FOOD, (ItemLike)juice).m_126209_((ItemLike)ItemRegistry.PURIFIED_WATER_BOTTLE.get()).m_126209_((ItemLike)Items.f_42501_).m_126209_(fruit).m_126209_(fruit).m_126209_(fruit).m_126145_("drink").m_126132_(ModRecipeProvider.m_176602_((ItemLike)fruit), (CriterionTriggerInstance)ModRecipeProvider.m_125977_((ItemLike)fruit)).m_176498_(consumer);
    }
}

