/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.world.item.Items
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.world.item.Items;
import net.minecraftforge.common.data.ExistingFileHelper;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyPartEnum;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.DamageDistributionEnum;
import sfiomn.legendarysurvivaloverhaul.api.data.providers.BodyDamageDataProvider;

public class MinecraftBodyDamageProvider
extends BodyDamageDataProvider {
    public MinecraftBodyDamageProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper fileHelper) {
        super("minecraft", output, lookupProvider, fileHelper);
    }

    @Override
    public void generate(HolderLookup.Provider provider, ExistingFileHelper existingFileHelper) {
        this.consumable(Items.f_42437_).healingCharges(0).healingValue(3.0f).duration(600);
        this.item(Items.f_42472_).headResistance(0.1f);
        this.item(Items.f_42473_).chestResistance(0.1f);
        this.item(Items.f_42474_).legsResistance(0.1f);
        this.item(Items.f_42475_).feetResistance(0.1f);
        this.damageSource("fall").damageDistribution(DamageDistributionEnum.ALL).addBodyParts(Arrays.asList(BodyPartEnum.LEFT_FOOT, BodyPartEnum.RIGHT_FOOT));
        this.damageSource("hotFloor").damageDistribution(DamageDistributionEnum.ALL).addBodyParts(Arrays.asList(BodyPartEnum.LEFT_FOOT, BodyPartEnum.RIGHT_FOOT));
        this.damageSource("fallingBlock").damageDistribution(DamageDistributionEnum.ALL).addBodyPart(BodyPartEnum.HEAD);
        this.damageSource("flyIntoWall").damageDistribution(DamageDistributionEnum.ALL).addBodyPart(BodyPartEnum.HEAD);
        this.damageSource("anvil").damageDistribution(DamageDistributionEnum.ALL).addBodyPart(BodyPartEnum.HEAD);
        this.damageSource("lightningBolt").damageDistribution(DamageDistributionEnum.ALL).addBodyParts(Arrays.asList(BodyPartEnum.values()));
        this.damageSource("onFire").damageDistribution(DamageDistributionEnum.ALL).addBodyParts(Arrays.asList(BodyPartEnum.values()));
        this.damageSource("explosion").damageDistribution(DamageDistributionEnum.ALL).addBodyParts(Arrays.asList(BodyPartEnum.values()));
        this.damageSource("bad_respawn_point").damageDistribution(DamageDistributionEnum.ALL).addBodyParts(Arrays.asList(BodyPartEnum.values()));
        this.damageSource("dragonBreath").damageDistribution(DamageDistributionEnum.ALL).addBodyParts(Arrays.asList(BodyPartEnum.values()));
        this.damageSource("inFire").damageDistribution(DamageDistributionEnum.ALL).addBodyParts(Arrays.asList(BodyPartEnum.LEFT_FOOT, BodyPartEnum.RIGHT_FOOT, BodyPartEnum.LEFT_LEG, BodyPartEnum.RIGHT_LEG));
        this.damageSource("cactus").damageDistribution(DamageDistributionEnum.ONE_OF).addBodyParts(Arrays.asList(BodyPartEnum.LEFT_FOOT, BodyPartEnum.RIGHT_FOOT, BodyPartEnum.LEFT_LEG, BodyPartEnum.RIGHT_LEG));
        this.damageSource("sweetBerryBush").damageDistribution(DamageDistributionEnum.ONE_OF).addBodyParts(Arrays.asList(BodyPartEnum.LEFT_FOOT, BodyPartEnum.RIGHT_FOOT, BodyPartEnum.LEFT_LEG, BodyPartEnum.RIGHT_LEG));
        this.damageSource("in_wall").damageDistribution(DamageDistributionEnum.NONE);
        this.damageSource("drown").damageDistribution(DamageDistributionEnum.NONE);
        this.damageSource("starve").damageDistribution(DamageDistributionEnum.NONE);
        this.damageSource("magic").damageDistribution(DamageDistributionEnum.NONE);
        this.damageSource("wither").damageDistribution(DamageDistributionEnum.NONE);
        this.damageSource("indirectMagic").damageDistribution(DamageDistributionEnum.NONE);
    }
}

