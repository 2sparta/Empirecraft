/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.advancements.Advancement
 *  net.minecraft.advancements.Advancement$Builder
 *  net.minecraft.advancements.CriterionTriggerInstance
 *  net.minecraft.advancements.FrameType
 *  net.minecraft.advancements.critereon.InventoryChangeTrigger$TriggerInstance
 *  net.minecraft.advancements.critereon.ItemPredicate
 *  net.minecraft.advancements.critereon.ItemPredicate$Builder
 *  net.minecraft.advancements.critereon.PlayerTrigger$TriggerInstance
 *  net.minecraft.advancements.critereon.RecipeCraftedTrigger$TriggerInstance
 *  net.minecraft.core.HolderLookup$Provider
 *  net.minecraft.data.PackOutput
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.network.chat.Component
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.level.ItemLike
 *  net.minecraftforge.common.Tags$Items
 *  net.minecraftforge.common.data.ExistingFileHelper
 *  net.minecraftforge.common.data.ForgeAdvancementProvider
 *  net.minecraftforge.common.data.ForgeAdvancementProvider$AdvancementGenerator
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.data.providers;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.CriterionTriggerInstance;
import net.minecraft.advancements.FrameType;
import net.minecraft.advancements.critereon.InventoryChangeTrigger;
import net.minecraft.advancements.critereon.ItemPredicate;
import net.minecraft.advancements.critereon.PlayerTrigger;
import net.minecraft.advancements.critereon.RecipeCraftedTrigger;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.common.Tags;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.common.data.ForgeAdvancementProvider;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.api.item.CoatEnum;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.RecipeRegistry;

public class ModAdvancementProvider
extends ForgeAdvancementProvider {
    public static String SEW_A_COAT_ADVANCEMENT = "legendarysurvivaloverhaul:main/sew_a_coat";

    public ModAdvancementProvider(PackOutput packOutput, CompletableFuture<HolderLookup.Provider> lookupProvider, ExistingFileHelper existingFileHelper) {
        super(packOutput, lookupProvider, existingFileHelper, List.of(new LegendarySurvivalAdvancements()));
    }

    private static class LegendarySurvivalAdvancements
    implements ForgeAdvancementProvider.AdvancementGenerator {
        private LegendarySurvivalAdvancements() {
        }

        public void generate(// Could not load outer class - annotation placement on inner may be incorrect
         @NotNull HolderLookup.Provider registries, @NotNull Consumer<Advancement> consumer, @NotNull ExistingFileHelper existingFileHelper) {
            Advancement root = Advancement.Builder.m_138353_().m_138371_((ItemLike)ItemRegistry.THERMOMETER.get(), (Component)Component.m_237115_((String)"advancement.legendarysurvivaloverhaul"), (Component)Component.m_237115_((String)"advancement.legendarysurvivaloverhaul.description"), new ResourceLocation("textures/block/ice.png"), FrameType.TASK, false, false, false).m_138386_("main", (CriterionTriggerInstance)PlayerTrigger.TriggerInstance.m_272050_()).m_138389_(consumer, "legendarysurvivaloverhaul:main/root");
            Advancement get_a_thermometer = Advancement.Builder.m_138353_().m_138371_((ItemLike)ItemRegistry.THERMOMETER.get(), (Component)Component.m_237115_((String)"advancement.legendarysurvivaloverhaul.get_a_thermometer"), (Component)Component.m_237115_((String)"advancement.legendarysurvivaloverhaul.get_a_thermometer.description"), null, FrameType.TASK, true, true, false).m_138398_(root).m_138386_("inventory_changed", (CriterionTriggerInstance)InventoryChangeTrigger.TriggerInstance.m_43199_((ItemLike[])new ItemLike[]{(ItemLike)ItemRegistry.THERMOMETER.get()})).m_138389_(consumer, "legendarysurvivaloverhaul:main/get_a_thermometer");
            Advancement get_a_calendar = Advancement.Builder.m_138353_().m_138371_((ItemLike)ItemRegistry.SEASONAL_CALENDAR.get(), (Component)Component.m_237115_((String)"advancement.legendarysurvivaloverhaul.get_a_calendar"), (Component)Component.m_237115_((String)"advancement.legendarysurvivaloverhaul.get_a_calendar.description"), null, FrameType.TASK, true, true, false).m_138398_(root).m_138386_("inventory_changed", (CriterionTriggerInstance)InventoryChangeTrigger.TriggerInstance.m_43199_((ItemLike[])new ItemLike[]{(ItemLike)ItemRegistry.SEASONAL_CALENDAR.get()})).m_138389_(consumer, "legendarysurvivaloverhaul:main/get_a_calendar");
            Advancement use_a_sewing_table = Advancement.Builder.m_138353_().m_138371_((ItemLike)BlockRegistry.SEWING_TABLE.get(), (Component)Component.m_237115_((String)"advancement.legendarysurvivaloverhaul.get_a_sewing_table"), (Component)Component.m_237115_((String)"advancement.legendarysurvivaloverhaul.get_a_sewing_table.description"), null, FrameType.TASK, true, true, false).m_138398_(root).m_138386_("inventory_changed", (CriterionTriggerInstance)InventoryChangeTrigger.TriggerInstance.m_43199_((ItemLike[])new ItemLike[]{(ItemLike)BlockRegistry.SEWING_TABLE.get()})).m_138389_(consumer, "legendarysurvivaloverhaul:main/get_a_sewing_table");
            ArrayList<ItemPredicate> itemPredicates = new ArrayList<ItemPredicate>();
            for (CoatEnum coatEnum : CoatEnum.values()) {
                CompoundTag coatTag = new CompoundTag();
                coatTag.m_128359_("Coat", coatEnum.id());
                itemPredicates.add(ItemPredicate.Builder.m_45068_().m_204145_(Tags.Items.ARMORS).m_45075_(coatTag).m_45077_());
            }
            Advancement sew_a_coat = Advancement.Builder.m_138353_().m_138371_((ItemLike)ItemRegistry.COOLING_COAT_1.get(), (Component)Component.m_237115_((String)"advancement.legendarysurvivaloverhaul.sew_a_coat"), (Component)Component.m_237115_((String)"advancement.legendarysurvivaloverhaul.sew_a_coat.description"), null, FrameType.TASK, true, true, false).m_138398_(use_a_sewing_table).m_138386_("recipe_crafted", (CriterionTriggerInstance)RecipeCraftedTrigger.TriggerInstance.m_280477_((ResourceLocation)RecipeRegistry.SEWING_RECIPE.getId(), itemPredicates)).m_138389_(consumer, SEW_A_COAT_ADVANCEMENT);
        }
    }
}

