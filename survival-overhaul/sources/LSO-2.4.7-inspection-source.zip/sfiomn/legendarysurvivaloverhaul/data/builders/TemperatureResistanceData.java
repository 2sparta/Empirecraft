/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.data.builders;

import com.google.gson.JsonObject;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureResistanceData;

public class TemperatureResistanceData
implements ITemperatureResistanceData {
    private float temperature;
    private float heatResistance;
    private float coldResistance;
    private float thermalResistance;

    @Override
    public ITemperatureResistanceData temperature(float temperatureValue) {
        this.temperature = temperatureValue;
        return this;
    }

    @Override
    public ITemperatureResistanceData heatResistance(float heatResistanceValue) {
        this.heatResistance = heatResistanceValue;
        return this;
    }

    @Override
    public ITemperatureResistanceData coldResistance(float coldResistanceValue) {
        this.coldResistance = coldResistanceValue;
        return this;
    }

    @Override
    public ITemperatureResistanceData thermalResistance(float thermalResistanceValue) {
        this.thermalResistance = thermalResistanceValue;
        return this;
    }

    @Override
    public JsonObject build() {
        JsonObject json = new JsonObject();
        json.addProperty("temperature", (Number)Float.valueOf(this.temperature));
        json.addProperty("heat_resistance", (Number)Float.valueOf(this.heatResistance));
        json.addProperty("cold_resistance", (Number)Float.valueOf(this.coldResistance));
        json.addProperty("thermal_resistance", (Number)Float.valueOf(this.thermalResistance));
        return json;
    }
}

