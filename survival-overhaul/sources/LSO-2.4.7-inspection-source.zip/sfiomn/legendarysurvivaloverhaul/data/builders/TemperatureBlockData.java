/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.data.builders;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.HashMap;
import java.util.Map;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureBlockData;

public class TemperatureBlockData
implements ITemperatureBlockData {
    private float temperature;
    private final Map<String, String> properties;

    public TemperatureBlockData() {
        this.properties = new HashMap<String, String>();
    }

    public TemperatureBlockData(TemperatureBlockData copy) {
        this.temperature = copy.temperature;
        this.properties = Map.copyOf(copy.properties);
    }

    @Override
    public ITemperatureBlockData temperature(float temperatureValue) {
        this.temperature = temperatureValue;
        return this;
    }

    @Override
    public ITemperatureBlockData addProperty(String propertyName, String propertyValue) {
        this.properties.put(propertyName, propertyValue);
        return this;
    }

    @Override
    public ITemperatureBlockData copy() {
        return new TemperatureBlockData(this);
    }

    @Override
    public JsonObject build() {
        JsonObject json = new JsonObject();
        json.addProperty("temperature", (Number)Float.valueOf(this.temperature));
        JsonObject jsonProperties = new JsonObject();
        this.properties.forEach((arg_0, arg_1) -> ((JsonObject)jsonProperties).addProperty(arg_0, arg_1));
        json.add("properties", (JsonElement)jsonProperties);
        return json;
    }
}

