/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 */
package sfiomn.legendarysurvivaloverhaul.data.builders;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.List;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstData;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IThirstDataHolder;

public class ThirstDataHolder
implements IThirstDataHolder {
    private final List<IThirstData> thirstDataList = new ArrayList<IThirstData>();

    @Override
    public IThirstDataHolder addThirst(IThirstData thirstData) {
        this.thirstDataList.add(thirstData.copy());
        return this;
    }

    @Override
    public JsonArray build() {
        JsonArray json = new JsonArray();
        this.thirstDataList.forEach(t -> json.add((JsonElement)t.build()));
        return json;
    }
}

