/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 */
package sfiomn.legendarysurvivaloverhaul.data.builders;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.List;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableBlockData;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableBlockDataHolder;

public class TemperatureConsumableBlockDataHolder
implements ITemperatureConsumableBlockDataHolder {
    private final List<ITemperatureConsumableBlockData> temperatureDataList = new ArrayList<ITemperatureConsumableBlockData>();

    @Override
    public ITemperatureConsumableBlockDataHolder addTemperature(ITemperatureConsumableBlockData temperatureData) {
        this.temperatureDataList.add(temperatureData.copy());
        return this;
    }

    @Override
    public JsonArray build() {
        JsonArray json = new JsonArray();
        this.temperatureDataList.forEach(t -> json.add((JsonElement)t.build()));
        return json;
    }
}

