/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.data.builders;

import com.google.gson.JsonObject;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureData;

public class TemperatureData
implements ITemperatureData {
    private float temperature;

    @Override
    public ITemperatureData temperature(float temperatureValue) {
        this.temperature = temperatureValue;
        return this;
    }

    @Override
    public JsonObject build() {
        JsonObject json = new JsonObject();
        json.addProperty("temperature", (Number)Float.valueOf(this.temperature));
        return json;
    }
}

