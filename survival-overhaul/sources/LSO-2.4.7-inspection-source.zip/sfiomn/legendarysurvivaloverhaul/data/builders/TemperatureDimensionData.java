/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.data.builders;

import com.google.gson.JsonObject;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureDimensionData;

public class TemperatureDimensionData
implements ITemperatureDimensionData {
    private float temperature;
    private int seaLevelHeight;
    private boolean hasAltitude;
    private int temperatureTimeCycleTicks;

    @Override
    public ITemperatureDimensionData temperature(float temperatureValue) {
        this.temperature = temperatureValue;
        return this;
    }

    @Override
    public ITemperatureDimensionData seaLevelHeight(int seaLevelHeightValue) {
        this.seaLevelHeight = seaLevelHeightValue;
        return this;
    }

    @Override
    public ITemperatureDimensionData hasAltitude() {
        this.hasAltitude = true;
        return this;
    }

    @Override
    public ITemperatureDimensionData temperatureTimeCycleTicks(int cycleDurationTicks) {
        this.temperatureTimeCycleTicks = cycleDurationTicks;
        return this;
    }

    @Override
    public JsonObject build() {
        JsonObject json = new JsonObject();
        json.addProperty("temperature", (Number)Float.valueOf(this.temperature));
        json.addProperty("sea_level_height", (Number)this.seaLevelHeight);
        json.addProperty("has_altitude", Boolean.valueOf(this.hasAltitude));
        json.addProperty("temperatureTimeCycleTicks", (Number)this.temperatureTimeCycleTicks);
        return json;
    }
}

