/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.data.builders;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.HashMap;
import java.util.Map;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableBlockData;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemporaryModifierGroupEnum;

public class TemperatureConsumableBlockData
implements ITemperatureConsumableBlockData {
    private TemporaryModifierGroupEnum group;
    private int temperatureLevel;
    private int durationInTick;
    private final Map<String, String> properties;

    public TemperatureConsumableBlockData() {
        this.properties = new HashMap<String, String>();
    }

    public TemperatureConsumableBlockData(TemperatureConsumableBlockData copy) {
        this.group = copy.group;
        this.temperatureLevel = copy.temperatureLevel;
        this.durationInTick = copy.durationInTick;
        this.properties = Map.copyOf(copy.properties);
    }

    @Override
    public ITemperatureConsumableBlockData group(TemporaryModifierGroupEnum group) {
        this.group = group;
        return this;
    }

    @Override
    public ITemperatureConsumableBlockData temperatureLevel(int temperatureLevel) {
        this.temperatureLevel = temperatureLevel;
        return this;
    }

    @Override
    public ITemperatureConsumableBlockData duration(int durationInTick) {
        this.durationInTick = durationInTick;
        return this;
    }

    @Override
    public ITemperatureConsumableBlockData addProperty(String propertyName, String propertyValue) {
        this.properties.put(propertyName, propertyValue);
        return this;
    }

    @Override
    public ITemperatureConsumableBlockData copy() {
        return new TemperatureConsumableBlockData(this);
    }

    @Override
    public JsonObject build() {
        JsonObject json = new JsonObject();
        json.addProperty("group", this.group.name());
        json.addProperty("temperature_level", (Number)this.temperatureLevel);
        json.addProperty("duration", (Number)this.durationInTick);
        JsonObject jsonProperties = new JsonObject();
        this.properties.forEach((arg_0, arg_1) -> ((JsonObject)jsonProperties).addProperty(arg_0, arg_1));
        json.add("properties", (JsonElement)jsonProperties);
        return json;
    }
}

