/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 */
package sfiomn.legendarysurvivaloverhaul.data.builders;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.List;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableData;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureConsumableDataHolder;

public class TemperatureConsumableDataHolder
implements ITemperatureConsumableDataHolder {
    private final List<ITemperatureConsumableData> temperatureDataList = new ArrayList<ITemperatureConsumableData>();

    @Override
    public ITemperatureConsumableDataHolder addTemperature(ITemperatureConsumableData temperatureData) {
        this.temperatureDataList.add(temperatureData.copy());
        return this;
    }

    @Override
    public JsonArray build() {
        JsonArray json = new JsonArray();
        this.temperatureDataList.forEach(t -> json.add((JsonElement)t.build()));
        return json;
    }
}

