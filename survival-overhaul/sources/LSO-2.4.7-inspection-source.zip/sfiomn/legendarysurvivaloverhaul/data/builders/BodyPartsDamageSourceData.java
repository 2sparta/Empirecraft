/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.data.builders;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyPartEnum;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.DamageDistributionEnum;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IBodyPartsDamageSourceData;

public class BodyPartsDamageSourceData
implements IBodyPartsDamageSourceData {
    private DamageDistributionEnum damageDistribution;
    private final List<BodyPartEnum> bodyParts = new ArrayList<BodyPartEnum>();

    @Override
    public IBodyPartsDamageSourceData damageDistribution(DamageDistributionEnum damageDistribution) {
        this.damageDistribution = damageDistribution;
        return this;
    }

    @Override
    public IBodyPartsDamageSourceData addBodyPart(BodyPartEnum bodyPart) {
        this.bodyParts.add(bodyPart);
        return this;
    }

    @Override
    public IBodyPartsDamageSourceData addBodyParts(List<BodyPartEnum> bodyParts) {
        this.bodyParts.addAll(bodyParts);
        return this;
    }

    @Override
    public JsonObject build() {
        JsonObject json = new JsonObject();
        json.addProperty("damage_distribution", this.damageDistribution.name());
        JsonArray jsonBodyParts = new JsonArray();
        this.bodyParts.forEach(b -> jsonBodyParts.add(b.name()));
        json.add("body_parts", (JsonElement)jsonBodyParts);
        return json;
    }
}

