/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package sfiomn.legendarysurvivaloverhaul.data.builders;

import com.google.gson.JsonObject;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.IBodyPartResistanceData;

public class BodyPartResistanceData
implements IBodyPartResistanceData {
    private float bodyResistance;
    private float headResistance;
    private float chestResistance;
    private float rightArmResistance;
    private float leftArmResistance;
    private float legsResistance;
    private float feetResistance;

    @Override
    public IBodyPartResistanceData bodyResistance(float resistanceValue) {
        this.bodyResistance = resistanceValue;
        return this;
    }

    @Override
    public IBodyPartResistanceData headResistance(float resistanceValue) {
        this.headResistance = resistanceValue;
        return this;
    }

    @Override
    public IBodyPartResistanceData chestResistance(float resistanceValue) {
        this.chestResistance = resistanceValue;
        return this;
    }

    @Override
    public IBodyPartResistanceData rightArmResistance(float resistanceValue) {
        this.rightArmResistance = resistanceValue;
        return this;
    }

    @Override
    public IBodyPartResistanceData leftArmResistance(float resistanceValue) {
        this.leftArmResistance = resistanceValue;
        return this;
    }

    @Override
    public IBodyPartResistanceData legsResistance(float resistanceValue) {
        this.legsResistance = resistanceValue;
        return this;
    }

    @Override
    public IBodyPartResistanceData feetResistance(float resistanceValue) {
        this.feetResistance = resistanceValue;
        return this;
    }

    @Override
    public JsonObject build() {
        JsonObject json = new JsonObject();
        json.addProperty("body_resistance", (Number)Float.valueOf(this.bodyResistance));
        json.addProperty("head_resistance", (Number)Float.valueOf(this.headResistance));
        json.addProperty("chest_resistance", (Number)Float.valueOf(this.chestResistance));
        json.addProperty("right_arm_resistance", (Number)Float.valueOf(this.rightArmResistance));
        json.addProperty("left_arm_resistance", (Number)Float.valueOf(this.leftArmResistance));
        json.addProperty("legs_resistance", (Number)Float.valueOf(this.legsResistance));
        json.addProperty("feet_resistance", (Number)Float.valueOf(this.feetResistance));
        return json;
    }
}

