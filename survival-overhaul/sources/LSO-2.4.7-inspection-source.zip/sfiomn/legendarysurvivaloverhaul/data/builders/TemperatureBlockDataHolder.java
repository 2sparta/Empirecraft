/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 */
package sfiomn.legendarysurvivaloverhaul.data.builders;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.List;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureBlockData;
import sfiomn.legendarysurvivaloverhaul.api.data.builder.ITemperatureBlockDataHolder;

public class TemperatureBlockDataHolder
implements ITemperatureBlockDataHolder {
    private final List<ITemperatureBlockData> temperatureDataList = new ArrayList<ITemperatureBlockData>();

    @Override
    public TemperatureBlockDataHolder addTemperature(ITemperatureBlockData temperatureData) {
        this.temperatureDataList.add(temperatureData.copy());
        return this;
    }

    @Override
    public JsonArray build() {
        JsonArray json = new JsonArray();
        this.temperatureDataList.forEach(t -> json.add((JsonElement)t.build()));
        return json;
    }
}

