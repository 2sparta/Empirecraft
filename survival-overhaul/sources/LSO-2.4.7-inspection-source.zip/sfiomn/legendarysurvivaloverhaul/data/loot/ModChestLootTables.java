/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.data.loot.LootTableSubProvider
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.item.enchantment.Enchantment
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.storage.loot.BuiltInLootTables
 *  net.minecraft.world.level.storage.loot.LootPool
 *  net.minecraft.world.level.storage.loot.LootPool$Builder
 *  net.minecraft.world.level.storage.loot.LootTable
 *  net.minecraft.world.level.storage.loot.LootTable$Builder
 *  net.minecraft.world.level.storage.loot.entries.EmptyLootItem
 *  net.minecraft.world.level.storage.loot.entries.LootItem
 *  net.minecraft.world.level.storage.loot.entries.LootPoolEntryContainer$Builder
 *  net.minecraft.world.level.storage.loot.functions.LootItemFunction$Builder
 *  net.minecraft.world.level.storage.loot.functions.SetEnchantmentsFunction$Builder
 *  net.minecraft.world.level.storage.loot.functions.SetItemCountFunction
 *  net.minecraft.world.level.storage.loot.providers.number.ConstantValue
 *  net.minecraft.world.level.storage.loot.providers.number.NumberProvider
 *  net.minecraft.world.level.storage.loot.providers.number.UniformGenerator
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.data.loot;

import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.data.loot.LootTableSubProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.EmptyLootItem;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.entries.LootPoolEntryContainer;
import net.minecraft.world.level.storage.loot.functions.LootItemFunction;
import net.minecraft.world.level.storage.loot.functions.SetEnchantmentsFunction;
import net.minecraft.world.level.storage.loot.functions.SetItemCountFunction;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraft.world.level.storage.loot.providers.number.NumberProvider;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.registry.EnchantmentRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;

public class ModChestLootTables
implements LootTableSubProvider {
    public static final Item PURITY_BOOK = Items.f_42690_;
    public static Map<ResourceLocation, List<Item>> chestInjectedLootTables = Map.ofEntries(Map.entry(BuiltInLootTables.f_78692_, List.of((Item)ItemRegistry.HEART_FRAGMENT.get())), Map.entry(BuiltInLootTables.f_78686_, List.of((Item)ItemRegistry.HEART_FRAGMENT.get())), Map.entry(BuiltInLootTables.f_78759_, List.of((Item)ItemRegistry.HEART_FRAGMENT.get())), Map.entry(BuiltInLootTables.f_78697_, List.of((Item)ItemRegistry.HEART_FRAGMENT.get(), (Item)ItemRegistry.COLD_RESISTANCE_RING.get(), PURITY_BOOK)), Map.entry(BuiltInLootTables.f_78699_, List.of(PURITY_BOOK)), Map.entry(BuiltInLootTables.f_78700_, List.of(PURITY_BOOK)), Map.entry(BuiltInLootTables.f_78698_, List.of(PURITY_BOOK)), Map.entry(BuiltInLootTables.f_78760_, List.of(PURITY_BOOK)), Map.entry(BuiltInLootTables.f_78764_, List.of((Item)ItemRegistry.HEAT_RESISTANCE_RING.get())), Map.entry(BuiltInLootTables.f_78696_, List.of((Item)ItemRegistry.FIRST_AID_SUPPLIES.get())));

    public void m_245126_(@NotNull BiConsumer<ResourceLocation, LootTable.Builder> biConsumer) {
        LootPool.Builder heartFragmentLoot = LootPool.m_79043_().m_165133_((NumberProvider)UniformGenerator.m_165780_((float)1.0f, (float)1.0f)).m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.HEART_FRAGMENT.get())).m_79707_(30)).m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.HEART_FRAGMENT.get())).m_79707_(5).m_79078_((LootItemFunction.Builder)SetItemCountFunction.m_165412_((NumberProvider)ConstantValue.m_165692_((float)2.0f)))).m_79076_((LootPoolEntryContainer.Builder)EmptyLootItem.m_79533_().m_79707_(80));
        LootPool.Builder heatResistanceRing = LootPool.m_79043_().m_165133_((NumberProvider)UniformGenerator.m_165780_((float)1.0f, (float)1.0f)).m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.HEAT_RESISTANCE_RING.get())).m_79707_(5)).m_79076_((LootPoolEntryContainer.Builder)EmptyLootItem.m_79533_().m_79707_(95));
        LootPool.Builder coldResistanceRing = LootPool.m_79043_().m_165133_((NumberProvider)UniformGenerator.m_165780_((float)1.0f, (float)1.0f)).m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.COLD_RESISTANCE_RING.get())).m_79707_(5)).m_79076_((LootPoolEntryContainer.Builder)EmptyLootItem.m_79533_().m_79707_(95));
        LootPool.Builder firstAidSupplies = LootPool.m_79043_().m_165133_((NumberProvider)UniformGenerator.m_165780_((float)1.0f, (float)1.0f)).m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.FIRST_AID_SUPPLIES.get())).m_79707_(1)).m_79076_((LootPoolEntryContainer.Builder)EmptyLootItem.m_79533_().m_79707_(99));
        LootPool.Builder purityBook = LootPool.m_79043_().m_165133_((NumberProvider)UniformGenerator.m_165780_((float)1.0f, (float)1.0f)).m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)Items.f_42690_).m_79707_(5).m_79078_((LootItemFunction.Builder)new SetEnchantmentsFunction.Builder(false).m_165374_((Enchantment)EnchantmentRegistry.PURITY.get(), (NumberProvider)ConstantValue.m_165692_((float)1.0f)))).m_79076_((LootPoolEntryContainer.Builder)EmptyLootItem.m_79533_().m_79707_(95));
        for (Map.Entry<ResourceLocation, List<Item>> entry : chestInjectedLootTables.entrySet()) {
            LootTable.Builder lootTable = LootTable.m_79147_();
            if (entry.getValue().contains(ItemRegistry.HEART_FRAGMENT.get())) {
                lootTable.m_79161_(heartFragmentLoot);
            }
            if (entry.getValue().contains(ItemRegistry.HEAT_RESISTANCE_RING.get())) {
                lootTable.m_79161_(heatResistanceRing);
            }
            if (entry.getValue().contains(ItemRegistry.COLD_RESISTANCE_RING.get())) {
                lootTable.m_79161_(coldResistanceRing);
            }
            if (entry.getValue().contains(ItemRegistry.FIRST_AID_SUPPLIES.get())) {
                lootTable.m_79161_(firstAidSupplies);
            }
            if (entry.getValue().contains(PURITY_BOOK)) {
                lootTable.m_79161_(purityBook);
            }
            biConsumer.accept(new ResourceLocation("legendarysurvivaloverhaul", "inject/" + entry.getKey().m_135815_()), lootTable);
        }
    }
}

