/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.data.loot.LootTableSubProvider
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.storage.loot.LootPool
 *  net.minecraft.world.level.storage.loot.LootTable
 *  net.minecraft.world.level.storage.loot.LootTable$Builder
 *  net.minecraft.world.level.storage.loot.entries.EmptyLootItem
 *  net.minecraft.world.level.storage.loot.entries.LootItem
 *  net.minecraft.world.level.storage.loot.entries.LootPoolEntryContainer$Builder
 */
package sfiomn.legendarysurvivaloverhaul.data.loot;

import java.util.Arrays;
import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.data.loot.LootTableSubProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.EmptyLootItem;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.entries.LootPoolEntryContainer;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;

public class ModEntityLootTables
implements LootTableSubProvider {
    public static List<ResourceLocation> entityInjectedLootTables = Arrays.asList(new ResourceLocation("entities/drowned"));

    public void m_245126_(BiConsumer<ResourceLocation, LootTable.Builder> biConsumer) {
        for (ResourceLocation lootTable : entityInjectedLootTables) {
            biConsumer.accept(new ResourceLocation("legendarysurvivaloverhaul", "inject/" + lootTable.m_135815_()), LootTable.m_79147_().m_79161_(LootPool.m_79043_().m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.WATER_PURIFIER.get())).m_79707_(1)).m_79076_((LootPoolEntryContainer.Builder)EmptyLootItem.m_79533_().m_79707_(100))));
        }
    }
}

