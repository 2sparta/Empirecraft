/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.advancements.critereon.StatePropertiesPredicate$Builder
 *  net.minecraft.data.loot.BlockLootSubProvider
 *  net.minecraft.world.flag.FeatureFlags
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.storage.loot.LootPool
 *  net.minecraft.world.level.storage.loot.LootTable
 *  net.minecraft.world.level.storage.loot.LootTable$Builder
 *  net.minecraft.world.level.storage.loot.entries.LootItem
 *  net.minecraft.world.level.storage.loot.entries.LootPoolEntryContainer$Builder
 *  net.minecraft.world.level.storage.loot.functions.FunctionUserBuilder
 *  net.minecraft.world.level.storage.loot.functions.LootItemFunction$Builder
 *  net.minecraft.world.level.storage.loot.functions.SetItemCountFunction
 *  net.minecraft.world.level.storage.loot.predicates.LootItemBlockStatePropertyCondition
 *  net.minecraft.world.level.storage.loot.predicates.LootItemBlockStatePropertyCondition$Builder
 *  net.minecraft.world.level.storage.loot.predicates.LootItemCondition$Builder
 *  net.minecraft.world.level.storage.loot.providers.number.NumberProvider
 *  net.minecraft.world.level.storage.loot.providers.number.UniformGenerator
 *  net.minecraftforge.registries.RegistryObject
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.data.loot;

import java.util.Set;
import net.minecraft.advancements.critereon.StatePropertiesPredicate;
import net.minecraft.data.loot.BlockLootSubProvider;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.entries.LootPoolEntryContainer;
import net.minecraft.world.level.storage.loot.functions.FunctionUserBuilder;
import net.minecraft.world.level.storage.loot.functions.LootItemFunction;
import net.minecraft.world.level.storage.loot.functions.SetItemCountFunction;
import net.minecraft.world.level.storage.loot.predicates.LootItemBlockStatePropertyCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.level.storage.loot.providers.number.NumberProvider;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;
import net.minecraftforge.registries.RegistryObject;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.common.blocks.IceFernBlock;
import sfiomn.legendarysurvivaloverhaul.common.blocks.SunFernBlock;
import sfiomn.legendarysurvivaloverhaul.common.blocks.WaterPlantBlock;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;

public class ModBlockLootTables
extends BlockLootSubProvider {
    public ModBlockLootTables() {
        super(Set.of(), FeatureFlags.f_244280_.m_247355_());
    }

    protected void m_245660_() {
        this.m_245724_((Block)BlockRegistry.HEATER.get());
        this.m_246125_((Block)BlockRegistry.HEATER_TOP.get(), (ItemLike)BlockRegistry.HEATER.get());
        this.m_245724_((Block)BlockRegistry.COOLER.get());
        this.m_245724_((Block)BlockRegistry.SEWING_TABLE.get());
        LootItemBlockStatePropertyCondition.Builder lootitemconditionMaxAgebuilder = LootItemBlockStatePropertyCondition.m_81769_((Block)((Block)BlockRegistry.WATER_PLANT_CROP.get())).m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67694_((Property)WaterPlantBlock.AGE, 7));
        LootItemBlockStatePropertyCondition.Builder lootitemconditionBelow1MaxAgebuilder = LootItemBlockStatePropertyCondition.m_81769_((Block)((Block)BlockRegistry.WATER_PLANT_CROP.get())).m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67694_((Property)WaterPlantBlock.AGE, 6));
        LootItemBlockStatePropertyCondition.Builder lootitemconditionBelow2MaxAgebuilder = LootItemBlockStatePropertyCondition.m_81769_((Block)((Block)BlockRegistry.WATER_PLANT_CROP.get())).m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67694_((Property)WaterPlantBlock.AGE, 5));
        this.m_247577_((Block)BlockRegistry.WATER_PLANT_CROP.get(), this.m_245238_((Block)BlockRegistry.WATER_PLANT_CROP.get(), (Item)ItemRegistry.WATER_PLANT_SEEDS.get(), (Item)ItemRegistry.WATER_PLANT_SEEDS.get(), (LootItemCondition.Builder)lootitemconditionMaxAgebuilder).m_79161_(LootPool.m_79043_().m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.WATER_PLANT_BAG.get()))).m_79078_((LootItemFunction.Builder)SetItemCountFunction.m_165412_((NumberProvider)UniformGenerator.m_165780_((float)1.0f, (float)2.0f))).m_79080_((LootItemCondition.Builder)lootitemconditionBelow2MaxAgebuilder)).m_79161_(LootPool.m_79043_().m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.WATER_PLANT_BAG.get()))).m_79078_((LootItemFunction.Builder)SetItemCountFunction.m_165412_((NumberProvider)UniformGenerator.m_165780_((float)1.0f, (float)3.0f))).m_79080_((LootItemCondition.Builder)lootitemconditionBelow1MaxAgebuilder)).m_79161_(LootPool.m_79043_().m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.WATER_PLANT_BAG.get()))).m_79078_((LootItemFunction.Builder)SetItemCountFunction.m_165412_((NumberProvider)UniformGenerator.m_165780_((float)2.0f, (float)4.0f))).m_79080_((LootItemCondition.Builder)lootitemconditionMaxAgebuilder)));
        lootitemconditionMaxAgebuilder = LootItemBlockStatePropertyCondition.m_81769_((Block)((Block)BlockRegistry.ICE_FERN_CROP.get())).m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67694_((Property)IceFernBlock.AGE, 3));
        this.m_247577_((Block)BlockRegistry.ICE_FERN_CROP.get(), (LootTable.Builder)this.m_246108_((ItemLike)BlockRegistry.ICE_FERN_CROP.get(), (FunctionUserBuilder)LootTable.m_79147_().m_79161_(LootPool.m_79043_().m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.ICE_FERN.get()))).m_79080_((LootItemCondition.Builder)lootitemconditionMaxAgebuilder)).m_79161_(LootPool.m_79043_().m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.ICE_FERN_SEEDS.get()))))));
        this.m_247577_((Block)BlockRegistry.ICE_FERN_GOLD.get(), LootTable.m_79147_().m_79161_(LootPool.m_79043_().m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.ICE_FERN_GOLD.get())))).m_79161_(LootPool.m_79043_().m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.ICE_FERN_SEEDS.get())))));
        lootitemconditionMaxAgebuilder = LootItemBlockStatePropertyCondition.m_81769_((Block)((Block)BlockRegistry.SUN_FERN_CROP.get())).m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67694_((Property)SunFernBlock.AGE, 3));
        this.m_247577_((Block)BlockRegistry.SUN_FERN_CROP.get(), (LootTable.Builder)this.m_246108_((ItemLike)BlockRegistry.SUN_FERN_CROP.get(), (FunctionUserBuilder)LootTable.m_79147_().m_79161_(LootPool.m_79043_().m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.SUN_FERN.get()))).m_79080_((LootItemCondition.Builder)lootitemconditionMaxAgebuilder)).m_79161_(LootPool.m_79043_().m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.SUN_FERN_SEEDS.get()))))));
        this.m_247577_((Block)BlockRegistry.SUN_FERN_GOLD.get(), LootTable.m_79147_().m_79161_(LootPool.m_79043_().m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.SUN_FERN_GOLD.get())))).m_79161_(LootPool.m_79043_().m_79076_((LootPoolEntryContainer.Builder)LootItem.m_79579_((ItemLike)((ItemLike)ItemRegistry.SUN_FERN_SEEDS.get())))));
    }

    @NotNull
    protected Iterable<Block> getKnownBlocks() {
        return BlockRegistry.BLOCKS.getEntries().stream().map(RegistryObject::get).toList();
    }
}

