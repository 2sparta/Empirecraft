/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.BushBlock
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.material.MapColor
 *  net.minecraft.world.level.material.PushReaction
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.common.IPlantable
 *  net.minecraftforge.common.PlantType
 */
package sfiomn.legendarysurvivaloverhaul.common.blocks;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.common.IPlantable;
import net.minecraftforge.common.PlantType;
import sfiomn.legendarysurvivaloverhaul.registry.ParticleTypeRegistry;

public class IceFernGoldBlock
extends BushBlock
implements IPlantable {
    public static final BlockBehaviour.Properties properties = IceFernGoldBlock.getProperties();

    public IceFernGoldBlock() {
        super(properties);
    }

    public static BlockBehaviour.Properties getProperties() {
        return BlockBehaviour.Properties.m_284310_().m_284180_(MapColor.f_283915_).m_60977_().m_60955_().m_60910_().m_60966_().m_60918_(SoundType.f_56758_).m_278166_(PushReaction.DESTROY);
    }

    protected boolean m_6266_(BlockState blockState, BlockGetter level, BlockPos pos) {
        return blockState.m_60713_(Blocks.f_50440_) || blockState.m_60713_(Blocks.f_50493_) || blockState.m_60713_(Blocks.f_50546_) || blockState.m_60713_(Blocks.f_50599_) || blockState.m_60713_(Blocks.f_50093_) || blockState.m_60713_(Blocks.f_50127_);
    }

    @OnlyIn(value=Dist.CLIENT)
    public void m_214162_(BlockState state, Level level, BlockPos pos, RandomSource rand) {
        double offsetX = (2.0f * rand.m_188501_() - 1.0f) * 0.3f;
        double offsetZ = (2.0f * rand.m_188501_() - 1.0f) * 0.3f;
        double x = (double)pos.m_123341_() + 0.5 + offsetX;
        double y = (double)pos.m_123342_() + 0.5 + (double)(rand.m_188501_() * 0.05f);
        double z = (double)pos.m_123343_() + 0.5 + offsetZ;
        if (level.m_46467_() % 3L == 0L) {
            level.m_7106_((ParticleOptions)ParticleTypeRegistry.ICE_FERN_BLOSSOM.get(), x, y, z, 0.04, 0.01, 0.04);
        }
    }

    public PlantType getPlantType(BlockGetter level, BlockPos pos) {
        return PlantType.PLAINS;
    }

    public BlockState getPlant(BlockGetter world, BlockPos pos) {
        return this.m_49966_();
    }
}

