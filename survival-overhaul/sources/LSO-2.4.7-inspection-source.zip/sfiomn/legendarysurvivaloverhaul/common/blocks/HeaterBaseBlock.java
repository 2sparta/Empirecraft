/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.core.particles.ParticleTypes
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.item.context.BlockPlaceContext
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.level.block.entity.BlockEntityTicker
 *  net.minecraft.world.level.block.entity.BlockEntityType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.BlockStateProperties
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.material.MapColor
 *  net.minecraft.world.phys.shapes.CollisionContext
 *  net.minecraft.world.phys.shapes.Shapes
 *  net.minecraft.world.phys.shapes.VoxelShape
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.common.blocks;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.api.block.ThermalTypeEnum;
import sfiomn.legendarysurvivaloverhaul.common.blockentities.AbstractThermalBlockEntity;
import sfiomn.legendarysurvivaloverhaul.common.blocks.HeaterTopBlock;
import sfiomn.legendarysurvivaloverhaul.common.blocks.ThermalBlock;
import sfiomn.legendarysurvivaloverhaul.registry.BlockEntityRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;

public class HeaterBaseBlock
extends ThermalBlock {
    public static final BlockBehaviour.Properties properties = HeaterBaseBlock.getProperties();
    private static final VoxelShape FEET = Block.m_49796_((double)0.0, (double)0.0, (double)0.0, (double)16.0, (double)6.0, (double)16.0);
    private static final VoxelShape BASE = Block.m_49796_((double)1.0, (double)6.0, (double)1.0, (double)15.0, (double)16.0, (double)15.0);
    private static final VoxelShape XZ_AXIS_AABB = Shapes.m_83110_((VoxelShape)FEET, (VoxelShape)BASE);

    public HeaterBaseBlock(ThermalTypeEnum thermalType) {
        super(thermalType, properties);
    }

    public static BlockBehaviour.Properties getProperties() {
        return BlockBehaviour.Properties.m_284310_().m_284180_(MapColor.f_283906_).m_60918_(SoundType.f_56743_).m_60913_(3.0f, 10.0f).m_60955_().m_60953_(lightLevel -> (Boolean)lightLevel.m_61143_((Property)BlockStateProperties.f_61443_) != false ? 13 : 0);
    }

    @Override
    public VoxelShape m_5940_(BlockState state, BlockGetter worldIn, BlockPos pos, CollisionContext context) {
        return XZ_AXIS_AABB;
    }

    @Nullable
    public <T extends BlockEntity> BlockEntityTicker<T> m_142354_(Level level, BlockState p_153213_, BlockEntityType<T> entityType) {
        return level.f_46443_ ? null : HeaterBaseBlock.m_152132_(entityType, (BlockEntityType)((BlockEntityType)BlockEntityRegistry.HEATER_BLOCK_ENTITY.get()), AbstractThermalBlockEntity::serverTick);
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext context) {
        BlockPos topPos;
        Level level = context.m_43725_();
        return level.m_8055_(topPos = context.m_8083_().m_7494_()).m_60629_(context) && level.m_6857_().m_61937_(topPos) ? (BlockState)this.m_49966_().m_61124_((Property)FACING, (Comparable)context.m_8125_()) : null;
    }

    @Override
    public void m_6810_(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        super.m_6810_(state, level, pos, newState, isMoving);
        if (!state.m_60713_(newState.m_60734_()) && level.m_8055_(pos.m_7494_()).m_60734_() instanceof HeaterTopBlock) {
            level.m_7471_(pos.m_7494_(), false);
        }
    }

    public void m_6807_(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        if (level.m_46859_(pos.m_7494_())) {
            level.m_7731_(pos.m_7494_(), (BlockState)((Block)BlockRegistry.HEATER_TOP.get()).m_49966_().m_61124_((Property)HeaterTopBlock.f_54117_, (Comparable)((Direction)state.m_61143_((Property)FACING))), 2);
        }
    }

    @OnlyIn(value=Dist.CLIENT)
    public void m_214162_(BlockState state, Level level, BlockPos pos, RandomSource rand) {
        if (((Boolean)state.m_61143_((Property)LIT)).booleanValue()) {
            float yr;
            float zr;
            float xr;
            float chance = 0.5f;
            float chance_flame = 0.4f;
            double posX = pos.m_123341_();
            double posY = pos.m_123342_();
            double posZ = pos.m_123343_();
            if (rand.m_188501_() < chance) {
                level.m_7785_(posX + 0.5, posY + 0.5, posZ + 0.5, SoundEvents.f_11907_, SoundSource.BLOCKS, 1.0f, 1.0f, false);
            }
            if (rand.m_188501_() < chance) {
                xr = rand.m_188501_() / 2.0f + 0.25f;
                float zr2 = rand.m_188501_() / 2.0f + 0.25f;
                float xm = rand.m_188501_() / 20.0f - 0.025f;
                float zm = rand.m_188501_() / 20.0f - 0.025f;
                float ym = rand.m_188501_() / 10.0f + 0.02f;
                level.m_6493_((ParticleOptions)ParticleTypes.f_123777_, false, posX + (double)xr, (double)pos.m_7494_().m_123342_() + 0.8, posZ + (double)zr2, (double)xm, (double)ym, (double)zm);
            }
            if (rand.m_188501_() < chance_flame) {
                zr = rand.m_188501_() / 3.0f + 0.33f;
                yr = rand.m_188501_() / 6.0f + 0.5f;
                level.m_6493_((ParticleOptions)ParticleTypes.f_123762_, false, posX + 0.05, posY + (double)yr, posZ + (double)zr, 0.0, 0.0, 0.0);
                level.m_6493_((ParticleOptions)ParticleTypes.f_123744_, false, posX + 0.05, posY + (double)yr, posZ + (double)zr, 0.0, 0.0, 0.0);
            }
            if (rand.m_188501_() < chance_flame) {
                zr = rand.m_188501_() / 3.0f + 0.33f;
                yr = rand.m_188501_() / 6.0f + 0.5f;
                level.m_6493_((ParticleOptions)ParticleTypes.f_123762_, false, posX + 0.95, posY + (double)yr, posZ + (double)zr, 0.0, 0.0, 0.0);
                level.m_6493_((ParticleOptions)ParticleTypes.f_123744_, false, posX + 0.95, posY + (double)yr, posZ + (double)zr, 0.0, 0.0, 0.0);
            }
            if (rand.m_188501_() < chance_flame) {
                xr = rand.m_188501_() / 3.0f + 0.33f;
                yr = rand.m_188501_() / 6.0f + 0.5f;
                level.m_6493_((ParticleOptions)ParticleTypes.f_123762_, false, posX + (double)xr, posY + (double)yr, posZ + 0.05, 0.0, 0.0, 0.0);
                level.m_6493_((ParticleOptions)ParticleTypes.f_123744_, false, posX + (double)xr, posY + (double)yr, posZ + 0.05, 0.0, 0.0, 0.0);
            }
            if (rand.m_188501_() < chance_flame) {
                xr = rand.m_188501_() / 3.0f + 0.33f;
                yr = rand.m_188501_() / 6.0f + 0.5f;
                level.m_6493_((ParticleOptions)ParticleTypes.f_123762_, false, posX + (double)xr, posY + (double)yr, posZ + 0.95, 0.0, 0.0, 0.0);
                level.m_6493_((ParticleOptions)ParticleTypes.f_123744_, false, posX + (double)xr, posY + (double)yr, posZ + 0.95, 0.0, 0.0, 0.0);
            }
        }
        super.m_214162_(state, level, pos, rand);
    }
}

