/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.util.Mth
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.CropBlock
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.StateDefinition$Builder
 *  net.minecraft.world.level.block.state.properties.BlockStateProperties
 *  net.minecraft.world.level.block.state.properties.IntegerProperty
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.material.MapColor
 *  net.minecraft.world.level.material.PushReaction
 *  net.minecraft.world.phys.shapes.CollisionContext
 *  net.minecraft.world.phys.shapes.VoxelShape
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.common.IPlantable
 *  net.minecraftforge.common.PlantType
 */
package sfiomn.legendarysurvivaloverhaul.common.blocks;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.common.IPlantable;
import net.minecraftforge.common.PlantType;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.ItemRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.ParticleTypeRegistry;

public class IceFernBlock
extends CropBlock
implements IPlantable {
    public static final int MAX_AGE = 3;
    public static final IntegerProperty AGE = BlockStateProperties.f_61407_;
    private static final VoxelShape[] SHAPE_BY_AGE = new VoxelShape[]{Block.m_49796_((double)3.0, (double)0.0, (double)3.0, (double)13.0, (double)8.0, (double)13.0), Block.m_49796_((double)1.0, (double)0.0, (double)1.0, (double)15.0, (double)10.0, (double)15.0), Block.m_49796_((double)1.0, (double)0.0, (double)1.0, (double)15.0, (double)15.0, (double)15.0), Block.m_49796_((double)0.0, (double)0.0, (double)0.0, (double)16.0, (double)16.0, (double)16.0)};
    public static final BlockBehaviour.Properties properties = IceFernBlock.getProperties();

    public IceFernBlock() {
        super(properties);
    }

    public static BlockBehaviour.Properties getProperties() {
        return BlockBehaviour.Properties.m_284310_().m_284180_(MapColor.f_283915_).m_60977_().m_60955_().m_60910_().m_60966_().m_60918_(SoundType.f_56758_).m_278166_(PushReaction.DESTROY);
    }

    public void m_52263_(Level level, BlockPos pos, BlockState blockState) {
        int j;
        int previousAge = this.m_52305_(blockState);
        int i = this.m_52305_(blockState) + this.m_7125_(level);
        if (i > (j = this.m_7419_())) {
            i = j;
        }
        if (previousAge < 3 && i == 3 && (double)level.m_213780_().m_188501_() < Config.Baked.goldFernChance) {
            level.m_7731_(pos, ((Block)BlockRegistry.ICE_FERN_GOLD.get()).m_49966_(), 2);
            return;
        }
        level.m_7731_(pos, this.m_52289_(i), 2);
    }

    public void m_213898_(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        int previousAge = this.m_52305_(state);
        super.m_213898_(state, level, pos, random);
        if (previousAge >= 3) {
            return;
        }
        BlockState newState = level.m_8055_(pos);
        if (this.m_52305_(newState) == 3 && (double)random.m_188501_() < Config.Baked.goldFernChance) {
            level.m_7731_(pos, ((Block)BlockRegistry.ICE_FERN_GOLD.get()).m_49966_(), 2);
        }
    }

    protected boolean m_6266_(BlockState blockState, BlockGetter level, BlockPos pos) {
        return blockState.m_60713_(Blocks.f_50440_) || blockState.m_60713_(Blocks.f_50493_) || blockState.m_60713_(Blocks.f_50546_) || blockState.m_60713_(Blocks.f_50599_) || blockState.m_60713_(Blocks.f_50093_) || blockState.m_60713_(Blocks.f_50127_);
    }

    protected int m_7125_(Level pLevel) {
        return Mth.m_216271_((RandomSource)pLevel.f_46441_, (int)0, (int)1);
    }

    protected ItemLike m_6404_() {
        return (ItemLike)ItemRegistry.ICE_FERN_SEEDS.get();
    }

    public IntegerProperty m_7959_() {
        return AGE;
    }

    public int m_7419_() {
        return 3;
    }

    protected void m_7926_(StateDefinition.Builder<Block, BlockState> builder) {
        builder.m_61104_(new Property[]{AGE});
    }

    public VoxelShape m_5940_(BlockState state, BlockGetter reader, BlockPos pos, CollisionContext context) {
        return SHAPE_BY_AGE[this.m_52305_(state)];
    }

    @OnlyIn(value=Dist.CLIENT)
    public void m_214162_(BlockState state, Level level, BlockPos pos, RandomSource rand) {
        if (this.m_52305_(state) < this.m_7419_()) {
            return;
        }
        double offsetX = (2.0f * rand.m_188501_() - 1.0f) * 0.3f;
        double offsetZ = (2.0f * rand.m_188501_() - 1.0f) * 0.3f;
        double x = (double)pos.m_123341_() + 0.5 + offsetX;
        double y = (double)pos.m_123342_() + 0.5 + (double)(rand.m_188501_() * 0.05f);
        double z = (double)pos.m_123343_() + 0.5 + offsetZ;
        if (level.m_46467_() % 3L == 0L) {
            level.m_7106_((ParticleOptions)ParticleTypeRegistry.ICE_FERN_BLOSSOM.get(), x, y, z, 0.04, 0.01, 0.04);
        }
    }

    public PlantType getPlantType(BlockGetter level, BlockPos pos) {
        return PlantType.CROP;
    }

    public BlockState getPlant(BlockGetter world, BlockPos pos) {
        return this.m_49966_();
    }
}

