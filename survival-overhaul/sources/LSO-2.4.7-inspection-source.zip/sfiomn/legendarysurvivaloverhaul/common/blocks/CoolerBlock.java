/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.core.particles.ParticleTypes
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.level.block.entity.BlockEntityTicker
 *  net.minecraft.world.level.block.entity.BlockEntityType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.material.MapColor
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.common.blocks;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.api.block.ThermalTypeEnum;
import sfiomn.legendarysurvivaloverhaul.common.blockentities.AbstractThermalBlockEntity;
import sfiomn.legendarysurvivaloverhaul.common.blocks.ThermalBlock;
import sfiomn.legendarysurvivaloverhaul.registry.BlockEntityRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.SoundRegistry;

public class CoolerBlock
extends ThermalBlock {
    public static final BlockBehaviour.Properties properties = CoolerBlock.getProperties();

    public CoolerBlock(ThermalTypeEnum thermalType) {
        super(thermalType, properties);
    }

    public static BlockBehaviour.Properties getProperties() {
        return BlockBehaviour.Properties.m_284310_().m_284180_(MapColor.f_283825_).m_60918_(SoundType.f_56736_).m_60913_(2.0f, 10.0f).m_60955_();
    }

    @Nullable
    public <T extends BlockEntity> BlockEntityTicker<T> m_142354_(Level level, BlockState p_153213_, BlockEntityType<T> entityType) {
        return level.f_46443_ ? null : CoolerBlock.m_152132_(entityType, (BlockEntityType)((BlockEntityType)BlockEntityRegistry.COOLER_BLOCK_ENTITY.get()), AbstractThermalBlockEntity::serverTick);
    }

    @OnlyIn(value=Dist.CLIENT)
    public void m_214162_(BlockState state, Level level, BlockPos pos, RandomSource rand) {
        if (((Boolean)state.m_61143_((Property)LIT)).booleanValue()) {
            float chanceSound = 0.1f;
            float chanceParticle = 0.25f;
            double posX = pos.m_123341_();
            double posY = pos.m_123342_();
            double posZ = pos.m_123343_();
            if (rand.m_188501_() < chanceSound) {
                level.m_7785_(posX + 0.5, posY + 0.5, posZ + 0.5, (SoundEvent)SoundRegistry.COOLER_BLOCK.get(), SoundSource.BLOCKS, 1.0f, 1.0f, false);
            }
            if (rand.m_188501_() < chanceParticle) {
                float xr = rand.m_188501_();
                float zr = rand.m_188501_();
                level.m_6493_((ParticleOptions)ParticleTypes.f_123754_, false, posX + (double)xr, posY + 1.0, posZ + (double)zr, 0.0, 0.0, 0.0);
            }
        }
        super.m_214162_(state, level, pos, rand);
    }
}

