/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mrcrayfish.furniture.refurbished.blockentity.BasinBlockEntity
 *  com.mrcrayfish.furniture.refurbished.blockentity.KitchenSinkBlockEntity
 *  com.mrcrayfish.furniture.refurbished.blockentity.fluid.FluidContainer
 *  com.mrcrayfish.furniture.refurbished.blockentity.fluid.IFluidContainerBlock
 *  net.minecraft.core.BlockPos
 *  net.minecraft.network.protocol.Packet
 *  net.minecraft.network.protocol.game.ClientboundSoundPacket
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.material.Fluid
 *  net.minecraft.world.level.material.Fluids
 *  net.minecraftforge.registries.ForgeRegistries
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.crayfish;

import com.mrcrayfish.furniture.refurbished.blockentity.BasinBlockEntity;
import com.mrcrayfish.furniture.refurbished.blockentity.KitchenSinkBlockEntity;
import com.mrcrayfish.furniture.refurbished.blockentity.fluid.FluidContainer;
import com.mrcrayfish.furniture.refurbished.blockentity.fluid.IFluidContainerBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.minecraftforge.registries.ForgeRegistries;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.CanteenItem;

public class CrayfishFurnitureUtil {
    public static InteractionResult tryFillCanteenFromSinkOrBasin(Level level, BlockPos pos, Player player, ItemStack canteen) {
        if (!LegendarySurvivalOverhaul.crayfishFurnitureLoaded) {
            return InteractionResult.PASS;
        }
        try {
            BlockEntity blockEntity = level.m_7702_(pos);
            if (blockEntity == null) {
                return InteractionResult.PASS;
            }
            boolean isKitchenSink = blockEntity instanceof KitchenSinkBlockEntity;
            boolean isBasin = blockEntity instanceof BasinBlockEntity;
            if (!isKitchenSink && !isBasin) {
                return InteractionResult.PASS;
            }
            if (!(blockEntity instanceof IFluidContainerBlock)) {
                return InteractionResult.PASS;
            }
            IFluidContainerBlock fluidContainerBlock = (IFluidContainerBlock)blockEntity;
            FluidContainer container = fluidContainerBlock.getFluidContainer();
            if (container == null) {
                return InteractionResult.PASS;
            }
            long storedAmount = container.getStoredAmount();
            if (container.isEmpty()) {
                return InteractionResult.PASS;
            }
            if (!container.getStoredFluid().m_6212_((Fluid)Fluids.f_76193_)) {
                return InteractionResult.PASS;
            }
            if (storedAmount <= 0L) {
                return InteractionResult.PASS;
            }
            Item item = canteen.m_41720_();
            if (!(item instanceof CanteenItem)) {
                return InteractionResult.PASS;
            }
            CanteenItem canteenItem = (CanteenItem)item;
            if (!canteenItem.canFill(canteen)) {
                return InteractionResult.PASS;
            }
            long bottleCapacity = FluidContainer.BOTTLE_CAPACITY;
            if (storedAmount >= bottleCapacity) {
                if (!level.f_46443_) {
                    container.pull(bottleCapacity, false);
                    canteenItem.fill(canteen);
                }
                if (player instanceof ServerPlayer) {
                    ServerPlayer serverPlayer = (ServerPlayer)player;
                    ForgeRegistries.SOUND_EVENTS.getHolder((Object)SoundEvents.f_11770_).ifPresent(soundHolder -> serverPlayer.f_8906_.m_9829_((Packet)new ClientboundSoundPacket(soundHolder, SoundSource.PLAYERS, serverPlayer.m_20185_(), serverPlayer.m_20186_(), serverPlayer.m_20189_(), 1.0f, 1.0f, player.m_9236_().m_213780_().m_188505_())));
                }
                return InteractionResult.m_19078_((boolean)level.f_46443_);
            }
            LegendarySurvivalOverhaul.LOGGER.debug("Not enough fluid in container: {} < {}", (Object)storedAmount, (Object)bottleCapacity);
            return InteractionResult.PASS;
        }
        catch (NoClassDefFoundError e) {
            LegendarySurvivalOverhaul.LOGGER.error("Crayfish Furniture classes not found - mod may not be installed", (Throwable)e);
            LegendarySurvivalOverhaul.crayfishFurnitureLoaded = false;
            return InteractionResult.PASS;
        }
        catch (Exception e) {
            LegendarySurvivalOverhaul.LOGGER.error("Error occurred while trying to fill canteen from Crayfish furniture", (Throwable)e);
            return InteractionResult.PASS;
        }
    }

    public static InteractionResult tryEmptyCanteenIntoSinkOrBasin(Level level, BlockPos pos, Player player, ItemStack canteen) {
        if (!LegendarySurvivalOverhaul.crayfishFurnitureLoaded) {
            return InteractionResult.PASS;
        }
        try {
            long maxCapacity;
            long bottleCapacity;
            BlockEntity blockEntity = level.m_7702_(pos);
            if (blockEntity == null) {
                return InteractionResult.PASS;
            }
            boolean isKitchenSink = blockEntity instanceof KitchenSinkBlockEntity;
            boolean isBasin = blockEntity instanceof BasinBlockEntity;
            if (!isKitchenSink && !isBasin) {
                return InteractionResult.PASS;
            }
            if (!(blockEntity instanceof IFluidContainerBlock)) {
                return InteractionResult.PASS;
            }
            IFluidContainerBlock fluidContainerBlock = (IFluidContainerBlock)blockEntity;
            FluidContainer container = fluidContainerBlock.getFluidContainer();
            if (container == null) {
                return InteractionResult.PASS;
            }
            Item item = canteen.m_41720_();
            if (!(item instanceof CanteenItem)) {
                return InteractionResult.PASS;
            }
            CanteenItem canteenItem = (CanteenItem)item;
            if (!CanteenItem.canDrink(canteen)) {
                return InteractionResult.PASS;
            }
            long currentAmount = container.getStoredAmount();
            if (currentAmount + (bottleCapacity = FluidContainer.BOTTLE_CAPACITY) > (maxCapacity = container.getCapacity())) {
                return InteractionResult.PASS;
            }
            if (!level.f_46443_) {
                container.push((Fluid)Fluids.f_76193_, bottleCapacity, false);
                CanteenItem.shrinkCapacity(canteen);
            }
            if (player instanceof ServerPlayer) {
                ServerPlayer serverPlayer = (ServerPlayer)player;
                ForgeRegistries.SOUND_EVENTS.getHolder((Object)SoundEvents.f_11769_).ifPresent(soundHolder -> serverPlayer.f_8906_.m_9829_((Packet)new ClientboundSoundPacket(soundHolder, SoundSource.PLAYERS, serverPlayer.m_20185_(), serverPlayer.m_20186_(), serverPlayer.m_20189_(), 1.0f, 1.0f, player.m_9236_().m_213780_().m_188505_())));
            }
            return InteractionResult.m_19078_((boolean)level.f_46443_);
        }
        catch (NoClassDefFoundError e) {
            LegendarySurvivalOverhaul.LOGGER.error("Crayfish Furniture classes not found - mod may not be installed", (Throwable)e);
            LegendarySurvivalOverhaul.crayfishFurnitureLoaded = false;
            return InteractionResult.PASS;
        }
        catch (Exception e) {
            LegendarySurvivalOverhaul.LOGGER.error("Error occurred while trying to empty canteen into Crayfish furniture", (Throwable)e);
            return InteractionResult.PASS;
        }
    }

    public static boolean isSinkOrBasin(BlockState blockState) {
        if (!LegendarySurvivalOverhaul.crayfishFurnitureLoaded) {
            return false;
        }
        try {
            String blockClassName = blockState.m_60734_().getClass().getName();
            return blockClassName.contains("KitchenSinkBlock") || blockClassName.contains("BasinBlock");
        }
        catch (Exception e) {
            return false;
        }
    }
}

