/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  de.teamlapen.vampirism.api.VReference
 *  de.teamlapen.vampirism.api.VampirismAPI
 *  de.teamlapen.vampirism.api.entity.factions.IFaction
 *  de.teamlapen.vampirism.api.entity.factions.IFactionPlayerHandler
 *  net.minecraft.world.entity.player.Player
 *  net.minecraftforge.common.util.LazyOptional
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.vampirism;

import de.teamlapen.vampirism.api.VReference;
import de.teamlapen.vampirism.api.VampirismAPI;
import de.teamlapen.vampirism.api.entity.factions.IFaction;
import de.teamlapen.vampirism.api.entity.factions.IFactionPlayerHandler;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.util.LazyOptional;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;

public class VampirismUtil {
    public static boolean isVampire(Player player) {
        LazyOptional factionHandlerOptional;
        if (LegendarySurvivalOverhaul.vampirismLoaded && player != null && (factionHandlerOptional = VampirismAPI.getFactionPlayerHandler((Player)player)).isPresent() && factionHandlerOptional.resolve().isPresent()) {
            return ((IFactionPlayerHandler)factionHandlerOptional.resolve().get()).isInFaction((IFaction)VReference.VAMPIRE_FACTION);
        }
        return false;
    }
}

