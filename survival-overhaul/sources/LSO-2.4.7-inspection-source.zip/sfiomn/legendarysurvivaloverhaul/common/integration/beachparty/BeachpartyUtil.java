/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nonnull
 *  net.minecraft.core.BlockPos
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.satisfy.beachparty.core.block.BeachParasolBlock
 *  net.satisfy.beachparty.core.block.HoodedBeachChair
 *  net.satisfy.beachparty.core.entity.ChairEntity
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.beachparty;

import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.satisfy.beachparty.core.block.BeachParasolBlock;
import net.satisfy.beachparty.core.block.HoodedBeachChair;
import net.satisfy.beachparty.core.entity.ChairEntity;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;

public class BeachpartyUtil {
    public static boolean isUnderParasol(Level level, Player player, BlockPos pos) {
        if (LegendarySurvivalOverhaul.beachpartyLoaded) {
            if (player != null && player.m_20202_() != null && player.m_20202_() instanceof ChairEntity) {
                BlockPos checkPos = player.m_20183_().m_7918_(0, 1, 0);
                BlockState blockState = level.m_8055_(checkPos);
                return blockState.m_60734_() instanceof HoodedBeachChair;
            }
            BlockPos checkPos = pos.m_7918_(0, 1, 0);
            BlockState blockState = level.m_8055_(checkPos);
            if (blockState.m_60734_() instanceof BeachParasolBlock) {
                return blockState.m_61138_((Property)BeachParasolBlock.OPEN) ? (Boolean)blockState.m_61143_((Property)BeachParasolBlock.OPEN) : false;
            }
        }
        return false;
    }

    public static boolean canProvideShade(@Nonnull ResourceLocation itemRegistryName) {
        return LegendarySurvivalOverhaul.beachpartyLoaded && (itemRegistryName.toString().equals("beachparty:hooded_beach_chair") || itemRegistryName.toString().equals("beachparty:beach_parasol"));
    }
}

