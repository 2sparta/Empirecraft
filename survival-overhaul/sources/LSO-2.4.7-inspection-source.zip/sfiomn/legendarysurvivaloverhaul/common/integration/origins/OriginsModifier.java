/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.edwinmindcraft.origins.api.OriginsAPI
 *  io.github.edwinmindcraft.origins.api.capabilities.IOriginContainer
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.world.entity.player.Player
 *  net.minecraftforge.common.util.LazyOptional
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.origins;

import io.github.edwinmindcraft.origins.api.OriginsAPI;
import io.github.edwinmindcraft.origins.api.capabilities.IOriginContainer;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.util.LazyOptional;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureResistance;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.TemperatureDataManager;
import sfiomn.legendarysurvivaloverhaul.api.temperature.ModifierBase;

public class OriginsModifier
extends ModifierBase {
    @Override
    public float getPlayerInfluence(Player player) {
        if (!LegendarySurvivalOverhaul.originsLoaded) {
            return 0.0f;
        }
        LazyOptional optionalOrigin = player.getCapability(OriginsAPI.ORIGIN_CONTAINER);
        float temp = 0.0f;
        if (optionalOrigin.isPresent() && optionalOrigin.resolve().isPresent()) {
            IOriginContainer origins = (IOriginContainer)optionalOrigin.resolve().get();
            for (ResourceKey origin : origins.getOrigins().values()) {
                JsonTemperatureResistance config = TemperatureDataManager.getOrigin(origin.m_135782_());
                temp += config != null ? config.temperature : 0.0f;
            }
        }
        return temp;
    }
}

