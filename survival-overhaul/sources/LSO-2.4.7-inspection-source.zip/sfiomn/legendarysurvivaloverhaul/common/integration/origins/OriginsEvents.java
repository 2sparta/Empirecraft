/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.event.TickEvent$PlayerTickEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.origins;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import sfiomn.legendarysurvivaloverhaul.common.integration.origins.OriginsUtil;

public class OriginsEvents {
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.side.isServer() && event.player.f_19797_ % 20 == 0) {
            OriginsUtil.assignOriginsFeatures(event.player);
        }
    }
}

