/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mezz.jei.api.constants.VanillaTypes
 *  mezz.jei.api.gui.builder.IRecipeLayoutBuilder
 *  mezz.jei.api.gui.drawable.IDrawable
 *  mezz.jei.api.helpers.IGuiHelper
 *  mezz.jei.api.ingredients.IIngredientType
 *  mezz.jei.api.recipe.IFocusGroup
 *  mezz.jei.api.recipe.RecipeIngredientRole
 *  mezz.jei.api.recipe.RecipeType
 *  mezz.jei.api.recipe.category.IRecipeCategory
 *  net.minecraft.network.chat.Component
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.ItemLike
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.jei;

import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.ingredients.IIngredientType;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import sfiomn.legendarysurvivaloverhaul.common.recipe.SewingRecipe;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;

public class SewingRecipeCategory
implements IRecipeCategory<SewingRecipe> {
    public static final ResourceLocation UID = new ResourceLocation("legendarysurvivaloverhaul", "sewing");
    public static final ResourceLocation TEXTURE = new ResourceLocation("legendarysurvivaloverhaul", "textures/gui/sewing_table_screen.png");
    public static final RecipeType<SewingRecipe> SEWING_RECIPE_TYPE = new RecipeType(UID, SewingRecipe.class);
    private final IDrawable background;
    private final IDrawable icon;

    public SewingRecipeCategory(IGuiHelper helper) {
        this.background = helper.createDrawable(TEXTURE, 10, 30, 156, 33);
        this.icon = helper.createDrawableIngredient((IIngredientType)VanillaTypes.ITEM_STACK, (Object)new ItemStack((ItemLike)BlockRegistry.SEWING_TABLE.get()));
    }

    public RecipeType<SewingRecipe> getRecipeType() {
        return SEWING_RECIPE_TYPE;
    }

    public Component getTitle() {
        return Component.m_237115_((String)"block.legendarysurvivaloverhaul.sewing_table");
    }

    public IDrawable getBackground() {
        return this.background;
    }

    public IDrawable getIcon() {
        return this.icon;
    }

    public void setRecipe(IRecipeLayoutBuilder builder, SewingRecipe recipe, IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 8, 9).addIngredients(recipe.getBase());
        builder.addSlot(RecipeIngredientRole.INPUT, 55, 9).addIngredients(recipe.getAddition());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 124, 9).addItemStack(recipe.m_8043_(null));
    }
}

