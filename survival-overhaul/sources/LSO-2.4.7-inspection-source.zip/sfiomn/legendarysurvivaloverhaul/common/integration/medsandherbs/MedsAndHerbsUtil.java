/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.chat.Component
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.medsandherbs;

import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class MedsAndHerbsUtil {
    public static boolean triggerMorphineBehavior(Player player) {
        if (player.m_21023_((MobEffect)MobEffectRegistry.PAINKILLER_ADDICTION.get())) {
            player.m_5661_((Component)Component.m_237115_((String)"message.legendarysurvivaloverhaul.morphine_use_under_painkiller_addiction"), true);
            return false;
        }
        player.m_7292_(new MobEffectInstance((MobEffect)MobEffectRegistry.PAINKILLER.get(), Config.Baked.morphinePainkillerTickDuration, 0, false, false, true));
        if (Config.Baked.morphineSyringeApplyPainkillerAddiction) {
            player.m_7292_(new MobEffectInstance((MobEffect)MobEffectRegistry.PAINKILLER_ADDICTION.get(), Config.Baked.painkillerAddictionDuration, 0, false, false, true));
        }
        return true;
    }
}

