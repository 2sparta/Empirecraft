/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  fuzs.overflowingbars.OverflowingBars
 *  fuzs.overflowingbars.config.ClientConfig
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.overflowingbars;

import fuzs.overflowingbars.OverflowingBars;
import fuzs.overflowingbars.config.ClientConfig;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;

public class OverflowingBarsUtil {
    public static boolean isHealthBarOverflowing() {
        return LegendarySurvivalOverhaul.overflowingbarsLoaded && ((ClientConfig)OverflowingBars.CONFIG.get(ClientConfig.class)).health.allowLayers;
    }
}

