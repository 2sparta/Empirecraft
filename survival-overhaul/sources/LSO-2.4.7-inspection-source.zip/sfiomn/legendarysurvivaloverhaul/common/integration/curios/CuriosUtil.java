/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.NonNullList
 *  net.minecraft.util.Tuple
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.common.util.LazyOptional
 *  net.minecraftforge.eventbus.api.Event
 *  net.minecraftforge.eventbus.api.Event$Result
 *  net.minecraftforge.fml.loading.FMLLoader
 *  top.theillusivec4.curios.api.CuriosApi
 *  top.theillusivec4.curios.api.SlotContext
 *  top.theillusivec4.curios.api.type.capability.ICuriosItemHandler
 *  top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler
 *  top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.curios;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import net.minecraft.core.NonNullList;
import net.minecraft.util.Tuple;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.fml.loading.FMLLoader;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import top.theillusivec4.curios.api.CuriosApi;
import top.theillusivec4.curios.api.SlotContext;
import top.theillusivec4.curios.api.type.capability.ICuriosItemHandler;
import top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler;
import top.theillusivec4.curios.api.type.inventory.IDynamicStackHandler;

public class CuriosUtil {
    public static boolean isThermometerEquipped = false;

    public static boolean isCurioItemEquipped(Player player, Item item) {
        if (LegendarySurvivalOverhaul.curiosLoaded) {
            LazyOptional curiosInventory = CuriosApi.getCuriosInventory((LivingEntity)player);
            if (curiosInventory.isPresent() && curiosInventory.resolve().isPresent()) {
                return ((ICuriosItemHandler)curiosInventory.resolve().get()).isEquipped(item);
            }
            return false;
        }
        return player.m_21120_(InteractionHand.MAIN_HAND).m_150930_(item) || player.m_21120_(InteractionHand.OFF_HAND).m_150930_(item);
    }

    public static boolean isCuriosItem(ItemStack stack) {
        return LegendarySurvivalOverhaul.curiosLoaded && !CuriosApi.getItemStackSlots((ItemStack)stack, (FMLLoader.getDist() == Dist.CLIENT ? 1 : 0) != 0).values().isEmpty();
    }

    public static boolean equipCurio(Player player, ItemStack stack, InteractionHand hand) {
        LazyOptional curiosInventory;
        if (LegendarySurvivalOverhaul.curiosLoaded && (curiosInventory = CuriosApi.getCuriosInventory((LivingEntity)player)).isPresent() && curiosInventory.resolve().isPresent()) {
            Map curios = ((ICuriosItemHandler)curiosInventory.resolve().get()).getCurios();
            Tuple firstSlot = null;
            for (Map.Entry entry : curios.entrySet()) {
                IDynamicStackHandler stackHandler = ((ICurioStacksHandler)entry.getValue()).getStacks();
                for (int ix = 0; ix < stackHandler.getSlots(); ++ix) {
                    String id = (String)entry.getKey();
                    NonNullList renderStates = ((ICurioStacksHandler)entry.getValue()).getRenders();
                    SlotContext slotContext = new SlotContext(id, (LivingEntity)player, ix, false, renderStates.size() > ix && (Boolean)renderStates.get(ix) != false);
                    if (!stackHandler.isItemValid(ix, stack)) continue;
                    ItemStack present = stackHandler.getStackInSlot(ix);
                    if (present.m_41619_()) {
                        stackHandler.setStackInSlot(ix, stack.m_41777_());
                        if (!player.m_7500_()) {
                            int count = stack.m_41613_();
                            stack.m_41774_(count);
                        }
                        return true;
                    }
                    if (firstSlot != null) continue;
                    try {
                        Class<?> curioUnequipEventClass = Class.forName("top.theillusivec4.curios.api.event.CurioUnequipEvent");
                        Constructor<?> constructor = curioUnequipEventClass.getConstructor(ItemStack.class, SlotContext.class);
                        Object event = constructor.newInstance(stack, slotContext);
                        if (!(event instanceof Event)) continue;
                        Event unequipEvent = (Event)event;
                        MinecraftForge.EVENT_BUS.post(unequipEvent);
                        Event.Result result = unequipEvent.getResult();
                        if (result == Event.Result.DENY || stackHandler.extractItem(ix, stack.m_41741_(), true).m_41613_() != stack.m_41613_()) continue;
                        firstSlot = new Tuple((Object)stackHandler, (Object)slotContext);
                        continue;
                    }
                    catch (ClassNotFoundException | IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e) {
                        return false;
                    }
                }
            }
            if (firstSlot != null) {
                IDynamicStackHandler stackHandler = (IDynamicStackHandler)firstSlot.m_14418_();
                SlotContext slotContext = (SlotContext)firstSlot.m_14419_();
                int i = slotContext.index();
                ItemStack presentx = stackHandler.getStackInSlot(i);
                stackHandler.setStackInSlot(i, stack.m_41777_());
                player.m_21008_(hand, presentx.m_41777_());
                return true;
            }
        }
        return false;
    }
}

