/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.item.ItemStack
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.fml.loading.FMLLoader
 *  net.minecraftforge.registries.ForgeRegistries
 *  top.theillusivec4.curios.api.CuriosApi
 *  top.theillusivec4.curios.api.event.CurioAttributeModifierEvent
 *  top.theillusivec4.curios.api.type.ISlotType
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.curios;

import java.util.UUID;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.loading.FMLLoader;
import net.minecraftforge.registries.ForgeRegistries;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureResistance;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.TemperatureDataManager;
import sfiomn.legendarysurvivaloverhaul.common.integration.curios.CurioAttributeBuilder;
import sfiomn.legendarysurvivaloverhaul.registry.AttributeRegistry;
import top.theillusivec4.curios.api.CuriosApi;
import top.theillusivec4.curios.api.event.CurioAttributeModifierEvent;
import top.theillusivec4.curios.api.type.ISlotType;

public class CuriosModifier {
    public static final CurioAttributeBuilder HEATING_TEMPERATURE = new CurioAttributeBuilder((Attribute)AttributeRegistry.HEATING_TEMPERATURE.get(), "attribute.legendarysurvivaloverhaul.heating_temperature");
    public static final CurioAttributeBuilder COOLING_TEMPERATURE = new CurioAttributeBuilder((Attribute)AttributeRegistry.COOLING_TEMPERATURE.get(), "attribute.legendarysurvivaloverhaul.cooling_temperature");
    public static final CurioAttributeBuilder HEAT_RESISTANCE = new CurioAttributeBuilder((Attribute)AttributeRegistry.HEAT_RESISTANCE.get(), "attribute.legendarysurvivaloverhaul.heat_resistance");
    public static final CurioAttributeBuilder COLD_RESISTANCE = new CurioAttributeBuilder((Attribute)AttributeRegistry.COLD_RESISTANCE.get(), "attribute.legendarysurvivaloverhaul.cold_resistance");
    public static final CurioAttributeBuilder THERMAL_RESISTANCE = new CurioAttributeBuilder((Attribute)AttributeRegistry.THERMAL_RESISTANCE.get(), "attribute.legendarysurvivaloverhaul.thermal_resistance");

    public static void addAttribute(CurioAttributeModifierEvent event) {
        if (!LegendarySurvivalOverhaul.curiosLoaded) {
            return;
        }
        ResourceLocation itemRegistryName = ForgeRegistries.ITEMS.getKey((Object)event.getItemStack().m_41720_());
        JsonTemperatureResistance tempConfig = TemperatureDataManager.getItem(itemRegistryName);
        if (itemRegistryName != null && tempConfig != null) {
            for (ISlotType slot : CuriosApi.getItemStackSlots((ItemStack)event.getItemStack(), (FMLLoader.getDist() == Dist.CLIENT ? 1 : 0) != 0).values()) {
                if (!slot.getIdentifier().equals(event.getSlotContext().identifier())) continue;
                UUID itemUuid = UUID.nameUUIDFromBytes(itemRegistryName.toString().getBytes());
                HEATING_TEMPERATURE.addModifier(event, itemUuid, (double)Math.max(tempConfig.temperature, 0.0f));
                COOLING_TEMPERATURE.addModifier(event, itemUuid, (double)Math.min(tempConfig.temperature, 0.0f));
                HEAT_RESISTANCE.addModifier(event, itemUuid, (double)tempConfig.heatResistance);
                COLD_RESISTANCE.addModifier(event, itemUuid, (double)tempConfig.coldResistance);
                THERMAL_RESISTANCE.addModifier(event, itemUuid, (double)tempConfig.thermalResistance);
            }
        }
    }
}

