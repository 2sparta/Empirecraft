/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  top.theillusivec4.curios.api.event.CurioAttributeModifierEvent
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.curios;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import sfiomn.legendarysurvivaloverhaul.common.integration.curios.CuriosModifier;
import top.theillusivec4.curios.api.event.CurioAttributeModifierEvent;

public class CuriosEvents {
    @SubscribeEvent
    public static void onCurioAttributeModifierEvent(CurioAttributeModifierEvent event) {
        CuriosModifier.addAttribute(event);
    }
}

