/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  artifacts.item.UmbrellaItem
 *  javax.annotation.Nonnull
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.artifacts;

import artifacts.item.UmbrellaItem;
import javax.annotation.Nonnull;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;

public class ArtifactsUtil {
    public static boolean isHoldingUmbrella(Player player) {
        if (LegendarySurvivalOverhaul.artifactsLoaded && player != null && player.m_21093_(itemStack -> itemStack.m_41720_() instanceof UmbrellaItem)) {
            return !(player.m_21211_().m_41720_() instanceof UmbrellaItem);
        }
        return false;
    }

    public static boolean canProvideShade(@Nonnull ResourceLocation itemRegistryName) {
        return LegendarySurvivalOverhaul.artifactsLoaded && itemRegistryName.toString().equals("artifacts:umbrella");
    }
}

