/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.sereneseasons;

import com.google.gson.annotations.SerializedName;

public class SSBiomeIdentity {
    @SerializedName(value="enable_seasonal_effects")
    public boolean seasonEffects;
    @SerializedName(value="use_tropical_seasons")
    public boolean isTropical;

    public SSBiomeIdentity(boolean isTropical) {
        this(true, isTropical);
    }

    public SSBiomeIdentity(boolean seasonEffects, boolean isTropical) {
        this.seasonEffects = seasonEffects;
        this.isTropical = isTropical;
    }
}

