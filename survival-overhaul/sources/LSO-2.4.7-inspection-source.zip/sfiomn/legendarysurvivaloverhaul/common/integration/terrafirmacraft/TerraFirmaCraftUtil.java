/*
 * Decompiled with CFR 0.152.
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.terrafirmacraft;

import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.config.Config;

public class TerraFirmaCraftUtil {
    public static boolean shouldUseTerraFirmaCraftTemp() {
        return LegendarySurvivalOverhaul.terraFirmaCraftLoaded && Config.Baked.tfcTemperatureMultiplier != 0.0;
    }
}

