/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.mehvahdjukaar.supplementaries.common.items.LunchBoxItem
 *  net.mehvahdjukaar.supplementaries.common.items.forge.LunchBoxItemImpl
 *  net.minecraft.world.item.ItemStack
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.supplementaries;

import net.mehvahdjukaar.supplementaries.common.items.LunchBoxItem;
import net.mehvahdjukaar.supplementaries.common.items.forge.LunchBoxItemImpl;
import net.minecraft.world.item.ItemStack;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;

public class SupplementariesUtil {
    public static ItemStack getSelectedItemInLunchBasket(ItemStack itemStack) {
        if (LegendarySurvivalOverhaul.supplementariesLoaded && itemStack.m_41720_() instanceof LunchBoxItem) {
            return LunchBoxItemImpl.getLunchBoxData((ItemStack)itemStack).getSelected();
        }
        return ItemStack.f_41583_;
    }
}

