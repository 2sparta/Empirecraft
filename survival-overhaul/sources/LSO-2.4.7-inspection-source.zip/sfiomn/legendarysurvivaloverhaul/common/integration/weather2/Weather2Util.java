/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.weather2;

import net.minecraft.world.entity.player.Player;

public class Weather2Util {
    public static boolean isUnderWeather(Player player) {
        return true;
    }
}

