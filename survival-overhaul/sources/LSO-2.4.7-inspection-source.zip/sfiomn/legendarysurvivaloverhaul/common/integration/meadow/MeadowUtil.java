/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.BlockState
 *  net.satisfy.meadow.core.registry.ObjectRegistry
 */
package sfiomn.legendarysurvivaloverhaul.common.integration.meadow;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.satisfy.meadow.core.registry.ObjectRegistry;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;

public class MeadowUtil {
    public static boolean isInWoodenWaterCauldron(BlockState blockState) {
        return LegendarySurvivalOverhaul.meadowLoaded && blockState.m_60713_((Block)ObjectRegistry.WOODEN_WATER_CAULDRON.get());
    }
}

