/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.event.entity.player.PlayerInteractEvent$RightClickBlock
 *  net.minecraftforge.eventbus.api.EventPriority
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 */
package sfiomn.legendarysurvivaloverhaul.common.events;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.common.integration.crayfish.CrayfishFurnitureUtil;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.CanteenItem;

@Mod.EventBusSubscriber(modid="legendarysurvivaloverhaul", bus=Mod.EventBusSubscriber.Bus.FORGE)
public class CanteenInteractionHandler {
    @SubscribeEvent(priority=EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        Player player = event.getEntity();
        InteractionHand hand = event.getHand();
        ItemStack itemStack = player.m_21120_(hand);
        Level level = event.getLevel();
        Item item = itemStack.m_41720_();
        if (!(item instanceof CanteenItem)) {
            return;
        }
        CanteenItem canteenItem = (CanteenItem)item;
        if (LegendarySurvivalOverhaul.crayfishFurnitureLoaded) {
            InteractionResult fillResult = CrayfishFurnitureUtil.tryFillCanteenFromSinkOrBasin(level, event.getPos(), player, itemStack);
            if (fillResult.m_19077_()) {
                event.setCanceled(true);
                event.setCancellationResult(fillResult);
                player.m_21011_(hand, true);
                return;
            }
            InteractionResult emptyResult = CrayfishFurnitureUtil.tryEmptyCanteenIntoSinkOrBasin(level, event.getPos(), player, itemStack);
            if (emptyResult.m_19077_()) {
                event.setCanceled(true);
                event.setCancellationResult(emptyResult);
                player.m_21011_(hand, true);
                return;
            }
        }
    }
}

