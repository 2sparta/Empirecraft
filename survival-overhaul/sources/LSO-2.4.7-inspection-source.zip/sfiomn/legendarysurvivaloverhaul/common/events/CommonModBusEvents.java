/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraftforge.event.entity.EntityAttributeModificationEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 */
package sfiomn.legendarysurvivaloverhaul.common.events;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraftforge.event.entity.EntityAttributeModificationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import sfiomn.legendarysurvivaloverhaul.registry.AttributeRegistry;

@Mod.EventBusSubscriber(modid="legendarysurvivaloverhaul", bus=Mod.EventBusSubscriber.Bus.MOD)
public class CommonModBusEvents {
    @SubscribeEvent
    public static void onEntityAttributesChange(EntityAttributeModificationEvent event) {
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.HEATING_TEMPERATURE.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.HEATING_TEMPERATURE.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.COOLING_TEMPERATURE.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.COOLING_TEMPERATURE.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.HEAT_RESISTANCE.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.HEAT_RESISTANCE.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.COLD_RESISTANCE.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.COLD_RESISTANCE.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.THERMAL_RESISTANCE.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.THERMAL_RESISTANCE.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.BODY_RESISTANCE.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.BODY_RESISTANCE.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.HEAD_RESISTANCE.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.HEAD_RESISTANCE.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.CHEST_RESISTANCE.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.CHEST_RESISTANCE.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.RIGHT_ARM_RESISTANCE.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.RIGHT_ARM_RESISTANCE.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.LEFT_ARM_RESISTANCE.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.LEFT_ARM_RESISTANCE.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.LEGS_RESISTANCE.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.LEGS_RESISTANCE.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.FEET_RESISTANCE.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.FEET_RESISTANCE.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.BROKEN_HEART.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.BROKEN_HEART.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.PERMANENT_HEART.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.PERMANENT_HEART.get());
        }
        if (!event.has(EntityType.f_20532_, (Attribute)AttributeRegistry.BROKEN_HEART_RESILIENCE.get())) {
            event.add(EntityType.f_20532_, (Attribute)AttributeRegistry.BROKEN_HEART_RESILIENCE.get());
        }
    }
}

