/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.effect.MobEffectCategory
 */
package sfiomn.legendarysurvivaloverhaul.common.effects;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

public class HeatImmunityEffect
extends MobEffect {
    public HeatImmunityEffect() {
        super(MobEffectCategory.BENEFICIAL, 0xFF0C0C);
    }
}

