/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.effect.MobEffectCategory
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.effects;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.api.ModDamageTypes;
import sfiomn.legendarysurvivaloverhaul.common.effects.IncurableMobEffect;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;
import sfiomn.legendarysurvivaloverhaul.util.DifficultyUtil;

public class FrostbiteEffect
extends IncurableMobEffect {
    public FrostbiteEffect() {
        super(MobEffectCategory.HARMFUL, 9164281);
    }

    public void m_6742_(@NotNull LivingEntity entity, int amplifier) {
        if (entity instanceof Player) {
            Player player = (Player)entity;
            if (!entity.m_21023_((MobEffect)MobEffectRegistry.COLD_IMMUNITY.get()) && DifficultyUtil.isModDangerous() && DifficultyUtil.healthAboveDifficulty(player) && !player.m_5803_()) {
                ModDamageTypes.hypothermia((Entity)player, 1.0f);
            }
        }
    }

    public boolean m_6584_(int duration, int amplifier) {
        int time = 50 >> amplifier;
        return time == 0 || duration % time == 0;
    }

    public static boolean playerIsImmuneToFrost(Player player) {
        return player.m_21023_((MobEffect)MobEffectRegistry.COLD_IMMUNITY.get()) || player.m_21023_((MobEffect)MobEffectRegistry.TEMPERATURE_IMMUNITY.get());
    }
}

