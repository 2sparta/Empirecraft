/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.effect.MobEffectCategory
 *  net.minecraft.world.entity.LivingEntity
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.effects;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.config.Config;

public class RecoveryEffect
extends MobEffect {
    public RecoveryEffect() {
        super(MobEffectCategory.BENEFICIAL, 0x11CCEE);
    }

    public void m_6742_(@NotNull LivingEntity entity, int amplifier) {
        entity.m_5634_((float)Config.Baked.recoveryEffectHealingValue);
    }

    public boolean m_6584_(int duration, int amplifier) {
        int i = 50 >> amplifier;
        if (i > 0) {
            return duration % i == 0;
        }
        return true;
    }
}

