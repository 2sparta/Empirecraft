/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffectCategory
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.effects;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.common.effects.IncurableMobEffect;
import sfiomn.legendarysurvivaloverhaul.config.Config;

public class ColdHungerEffect
extends IncurableMobEffect {
    public ColdHungerEffect() {
        super(MobEffectCategory.HARMFUL, 10870382);
    }

    public void m_6742_(@NotNull LivingEntity entity, int amplifier) {
        if (entity instanceof Player) {
            ((Player)entity).m_36399_((float)(Config.Baked.coldHungerEffectModifier * (double)(amplifier + 1)));
        }
    }

    public boolean m_6584_(int duration, int amplifier) {
        int time = 50 >> amplifier;
        return time == 0 || duration % time == 0;
    }
}

