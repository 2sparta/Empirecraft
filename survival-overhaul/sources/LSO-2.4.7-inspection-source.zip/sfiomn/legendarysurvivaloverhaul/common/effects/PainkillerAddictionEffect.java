/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffectCategory
 */
package sfiomn.legendarysurvivaloverhaul.common.effects;

import net.minecraft.world.effect.MobEffectCategory;
import sfiomn.legendarysurvivaloverhaul.common.effects.IncurableMobEffect;

public class PainkillerAddictionEffect
extends IncurableMobEffect {
    public PainkillerAddictionEffect() {
        super(MobEffectCategory.HARMFUL, 14966607);
    }
}

