/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.effect.MobEffectCategory
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.effects;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.thirst.ThirstCapability;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.util.CapabilityUtil;

public class ThirstEffect
extends MobEffect {
    public ThirstEffect() {
        super(MobEffectCategory.HARMFUL, 10870382);
    }

    public void m_6742_(@NotNull LivingEntity entity, int amplifier) {
        if (entity instanceof Player) {
            ThirstCapability thirstCapability = CapabilityUtil.getThirstCapability((Player)entity);
            thirstCapability.addThirstExhaustion((float)(Config.Baked.thirstEffectModifier * (double)amplifier + 1.0));
        }
    }

    public boolean m_6584_(int duration, int amplifier) {
        int time = 50 >> amplifier;
        return time == 0 || duration % time == 0;
    }
}

