/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.EquipmentSlot
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.enchantment.Enchantment
 *  net.minecraft.world.item.enchantment.Enchantment$Rarity
 *  net.minecraft.world.item.enchantment.EnchantmentCategory
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.enchantments;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.CanteenItem;

public class RefreshingEnchantment
extends Enchantment {
    public RefreshingEnchantment() {
        super(Enchantment.Rarity.UNCOMMON, EnchantmentCategory.BREAKABLE, new EquipmentSlot[0]);
    }

    public int m_6183_(int level) {
        return 10 + (level - 1) * 10;
    }

    public int m_6175_(int level) {
        return this.m_6183_(level) + 50;
    }

    public int m_6586_() {
        return 3;
    }

    public boolean m_6081_(@NotNull ItemStack stack) {
        return stack.m_41720_() instanceof CanteenItem;
    }

    public boolean canApplyAtEnchantingTable(ItemStack stack) {
        return stack.m_41720_() instanceof CanteenItem;
    }

    public boolean isAllowedOnBooks() {
        return true;
    }
}

