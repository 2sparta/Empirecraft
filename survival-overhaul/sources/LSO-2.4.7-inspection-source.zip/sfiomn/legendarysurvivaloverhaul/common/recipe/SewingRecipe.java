/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  net.minecraft.core.RegistryAccess
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.GsonHelper
 *  net.minecraft.world.SimpleContainer
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.crafting.Ingredient
 *  net.minecraft.world.item.crafting.Recipe
 *  net.minecraft.world.item.crafting.RecipeSerializer
 *  net.minecraft.world.item.crafting.RecipeType
 *  net.minecraft.world.item.crafting.ShapedRecipe
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.common.recipe;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.core.RegistryAccess;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.ShapedRecipe;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class SewingRecipe
implements Recipe<SimpleContainer> {
    private final Ingredient base;
    private final Ingredient addition;
    private final ItemStack result;
    private final ResourceLocation id;

    public SewingRecipe(Ingredient base, Ingredient addition, ItemStack result, ResourceLocation id) {
        this.base = base;
        this.addition = addition;
        this.result = result;
        this.id = id;
    }

    public Ingredient getBase() {
        return this.base;
    }

    public Ingredient getAddition() {
        return this.addition;
    }

    public boolean matches(@NotNull SimpleContainer simpleContainer, Level level) {
        if (level.f_46443_) {
            return false;
        }
        return this.base.test(simpleContainer.m_8020_(0)) && this.addition.test(simpleContainer.m_8020_(1));
    }

    @NotNull
    public ItemStack assemble(@NotNull SimpleContainer simpleContainer, @NotNull RegistryAccess registryAccess) {
        ItemStack itemstack = this.result.m_41777_();
        CompoundTag compoundTag = simpleContainer.m_8020_(0).m_41783_();
        if (compoundTag != null) {
            itemstack.m_41751_(compoundTag.m_6426_());
        }
        return itemstack;
    }

    public boolean m_8004_(int i, int i1) {
        return true;
    }

    @NotNull
    public ItemStack m_8043_(@NotNull RegistryAccess registryAccess) {
        return this.result.m_41777_();
    }

    public ResourceLocation m_6423_() {
        return this.id;
    }

    public RecipeSerializer<?> m_7707_() {
        return Serializer.INSTANCE;
    }

    public RecipeType<?> m_6671_() {
        return Type.INSTANCE;
    }

    public static class Serializer
    implements RecipeSerializer<SewingRecipe> {
        public static final Serializer INSTANCE = new Serializer();
        public static final ResourceLocation ID = new ResourceLocation("legendarysurvivaloverhaul", "sewing");

        @NotNull
        public SewingRecipe fromJson(@NotNull ResourceLocation recipeId, @NotNull JsonObject jsonObject) {
            Ingredient base = Ingredient.m_43917_((JsonElement)GsonHelper.m_13930_((JsonObject)jsonObject, (String)"base"));
            Ingredient addition = Ingredient.m_43917_((JsonElement)GsonHelper.m_13930_((JsonObject)jsonObject, (String)"addition"));
            ItemStack result = ShapedRecipe.m_151274_((JsonObject)GsonHelper.m_13930_((JsonObject)jsonObject, (String)"result"));
            return new SewingRecipe(base, addition, result, recipeId);
        }

        @Nullable
        public SewingRecipe fromNetwork(ResourceLocation recipeId, FriendlyByteBuf friendlyByteBuf) {
            Ingredient base = Ingredient.m_43940_((FriendlyByteBuf)friendlyByteBuf);
            Ingredient addition = Ingredient.m_43940_((FriendlyByteBuf)friendlyByteBuf);
            ItemStack result = friendlyByteBuf.m_130267_();
            return new SewingRecipe(base, addition, result, recipeId);
        }

        public void toNetwork(FriendlyByteBuf friendlyByteBuf, SewingRecipe sewingRecipe) {
            sewingRecipe.base.m_43923_(friendlyByteBuf);
            sewingRecipe.addition.m_43923_(friendlyByteBuf);
            friendlyByteBuf.m_130055_(sewingRecipe.result);
        }
    }

    public static class Type
    implements RecipeType<SewingRecipe> {
        public static final Type INSTANCE = new Type();
        public static final ResourceLocation ID = new ResourceLocation("legendarysurvivaloverhaul", "sewing");
    }
}

