/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.NonNullList
 *  net.minecraft.core.RegistryAccess
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.inventory.CraftingContainer
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.ShearsItem
 *  net.minecraft.world.item.crafting.CraftingBookCategory
 *  net.minecraft.world.item.crafting.CustomRecipe
 *  net.minecraft.world.item.crafting.RecipeSerializer
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.recipe;

import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShearsItem;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureUtil;
import sfiomn.legendarysurvivaloverhaul.common.containers.SewingTableContainer;
import sfiomn.legendarysurvivaloverhaul.registry.RecipeRegistry;

public class RemoveCoatRecipe
extends CustomRecipe {
    public RemoveCoatRecipe(ResourceLocation id, CraftingBookCategory category) {
        super(id, category);
    }

    public boolean matches(@NotNull CraftingContainer craftingContainer, @NotNull Level level) {
        int armorSlot = -1;
        int shearsSlot = -1;
        for (int i = 0; i < craftingContainer.m_6643_(); ++i) {
            ItemStack stack = craftingContainer.m_8020_(i);
            if (stack.m_41619_()) continue;
            if (stack.m_41720_() instanceof ShearsItem) {
                if (shearsSlot != -1) {
                    return false;
                }
                shearsSlot = i;
                continue;
            }
            if (SewingTableContainer.isItemArmor(stack) && !TemperatureUtil.getArmorCoatTag(stack).isEmpty()) {
                if (armorSlot != -1) {
                    return false;
                }
                armorSlot = i;
                continue;
            }
            return false;
        }
        return armorSlot != -1 && shearsSlot != -1;
    }

    @NotNull
    public ItemStack assemble(@NotNull CraftingContainer craftingContainer, @NotNull RegistryAccess registryAccess) {
        for (int i = 0; i < craftingContainer.m_6643_(); ++i) {
            ItemStack stack = craftingContainer.m_8020_(i);
            if (stack.m_41619_() || !SewingTableContainer.isItemArmor(stack) || TemperatureUtil.getArmorCoatTag(stack).isEmpty()) continue;
            ItemStack result = stack.m_41777_();
            result.m_41764_(1);
            TemperatureUtil.removeArmorCoatTag(result);
            return result;
        }
        return ItemStack.f_41583_;
    }

    public boolean m_8004_(int width, int height) {
        return width * height >= 2;
    }

    @NotNull
    public NonNullList<ItemStack> getRemainingItems(@NotNull CraftingContainer craftingContainer) {
        NonNullList remaining = NonNullList.m_122780_((int)craftingContainer.m_6643_(), (Object)ItemStack.f_41583_);
        RandomSource random = RandomSource.m_216327_();
        for (int i = 0; i < craftingContainer.m_6643_(); ++i) {
            ItemStack stack = craftingContainer.m_8020_(i);
            if (!(stack.m_41720_() instanceof ShearsItem)) continue;
            ItemStack shears = stack.m_41777_();
            if (shears.m_220157_(1, random, null)) {
                shears = ItemStack.f_41583_;
            }
            remaining.set(i, (Object)shears);
        }
        return remaining;
    }

    @NotNull
    public RecipeSerializer<?> m_7707_() {
        return (RecipeSerializer)RecipeRegistry.REMOVE_COAT_SERIALIZER.get();
    }
}

