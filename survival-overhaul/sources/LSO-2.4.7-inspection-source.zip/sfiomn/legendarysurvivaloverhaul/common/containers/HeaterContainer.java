/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.world.entity.player.Inventory
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.inventory.ContainerData
 *  net.minecraft.world.inventory.ContainerLevelAccess
 *  net.minecraft.world.inventory.SimpleContainerData
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.entity.BlockEntity
 */
package sfiomn.legendarysurvivaloverhaul.common.containers;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import sfiomn.legendarysurvivaloverhaul.api.block.ThermalTypeEnum;
import sfiomn.legendarysurvivaloverhaul.common.blockentities.AbstractThermalBlockEntity;
import sfiomn.legendarysurvivaloverhaul.common.containers.AbstractThermalContainer;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.ContainerRegistry;

public class HeaterContainer
extends AbstractThermalContainer {
    public HeaterContainer(int windowId, Inventory playerInventory, BlockEntity be, ContainerData dataAccess) {
        super(windowId, playerInventory, (AbstractThermalBlockEntity)be, dataAccess, ContainerRegistry.HEATER_CONTAINER, ThermalTypeEnum.HEATING);
    }

    public HeaterContainer(int windowId, Inventory playerInv, FriendlyByteBuf data) {
        this(windowId, playerInv, playerInv.f_35978_.m_9236_().m_7702_(data.m_130135_()), (ContainerData)new SimpleContainerData(2));
    }

    public boolean m_6875_(Player player) {
        return HeaterContainer.m_38889_((ContainerLevelAccess)ContainerLevelAccess.m_39289_((Level)this.level, (BlockPos)this.blockEntity.m_58899_()), (Player)player, (Block)((Block)BlockRegistry.HEATER.get()));
    }
}

