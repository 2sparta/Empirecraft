/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.Container
 *  net.minecraft.world.entity.player.Inventory
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.inventory.AbstractContainerMenu
 *  net.minecraft.world.inventory.ContainerData
 *  net.minecraft.world.inventory.MenuType
 *  net.minecraft.world.inventory.Slot
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.common.capabilities.ForgeCapabilities
 *  net.minecraftforge.items.IItemHandler
 *  net.minecraftforge.items.SlotItemHandler
 *  net.minecraftforge.registries.RegistryObject
 */
package sfiomn.legendarysurvivaloverhaul.common.containers;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.SlotItemHandler;
import net.minecraftforge.registries.RegistryObject;
import sfiomn.legendarysurvivaloverhaul.api.block.ThermalTypeEnum;
import sfiomn.legendarysurvivaloverhaul.common.blockentities.AbstractThermalBlockEntity;

public abstract class AbstractThermalContainer
extends AbstractContainerMenu {
    public final AbstractThermalBlockEntity blockEntity;
    public final ThermalTypeEnum thermalType;
    public final Level level;
    public final ContainerData dataAccess;

    public AbstractThermalContainer(int windowId, Inventory playerInventory, AbstractThermalBlockEntity be, ContainerData dataAccess, RegistryObject<MenuType<AbstractThermalContainer>> registryObject, ThermalTypeEnum thermalType) {
        super((MenuType)registryObject.get(), windowId);
        AbstractThermalContainer.m_38869_((Container)playerInventory, (int)4);
        this.thermalType = thermalType;
        this.blockEntity = be;
        this.level = playerInventory.f_35978_.m_9236_();
        this.dataAccess = dataAccess;
        this.layoutPlayerInventorySlots(playerInventory, 8, 84);
        this.blockEntity.getCapability(ForgeCapabilities.ITEM_HANDLER).ifPresent(iItemHandler -> {
            this.m_38897_((Slot)this.addThermalSlot((IItemHandler)iItemHandler, 0, 14, 32));
            this.m_38897_((Slot)this.addThermalSlot((IItemHandler)iItemHandler, 1, 34, 32));
            this.m_38897_((Slot)this.addThermalSlot((IItemHandler)iItemHandler, 2, 14, 52));
            this.m_38897_((Slot)this.addThermalSlot((IItemHandler)iItemHandler, 3, 34, 52));
        });
        this.m_38884_(dataAccess);
    }

    private SlotItemHandler addThermalSlot(final IItemHandler ih, final int index, int posX, int posY) {
        return new SlotItemHandler(ih, index, posX, posY){

            public boolean m_5857_(ItemStack stack) {
                return ih.isItemValid(index, stack);
            }
        };
    }

    public ThermalTypeEnum getThermalType() {
        return this.thermalType;
    }

    @OnlyIn(value=Dist.CLIENT)
    public boolean isPowered() {
        return this.blockEntity.isPowered();
    }

    @OnlyIn(value=Dist.CLIENT)
    public float getFuelTimeScale() {
        if (this.dataAccess.m_6413_(1) != 0) {
            return (float)this.dataAccess.m_6413_(0) / (float)this.dataAccess.m_6413_(1);
        }
        return 0.0f;
    }

    private int addSlotRange(Inventory playerInventory, int index, int x, int y, int amount, int dx) {
        for (int i = 0; i < amount; ++i) {
            this.m_38897_(new Slot((Container)playerInventory, index, x, y));
            x += dx;
            ++index;
        }
        return index;
    }

    private int addSlotBox(Inventory playerInventory, int index, int x, int y, int horAmount, int dx, int verAmount, int dy) {
        for (int j = 0; j < verAmount; ++j) {
            index = this.addSlotRange(playerInventory, index, x, y, horAmount, dx);
            y += dy;
        }
        return index;
    }

    private void layoutPlayerInventorySlots(Inventory playerInventory, int leftCol, int topRow) {
        int lastIndex = this.addSlotRange(playerInventory, 0, leftCol, topRow + 58, 9, 18);
        this.addSlotBox(playerInventory, lastIndex, leftCol, topRow, 9, 18, 3, 18);
    }

    public ItemStack m_7648_(Player player, int index) {
        ItemStack itemstack = ItemStack.f_41583_;
        Slot slot = (Slot)this.f_38839_.get(index);
        if (slot != null && slot.m_6657_()) {
            ItemStack itemstack1 = slot.m_7993_();
            itemstack = itemstack1.m_41777_();
            if (index < 4) {
                if (!this.m_38903_(itemstack1, 13, this.f_38839_.size(), false)) {
                    return ItemStack.f_41583_;
                }
            } else if (index < this.f_38839_.size()) {
                if (this.blockEntity.isItemValid(itemstack1.m_41720_()) ? !this.m_38903_(itemstack1, 0, 4, false) : (index < 13 ? !this.m_38903_(itemstack1, 13, this.f_38839_.size(), false) : !this.m_38903_(itemstack1, 4, 13, false))) {
                    return ItemStack.f_41583_;
                }
            } else {
                return ItemStack.f_41583_;
            }
            if (itemstack1.m_41619_()) {
                slot.m_5852_(ItemStack.f_41583_);
            } else {
                slot.m_6654_();
            }
            if (itemstack1.m_41613_() == itemstack.m_41613_()) {
                return ItemStack.f_41583_;
            }
            slot.m_142406_(player, itemstack1);
        }
        return itemstack;
    }
}

