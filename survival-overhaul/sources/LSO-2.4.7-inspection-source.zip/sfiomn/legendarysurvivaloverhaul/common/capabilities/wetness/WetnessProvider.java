/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Direction
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraftforge.common.capabilities.Capability
 *  net.minecraftforge.common.capabilities.CapabilityManager
 *  net.minecraftforge.common.capabilities.CapabilityToken
 *  net.minecraftforge.common.capabilities.ICapabilityProvider
 *  net.minecraftforge.common.capabilities.ICapabilitySerializable
 *  net.minecraftforge.common.util.LazyOptional
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.capabilities.wetness;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.wetness.WetnessCapability;

public class WetnessProvider
implements ICapabilityProvider,
ICapabilitySerializable<CompoundTag> {
    public static Capability<WetnessCapability> WETNESS_CAPABILITY = CapabilityManager.get((CapabilityToken)new CapabilityToken<WetnessCapability>(){});
    private final LazyOptional<WetnessCapability> instance = LazyOptional.of(this::getInstance);
    private WetnessCapability wetnessCapability = null;

    private WetnessCapability getInstance() {
        if (this.wetnessCapability == null) {
            this.wetnessCapability = new WetnessCapability();
        }
        return this.wetnessCapability;
    }

    public <T> LazyOptional<T> getCapability(@NotNull Capability<T> capability, Direction side) {
        if (capability == WETNESS_CAPABILITY) {
            return this.instance.cast();
        }
        return LazyOptional.empty();
    }

    public CompoundTag serializeNBT() {
        return this.getInstance().writeNBT();
    }

    public void deserializeNBT(CompoundTag tag) {
        this.getInstance().readNBT(tag);
    }
}

