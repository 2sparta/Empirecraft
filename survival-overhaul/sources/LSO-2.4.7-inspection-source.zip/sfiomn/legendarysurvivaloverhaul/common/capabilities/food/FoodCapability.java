/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.phys.Vec3
 *  net.minecraftforge.event.TickEvent$Phase
 */
package sfiomn.legendarysurvivaloverhaul.common.capabilities.food;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import sfiomn.legendarysurvivaloverhaul.api.food.IFoodCapability;
import sfiomn.legendarysurvivaloverhaul.config.Config;

public class FoodCapability
implements IFoodCapability {
    private Vec3 oldPos;
    private boolean wasSprinting;
    private int updateTickTimer;

    public FoodCapability() {
        this.init();
    }

    public void init() {
        this.oldPos = null;
        this.updateTickTimer = 0;
        this.wasSprinting = false;
    }

    @Override
    public void tickUpdate(Player player, Level world, TickEvent.Phase phase) {
        if (phase == TickEvent.Phase.START) {
            return;
        }
        if (this.oldPos == null) {
            this.oldPos = player.m_20182_();
        }
        ++this.updateTickTimer;
        if (this.updateTickTimer >= 10) {
            this.updateTickTimer = 0;
            if (this.oldPos.m_82554_(player.m_20182_()) > 1.0) {
                float foodExhausted = player.m_20142_() && this.wasSprinting ? (float)Config.Baked.sprintingFoodExhaustion : (player.m_20142_() || this.wasSprinting ? (float)((Config.Baked.sprintingFoodExhaustion + Config.Baked.baseFoodExhaustion) / 2.0) : (float)Config.Baked.baseFoodExhaustion);
                player.m_36324_().m_38703_(foodExhausted);
                this.oldPos = player.m_20182_();
                this.wasSprinting = player.m_20142_();
            }
        }
    }
}

