/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Direction
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraftforge.common.capabilities.Capability
 *  net.minecraftforge.common.capabilities.CapabilityManager
 *  net.minecraftforge.common.capabilities.CapabilityToken
 *  net.minecraftforge.common.capabilities.ICapabilityProvider
 *  net.minecraftforge.common.capabilities.ICapabilitySerializable
 *  net.minecraftforge.common.util.LazyOptional
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.common.capabilities.temperature;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.temperature.TemperatureCapability;

public class TemperatureProvider
implements ICapabilityProvider,
ICapabilitySerializable<CompoundTag> {
    public static Capability<TemperatureCapability> TEMPERATURE_CAPABILITY = CapabilityManager.get((CapabilityToken)new CapabilityToken<TemperatureCapability>(){});
    private final LazyOptional<TemperatureCapability> instance = LazyOptional.of(this::getInstance);
    private TemperatureCapability temperatureCapability = null;

    private TemperatureCapability getInstance() {
        if (this.temperatureCapability == null) {
            this.temperatureCapability = new TemperatureCapability();
        }
        return this.temperatureCapability;
    }

    @NotNull
    public <T> LazyOptional<T> getCapability(@NotNull Capability<T> capability, @Nullable Direction direction) {
        if (capability == TEMPERATURE_CAPABILITY) {
            return this.instance.cast();
        }
        return LazyOptional.empty();
    }

    public CompoundTag serializeNBT() {
        return this.getInstance().writeNBT();
    }

    public void deserializeNBT(CompoundTag tag) {
        this.getInstance().readNBT(tag);
    }
}

