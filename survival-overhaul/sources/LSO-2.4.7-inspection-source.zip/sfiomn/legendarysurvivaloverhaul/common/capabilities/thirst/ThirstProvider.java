/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Direction
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraftforge.common.capabilities.Capability
 *  net.minecraftforge.common.capabilities.CapabilityManager
 *  net.minecraftforge.common.capabilities.CapabilityToken
 *  net.minecraftforge.common.capabilities.ICapabilityProvider
 *  net.minecraftforge.common.capabilities.ICapabilitySerializable
 *  net.minecraftforge.common.util.LazyOptional
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.capabilities.thirst;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.thirst.ThirstCapability;

public class ThirstProvider
implements ICapabilityProvider,
ICapabilitySerializable<CompoundTag> {
    public static Capability<ThirstCapability> THIRST_CAPABILITY = CapabilityManager.get((CapabilityToken)new CapabilityToken<ThirstCapability>(){});
    private final LazyOptional<ThirstCapability> instance = LazyOptional.of(this::getInstance);
    private ThirstCapability thirstCapability = null;

    private ThirstCapability getInstance() {
        if (this.thirstCapability == null) {
            this.thirstCapability = new ThirstCapability();
        }
        return this.thirstCapability;
    }

    public <T> LazyOptional<T> getCapability(@NotNull Capability<T> capability, Direction side) {
        if (capability == THIRST_CAPABILITY) {
            return this.instance.cast();
        }
        return LazyOptional.empty();
    }

    public CompoundTag serializeNBT() {
        return this.getInstance().writeNBT();
    }

    public void deserializeNBT(CompoundTag tag) {
        this.getInstance().readNBT(tag);
    }
}

