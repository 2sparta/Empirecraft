/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Direction
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraftforge.common.capabilities.Capability
 *  net.minecraftforge.common.capabilities.CapabilityManager
 *  net.minecraftforge.common.capabilities.CapabilityToken
 *  net.minecraftforge.common.capabilities.ICapabilityProvider
 *  net.minecraftforge.common.capabilities.ICapabilitySerializable
 *  net.minecraftforge.common.util.LazyOptional
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.common.capabilities.bodydamage;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.bodydamage.BodyDamageCapability;

public class BodyDamageProvider
implements ICapabilityProvider,
ICapabilitySerializable<CompoundTag> {
    public static Capability<BodyDamageCapability> BODY_DAMAGE_CAPABILITY = CapabilityManager.get((CapabilityToken)new CapabilityToken<BodyDamageCapability>(){});
    private final LazyOptional<BodyDamageCapability> instance = LazyOptional.of(this::getInstance);
    private BodyDamageCapability bodyDamageCapability = null;

    private BodyDamageCapability getInstance() {
        if (this.bodyDamageCapability == null) {
            this.bodyDamageCapability = new BodyDamageCapability();
        }
        return this.bodyDamageCapability;
    }

    @NotNull
    public <T> LazyOptional<T> getCapability(@NotNull Capability<T> capability, @Nullable Direction direction) {
        if (capability == BODY_DAMAGE_CAPABILITY) {
            return this.instance.cast();
        }
        return LazyOptional.empty();
    }

    public CompoundTag serializeNBT() {
        return this.getInstance().writeNBT();
    }

    public void deserializeNBT(CompoundTag nbt) {
        this.getInstance().readNBT(nbt);
    }
}

