/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  net.minecraft.commands.CommandSourceStack
 */
package sfiomn.legendarysurvivaloverhaul.common.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;

public class CommandBase {
    CommandSourceStack source;
    LiteralArgumentBuilder<CommandSourceStack> builder;

    public CommandBase(LiteralArgumentBuilder<CommandSourceStack> builder) {
        this.builder = builder;
    }

    public LiteralArgumentBuilder<CommandSourceStack> getBuilder() {
        return this.builder;
    }

    public int get(CommandSourceStack source) throws CommandSyntaxException {
        return 1;
    }

    public int get(CommandSourceStack source, String[] args) throws CommandSyntaxException {
        return 1;
    }
}

