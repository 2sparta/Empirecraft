/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.arguments.FloatArgumentType
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.builder.RequiredArgumentBuilder
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraft.commands.Commands
 *  net.minecraft.commands.arguments.EntityArgument
 *  net.minecraft.network.chat.Component
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraftforge.server.command.EnumArgument
 */
package sfiomn.legendarysurvivaloverhaul.common.commands;

import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Collection;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.server.command.EnumArgument;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyPartEnum;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.bodydamage.BodyDamageCapability;
import sfiomn.legendarysurvivaloverhaul.common.commands.CommandBase;
import sfiomn.legendarysurvivaloverhaul.util.CapabilityUtil;

public class BodyDamageCommand
extends CommandBase {
    public BodyDamageCommand() {
        super((LiteralArgumentBuilder<CommandSourceStack>)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.m_82127_((String)"bodydamage").requires(p_198521_0_ -> p_198521_0_.m_6761_(2))).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.m_82129_((String)"target", (ArgumentType)EntityArgument.m_91460_()).then(((LiteralArgumentBuilder)Commands.m_82127_((String)"set").then(Commands.m_82129_((String)"BodyPart", (ArgumentType)EnumArgument.enumArgument(BodyPartEnum.class)).then(Commands.m_82129_((String)"Health", (ArgumentType)FloatArgumentType.floatArg((float)0.0f)).executes(src -> new BodyDamageCommand().set((CommandSourceStack)src.getSource(), EntityArgument.m_91461_((CommandContext)src, (String)"target"), (BodyPartEnum)((Object)((Object)src.getArgument("BodyPart", BodyPartEnum.class))), FloatArgumentType.getFloat((CommandContext)src, (String)"Health")))))).then(Commands.m_82127_((String)"ALL").then(Commands.m_82129_((String)"Health", (ArgumentType)FloatArgumentType.floatArg((float)0.0f)).executes(src -> new BodyDamageCommand().setAll((CommandSourceStack)src.getSource(), EntityArgument.m_91461_((CommandContext)src, (String)"target"), FloatArgumentType.getFloat((CommandContext)src, (String)"Health"))))))).then(((LiteralArgumentBuilder)Commands.m_82127_((String)"heal").then(Commands.m_82129_((String)"BodyPart", (ArgumentType)EnumArgument.enumArgument(BodyPartEnum.class)).then(Commands.m_82129_((String)"Health", (ArgumentType)FloatArgumentType.floatArg((float)0.0f)).executes(src -> new BodyDamageCommand().heal((CommandSourceStack)src.getSource(), EntityArgument.m_91461_((CommandContext)src, (String)"target"), (BodyPartEnum)((Object)((Object)src.getArgument("BodyPart", BodyPartEnum.class))), FloatArgumentType.getFloat((CommandContext)src, (String)"Health")))))).then(Commands.m_82127_((String)"ALL").then(Commands.m_82129_((String)"Health", (ArgumentType)FloatArgumentType.floatArg((float)0.0f)).executes(src -> new BodyDamageCommand().healAll((CommandSourceStack)src.getSource(), EntityArgument.m_91461_((CommandContext)src, (String)"target"), FloatArgumentType.getFloat((CommandContext)src, (String)"Health"))))))).then(((LiteralArgumentBuilder)Commands.m_82127_((String)"get").then(Commands.m_82129_((String)"BodyPart", (ArgumentType)EnumArgument.enumArgument(BodyPartEnum.class)).executes(src -> new BodyDamageCommand().get((CommandSourceStack)src.getSource(), EntityArgument.m_91461_((CommandContext)src, (String)"target"), (BodyPartEnum)((Object)((Object)src.getArgument("BodyPart", BodyPartEnum.class))))))).then(Commands.m_82127_((String)"ALL").executes(src -> new BodyDamageCommand().getAll((CommandSourceStack)src.getSource(), EntityArgument.m_91461_((CommandContext)src, (String)"target"))))))));
    }

    public int get(CommandSourceStack source, Collection<? extends Entity> entities, BodyPartEnum bodyPart) {
        try {
            StringBuilder reply = new StringBuilder();
            for (Entity entity : entities) {
                if (!(entity instanceof Player)) continue;
                Player player = (Player)entity;
                if (!(source.m_81373_() instanceof Player)) continue;
                BodyDamageCapability cap = CapabilityUtil.getBodyDamageCapability(player);
                float bodyPartMaxHealth = cap.getBodyPartMaxHealth(bodyPart);
                float bodyPartHealth = bodyPartMaxHealth - cap.getBodyPartDamage(bodyPart);
                reply.append("Player ").append(player.m_7755_().getString()).append("\n").append("Body Limb ").append(bodyPart.name()).append(" Health : ").append(bodyPartHealth).append("/").append(bodyPartMaxHealth).append("\n");
                source.m_288197_(() -> Component.m_237113_((String)reply.toString()), false);
            }
        }
        catch (Exception e) {
            LegendarySurvivalOverhaul.LOGGER.error(e.getMessage());
        }
        return 1;
    }

    public int getAll(CommandSourceStack source, Collection<? extends Entity> entities) {
        try {
            StringBuilder reply = new StringBuilder();
            for (Entity entity : entities) {
                if (!(entity instanceof Player)) continue;
                Player player = (Player)entity;
                if (!(source.m_81373_() instanceof Player)) continue;
                BodyDamageCapability cap = CapabilityUtil.getBodyDamageCapability(player);
                reply.append("Player ").append(player.m_7755_().getString()).append("\n");
                for (BodyPartEnum bodyPart : BodyPartEnum.values()) {
                    float bodyPartMaxHealth = cap.getBodyPartMaxHealth(bodyPart);
                    float bodyPartHealth = bodyPartMaxHealth - cap.getBodyPartDamage(bodyPart);
                    reply.append("Body Limb ").append(bodyPart.name()).append(" Health : ").append(bodyPartHealth).append("/").append(bodyPartMaxHealth).append("\n");
                }
                source.m_288197_(() -> Component.m_237113_((String)reply.toString()), false);
            }
        }
        catch (Exception e) {
            LegendarySurvivalOverhaul.LOGGER.error(e.getMessage());
        }
        return 1;
    }

    private int set(CommandSourceStack src, Collection<? extends Entity> entities, BodyPartEnum bodyPart, float healthValue) throws CommandSyntaxException {
        for (Entity entity : entities) {
            if (!(entity instanceof Player)) continue;
            Player player = (Player)entity;
            BodyDamageCapability cap = CapabilityUtil.getBodyDamageCapability(player);
            cap.setBodyPartDamage(bodyPart, cap.getBodyPartMaxHealth(bodyPart) - healthValue);
        }
        return 1;
    }

    private int setAll(CommandSourceStack src, Collection<? extends Entity> entities, float healthValue) throws CommandSyntaxException {
        for (Entity entity : entities) {
            if (!(entity instanceof Player)) continue;
            Player player = (Player)entity;
            BodyDamageCapability cap = CapabilityUtil.getBodyDamageCapability(player);
            for (BodyPartEnum bodyPart : BodyPartEnum.values()) {
                cap.setBodyPartDamage(bodyPart, cap.getBodyPartMaxHealth(bodyPart) - healthValue);
            }
        }
        return 1;
    }

    private int heal(CommandSourceStack src, Collection<? extends Entity> entities, BodyPartEnum bodyPart, float healthValue) throws CommandSyntaxException {
        for (Entity entity : entities) {
            if (!(entity instanceof Player)) continue;
            Player player = (Player)entity;
            BodyDamageCapability cap = CapabilityUtil.getBodyDamageCapability(player);
            cap.setBodyPartDamage(bodyPart, cap.getBodyPartDamage(bodyPart) - healthValue);
        }
        return 1;
    }

    private int healAll(CommandSourceStack src, Collection<? extends Entity> entities, float healthValue) throws CommandSyntaxException {
        for (Entity entity : entities) {
            if (!(entity instanceof Player)) continue;
            Player player = (Player)entity;
            BodyDamageCapability cap = CapabilityUtil.getBodyDamageCapability(player);
            for (BodyPartEnum bodyPart : BodyPartEnum.values()) {
                cap.setBodyPartDamage(bodyPart, cap.getBodyPartDamage(bodyPart) - healthValue);
            }
        }
        return 1;
    }
}

