/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.arguments.IntegerArgumentType
 *  com.mojang.brigadier.arguments.StringArgumentType
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.context.CommandContext
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraft.commands.Commands
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Holder$Reference
 *  net.minecraft.core.Registry
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.network.chat.Component
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.level.WorldGenLevel
 *  net.minecraft.world.level.levelgen.Heightmap$Types
 *  net.minecraft.world.level.levelgen.feature.ConfiguredFeature
 */
package sfiomn.legendarysurvivaloverhaul.common.commands;

import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.common.commands.CommandBase;
import sfiomn.legendarysurvivaloverhaul.common.level.gen.ModConfiguredFeatures;

public class FernTestCommand
extends CommandBase {
    public FernTestCommand() {
        super((LiteralArgumentBuilder<CommandSourceStack>)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.m_82127_((String)"lso").requires(p_198521_0_ -> p_198521_0_.m_6761_(2))).then(Commands.m_82127_((String)"fernpatch").then(Commands.m_82129_((String)"type", (ArgumentType)StringArgumentType.word()).then(Commands.m_82129_((String)"radius", (ArgumentType)IntegerArgumentType.integer((int)1, (int)256)).then(Commands.m_82129_((String)"attempts", (ArgumentType)IntegerArgumentType.integer((int)1, (int)10000)).executes(ctx -> new FernTestCommand().spawnFernPatches((CommandSourceStack)ctx.getSource(), StringArgumentType.getString((CommandContext)ctx, (String)"type"), IntegerArgumentType.getInteger((CommandContext)ctx, (String)"radius"), IntegerArgumentType.getInteger((CommandContext)ctx, (String)"attempts")))))))));
    }

    private int spawnFernPatches(CommandSourceStack source, String type, int radius, int attempts) {
        try {
            Holder.Reference feature;
            ServerLevel level = source.m_81372_();
            if (source.m_81373_() == null) {
                return 1;
            }
            Registry registry = level.m_9598_().m_175515_(Registries.f_256911_);
            if (type.equalsIgnoreCase("ice")) {
                feature = registry.m_246971_(ModConfiguredFeatures.ICE_FERN_CONFIG_KEY);
            } else if (type.equalsIgnoreCase("sun")) {
                feature = registry.m_246971_(ModConfiguredFeatures.SUN_FERN_CONFIG_KEY);
            } else {
                source.m_81352_((Component)Component.m_237113_((String)("Unknown type: " + type + " (use: ice | sun)")));
                return 1;
            }
            RandomSource random = level.m_213780_();
            BlockPos center = source.m_81373_().m_20183_();
            int placed = 0;
            for (int i = 0; i < attempts; ++i) {
                int dx = random.m_188503_(radius * 2 + 1) - radius;
                int dz = random.m_188503_(radius * 2 + 1) - radius;
                int x = center.m_123341_() + dx;
                int z = center.m_123343_() + dz;
                int y = level.m_6924_(Heightmap.Types.WORLD_SURFACE, x, z);
                BlockPos origin = new BlockPos(x, y, z);
                if (!((ConfiguredFeature)feature.m_203334_()).m_224953_((WorldGenLevel)level, level.m_7726_().m_8481_(), random, origin)) continue;
                ++placed;
            }
            int finalPlaced = placed;
            source.m_288197_(() -> Component.m_237113_((String)("Placed " + finalPlaced + " fern patches (type=" + type + ") within radius " + radius)), false);
        }
        catch (Exception e) {
            LegendarySurvivalOverhaul.LOGGER.error(e.getMessage());
        }
        return 1;
    }
}

