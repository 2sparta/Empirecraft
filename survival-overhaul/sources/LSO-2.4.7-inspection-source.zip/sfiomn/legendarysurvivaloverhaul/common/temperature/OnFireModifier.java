/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.common.temperature;

import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.api.temperature.ModifierBase;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureImmunityEnum;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureUtil;
import sfiomn.legendarysurvivaloverhaul.config.Config;

public class OnFireModifier
extends ModifierBase {
    @Override
    public float getPlayerInfluence(Player player) {
        if (player.m_20094_() > 0 && !TemperatureUtil.hasImmunity(player, TemperatureImmunityEnum.ON_FIRE)) {
            return (float)Config.Baked.onFireModifier;
        }
        return 0.0f;
    }
}

