/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.common.temperature;

import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.api.temperature.ModifierBase;
import sfiomn.legendarysurvivaloverhaul.config.Config;

public class SprintModifier
extends ModifierBase {
    @Override
    public float getPlayerInfluence(Player player) {
        if (player.m_20142_()) {
            return (float)Config.Baked.sprintModifier;
        }
        return 0.0f;
    }
}

