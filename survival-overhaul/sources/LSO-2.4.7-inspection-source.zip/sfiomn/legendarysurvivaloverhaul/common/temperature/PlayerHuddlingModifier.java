/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.ai.targeting.TargetingConditions
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.phys.AABB
 */
package sfiomn.legendarysurvivaloverhaul.common.temperature;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import sfiomn.legendarysurvivaloverhaul.api.temperature.ModifierBase;
import sfiomn.legendarysurvivaloverhaul.config.Config;

public class PlayerHuddlingModifier
extends ModifierBase {
    @Override
    public float getPlayerInfluence(Player player) {
        if (Config.Baked.playerHuddlingRadius == 0 || Config.Baked.playerHuddlingModifier == 0.0) {
            return 0.0f;
        }
        Level world = player.m_20193_();
        BlockPos pos = player.m_20183_();
        int huddleRadius = Config.Baked.playerHuddlingRadius;
        AABB bounds = new AABB(pos.m_7918_(-huddleRadius, -huddleRadius, -huddleRadius), pos.m_7918_(huddleRadius, huddleRadius, huddleRadius));
        List players = world.m_45955_(TargetingConditions.f_26872_, (LivingEntity)player, bounds);
        int playerCount = 0;
        for (Player p : players) {
            if (p.m_7500_() || p.m_5833_()) continue;
            ++playerCount;
        }
        return (float)((double)playerCount * Config.Baked.playerHuddlingModifier);
    }
}

