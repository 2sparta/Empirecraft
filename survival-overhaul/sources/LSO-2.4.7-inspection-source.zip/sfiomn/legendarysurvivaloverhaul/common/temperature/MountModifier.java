/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraftforge.registries.ForgeRegistries
 */
package sfiomn.legendarysurvivaloverhaul.common.temperature;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.registries.ForgeRegistries;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureResistance;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.TemperatureDataManager;
import sfiomn.legendarysurvivaloverhaul.api.temperature.ModifierBase;

public class MountModifier
extends ModifierBase {
    @Override
    public float getPlayerInfluence(Player player) {
        if (player.m_20202_() != null) {
            return this.processMountJson(player.m_20202_());
        }
        return 0.0f;
    }

    private float processMountJson(Entity entity) {
        ResourceLocation entityRegistryName = ForgeRegistries.ENTITY_TYPES.getKey((Object)entity.m_6095_());
        JsonTemperatureResistance jsonTemperature = TemperatureDataManager.getMount(entityRegistryName);
        if (jsonTemperature != null) {
            return jsonTemperature.temperature;
        }
        return 0.0f;
    }
}

