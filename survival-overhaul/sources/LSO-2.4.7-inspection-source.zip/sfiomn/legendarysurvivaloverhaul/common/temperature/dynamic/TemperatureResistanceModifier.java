/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.common.temperature.dynamic;

import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureResistance;
import sfiomn.legendarysurvivaloverhaul.api.temperature.DynamicModifierBase;
import sfiomn.legendarysurvivaloverhaul.registry.AttributeRegistry;

public class TemperatureResistanceModifier
extends DynamicModifierBase {
    @Override
    public float applyDynamicPlayerInfluence(Player player, float currentTemperature, float currentResistance) {
        JsonTemperatureResistance jsonTemperatureResistance = new JsonTemperatureResistance();
        if (player.m_21204_().m_22171_((Attribute)AttributeRegistry.THERMAL_RESISTANCE.get())) {
            jsonTemperatureResistance.thermalResistance = (float)player.m_21133_((Attribute)AttributeRegistry.THERMAL_RESISTANCE.get());
        }
        if (player.m_21204_().m_22171_((Attribute)AttributeRegistry.HEAT_RESISTANCE.get())) {
            jsonTemperatureResistance.heatResistance = (float)player.m_21133_((Attribute)AttributeRegistry.HEAT_RESISTANCE.get());
        }
        if (player.m_21204_().m_22171_((Attribute)AttributeRegistry.COLD_RESISTANCE.get())) {
            jsonTemperatureResistance.coldResistance = (float)player.m_21133_((Attribute)AttributeRegistry.COLD_RESISTANCE.get());
        }
        return this.getEffectiveResistance(currentTemperature, currentResistance, jsonTemperatureResistance);
    }
}

