/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraftforge.registries.ForgeRegistries
 */
package sfiomn.legendarysurvivaloverhaul.common.temperature.dynamic;

import java.util.Objects;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.registries.ForgeRegistries;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureResistance;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.TemperatureDataManager;
import sfiomn.legendarysurvivaloverhaul.api.temperature.DynamicModifierBase;

public class MountDynamicModifier
extends DynamicModifierBase {
    @Override
    public float applyDynamicPlayerInfluence(Player player, float currentTemperature, float currentResistance) {
        if (player.m_20202_() == null) {
            return 0.0f;
        }
        return this.getEffectiveResistance(currentTemperature, currentResistance, this.processMountJson(player.m_20202_()));
    }

    private JsonTemperatureResistance processMountJson(Entity entity) {
        ResourceLocation entityRegistryName = ForgeRegistries.ENTITY_TYPES.getKey((Object)entity.m_6095_());
        JsonTemperatureResistance jsonTemperatureResistance = TemperatureDataManager.getMount(entityRegistryName);
        return Objects.requireNonNullElseGet(jsonTemperatureResistance, JsonTemperatureResistance::new);
    }
}

