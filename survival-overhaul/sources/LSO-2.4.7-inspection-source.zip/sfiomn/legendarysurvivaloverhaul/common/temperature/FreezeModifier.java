/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.common.temperature;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.api.temperature.ModifierBase;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.util.CapabilityUtil;

public class FreezeModifier
extends ModifierBase {
    @Override
    public float getPlayerInfluence(Player player) {
        if (Config.Baked.maxFreezeTemperatureModifier == 0.0) {
            return 0.0f;
        }
        int freezeTickTimer = CapabilityUtil.getTempCapability(player).getFreezeTickTimer();
        if (freezeTickTimer > 0) {
            return (float)Mth.m_14139_((double)Math.min((double)freezeTickTimer / (double)Config.Baked.maxFreezeEffectTick, 1.0), (double)0.0, (double)Config.Baked.maxFreezeTemperatureModifier);
        }
        return 0.0f;
    }
}

