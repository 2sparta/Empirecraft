/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.ItemStack
 */
package sfiomn.legendarysurvivaloverhaul.common.temperature.attribute;

import net.minecraft.world.item.ItemStack;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureResistance;
import sfiomn.legendarysurvivaloverhaul.api.item.CoatEnum;
import sfiomn.legendarysurvivaloverhaul.api.temperature.AttributeModifierBase;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureUtil;

public class CoatAttributeModifier
extends AttributeModifierBase {
    @Override
    public JsonTemperatureResistance getItemAttributes(ItemStack stack) {
        CoatEnum coat;
        JsonTemperatureResistance config = new JsonTemperatureResistance();
        if (!TemperatureUtil.getArmorCoatTag(stack).isEmpty() && (coat = CoatEnum.getFromId(TemperatureUtil.getArmorCoatTag(stack))) != null) {
            if (coat.type().equals("cooling")) {
                config.heatResistance += (float)coat.modifier();
            }
            if (coat.type().equals("heating")) {
                config.coldResistance += (float)coat.modifier();
            }
            if (coat.type().equals("thermal")) {
                config.thermalResistance += (float)coat.modifier();
            }
        }
        return config;
    }
}

