/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.common.temperature;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureDimension;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.TemperatureDataManager;
import sfiomn.legendarysurvivaloverhaul.api.temperature.ModifierBase;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureImmunityEnum;
import sfiomn.legendarysurvivaloverhaul.api.temperature.TemperatureUtil;
import sfiomn.legendarysurvivaloverhaul.common.integration.terrafirmacraft.TerraFirmaCraftUtil;
import sfiomn.legendarysurvivaloverhaul.config.Config;

public class AltitudeModifier
extends ModifierBase {
    @Override
    public float getWorldInfluence(@Nullable Player player, Level level, BlockPos pos) {
        JsonTemperatureDimension dimensionTemperature = TemperatureDataManager.getDimension(level.m_46472_().m_135782_());
        if (dimensionTemperature == null || !dimensionTemperature.hasAltitude || TerraFirmaCraftUtil.shouldUseTerraFirmaCraftTemp()) {
            return 0.0f;
        }
        float altitudeDiff = (float)(pos.m_123342_() - dimensionTemperature.seaLevelHeight) / 64.0f;
        if (player != null && altitudeDiff > 0.0f && TemperatureUtil.hasImmunity(player, TemperatureImmunityEnum.HIGH_ALTITUDE)) {
            return 0.0f;
        }
        return Math.abs(altitudeDiff) * (float)Config.Baked.altitudeModifier;
    }
}

