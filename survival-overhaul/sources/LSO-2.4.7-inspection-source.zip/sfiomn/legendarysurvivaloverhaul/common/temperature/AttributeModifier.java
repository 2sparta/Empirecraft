/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.common.temperature;

import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.api.temperature.ModifierBase;
import sfiomn.legendarysurvivaloverhaul.registry.AttributeRegistry;

public class AttributeModifier
extends ModifierBase {
    @Override
    public float getPlayerInfluence(Player player) {
        return (float)(player.m_21133_((Attribute)AttributeRegistry.HEATING_TEMPERATURE.get()) + player.m_21133_((Attribute)AttributeRegistry.COOLING_TEMPERATURE.get()));
    }
}

