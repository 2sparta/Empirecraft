/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.biome.Biome
 */
package sfiomn.legendarysurvivaloverhaul.common.temperature;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonTemperatureDimension;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.TemperatureDataManager;
import sfiomn.legendarysurvivaloverhaul.api.temperature.ModifierBase;
import sfiomn.legendarysurvivaloverhaul.common.integration.eclipticseasons.EclipticSeasonsUtil;
import sfiomn.legendarysurvivaloverhaul.common.integration.terrafirmacraft.TerraFirmaCraftUtil;
import sfiomn.legendarysurvivaloverhaul.config.Config;

public class TimeModifier
extends ModifierBase {
    @Override
    public float getWorldInfluence(Player player, Level level, BlockPos pos) {
        int timeCycleTicks;
        JsonTemperatureDimension jsonTemperatureDimension = TemperatureDataManager.getDimension(level.m_46472_().m_135782_());
        int n = timeCycleTicks = jsonTemperatureDimension != null ? jsonTemperatureDimension.temperatureTimeCycleTicks : 0;
        if (timeCycleTicks == 0 || TerraFirmaCraftUtil.shouldUseTerraFirmaCraftTemp()) {
            return 0.0f;
        }
        long time = level.m_6106_().m_6792_();
        double timeAngle = (double)(time * 2L) * Math.PI / (double)timeCycleTicks;
        if (EclipticSeasonsUtil.hasDimensionSeason(level)) {
            long sunRiseTime = EclipticSeasonsUtil.getSunRiseTime(level);
            int dayDuration = EclipticSeasonsUtil.getDayDuration(level);
            long sunSetTime = sunRiseTime + (long)dayDuration;
            timeAngle = time > sunRiseTime && time < sunSetTime % (long)timeCycleTicks ? Math.PI / (double)dayDuration * (double)((time - sunRiseTime) % (long)timeCycleTicks) : -(Math.PI / (double)(timeCycleTicks - dayDuration)) * (double)((time - sunSetTime) % (long)timeCycleTicks);
        }
        float timeTemperature = (float)Math.sin(timeAngle) * (float)Config.Baked.timeModifier;
        float biomeMultiplier = 1.0f + Math.abs(this.normalizeToPositiveNegative(this.getNormalizedTempForBiome(level, (Biome)level.m_204166_(pos).get()))) * ((float)Config.Baked.biomeTimeMultiplier - 1.0f);
        return this.applyUndergroundEffect(timeTemperature *= biomeMultiplier, level, pos, 0.0f);
    }
}

