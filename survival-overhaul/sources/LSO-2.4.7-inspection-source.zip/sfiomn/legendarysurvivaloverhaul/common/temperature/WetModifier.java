/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 */
package sfiomn.legendarysurvivaloverhaul.common.temperature;

import net.minecraft.world.entity.player.Player;
import sfiomn.legendarysurvivaloverhaul.api.temperature.ModifierBase;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.wetness.WetnessCapability;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.util.CapabilityUtil;
import sfiomn.legendarysurvivaloverhaul.util.MathUtil;

public class WetModifier
extends ModifierBase {
    @Override
    public float getPlayerInfluence(Player player) {
        if (Config.Baked.wetnessEnabled) {
            WetnessCapability wetCap = CapabilityUtil.getWetnessCapability(player);
            if (wetCap.getWetness() == 0) {
                return 0.0f;
            }
            return (float)(Config.Baked.wetMultiplier * (double)MathUtil.invLerp(0.0f, 400.0f, wetCap.getWetness()));
        }
        return 0.0f;
    }
}

