/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.data.worldgen.BootstapContext
 *  net.minecraft.data.worldgen.features.FeatureUtils
 *  net.minecraft.data.worldgen.placement.PlacementUtils
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate
 *  net.minecraft.world.level.levelgen.feature.ConfiguredFeature
 *  net.minecraft.world.level.levelgen.feature.Feature
 *  net.minecraft.world.level.levelgen.feature.configurations.FeatureConfiguration
 *  net.minecraft.world.level.levelgen.feature.configurations.RandomPatchConfiguration
 *  net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration
 *  net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider
 */
package sfiomn.legendarysurvivaloverhaul.common.level.gen;

import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstapContext;
import net.minecraft.data.worldgen.features.FeatureUtils;
import net.minecraft.data.worldgen.placement.PlacementUtils;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.FeatureConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.RandomPatchConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration;
import net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider;
import sfiomn.legendarysurvivaloverhaul.common.blocks.IceFernBlock;
import sfiomn.legendarysurvivaloverhaul.common.blocks.SunFernBlock;
import sfiomn.legendarysurvivaloverhaul.common.blocks.WaterPlantBlock;
import sfiomn.legendarysurvivaloverhaul.common.level.feature.DoubleBlockFeature;
import sfiomn.legendarysurvivaloverhaul.common.level.feature.GoldFernFeature;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.FeatureRegistry;

public class ModConfiguredFeatures {
    public static final ResourceKey<ConfiguredFeature<?, ?>> ICE_FERN_CONFIG_KEY = ModConfiguredFeatures.registerKey("ice_fern_config_feature");
    public static final ResourceKey<ConfiguredFeature<?, ?>> SUN_FERN_CONFIG_KEY = ModConfiguredFeatures.registerKey("sun_fern_config_feature");
    public static final ResourceKey<ConfiguredFeature<?, ?>> WATER_PLANT_CONFIG_KEY = ModConfiguredFeatures.registerKey("water_plant_config_feature");

    public static ResourceKey<ConfiguredFeature<?, ?>> registerKey(String name) {
        return ResourceKey.m_135785_((ResourceKey)Registries.f_256911_, (ResourceLocation)new ResourceLocation("legendarysurvivaloverhaul", name));
    }

    public static void registerSimpleRandomPatchConfig(BootstapContext<ConfiguredFeature<?, ?>> context, ResourceKey<ConfiguredFeature<?, ?>> resourceKey, BlockState blockState) {
        FeatureUtils.m_254977_(context, resourceKey, (Feature)Feature.f_65763_, (FeatureConfiguration)new RandomPatchConfiguration(5, 5, 3, PlacementUtils.m_206498_((Feature)((GoldFernFeature)((Object)FeatureRegistry.GOLD_FERN.get())), (FeatureConfiguration)new SimpleBlockConfiguration((BlockStateProvider)BlockStateProvider.m_191384_((BlockState)blockState)), (BlockPredicate)BlockPredicate.m_190419_())));
    }

    public static void registerDoubleRandomPatchConfig(BootstapContext<ConfiguredFeature<?, ?>> context, ResourceKey<ConfiguredFeature<?, ?>> resourceKey, BlockState blockState) {
        FeatureUtils.m_254977_(context, resourceKey, (Feature)Feature.f_65763_, (FeatureConfiguration)new RandomPatchConfiguration(10, 5, 3, PlacementUtils.m_206498_((Feature)((DoubleBlockFeature)((Object)FeatureRegistry.DOUBLE_BLOCK.get())), (FeatureConfiguration)new SimpleBlockConfiguration((BlockStateProvider)BlockStateProvider.m_191384_((BlockState)blockState)), (BlockPredicate)BlockPredicate.m_190419_())));
    }

    public static void bootstrap(BootstapContext<ConfiguredFeature<?, ?>> context) {
        ModConfiguredFeatures.registerSimpleRandomPatchConfig(context, ICE_FERN_CONFIG_KEY, (BlockState)((Block)BlockRegistry.ICE_FERN_CROP.get()).m_49966_().m_61124_((Property)IceFernBlock.AGE, (Comparable)Integer.valueOf(3)));
        ModConfiguredFeatures.registerSimpleRandomPatchConfig(context, SUN_FERN_CONFIG_KEY, (BlockState)((Block)BlockRegistry.SUN_FERN_CROP.get()).m_49966_().m_61124_((Property)SunFernBlock.AGE, (Comparable)Integer.valueOf(3)));
        ModConfiguredFeatures.registerDoubleRandomPatchConfig(context, WATER_PLANT_CONFIG_KEY, (BlockState)((Block)BlockRegistry.WATER_PLANT_CROP.get()).m_49966_().m_61124_((Property)WaterPlantBlock.AGE, (Comparable)Integer.valueOf(7)));
    }
}

