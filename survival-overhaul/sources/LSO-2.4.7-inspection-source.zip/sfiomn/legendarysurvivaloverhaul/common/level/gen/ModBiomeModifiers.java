/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Holder
 *  net.minecraft.core.HolderGetter
 *  net.minecraft.core.HolderSet
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.data.worldgen.BootstapContext
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.level.levelgen.GenerationStep$Decoration
 *  net.minecraftforge.common.Tags$Biomes
 *  net.minecraftforge.common.world.BiomeModifier
 *  net.minecraftforge.common.world.ForgeBiomeModifiers$AddFeaturesBiomeModifier
 *  net.minecraftforge.registries.ForgeRegistries$Keys
 */
package sfiomn.legendarysurvivaloverhaul.common.level.gen;

import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstapContext;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraftforge.common.Tags;
import net.minecraftforge.common.world.BiomeModifier;
import net.minecraftforge.common.world.ForgeBiomeModifiers;
import net.minecraftforge.registries.ForgeRegistries;
import sfiomn.legendarysurvivaloverhaul.common.level.gen.ModPlacedFeatures;

public class ModBiomeModifiers {
    public static final ResourceKey<BiomeModifier> ADD_ICE_FERN = ModBiomeModifiers.registerKey("add_ice_fern");
    public static final ResourceKey<BiomeModifier> ADD_SUN_FERN = ModBiomeModifiers.registerKey("add_sun_fern");
    public static final ResourceKey<BiomeModifier> ADD_WATER_PLANT = ModBiomeModifiers.registerKey("add_water_plant");

    public static ResourceKey<BiomeModifier> registerKey(String name) {
        return ResourceKey.m_135785_((ResourceKey)ForgeRegistries.Keys.BIOME_MODIFIERS, (ResourceLocation)new ResourceLocation("legendarysurvivaloverhaul", name));
    }

    public static void bootstrap(BootstapContext<BiomeModifier> context) {
        HolderGetter placedFeatures = context.m_255420_(Registries.f_256988_);
        HolderGetter biomes = context.m_255420_(Registries.f_256952_);
        context.m_255272_(ADD_ICE_FERN, (Object)new ForgeBiomeModifiers.AddFeaturesBiomeModifier((HolderSet)biomes.m_254956_(Tags.Biomes.IS_COLD_OVERWORLD), (HolderSet)HolderSet.m_205809_((Holder[])new Holder[]{placedFeatures.m_255043_(ModPlacedFeatures.ICE_FERN_PLACED_KEY)}), GenerationStep.Decoration.VEGETAL_DECORATION));
        context.m_255272_(ADD_SUN_FERN, (Object)new ForgeBiomeModifiers.AddFeaturesBiomeModifier((HolderSet)biomes.m_254956_(Tags.Biomes.IS_HOT_OVERWORLD), (HolderSet)HolderSet.m_205809_((Holder[])new Holder[]{placedFeatures.m_255043_(ModPlacedFeatures.SUN_FERN_PLACED_KEY)}), GenerationStep.Decoration.VEGETAL_DECORATION));
        context.m_255272_(ADD_WATER_PLANT, (Object)new ForgeBiomeModifiers.AddFeaturesBiomeModifier((HolderSet)biomes.m_254956_(Tags.Biomes.IS_HOT_OVERWORLD), (HolderSet)HolderSet.m_205809_((Holder[])new Holder[]{placedFeatures.m_255043_(ModPlacedFeatures.WATER_PLANT_PLACED_KEY)}), GenerationStep.Decoration.VEGETAL_DECORATION));
    }
}

