/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Holder
 *  net.minecraft.core.HolderGetter
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.data.worldgen.BootstapContext
 *  net.minecraft.data.worldgen.placement.PlacementUtils
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.valueproviders.IntProvider
 *  net.minecraft.util.valueproviders.UniformInt
 *  net.minecraft.world.level.levelgen.placement.BiomeFilter
 *  net.minecraft.world.level.levelgen.placement.CountPlacement
 *  net.minecraft.world.level.levelgen.placement.PlacedFeature
 *  net.minecraft.world.level.levelgen.placement.PlacementModifier
 *  net.minecraft.world.level.levelgen.placement.RarityFilter
 */
package sfiomn.legendarysurvivaloverhaul.common.level.gen;

import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstapContext;
import net.minecraft.data.worldgen.placement.PlacementUtils;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.levelgen.placement.BiomeFilter;
import net.minecraft.world.level.levelgen.placement.CountPlacement;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.placement.PlacementModifier;
import net.minecraft.world.level.levelgen.placement.RarityFilter;
import sfiomn.legendarysurvivaloverhaul.common.level.gen.ModConfiguredFeatures;

public class ModPlacedFeatures {
    public static final ResourceKey<PlacedFeature> ICE_FERN_PLACED_KEY = ModPlacedFeatures.registerKey("ice_fern_placed");
    public static final ResourceKey<PlacedFeature> SUN_FERN_PLACED_KEY = ModPlacedFeatures.registerKey("sun_fern_placed");
    public static final ResourceKey<PlacedFeature> WATER_PLANT_PLACED_KEY = ModPlacedFeatures.registerKey("water_plant_placed");

    public static ResourceKey<PlacedFeature> registerKey(String name) {
        return ResourceKey.m_135785_((ResourceKey)Registries.f_256988_, (ResourceLocation)new ResourceLocation("legendarysurvivaloverhaul", name));
    }

    public static List<PlacementModifier> worldSurfaceWithCountAndChance(int minCount, int maxCount, int chanceOnceEvery) {
        return List.of(RarityFilter.m_191900_((int)chanceOnceEvery), PlacementUtils.f_195354_, BiomeFilter.m_191561_(), CountPlacement.m_191630_((IntProvider)UniformInt.m_146622_((int)minCount, (int)maxCount)));
    }

    public static void bootstrap(BootstapContext<PlacedFeature> context) {
        HolderGetter configuredFeatures = context.m_255420_(Registries.f_256911_);
        PlacementUtils.m_254943_(context, ICE_FERN_PLACED_KEY, (Holder)configuredFeatures.m_255043_(ModConfiguredFeatures.ICE_FERN_CONFIG_KEY), ModPlacedFeatures.worldSurfaceWithCountAndChance(4, 7, 20));
        PlacementUtils.m_254943_(context, SUN_FERN_PLACED_KEY, (Holder)configuredFeatures.m_255043_(ModConfiguredFeatures.SUN_FERN_CONFIG_KEY), ModPlacedFeatures.worldSurfaceWithCountAndChance(4, 7, 20));
        PlacementUtils.m_254943_(context, WATER_PLANT_PLACED_KEY, (Holder)configuredFeatures.m_255043_(ModConfiguredFeatures.WATER_PLANT_CONFIG_KEY), ModPlacedFeatures.worldSurfaceWithCountAndChance(3, 5, 20));
    }
}

