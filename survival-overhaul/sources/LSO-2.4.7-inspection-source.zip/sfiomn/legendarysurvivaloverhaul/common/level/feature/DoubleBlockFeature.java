/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.core.BlockPos
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.WorldGenLevel
 *  net.minecraft.world.level.block.DoublePlantBlock
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.levelgen.feature.Feature
 *  net.minecraft.world.level.levelgen.feature.FeaturePlaceContext
 *  net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration
 */
package sfiomn.legendarysurvivaloverhaul.common.level.feature;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration;

public class DoubleBlockFeature
extends Feature<SimpleBlockConfiguration> {
    public DoubleBlockFeature(Codec<SimpleBlockConfiguration> codec) {
        super(codec);
    }

    public boolean m_142674_(FeaturePlaceContext<SimpleBlockConfiguration> context) {
        SimpleBlockConfiguration config = (SimpleBlockConfiguration)context.m_159778_();
        WorldGenLevel level = context.m_159774_();
        BlockPos pos = context.m_159777_();
        BlockState state = config.f_68069_().m_213972_(context.m_225041_(), pos);
        if (state.m_60710_((LevelReader)level, pos)) {
            if (!level.m_46859_(pos.m_7494_())) {
                return false;
            }
            DoublePlantBlock.m_153173_((LevelAccessor)level, (BlockState)state, (BlockPos)pos, (int)2);
            return true;
        }
        return false;
    }
}

