/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.core.BlockPos
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.WorldGenLevel
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.levelgen.feature.Feature
 *  net.minecraft.world.level.levelgen.feature.FeaturePlaceContext
 *  net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration
 */
package sfiomn.legendarysurvivaloverhaul.common.level.feature;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.registry.BlockRegistry;

public class GoldFernFeature
extends Feature<SimpleBlockConfiguration> {
    public GoldFernFeature(Codec<SimpleBlockConfiguration> codec) {
        super(codec);
    }

    public boolean m_142674_(FeaturePlaceContext<SimpleBlockConfiguration> context) {
        SimpleBlockConfiguration config = (SimpleBlockConfiguration)context.m_159778_();
        WorldGenLevel level = context.m_159774_();
        BlockPos pos = context.m_159777_();
        BlockState state = config.f_68069_().m_213972_(context.m_225041_(), pos);
        if ((double)context.m_225041_().m_188501_() < Config.Baked.goldFernChance) {
            if (state.m_60713_((Block)BlockRegistry.ICE_FERN_CROP.get())) {
                state = ((Block)BlockRegistry.ICE_FERN_GOLD.get()).m_49966_();
            } else if (state.m_60713_((Block)BlockRegistry.SUN_FERN_CROP.get())) {
                state = ((Block)BlockRegistry.SUN_FERN_GOLD.get()).m_49966_();
            }
        }
        if (!state.m_60710_((LevelReader)level, pos)) {
            return false;
        }
        level.m_7731_(pos, state, 2);
        return true;
    }
}

