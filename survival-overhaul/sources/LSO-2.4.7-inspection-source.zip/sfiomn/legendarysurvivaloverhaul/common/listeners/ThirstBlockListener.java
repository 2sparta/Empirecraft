/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonElement
 *  com.mojang.serialization.DataResult
 *  com.mojang.serialization.DynamicOps
 *  com.mojang.serialization.JsonOps
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.packs.resources.ResourceManager
 *  net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener
 *  net.minecraft.util.profiling.ProfilerFiller
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.material.FluidState
 *  net.minecraftforge.fml.ModList
 *  net.minecraftforge.network.PacketDistributor$PacketTarget
 *  net.minecraftforge.registries.ForgeRegistries
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.listeners;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonThirstBlock;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.IThirstBlockManager;
import sfiomn.legendarysurvivaloverhaul.network.packets.SyncThirstBlocksPacket;

public class ThirstBlockListener
extends SimpleJsonResourceReloadListener
implements IThirstBlockManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Map<ResourceLocation, List<JsonThirstBlock>> THIRST_BLOCKS = new HashMap<ResourceLocation, List<JsonThirstBlock>>();

    public ThirstBlockListener() {
        super(GSON, "legendarysurvivaloverhaul/thirst/blocks");
    }

    protected void apply(@NotNull Map<ResourceLocation, JsonElement> resourceLocationJsonElementMap, @NotNull ResourceManager resourceManager, @NotNull ProfilerFiller profilerFiller) {
        THIRST_BLOCKS.clear();
        resourceLocationJsonElementMap.forEach((key, json) -> {
            try {
                DataResult parsedJson = JsonThirstBlock.LIST_CODEC.parse((DynamicOps)JsonOps.INSTANCE, json);
                List parsedThirstBlocks = (List)parsedJson.getOrThrow(false, error -> LegendarySurvivalOverhaul.LOGGER.error("Failed parsing thirst block : {}", error));
                if (ModList.get().isLoaded(key.m_135827_())) {
                    THIRST_BLOCKS.put((ResourceLocation)key, parsedThirstBlocks);
                }
            }
            catch (Exception error2) {
                LegendarySurvivalOverhaul.LOGGER.error("Failed to parse thirst block json {}", key);
            }
        });
        LegendarySurvivalOverhaul.LOGGER.info("Loaded {} thirst blocks", (Object)THIRST_BLOCKS.size());
    }

    public static void sendDataToClient(PacketDistributor.PacketTarget packetTarget) {
        SyncThirstBlocksPacket.sendTo(packetTarget, THIRST_BLOCKS);
    }

    public static void acceptServerThirstBlocks(Map<ResourceLocation, List<JsonThirstBlock>> thirstBlocks) {
        THIRST_BLOCKS.clear();
        THIRST_BLOCKS.putAll(thirstBlocks);
    }

    @Override
    public List<JsonThirstBlock> get(ResourceLocation resourceLocation) {
        return THIRST_BLOCKS.get(resourceLocation);
    }

    @Override
    public JsonThirstBlock get(BlockState block) {
        List<JsonThirstBlock> jsonThirstBlocks = null;
        JsonThirstBlock defaultJct = null;
        ResourceLocation blockRegistryName = ForgeRegistries.BLOCKS.getKey((Object)block.m_60734_());
        if (blockRegistryName != null) {
            jsonThirstBlocks = THIRST_BLOCKS.get(blockRegistryName);
        }
        if (jsonThirstBlocks != null) {
            for (JsonThirstBlock jtb : jsonThirstBlocks) {
                if (jtb.matchesState(block)) {
                    return jtb;
                }
                if (!jtb.isDefault()) continue;
                defaultJct = jtb;
            }
        }
        return defaultJct;
    }

    @Override
    public JsonThirstBlock get(FluidState fluid) {
        List<JsonThirstBlock> jsonThirstBlocks = null;
        JsonThirstBlock defaultJct = null;
        ResourceLocation fluidRegistryName = ForgeRegistries.FLUIDS.getKey((Object)fluid.m_76152_());
        if (fluidRegistryName != null) {
            jsonThirstBlocks = THIRST_BLOCKS.get(fluidRegistryName);
        }
        if (jsonThirstBlocks != null) {
            for (JsonThirstBlock jtb : jsonThirstBlocks) {
                if (jtb.matchesState(fluid)) {
                    return jtb;
                }
                if (!jtb.isDefault()) continue;
                defaultJct = jtb;
            }
        }
        return defaultJct;
    }
}

