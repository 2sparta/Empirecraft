/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.nbt.ListTag
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.item.EnchantedBookItem
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.item.enchantment.Enchantment
 *  net.minecraft.world.item.enchantment.EnchantmentHelper
 *  net.minecraftforge.event.AnvilUpdateEvent
 *  net.minecraftforge.event.GrindstoneEvent$OnPlaceItem
 *  net.minecraftforge.eventbus.api.EventPriority
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 *  net.minecraftforge.registries.ForgeRegistries
 */
package sfiomn.legendarysurvivaloverhaul.common.listeners;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraftforge.event.AnvilUpdateEvent;
import net.minecraftforge.event.GrindstoneEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.CanteenItem;
import sfiomn.legendarysurvivaloverhaul.registry.EnchantmentRegistry;

@Mod.EventBusSubscriber(modid="legendarysurvivaloverhaul", bus=Mod.EventBusSubscriber.Bus.FORGE)
public class EnchantmentListener {
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void onAnvilUpdate(AnvilUpdateEvent event) {
        boolean rightHasPurity;
        ItemStack left = event.getLeft();
        ItemStack right = event.getRight();
        int leftPurity = EnchantmentHelper.m_44843_((Enchantment)((Enchantment)EnchantmentRegistry.PURITY.get()), (ItemStack)left);
        int rightPurity = EnchantmentHelper.m_44843_((Enchantment)((Enchantment)EnchantmentRegistry.PURITY.get()), (ItemStack)right);
        boolean leftHasPurity = leftPurity > 0 || EnchantmentListener.stackHasPurityOnBook(left);
        boolean bl = rightHasPurity = rightPurity > 0 || EnchantmentListener.stackHasPurityOnBook(right);
        LegendarySurvivalOverhaul.LOGGER.debug("AnvilUpdateEvent: side={}, left={}, right={}, leftPurity={}, rightPurity={}, leftHasPurityBook={}, rightHasPurityBook={}", (Object)(event.getPlayer() != null ? (event.getPlayer().m_9236_().f_46443_ ? "client" : "server") : "unknown"), (Object)(left.m_41619_() ? "empty" : left.m_41720_().m_5524_()), (Object)(right.m_41619_() ? "empty" : right.m_41720_().m_5524_()), (Object)leftPurity, (Object)rightPurity, (Object)EnchantmentListener.stackHasPurityOnBook(left), (Object)EnchantmentListener.stackHasPurityOnBook(right));
        if (event.getPlayer() == null || event.getPlayer().m_9236_().f_46443_) {
            return;
        }
        if (!left.m_41619_() && left.m_41720_() instanceof CanteenItem && leftPurity == 0 && rightHasPurity) {
            CanteenItem.onPurityApplied(left);
            LegendarySurvivalOverhaul.LOGGER.debug("Purified LEFT canteen via anvil (book on right)");
        }
        if (!right.m_41619_() && right.m_41720_() instanceof CanteenItem && rightPurity == 0 && leftHasPurity) {
            CanteenItem.onPurityApplied(right);
            LegendarySurvivalOverhaul.LOGGER.debug("Purified RIGHT canteen via anvil (book on left)");
        }
    }

    private static boolean stackHasPurityOnBook(ItemStack stack) {
        if (stack.m_41619_() || stack.m_41720_() != Items.f_42690_) {
            return false;
        }
        ListTag listtag = EnchantedBookItem.m_41163_((ItemStack)stack);
        if (listtag == null) {
            return false;
        }
        ResourceLocation purityId = ForgeRegistries.ENCHANTMENTS.getKey((Object)((Enchantment)EnchantmentRegistry.PURITY.get()));
        if (purityId == null) {
            return false;
        }
        for (int i = 0; i < listtag.size(); ++i) {
            CompoundTag tag = listtag.m_128728_(i);
            String id = tag.m_128461_("id");
            if (!purityId.toString().equals(id)) continue;
            return tag.m_128448_("lvl") > 0;
        }
        return false;
    }

    @SubscribeEvent
    public static void onGrindstone(GrindstoneEvent.OnPlaceItem event) {
        int purityLevel;
        ItemStack topItem = event.getTopItem();
        ItemStack bottomItem = event.getBottomItem();
        if (!(topItem.m_41720_() instanceof CanteenItem) || (purityLevel = EnchantmentHelper.m_44843_((Enchantment)((Enchantment)EnchantmentRegistry.PURITY.get()), (ItemStack)topItem)) > 0) {
            // empty if block
        }
        if (!(bottomItem.m_41720_() instanceof CanteenItem) || (purityLevel = EnchantmentHelper.m_44843_((Enchantment)((Enchantment)EnchantmentRegistry.PURITY.get()), (ItemStack)bottomItem)) > 0) {
            // empty if block
        }
    }
}

