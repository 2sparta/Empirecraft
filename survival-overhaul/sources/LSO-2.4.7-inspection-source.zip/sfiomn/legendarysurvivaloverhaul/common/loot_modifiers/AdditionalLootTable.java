/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Suppliers
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  com.mojang.serialization.codecs.RecordCodecBuilder$Instance
 *  it.unimi.dsi.fastutil.objects.ObjectArrayList
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.storage.loot.LootContext
 *  net.minecraft.world.level.storage.loot.LootTable
 *  net.minecraft.world.level.storage.loot.predicates.LootItemCondition
 *  net.minecraftforge.common.loot.IGlobalLootModifier
 *  net.minecraftforge.common.loot.LootModifier
 */
package sfiomn.legendarysurvivaloverhaul.common.loot_modifiers;

import com.google.common.base.Suppliers;
import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;

public class AdditionalLootTable
extends LootModifier {
    public static final Supplier<Codec<AdditionalLootTable>> CODEC = Suppliers.memoize(() -> RecordCodecBuilder.create(instance -> AdditionalLootTable.codecStart((RecordCodecBuilder.Instance)instance).and((App)ResourceLocation.f_135803_.fieldOf("lootTable").forGetter(m -> m.lootTable)).and((App)Codec.BOOL.optionalFieldOf("replace", (Object)false).forGetter(m -> m.replace)).apply((Applicative)instance, AdditionalLootTable::new)));
    private final ResourceLocation lootTable;
    private final boolean replace;

    public AdditionalLootTable(LootItemCondition[] conditions, ResourceLocation lootTable, boolean replace) {
        super(conditions);
        this.lootTable = lootTable;
        this.replace = replace;
    }

    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> generatedLoot, LootContext context) {
        if (this.replace) {
            generatedLoot.clear();
        }
        ServerLevel level = context.m_78952_();
        context.m_278643_().m_278676_(this.lootTable).m_79131_(context, LootTable.m_246283_((ServerLevel)level, arg_0 -> generatedLoot.add(arg_0)));
        LegendarySurvivalOverhaul.LOGGER.debug((Object)context.m_278643_().m_278676_(this.lootTable).getLootTableId());
        LegendarySurvivalOverhaul.LOGGER.debug("gen loot : " + String.valueOf(generatedLoot));
        return generatedLoot;
    }

    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC.get();
    }
}

