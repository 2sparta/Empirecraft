/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.Item$Properties
 */
package sfiomn.legendarysurvivaloverhaul.common.items.drink;

import net.minecraft.world.item.Item;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.BottledDrinkItem;

public class JuiceItem
extends BottledDrinkItem {
    public JuiceItem(Item.Properties properties) {
        super(properties);
    }
}

