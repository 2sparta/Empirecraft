/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.network.protocol.Packet
 *  net.minecraft.network.protocol.game.ClientboundSoundPacket
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.util.Mth
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.context.UseOnContext
 *  net.minecraft.world.item.enchantment.Enchantment
 *  net.minecraft.world.item.enchantment.EnchantmentHelper
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.LayeredCauldronBlock
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.gameevent.GameEvent
 *  net.minecraft.world.level.material.FluidState
 *  net.minecraft.world.phys.BlockHitResult
 *  net.minecraft.world.phys.HitResult
 *  net.minecraft.world.phys.HitResult$Type
 *  net.minecraftforge.common.ForgeMod
 *  net.minecraftforge.registries.ForgeRegistries
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.items.drink;

import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LayeredCauldronBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.registries.ForgeRegistries;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonMobEffect;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonThirstBlock;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.ThirstDataManager;
import sfiomn.legendarysurvivaloverhaul.api.thirst.HydrationEnum;
import sfiomn.legendarysurvivaloverhaul.api.thirst.ThirstUtil;
import sfiomn.legendarysurvivaloverhaul.api.wetness.WetnessUtil;
import sfiomn.legendarysurvivaloverhaul.common.integration.crayfish.CrayfishFurnitureUtil;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.DrinkItem;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.registry.EnchantmentRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;
import sfiomn.legendarysurvivaloverhaul.registry.SoundRegistry;
import sfiomn.legendarysurvivaloverhaul.util.CapabilityUtil;

public class CanteenItem
extends DrinkItem {
    public CanteenItem(Item.Properties properties) {
        super(properties.m_41487_(1));
    }

    public int getMaxCapacity() {
        return Config.Baked.canteenCapacity;
    }

    public int getMaxCapacity(ItemStack stack) {
        int baseCapacity = this.getMaxCapacity();
        int reservoirLevel = EnchantmentHelper.m_44843_((Enchantment)((Enchantment)EnchantmentRegistry.RESERVOIR.get()), (ItemStack)stack);
        return baseCapacity + reservoirLevel;
    }

    @Override
    public int m_8105_(@NotNull ItemStack stack) {
        return CanteenItem.canDrink(stack) ? 40 : 0;
    }

    public static boolean canDrink(ItemStack stack) {
        return ThirstUtil.getCapacityTag(stack) > 0 && ThirstUtil.getHydrationEnumTag(stack) != null;
    }

    public boolean canFill(ItemStack stack) {
        return Config.Baked.allowOverridePurifiedWater ? ThirstUtil.getCapacityTag(stack) < this.getMaxCapacity(stack) : ThirstUtil.getCapacityTag(stack) < this.getMaxCapacity(stack) && ThirstUtil.getHydrationEnumTag(stack) != HydrationEnum.PURIFIED;
    }

    public void fill(ItemStack stack) {
        ThirstUtil.setCapacityTag(stack, Math.min(this.getMaxCapacity(stack), ThirstUtil.getCapacityTag(stack) + 1));
        boolean hasPurity = EnchantmentHelper.m_44843_((Enchantment)((Enchantment)EnchantmentRegistry.PURITY.get()), (ItemStack)stack) > 0;
        ThirstUtil.setHydrationEnumTag(stack, hasPurity ? HydrationEnum.PURIFIED : HydrationEnum.NORMAL);
    }

    public boolean isWater(Level level, BlockPos blockPos) {
        FluidState fluidState = level.m_6425_(blockPos);
        JsonThirstBlock thirstInfo = ThirstDataManager.getBlock(fluidState);
        if (thirstInfo == null) {
            thirstInfo = ThirstDataManager.getBlock(level.m_8055_(blockPos));
        }
        if (thirstInfo != null && thirstInfo.hydration == 3 && thirstInfo.saturation == 0.0f && !thirstInfo.effects.isEmpty()) {
            for (JsonMobEffect jsonMobEffect : thirstInfo.effects) {
                if (!jsonMobEffect.name.equalsIgnoreCase(MobEffectRegistry.THIRST.getId().toString())) continue;
                return true;
            }
        }
        return false;
    }

    @NotNull
    public InteractionResult m_6225_(UseOnContext useOnContext) {
        InteractionResult result;
        int currentLevel;
        int maxCapacity;
        boolean isFullCanteen;
        ItemStack canteen = useOnContext.m_43722_();
        Player player = useOnContext.m_43723_();
        Level level = useOnContext.m_43725_();
        BlockPos clickedPos = useOnContext.m_8083_();
        BlockState blockState = level.m_8055_(clickedPos);
        if (player == null) {
            return InteractionResult.PASS;
        }
        int currentCapacity = ThirstUtil.getCapacityTag(canteen);
        boolean bl = isFullCanteen = currentCapacity >= (maxCapacity = this.getMaxCapacity(canteen));
        if (isFullCanteen && CanteenItem.canDrink(canteen)) {
            if (blockState.m_60713_(Blocks.f_50256_)) {
                if (!level.f_46443_) {
                    CanteenItem.shrinkCapacity(canteen);
                    level.m_46597_(clickedPos, (BlockState)Blocks.f_152476_.m_49966_().m_61124_((Property)LayeredCauldronBlock.f_153514_, (Comparable)Integer.valueOf(1)));
                    level.m_5594_(null, clickedPos, SoundEvents.f_11769_, SoundSource.BLOCKS, 1.0f, 1.0f);
                    level.m_142346_(null, GameEvent.f_157769_, clickedPos);
                }
                player.m_21011_(InteractionHand.MAIN_HAND, true);
                return InteractionResult.m_19078_((boolean)level.f_46443_);
            }
            if (blockState.m_60713_(Blocks.f_152476_) && (currentLevel = ((Integer)blockState.m_61143_((Property)LayeredCauldronBlock.f_153514_)).intValue()) < 3) {
                if (!level.f_46443_) {
                    CanteenItem.shrinkCapacity(canteen);
                    level.m_46597_(clickedPos, (BlockState)blockState.m_61124_((Property)LayeredCauldronBlock.f_153514_, (Comparable)Integer.valueOf(currentLevel + 1)));
                    level.m_5594_(null, clickedPos, SoundEvents.f_11769_, SoundSource.BLOCKS, 1.0f, 1.0f);
                    level.m_142346_(null, GameEvent.f_157769_, clickedPos);
                }
                player.m_21011_(InteractionHand.MAIN_HAND, true);
                return InteractionResult.m_19078_((boolean)level.f_46443_);
            }
        }
        if (LegendarySurvivalOverhaul.crayfishFurnitureLoaded && (result = CrayfishFurnitureUtil.tryFillCanteenFromSinkOrBasin(level, clickedPos, player, canteen)).m_19077_()) {
            player.m_21011_(InteractionHand.MAIN_HAND, true);
            return result;
        }
        if (blockState.m_60713_(Blocks.f_152476_) && this.canFill(canteen)) {
            if (!level.f_46443_) {
                this.fill(canteen);
                LayeredCauldronBlock.m_153559_((BlockState)blockState, (Level)level, (BlockPos)clickedPos);
                level.m_5594_(null, clickedPos, SoundEvents.f_11770_, SoundSource.BLOCKS, 1.0f, 1.0f);
                level.m_142346_(null, GameEvent.f_157816_, clickedPos);
            }
            player.m_21011_(InteractionHand.MAIN_HAND, true);
            return InteractionResult.m_19078_((boolean)level.f_46443_);
        }
        if (blockState.m_60713_(Blocks.f_50256_) && CanteenItem.canDrink(canteen)) {
            if (!level.f_46443_) {
                CanteenItem.shrinkCapacity(canteen);
                level.m_46597_(clickedPos, (BlockState)Blocks.f_152476_.m_49966_().m_61124_((Property)LayeredCauldronBlock.f_153514_, (Comparable)Integer.valueOf(1)));
                level.m_5594_(null, clickedPos, SoundEvents.f_11769_, SoundSource.BLOCKS, 1.0f, 1.0f);
                level.m_142346_(null, GameEvent.f_157769_, clickedPos);
            }
            player.m_21011_(InteractionHand.MAIN_HAND, true);
            return InteractionResult.m_19078_((boolean)level.f_46443_);
        }
        if (blockState.m_60713_(Blocks.f_152476_) && CanteenItem.canDrink(canteen) && (currentLevel = ((Integer)blockState.m_61143_((Property)LayeredCauldronBlock.f_153514_)).intValue()) < 3) {
            if (!level.f_46443_) {
                CanteenItem.shrinkCapacity(canteen);
                level.m_46597_(clickedPos, (BlockState)blockState.m_61124_((Property)LayeredCauldronBlock.f_153514_, (Comparable)Integer.valueOf(currentLevel + 1)));
                level.m_5594_(null, clickedPos, SoundEvents.f_11769_, SoundSource.BLOCKS, 1.0f, 1.0f);
                level.m_142346_(null, GameEvent.f_157769_, clickedPos);
            }
            player.m_21011_(InteractionHand.MAIN_HAND, true);
            return InteractionResult.m_19078_((boolean)level.f_46443_);
        }
        boolean isWater = this.isWater(level, clickedPos);
        if (this.canFill(canteen) && isWater) {
            player.m_21011_(InteractionHand.MAIN_HAND, true);
            if (player instanceof ServerPlayer) {
                ServerPlayer serverPlayer = (ServerPlayer)player;
                ForgeRegistries.SOUND_EVENTS.getHolder((Object)SoundEvents.f_11770_).ifPresent(soundHolder -> serverPlayer.f_8906_.m_9829_((Packet)new ClientboundSoundPacket(soundHolder, SoundSource.PLAYERS, serverPlayer.m_20185_(), serverPlayer.m_20186_(), serverPlayer.m_20189_(), 1.0f, 1.0f, player.m_9236_().m_213780_().m_188505_())));
            }
            this.fill(canteen);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }

    @Override
    @NotNull
    public InteractionResultHolder<ItemStack> m_7203_(@NotNull Level level, Player player, @NotNull InteractionHand hand) {
        HitResult positionLookedAt = player.m_19907_(Math.max(3.0, player.m_21133_((Attribute)ForgeMod.BLOCK_REACH.get()) / 2.0), 0.0f, true);
        ItemStack canteen = player.m_21120_(hand);
        boolean isWater = false;
        BlockPos blockPos = null;
        if (positionLookedAt.m_6662_() == HitResult.Type.BLOCK) {
            blockPos = ((BlockHitResult)positionLookedAt).m_82425_();
            isWater = this.isWater(level, blockPos);
        }
        if (this.canFill(canteen) && isWater) {
            player.m_6674_(InteractionHand.MAIN_HAND);
            player.m_5496_(SoundEvents.f_11770_, 1.0f, 1.0f);
            this.fill(canteen);
            return InteractionResultHolder.m_19096_((Object)canteen);
        }
        if (positionLookedAt.m_6662_() == HitResult.Type.BLOCK && blockPos != null) {
            boolean isHandledByUseOn;
            BlockState blockState = level.m_8055_(blockPos);
            boolean bl = isHandledByUseOn = blockState.m_60713_(Blocks.f_50256_) || blockState.m_60713_(Blocks.f_152476_) || LegendarySurvivalOverhaul.crayfishFurnitureLoaded && CrayfishFurnitureUtil.isSinkOrBasin(blockState);
            if (isHandledByUseOn) {
                return InteractionResultHolder.m_19098_((Object)canteen);
            }
        }
        if (player.m_6047_() && player.m_5686_(1.0f) < -60.0f && CanteenItem.canDrink(canteen) && Config.Baked.selfWateringCanteenEnabled) {
            player.m_5496_((SoundEvent)SoundRegistry.SELF_WATERING.get(), 1.0f, 1.0f);
            if (player.m_6060_()) {
                player.m_20254_(0);
            }
            if (Config.Baked.selfWateringCanteenWetnessIncrease > 0) {
                WetnessUtil.addWetness(player, Config.Baked.selfWateringCanteenWetnessIncrease);
            }
            player.m_6674_(InteractionHand.MAIN_HAND);
            CanteenItem.shrinkCapacity(canteen);
            return InteractionResultHolder.m_19096_((Object)canteen);
        }
        if (CanteenItem.canDrink(canteen) && !CapabilityUtil.getThirstCapability(player).isHydrationLevelAtMax()) {
            player.m_6672_(hand);
            return InteractionResultHolder.m_19096_((Object)canteen);
        }
        return InteractionResultHolder.m_19100_((Object)canteen);
    }

    @Override
    @NotNull
    public ItemStack m_5922_(@NotNull ItemStack stack, Level level, @NotNull LivingEntity entity) {
        if (level.f_46443_ || !(entity instanceof Player)) {
            return stack;
        }
        Player player = (Player)entity;
        this.runSecondaryEffect(player, stack);
        int refreshingLevel = EnchantmentHelper.m_44843_((Enchantment)((Enchantment)EnchantmentRegistry.REFRESHING.get()), (ItemStack)stack);
        if (refreshingLevel > 0) {
            int bonusHydration = refreshingLevel;
            float bonusSaturation = Math.max(0, refreshingLevel - 1);
            ThirstUtil.takeDrink(player, bonusHydration, bonusSaturation);
        }
        CanteenItem.shrinkCapacity(stack);
        return stack;
    }

    public static void shrinkCapacity(ItemStack stack) {
        int newCapacity = ThirstUtil.getCapacityTag(stack) - 1;
        ThirstUtil.setCapacityTag(stack, newCapacity);
        if (newCapacity == 0) {
            ThirstUtil.removeHydrationEnumTag(stack);
        }
    }

    @NotNull
    public String m_5671_(ItemStack stack) {
        if (ThirstUtil.getCapacityTag(stack) == 0) {
            return "item.legendarysurvivaloverhaul.canteen_empty";
        }
        if (ThirstUtil.getHydrationEnumTag(stack) == HydrationEnum.PURIFIED) {
            return "item.legendarysurvivaloverhaul.canteen_purified";
        }
        return "item.legendarysurvivaloverhaul.canteen";
    }

    public boolean m_142522_(@NotNull ItemStack stack) {
        return ThirstUtil.getCapacityTag(stack) > 0;
    }

    public int m_142158_(@NotNull ItemStack stack) {
        float max = this.getMaxCapacity(stack);
        if (max == 0.0f) {
            return 0;
        }
        return Math.min(13, Math.round((float)ThirstUtil.getCapacityTag(stack) / max * 13.0f));
    }

    public int m_142159_(@NotNull ItemStack stack) {
        float f = Math.max(0.0f, (float)ThirstUtil.getCapacityTag(stack) / (float)this.getMaxCapacity(stack));
        return Mth.m_14169_((float)(f / 3.0f), (float)1.0f, (float)1.0f);
    }

    @Override
    public boolean m_8120_(@NotNull ItemStack stack) {
        return true;
    }

    public int m_6473_() {
        return 10;
    }

    public static void onPurityApplied(ItemStack stack) {
        if (ThirstUtil.getCapacityTag(stack) > 0 && ThirstUtil.getHydrationEnumTag(stack) == HydrationEnum.NORMAL) {
            ThirstUtil.setHydrationEnumTag(stack, HydrationEnum.PURIFIED);
        }
    }
}

