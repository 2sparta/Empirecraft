/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.items.drink;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.DrinkItem;
import sfiomn.legendarysurvivaloverhaul.config.Config;

public abstract class BottledDrinkItem
extends DrinkItem {
    public BottledDrinkItem(Item.Properties properties) {
        super(properties.m_41487_(64));
    }

    @Override
    public int m_8105_(@NotNull ItemStack stack) {
        return 32;
    }

    @Override
    @NotNull
    public ItemStack m_5922_(@NotNull ItemStack stack, Level level, @NotNull LivingEntity entity) {
        if (level.f_46443_ || !(entity instanceof Player)) {
            return stack;
        }
        Player player = (Player)entity;
        stack = super.m_5922_(stack, level, (LivingEntity)player);
        if (Config.Baked.glassBottleLootAfterDrink) {
            ItemStack glassBottle = new ItemStack((ItemLike)Items.f_42590_);
            if (stack.m_41619_()) {
                return glassBottle;
            }
            int slot = player.m_150109_().m_36043_(glassBottle);
            if (slot == -1) {
                slot = player.m_150109_().m_36062_();
            }
            if (slot > -1) {
                player.m_150109_().m_36040_(slot, glassBottle);
            } else {
                player.m_36176_(glassBottle, false);
            }
        }
        return stack;
    }

    @Override
    public boolean m_8120_(ItemStack stack) {
        return false;
    }
}

