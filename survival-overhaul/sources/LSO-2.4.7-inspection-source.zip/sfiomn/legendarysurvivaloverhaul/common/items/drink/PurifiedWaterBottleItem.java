/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.Item$Properties
 */
package sfiomn.legendarysurvivaloverhaul.common.items.drink;

import net.minecraft.world.item.Item;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.BottledDrinkItem;

public class PurifiedWaterBottleItem
extends BottledDrinkItem {
    public PurifiedWaterBottleItem(Item.Properties properties) {
        super(properties);
    }
}

