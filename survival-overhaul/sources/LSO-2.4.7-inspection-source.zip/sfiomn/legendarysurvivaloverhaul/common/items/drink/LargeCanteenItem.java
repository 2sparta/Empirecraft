/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.enchantment.Enchantment
 *  net.minecraft.world.item.enchantment.EnchantmentHelper
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.items.drink;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.api.thirst.HydrationEnum;
import sfiomn.legendarysurvivaloverhaul.api.thirst.ThirstUtil;
import sfiomn.legendarysurvivaloverhaul.common.items.drink.CanteenItem;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.registry.EnchantmentRegistry;

public class LargeCanteenItem
extends CanteenItem {
    public LargeCanteenItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public int getMaxCapacity() {
        return Config.Baked.largeCanteenCapacity;
    }

    @Override
    public int getMaxCapacity(ItemStack stack) {
        int baseCapacity = this.getMaxCapacity();
        int reservoirLevel = EnchantmentHelper.m_44843_((Enchantment)((Enchantment)EnchantmentRegistry.RESERVOIR.get()), (ItemStack)stack);
        return baseCapacity + reservoirLevel;
    }

    @Override
    @NotNull
    public String m_5671_(ItemStack stack) {
        if (ThirstUtil.getCapacityTag(stack) == 0) {
            return "item.legendarysurvivaloverhaul.large_canteen_empty";
        }
        if (ThirstUtil.getHydrationEnumTag(stack) == HydrationEnum.PURIFIED) {
            return "item.legendarysurvivaloverhaul.large_canteen_purified";
        }
        return "item.legendarysurvivaloverhaul.large_canteen";
    }
}

