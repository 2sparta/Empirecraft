/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.InputConstants
 *  net.minecraft.ChatFormatting
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.resources.language.I18n
 *  net.minecraft.network.chat.Component
 *  net.minecraft.network.chat.MutableComponent
 *  net.minecraft.network.chat.Style
 *  net.minecraft.network.chat.TextColor
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.TooltipFlag
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.common.items;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.List;
import java.util.Objects;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.api.item.CoatEnum;
import sfiomn.legendarysurvivaloverhaul.registry.KeyMappingRegistry;

public class CoatItem
extends Item {
    public CoatEnum coat;

    public CoatItem(CoatEnum coat, Item.Properties properties) {
        super(properties);
        this.coat = coat;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void m_7373_(ItemStack stack, @Nullable Level level, List<Component> tooltipComponents, TooltipFlag isAdvanced) {
        MutableComponent text;
        super.m_7373_(stack, level, tooltipComponents, isAdvanced);
        if (InputConstants.m_84830_((long)Minecraft.m_91087_().m_91268_().m_85439_(), (int)KeyMappingRegistry.showAddedDesc.getKey().m_84873_())) {
            if (this.coat == null) return;
            MutableComponent effectComponent = Component.m_237115_((String)("tooltip.legendarysurvivaloverhaul.coat_item." + this.coat.type() + ".effect")).m_130948_(Style.f_131099_.m_131148_(TextColor.m_131266_((int)6466303)));
            MutableComponent temperatureComponent = Component.m_237113_((String)(" " + this.coat.modifier()));
            if (Objects.equals(this.coat.type(), "heating")) {
                effectComponent = effectComponent.m_130948_(Style.f_131099_.m_131148_(TextColor.m_131266_((int)6466303)));
                temperatureComponent = temperatureComponent.m_130948_(Style.f_131099_.m_131148_(TextColor.m_131266_((int)6466303)));
            } else if (Objects.equals(this.coat.type(), "cooling")) {
                effectComponent = effectComponent.m_130948_(Style.f_131099_.m_131148_(TextColor.m_131266_((int)16420407)));
                temperatureComponent = temperatureComponent.m_130948_(Style.f_131099_.m_131148_(TextColor.m_131266_((int)16420407)));
            } else {
                effectComponent = effectComponent.m_130948_(Style.f_131099_.m_131148_(TextColor.m_131266_((int)0x9933FF)));
                temperatureComponent = temperatureComponent.m_130948_(Style.f_131099_.m_131148_(TextColor.m_131266_((int)0x9933FF)));
            }
            text = Component.m_237110_((String)"tooltip.legendarysurvivaloverhaul.coat_item.desc", (Object[])new Object[]{effectComponent}).m_7220_((Component)temperatureComponent);
        } else {
            text = Component.m_237113_((String)(String.valueOf(ChatFormatting.GRAY) + I18n.m_118938_((String)"tooltip.legendarysurvivaloverhaul.added_desc.activate", (Object[])new Object[]{ChatFormatting.LIGHT_PURPLE, I18n.m_118938_((String)KeyMappingRegistry.showAddedDesc.m_90863_().getString(), (Object[])new Object[0]), ChatFormatting.GRAY})));
        }
        tooltipComponents.add((Component)text);
    }
}

