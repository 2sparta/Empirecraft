/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.chat.Component
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 */
package sfiomn.legendarysurvivaloverhaul.common.items;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.common.integration.eclipticseasons.EclipticSeasonsUtil;
import sfiomn.legendarysurvivaloverhaul.common.integration.sereneseasons.SereneSeasonsUtil;

public class SeasonalCalendarItem
extends Item {
    public SeasonalCalendarItem(Item.Properties properties) {
        super(properties.m_41487_(1));
    }

    public InteractionResultHolder<ItemStack> m_7203_(Level level, Player player, InteractionHand hand) {
        if (level.m_5776_()) {
            if (LegendarySurvivalOverhaul.sereneSeasonsLoaded) {
                player.m_5661_(SereneSeasonsUtil.seasonTooltip(player.m_20183_(), player.m_9236_()), true);
            } else if (LegendarySurvivalOverhaul.eclipticSeasonsLoaded) {
                player.m_5661_(EclipticSeasonsUtil.seasonTooltip(player.m_9236_()), true);
            } else {
                player.m_5661_((Component)Component.m_237115_((String)"message.legendarysurvivaloverhaul.no_season_loaded"), true);
            }
        }
        return super.m_7203_(level, player, hand);
    }
}

