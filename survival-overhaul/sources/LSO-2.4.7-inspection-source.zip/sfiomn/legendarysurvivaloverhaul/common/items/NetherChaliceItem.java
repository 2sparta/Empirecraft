/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.chat.Component
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.TooltipFlag
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.material.Fluid
 *  net.minecraft.world.level.material.FluidState
 *  net.minecraft.world.level.material.Fluids
 *  net.minecraft.world.phys.BlockHitResult
 *  net.minecraft.world.phys.HitResult
 *  net.minecraft.world.phys.HitResult$Type
 *  net.minecraftforge.common.ForgeMod
 *  org.jetbrains.annotations.Nullable
 */
package sfiomn.legendarysurvivaloverhaul.common.items;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.common.ForgeMod;
import org.jetbrains.annotations.Nullable;
import sfiomn.legendarysurvivaloverhaul.LegendarySurvivalOverhaul;
import sfiomn.legendarysurvivaloverhaul.api.thirst.ThirstUtil;
import sfiomn.legendarysurvivaloverhaul.common.items.WearableCurioItem;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.util.CapabilityUtil;

public class NetherChaliceItem
extends WearableCurioItem {
    public NetherChaliceItem(Item.Properties pProperties) {
        super(pProperties);
    }

    @Override
    public InteractionResultHolder<ItemStack> m_7203_(Level level, Player player, InteractionHand usedHand) {
        if (LegendarySurvivalOverhaul.curiosLoaded) {
            return super.m_7203_(level, player, usedHand);
        }
        ItemStack itemstack = player.m_21120_(usedHand);
        if (CapabilityUtil.getThirstCapability(player).isHydrationLevelAtMax()) {
            return InteractionResultHolder.m_19100_((Object)itemstack);
        }
        HitResult positionLookedAt = player.m_19907_(Math.max(3.0, player.m_21133_((Attribute)ForgeMod.BLOCK_REACH.get()) / 2.0), 0.0f, true);
        FluidState fluidState = null;
        if (positionLookedAt.m_6662_() == HitResult.Type.BLOCK) {
            fluidState = level.m_6425_(((BlockHitResult)positionLookedAt).m_82425_());
        }
        if (fluidState != null && (fluidState.m_192917_((Fluid)Fluids.f_76195_) || fluidState.m_192917_((Fluid)Fluids.f_76194_))) {
            player.m_6674_(InteractionHand.MAIN_HAND);
            player.m_5496_(SoundEvents.f_11911_, 1.0f, 1.0f);
            ThirstUtil.takeDrink(player, Config.Baked.hydrationLava, (float)Config.Baked.saturationLava);
            return InteractionResultHolder.m_19098_((Object)itemstack);
        }
        return InteractionResultHolder.m_19100_((Object)itemstack);
    }

    public void m_7373_(ItemStack stack, @Nullable Level level, List<Component> tooltipComponents, TooltipFlag isAdvanced) {
        super.m_7373_(stack, level, tooltipComponents, isAdvanced);
        tooltipComponents.add((Component)Component.m_237115_((String)"tooltip.legendarysurvivaloverhaul.nether_chalice.description"));
    }

    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged;
    }
}

