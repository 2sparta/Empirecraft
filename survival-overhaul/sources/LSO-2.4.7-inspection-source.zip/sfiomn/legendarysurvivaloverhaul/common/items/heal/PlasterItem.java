/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 */
package sfiomn.legendarysurvivaloverhaul.common.items.heal;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import sfiomn.legendarysurvivaloverhaul.common.items.heal.BodyHealingItem;
import sfiomn.legendarysurvivaloverhaul.config.Config;

public class PlasterItem
extends BodyHealingItem {
    public PlasterItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public int m_8105_(ItemStack stack) {
        return Config.Baked.plasterUseTime;
    }
}

