/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.UseAnim
 */
package sfiomn.legendarysurvivaloverhaul.common.items.heal;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import sfiomn.legendarysurvivaloverhaul.common.items.heal.BodyHealingItem;
import sfiomn.legendarysurvivaloverhaul.config.Config;

public class TonicItem
extends BodyHealingItem {
    public TonicItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public UseAnim m_6164_(ItemStack stack) {
        return UseAnim.DRINK;
    }

    @Override
    public int m_8105_(ItemStack stack) {
        return Config.Baked.tonicUseTime;
    }
}

