/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.network.chat.Component
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.TooltipFlag
 *  net.minecraft.world.item.UseAnim
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.items.heal;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;

public class MorphineItem
extends Item {
    public MorphineItem(Item.Properties p_i48487_1_) {
        super(p_i48487_1_);
    }

    @NotNull
    public UseAnim m_6164_(@NotNull ItemStack stack) {
        return UseAnim.BOW;
    }

    public int m_8105_(@NotNull ItemStack stack) {
        return Config.Baked.morphineUseTime;
    }

    @NotNull
    public InteractionResultHolder<ItemStack> m_7203_(@NotNull Level level, Player player, @NotNull InteractionHand hand) {
        ItemStack stack = player.m_21120_(hand);
        if (player.m_21023_((MobEffect)MobEffectRegistry.PAINKILLER_ADDICTION.get())) {
            player.m_5661_((Component)Component.m_237115_((String)"message.legendarysurvivaloverhaul.morphine_use_under_painkiller_addiction"), true);
            return InteractionResultHolder.m_19100_((Object)stack);
        }
        player.m_6672_(hand);
        return InteractionResultHolder.m_19090_((Object)stack);
    }

    @NotNull
    public ItemStack m_5922_(@NotNull ItemStack stack, Level level, @NotNull LivingEntity entity) {
        if (level.f_46443_ || !(entity instanceof Player)) {
            return stack;
        }
        Player player = (Player)entity;
        player.m_7292_(new MobEffectInstance((MobEffect)MobEffectRegistry.PAINKILLER.get(), Config.Baked.morphinePainkillerTickDuration, 0, false, false, true));
        player.m_7292_(new MobEffectInstance((MobEffect)MobEffectRegistry.PAINKILLER_ADDICTION.get(), Config.Baked.painkillerAddictionDuration, 0, false, false, true));
        if (!player.m_7500_()) {
            stack.m_41774_(1);
        }
        return stack;
    }

    public boolean m_8120_(@NotNull ItemStack stack) {
        return false;
    }

    public void m_7373_(@NotNull ItemStack stack, @Nullable Level level, @NotNull List<Component> tooltip, @NotNull TooltipFlag isAdvanced) {
        if (Config.Baked.localizedBodyDamageEnabled) {
            tooltip.add((Component)Component.m_237115_((String)"tooltip.legendarysurvivaloverhaul.body_heal_item.morphine"));
        }
        super.m_7373_(stack, level, tooltip, isAdvanced);
    }
}

