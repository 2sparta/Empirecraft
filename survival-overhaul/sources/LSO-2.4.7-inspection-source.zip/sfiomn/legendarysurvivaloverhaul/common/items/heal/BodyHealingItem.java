/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.UseAnim
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.registries.ForgeRegistries
 */
package sfiomn.legendarysurvivaloverhaul.common.items.heal;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyDamageUtil;
import sfiomn.legendarysurvivaloverhaul.api.bodydamage.BodyPartEnum;
import sfiomn.legendarysurvivaloverhaul.api.data.json.JsonHealingConsumable;
import sfiomn.legendarysurvivaloverhaul.api.data.manager.BodyDamageDataManager;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.bodydamage.BodyDamageCapability;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.registry.MobEffectRegistry;
import sfiomn.legendarysurvivaloverhaul.util.CapabilityUtil;

public class BodyHealingItem
extends Item {
    public BodyHealingItem(Item.Properties properties) {
        super(properties);
    }

    public UseAnim m_6164_(ItemStack stack) {
        return UseAnim.BOW;
    }

    public int m_8105_(ItemStack stack) {
        return 20;
    }

    public InteractionResultHolder<ItemStack> m_7203_(Level world, Player player, InteractionHand hand) {
        ItemStack stack = player.m_21120_(hand);
        if (!Config.Baked.localizedBodyDamageEnabled) {
            player.m_6672_(hand);
            return InteractionResultHolder.m_19090_((Object)stack);
        }
        ResourceLocation registryName = ForgeRegistries.ITEMS.getKey((Object)this);
        JsonHealingConsumable jsonConsumableHeal = BodyDamageDataManager.getHealingItem(registryName);
        if (jsonConsumableHeal != null) {
            BodyDamageCapability capability = CapabilityUtil.getBodyDamageCapability(player);
            if (jsonConsumableHeal.healingCharges == 0) {
                for (BodyPartEnum bodyPart : BodyPartEnum.values()) {
                    if (!(capability.getBodyPartDamage(bodyPart) > 0.0f) && !(player.m_21223_() < player.m_21233_())) continue;
                    player.m_6672_(hand);
                    return InteractionResultHolder.m_19090_((Object)stack);
                }
            } else if (jsonConsumableHeal.healingCharges > 0) {
                player.m_6672_(hand);
                return InteractionResultHolder.m_19090_((Object)stack);
            }
        }
        return InteractionResultHolder.m_19100_((Object)stack);
    }

    public ItemStack m_5922_(ItemStack stack, Level level, LivingEntity entity) {
        if (!(entity instanceof Player)) {
            return stack;
        }
        Player player = (Player)entity;
        ResourceLocation registryName = ForgeRegistries.ITEMS.getKey((Object)this);
        JsonHealingConsumable jsonConsumableHeal = BodyDamageDataManager.getHealingItem(registryName);
        if (jsonConsumableHeal == null) {
            return stack;
        }
        if (!Config.Baked.localizedBodyDamageEnabled) {
            if (jsonConsumableHeal.recoveryEffectDuration > 0) {
                player.m_7292_(new MobEffectInstance((MobEffect)MobEffectRegistry.RECOVERY.get(), jsonConsumableHeal.recoveryEffectDuration, jsonConsumableHeal.recoveryEffectAmplifier, false, true, true));
            }
            stack.m_41774_(1);
            return stack;
        }
        BodyDamageUtil.applyConsumableHealing(player, stack, false);
        return stack;
    }

    public boolean m_8120_(ItemStack stack) {
        return false;
    }
}

