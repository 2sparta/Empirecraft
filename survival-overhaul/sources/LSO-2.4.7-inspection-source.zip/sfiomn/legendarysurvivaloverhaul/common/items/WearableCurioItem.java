/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 */
package sfiomn.legendarysurvivaloverhaul.common.items;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import sfiomn.legendarysurvivaloverhaul.common.integration.curios.CuriosUtil;

public class WearableCurioItem
extends Item {
    public WearableCurioItem(Item.Properties p_41383_) {
        super(p_41383_);
    }

    public InteractionResultHolder<ItemStack> m_7203_(Level level, Player player, InteractionHand hand) {
        ItemStack itemstack = player.m_21120_(hand);
        boolean isWorn = CuriosUtil.equipCurio(player, itemstack, hand);
        if (isWorn) {
            level.m_5594_(null, player.m_20183_(), SoundEvents.f_11675_, player.m_5720_(), 1.0f, 1.0f);
        }
        return isWorn ? InteractionResultHolder.m_19090_((Object)itemstack) : InteractionResultHolder.m_19100_((Object)itemstack);
    }
}

