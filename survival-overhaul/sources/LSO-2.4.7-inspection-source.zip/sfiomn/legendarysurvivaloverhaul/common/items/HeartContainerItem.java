/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.core.particles.ParticleTypes
 *  net.minecraft.network.chat.Component
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.effect.MobEffects
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.UseAnim
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.NotNull
 */
package sfiomn.legendarysurvivaloverhaul.common.items;

import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import sfiomn.legendarysurvivaloverhaul.common.capabilities.health.HealthCapability;
import sfiomn.legendarysurvivaloverhaul.config.Config;
import sfiomn.legendarysurvivaloverhaul.registry.SoundRegistry;
import sfiomn.legendarysurvivaloverhaul.util.CapabilityUtil;

public class HeartContainerItem
extends Item {
    public HeartContainerItem(Item.Properties properties) {
        super(properties);
    }

    public int m_8105_(@NotNull ItemStack stack) {
        return 30;
    }

    @NotNull
    public UseAnim m_6164_(@NotNull ItemStack stack) {
        return UseAnim.BOW;
    }

    @NotNull
    public InteractionResultHolder<ItemStack> m_7203_(@NotNull Level level, @NotNull Player player, @NotNull InteractionHand hand) {
        HealthCapability cap;
        if (Config.Baked.healthOverhaulEnabled && (double)(cap = CapabilityUtil.getHealthCapability(player)).getAdditionalHealth() >= Config.Baked.maxAdditionalHealth) {
            if (level.f_46443_) {
                player.m_5661_((Component)Component.m_237115_((String)"message.legendarysurvivaloverhaul.heart_container.additional_health_full"), true);
            }
            return InteractionResultHolder.m_19100_((Object)player.m_21120_(hand));
        }
        player.m_6672_(hand);
        return InteractionResultHolder.m_19090_((Object)player.m_21120_(hand));
    }

    @NotNull
    public ItemStack m_5922_(@NotNull ItemStack stack, @NotNull Level level, @NotNull LivingEntity entity) {
        if (entity instanceof Player) {
            Player player = (Player)entity;
            stack = super.m_5922_(stack, level, (LivingEntity)player);
            if (!level.f_46443_) {
                player.m_7292_(new MobEffectInstance(MobEffects.f_19605_, 200, 1));
            }
            if (Config.Baked.healthOverhaulEnabled) {
                HealthCapability cap = CapabilityUtil.getHealthCapability(player);
                cap.addAdditionalHealth(2.0f);
                level.m_6269_(null, (Entity)player, (SoundEvent)SoundRegistry.HEART_CONTAINER.get(), SoundSource.NEUTRAL, 1.0f, 1.0f);
                for (int i = 0; i < 100; ++i) {
                    level.m_7106_((ParticleOptions)ParticleTypes.f_123784_, player.m_20182_().f_82479_, player.m_20182_().m_82520_((double)0.0, (double)1.5, (double)0.0).f_82480_, player.m_20182_().f_82481_, 0.2, 0.2, 0.2);
                }
                if (level.f_46443_) {
                    Minecraft.m_91087_().f_91063_.m_109113_(stack);
                }
            }
            if (!player.m_7500_()) {
                stack.m_41774_(1);
            }
        }
        return stack;
    }
}

