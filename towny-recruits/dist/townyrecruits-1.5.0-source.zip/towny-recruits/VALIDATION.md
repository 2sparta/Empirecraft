# Towny Recruits 1.5.0 — allied commanders and stable city ownership

Native JAR SHA-256: `09ed4b0328950dd057610706518deb8a092544cd6c2245d0dcdee643d79c7615`.
Paired versions: Feudal 1.17.0 and Engagement 1.1.0; install the matching client/server JARs together.

- All 27 native Java test programs and the 128-skin verification passed. The expanded military NBT/transfer checks retain the city and original national quota when assigning allied commanders.
- The disposable Mohist integration uses real Towny alliances, native regiment commands, a loaded recruit and a persisted unloaded soldier record. It checks foreign leadership, original ownership for combat protection, revocation after alliance removal and restoration of the owning city's command.
- Sale accepts an allied commander of the buying city. Battle hire still requires the original local citizenship so its protected temporary membership can be restored correctly.
- Exact component identities and the executed two-boot integration are recorded in [engagement-1.1.0.json](../validation/engagement-1.1.0.json). Backend results and setup: [city-markets-1.17.0.md](../validation/city-markets-1.17.0.md), [allied command and Discord guide](../feudal/ALLIED-COMMAND-DISCORD.md).

Graphical client gameplay and large-battle performance were not measured. The sections below describe the historical release bytes, not the new JAR.

---

# Towny Recruits 1.4.0 — regiment sales and mercenary contracts

Native JAR SHA-256: `39382481a5b25c629448dd8d09d3558ab2ce69e74af949340c9143e53a56fa2f`. Paired EmpirecraftFeudal 1.15.0 SHA-256: `c59e07ed0a5cd5428974f718996c7ca63d3067b25d69a2204abc2a63f59cc1a4`.

- All **27 native Java programs** and the 128-skin check passed against the installed Forge/Mohist/Recruits JARs and full SRG client. All **28 Feudal suites** pass with real H2/Towny/Bukkit APIs and a Java 21 runtime.
- Twelve new SQL scenarios cover permanent transfer, national capacity, city authority, ordinary versus trade-republic markets, physical counter access, escrow, captain consent, absence refunds including fees, finite battles, decisions, cancellation, exactly-once settlement, SQL failure rollback and real file restart.
- Executed the compiled Towny citizenship adapter with boundary fixtures and real JSON: plots retained, roles/title/join date restored, replay safe, failed save compensated, transition guards cleared. Checked real native Towny cancellable events and handler bindings.
- Executed the production native ownership/lock decision, checked spoofed actor UUIDs against 20 installed packet field contracts, and applied real Mixin/ASM verification to all guarded GUI/group/equipment/companion command targets. The inventory validity override protects menus opened before a listing.
- Production projections preserve city, regiment, captain, loaded/offline counts and heraldry across real NBT roundtrips; repair an older army ledger after partial file flushing. Replayed jobs cannot resurrect casualties/deserters or duplicate ownership.
- All previous tactical, bomb, fire, morale, map, skin and Towny regressions remain green. Feudal UI strings have matching English/Russian catalogs; Ukrainian is the source language.
- The paired Feudal JAR also passed a fresh isolated Mohist fleet regression: 61 live-server assertions and 12 after restart. This checks existing fleet compatibility, not the complete mercenary battle cycle; evidence: [city-fleet-17.json](../validation/city-fleet-17.json).

These policy, real-API, fixture-execution and bytecode checks do not establish graphical gameplay behavior or TPS. The complete live mercenary/Towny battle cycle remains an acceptance check. [Commands and scenarios](CONTRACTS.md), [backend validation](../feudal/RECRUIT-CONTRACTS-VALIDATION.md), [structured report](../validation/recruit-contracts-1.4.0.json).

---

# Towny Recruits 1.3.0 — JourneyMap armies and regimental banners

Java 17 compilation passed against the real Forge/Mohist 47.4.23 runtime, full Minecraft 1.20.1 SRG client, Recruits 1.15.0 and installed JourneyMap 6.0.7. The build extracts JourneyMap's nested API 2.0.0 as a compile dependency; no JourneyMap/game API classes are packaged in this mod.

JAR SHA-256: `f4965f1cbbb64b31b0e3e8fd68f7d7034c28e0195d1586b9634ba7f0661ad97d`.

- All **24 Java test programs** and 128-skin verification passed. Output: [test-results.txt](test-results.txt); structured report: [recruit-map-banners-1.3.0.json](../validation/recruit-map-banners-1.3.0.json).
- Real FriendlyByteBuf roundtrip of 2 048 soldiers and 128 regimental designs; rejects duplicate IDs, missing styles, oversized lists, invalid dyes/patterns and non-finite coordinates. Tests cover tracked neutral/enemy visibility, invisible non-allies, shared loaded allies, dimensions, ordering, five-second expiry, reconnects and safe UTF-16 labels.
- Executed the compiled JourneyMap layer with actual installed API MarkerOverlay/MapImage types, an IClientAPI proxy and an isolated dimension-registry boot fixture. Checked stable moving markers, diplomacy recoloring, visible standard bearers, fallback to an actual visible soldier, disappearance, reload and namespace-scoped cleanup that preserves other mods' overlays. No waypoint mutation is called.
- Generated 30 distinct type/relation/routing icons and rendered real vanilla banner texture masks with native UV cropping, layer colors and deterministic output. The [legend](assets/army-map-preview.png) is a CPU-generated preview, not a game screenshot.
- Executed compiled banner inventory transaction methods with small item/entity fixtures: one real item transfers, reassigning the same bearer does not duplicate or consume another banner, changing bearers preserves the old item, occupied offhands/armor/weapons stay intact, and mismatched designs or routed soldiers are rejected.
- Real military NBT roundtrips preserve heraldry and bearer IDs. The existing compiled desertion test also checks designation cleanup. All previous formation, bomb, cavalry, fire, morale, Towny, census, appearance and real Mixin regressions still pass.
- Embedded 121 matching translation keys in en_us, uk_ua and ru_ru. Optional JourneyMap integration uses client-only classes; the server map service and independent client snapshot lifecycle contain no JourneyMap API references. The optional VS coordinate adapter targets the method present in the installed Valkyrien Skies JAR.

Client/server JARs, hashes, lock, ADM and shared inventories are synchronized; source/update archives contain matching bytes. The full graphical client, optional-map-absent Forge boot, moving-ship gameplay and TPS have **not** been run. The tests above exercise policies, compiled bodies, real API models and texture rasters; they do not establish in-game appearance. Acceptance steps: [MAP.md](MAP.md), [TACTICS.md](TACTICS.md) and [ARMY.md](ARMY.md).

---

# Towny Recruits 1.2.0 battle orders validation

Java 17 compilation passed against the real Forge/Mohist 47.4.23 server, Recruits 1.15.0, Supplementaries, Musket, Boomsticks and the official Minecraft 1.20.1 client remapped to SRG. No API stubs or downloaded game libraries are included in the production JAR. Client SHA-1: `0c3ec587af28e5a785c0b4a7b8a30f9a8f78f838`; mappings SHA-1: `6c48521eed01fe2e8ecdadbd5ae348415f3c47da`.

JAR SHA-256: `f81588164e29211231306380c02f47c98990335f73f441a43083fcd8a171bd84`.

- Passed all 20 Java test programs plus the 128-skin asset verification; full output is in [test-results.txt](test-results.txt).
- Checked 1,920 formation/count cases, distinct slots, square facings, two pike ranks and open retreat corridors even with odd or tiny groups. Checked cavalry body clearance at widths 0.6, 1 and 3 for every count from 1 to 128.
- Preserved physical rank membership through march/KEEP orders, including interleaved UUID selection and small position differences.
- Independently integrated arrow trajectories through move/drag/gravity updates, checked lateral interception, imperfect leading, strict pursuit-radius clamping and continuous semicircles. Existing 255 native bomb arcs, scatter/cooldown/capacity regressions still pass.
- Round-tripped every mode/formation/speed combination, eight differently configured waypoints, a 128-unit preview with 64 route samples per unit and mounted footprints. Rejected a ninth waypoint, invalid enums, non-finite coordinates, duplicate groups, invalid widths and out-of-range distance/leash values.
- Executed the actual compiled fire coordinator using small recruit/clock fixtures: same-tick grants after the real server-start/world-time phase transition, loading barrier, blocked shooters retaining their pending shot, alternating ranks covering reloads, hold/cancel, owner transfer, free fire and mounted firing phases.
- Executed the actual compiled obstruction check with real Vec3/AABB intersections and small level/entity fixtures: friendly soldiers ahead, allies beside/behind, cavalry bodies, own-mount exclusion, solid blocks, straight firing lanes and discrete arrow arcs. These fixture tests do not claim a Minecraft gameplay boot.
- Executed production route-leg revalidation: partial availability and casualties keep the exact approved slots, facings and ranks; changed terrain/equipment only invalidates the affected recruit.
- Verified preview path search uses a fresh GroundPathNavigation attached to an unspawned virtual-position probe, without repositioning the recruit or horse or changing active navigation caches.
- Applied real Mixin transforms and ASM verification to PathNavigation, both native archer goals, the existing 23 server targets, Entity/Slot/inventory/command targets, CommandScreen/HumanoidModel and the human renderer. Existing Towny policy/reflection/census/NBT/appearance regressions pass.
- Checked morale and allied support, rout/escape and straggler safeguards, national/rank authority, atomic same-nation reassignment of loaded/offline records, persistent military NBT and commander/nation departure.
- Executed the compiled desertion cleanup with ownership fixtures: cancelled dismissal retains its army record, completed dismissal clears ownership/formation/mount/routing state, preserves equipment and counts once.
- Verified the real Towny addon command API/reflection contracts and group/ownership/disband packet Mixin transforms.
- Embedded 107 matching translation keys in en_us, uk_ua and ru_ru.

Live graphical gameplay, mounted animation/steering under load, Copycats appearance, Towny addon command gameplay, battlefield morale/routing and large-army TPS have **not** been measured in this environment. The acceptance scenarios in [TACTICS.md](TACTICS.md) cover these limits. Geometry, fixture execution and bytecode checks cannot establish live navigation quality or visual behavior.

Client/server copies, source/update ZIPs, ADM, lock and shared inventories are checked during packaging. The source archive contains the exact implementation, tests and build instructions, with no game dependencies.

---

# Towny Recruits 1.1.0 tactical validation

Java 17 compilation passed against real Forge/Mohist 47.4.23, Recruits 1.15.0, Supplementaries and the official Minecraft 1.20.1 client remapped to SRG. Client SHA-1: `0c3ec587af28e5a785c0b4a7b8a30f9a8f78f838`; official client mappings SHA-1: `6c48521eed01fe2e8ecdadbd5ae348415f3c47da`. No API stubs or downloaded game libraries are included in the production JAR.

JAR SHA-256: `1348f40e390c5d2bb92725c4dc575ac59b9dd1c9c3ca084127aec79c5f89d137`.

- Passed 1,536 formation/count cases (1–128), distinct slots, centered layouts, rotations, outward square sides and two pike ranks.
- Integrated 255 valid trajectories with the same move/drag/gravity update as Moonlight; checked unreachable arcs and fuse bounds, uniform disk scatter, 18,000-tick cooldown boundary and shared bomb capacity.
- Round-tripped every mode/formation request and a mixed-validity 128-unit preview with actual FriendlyByteBuf; rejected oversized groups, invalid modes, duplicate groups and non-finite coordinates.
- Executed actual compiled bomb/container/slot hook bodies in a CPU harness with fixture inventories: mixed bomb types, one-slot and second-slot limits, equipment rejection, pickup conservation (64 → 1 + 63), reinsertion after removal, and unrelated inventory behavior. This harness is not a Minecraft server boot.
- Applied the real Mixin transformer and ASM verification to Entity, Slot, RecruitSimpleContainer, all three native equipment-slot classes, CommandEvents, CommandScreen and HumanoidModel, in addition to the existing 23 server targets and human renderer.
- Verified the preview path-search receiver originates from an independent GroundPathNavigation. The regression rejects the previous compiled implementation, which could change the active navigation cache before click confirmation. Door, float and fence flags are copied for planning.
- Passed existing Towny policy/reflection, census, real NBT, appearance, skin generation and compiled renderer-hook regression checks. Complete output: [test-results.txt](test-results.txt).

A complete running hybrid server with graphical clients has **not** been tested. March cohesion under live navigation, visual pike/item poses, Copycats slope appearance, claim-boundary explosions and large-army TPS still require the acceptance scenarios in [TACTICS.md](TACTICS.md). Automated geometry and bytecode checks do not establish live gameplay behavior.

The installed copies, ADM, lock and update ZIP are checked by `validation/check_installed_releases.py`, `validation/reconcile_modpack.py` and package byte comparisons when preparing the release.

---

# Validation — 1.0.4, 2026-11-01

## Height balance 1.0.4

- User confirmed that 1.0.3 runs and supplied an in-game screenshot showing too many recruits shorter than the player.
- Main height band moved from 1.75–1.90 to 1.86–1.94, close to the player's rendered humanoid silhouette. New intended weights: 92% near player, 5% moderately taller, 2% visibly shorter, 1% very tall.
- Deterministic 300,000 UUID sample passes: 92.02%, 4.94%, 2.06%, 0.99%, respectively; all 128 skins remain reachable; height endpoints remain 1.50–2.50.
- Tests enforce the short-recruit proportion below 2.2%, the main band above 91.5%, stable UUID serialization, and coherent render/collision/eye factors.
- Renderer and size event hooks are byte-for-byte unchanged from working 1.0.3. Existing identity gets a new deterministic height when the entity joins a world; skin selection is unchanged.
- Full graphical 1.0.4 gameplay has not been run in this environment.

## Client crash regression

- User log: Forge client 47.4.28, Recruits 1.15.0, TownyRecruits 1.0.2 failed at EntityRenderersEvent.RegisterRenderers with NoClassDefFoundError for `org.spongepowered.asm.synthetic.args.Args$1`.
- The new regression was run against the compiled 1.0.2 hooks and detected that exact generated dependency. The same check passes after replacement with typed variable hooks in 1.0.3.
- The actual transformed Recruits human renderer passes ASM verification and contains no generated Args references. Hook order is checked: entity capture → pose scale → native renderer → restoration.
- A CPU-only runtime harness uses the actual compiled hook bodies (renamed to a plain test class), resolves their dependencies and executes scale/restoration with the real PoseStack/JOML classes, including nested rendering and a redundant restore. Matrices restore exactly within float tolerance; the 128 resource paths initialize successfully.
- The harness is not a complete graphical Minecraft/Forge boot. A full boot of the user's exact client, in-game appearance/equipment and mounted poses remain unverified in this environment.

## Appearance checks

- 128 unique original 64x64 RGBA skins pass PNG/UV coverage and deterministic regeneration checks; all checksums are pinned in assets/skins-manifest.json.
- 300,000 UUIDs: all 128 skins reachable, identical results after UUID serialization, height range 1.5000..2.5000, 92.02% in 1.86..1.94, 4.94% moderately taller, 2.06% visibly short, 0.99% very tall.
- Policy checks verify collision/eye scale and 32-pixel standard humanoid render-height calibration.
- The actual RecruitHumanRenderer client-side Mixin transformation and ASM BasicVerifier checks pass, including texture selection and balanced pose-stack scale/restoration. The 23 server target checks still pass independently.
- Main compilation uses real runtime classes; the renderer hook does not bundle client API stubs. No layer-buffer argument capture or generated Args class is needed.
- Skin gallery inspected as a flat preview. A live graphical client test of the new skins, equipment animations, collision/navigation clearance and mounting poses remains pending.

## Reproduced bug and regression checks

- Original 1.0.0 failed while reading the provided workspace worlds: `Truncated entity region: .../world/entities/r.-1.0.mca`. There are 66 entity-region files in that snapshot, including two zero-byte files.
- 1.0.1 completes the same read-only census successfully. Empty files remain untouched. This is a file-level reproduction, not a running-server test.
- Regression tests cover an empty region alongside populated regions, a non-empty corrupt header, no partial ledger commit after failure, and a successful retry after repair.
- Hire-policy regression distinguishes `census=false` at `0/100` from an exhausted cap, absent nation, owned recruit and unavailable Towny.
- Cleanup regressions cover deleted `tr_` and legacy `ec_` faction IDs, outgoing/incoming diplomatic relations and embargo entries; unrelated manual faction records remain intact.
- ADM roundtrip preserves every other mod row and resource pack; only TownyRecruits version/checksum and required integrity metadata change.

## Passed

- Java 17 compilation against the actual Mohist/Forge 1.20.1 47.4.23 runtime, with the exact uploaded mod/plugin JAR hashes below. No API stubs are packaged or used for main compilation.
- Pure policy tests: baseline/additional-town limits, zero and fixed overrides, UUID identity, symmetric enemies, accepted alliances, neutrality and conflict priority.
- Reflection contract tests against Towny 0.101.2.0: nation/member/territory APIs and the concrete event classes used by the bridge.
- Actual Minecraft NBT roundtrip: nation overrides, counts retained for unloaded units, retirement on player departure and nation deletion, retirement surviving restart.
- A synthetic compressed `.mca` entity-region migration test: recruit discovery, idempotent tracking and byte-for-byte unchanged input region.
- Real Sponge Mixin transformation and ASM BasicVerifier analysis for all 23 target classes, including both upkeep goals, hire/transfer/payment hooks, faction controls, diplomacy and 13 client-to-server mutation packet handlers.
- Uploaded Musket and Boomsticks SHA-256 sidecars match their JAR files.

## Pinned input SHA-256

```text
5c0c9252b332babf7e7cf5fc9a5a6f08018df5b9f86827853db2cb3f39b127ce  recruits-1.20.1-1.15.0.jar
c21dd5c8e63401fe5f14be77a33e96afa727b9c8214a7f85c2c4f67b761645a6  Towny-0.101.2.0.jar
4e213daae42d92606639dd98c340e2274ffaa460a4832850d468900ee326a5ad  musketmod-1.20.1-forge-1.5.4.jar
b5ba292cde703946a18cd18c87c93ae970eef057dbbeff8c6b6243aa4397c3c9  medieval_boomsticks-no_stars (8).jar
```

## Not yet validated

- Booting this new integration in a complete running hybrid server and joining graphical clients.
- The full gameplay checklist in README, including animation appearance and chest access at a live claim border.
- TPS/load measurements with large armies.
- Arclight, Magma or other Forge/Bukkit hybrid implementations.
- Coexistence with other Recruits integration mods or scoreboard controllers. Remove competing integrations before testing.
- Importing an old, populated additional world after the first completed census. Initial migration includes currently loaded Bukkit worlds; later imported worlds must have their old recruits loaded/adopted before relying on their count.

Tests show bytecode compatibility and policy/persistence behavior; they do not establish production gameplay compatibility.
