package com.quintonc.vs_sails.blocks;

import com.quintonc.vs_sails.registration.SailsBlocks;
import com.quintonc.vs_sails.ship.SailsShipControl;
import kotlin.Pair;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.block.*;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3d;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.mod.common.VSGameUtilsKt;
import org.valkyrienskies.mod.common.ValkyrienSkiesMod;
import org.valkyrienskies.mod.common.assembly.ICopyableBlock;

import java.util.List;
import java.util.Map;

public class SailBlock extends Block implements ICopyableBlock {

    public static final BooleanProperty SET = BooleanProperty.create("set");
    public static final BooleanProperty INVISIBLE = BooleanProperty.create("invisible");

    public static final Logger LOGGER = LoggerFactory.getLogger("sail_block");
    public static final VoxelShape SET_SHAPE = Block.box(0,0,0,16,16,16);

    public SailBlock(Properties settings) {
        super(settings);
        this.registerDefaultState(this.defaultBlockState().setValue(SET, true).setValue(INVISIBLE, false));
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return this.defaultBlockState().setValue(SET, true);
    }

    @SuppressWarnings("deprecation")
    public void onPlace(BlockState state, Level world, BlockPos pos, BlockState oldState, boolean notify) {
        if (!world.isClientSide && !state.equals(oldState)) {
            SailsShipControl.markDirty(world, pos);
        }
    }

    @SuppressWarnings("deprecation")
    public InteractionResult use(BlockState state, Level world, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack heldItem = player.getItemInHand(hand);
        if (heldItem.is(Items.POTION) && PotionUtils.getPotion(heldItem) == Potions.WATER) {
            BlockState regularState = toRegularState(state);
            if (regularState != null) {
                if (!world.isClientSide) {
                    world.setBlock(pos, regularState, 10);
                    world.playSound(null, pos, SoundEvents.BOTTLE_EMPTY, SoundSource.BLOCKS, 1.0F, 1.0F);
                    if (world instanceof ServerLevel serverLevel) {
                        serverLevel.sendParticles(ParticleTypes.SPLASH,
                                pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D,
                                12, 0.3D, 0.3D, 0.3D, 0.02D);
                    }
                }
                return InteractionResult.sidedSuccess(world.isClientSide);
            }
        }

        if (heldItem.is(Items.MAGMA_CREAM)) {
            BlockState magmaState = toMagmaCoatedState(state);
            if (magmaState != null) {
                if (!world.isClientSide) {
                    world.setBlock(pos, magmaState, 10);
                    world.playSound(null, pos, SoundEvents.HONEY_BLOCK_PLACE, SoundSource.BLOCKS, 1.0F, 1.0F);
                    if (world instanceof ServerLevel serverLevel) {
                        serverLevel.sendParticles(new ItemParticleOption(ParticleTypes.ITEM, new ItemStack(Items.MAGMA_CREAM)),
                                pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D,
                                10, 0.3D, 0.3D, 0.3D, 0.02D);
                    }
                    if (!player.getAbilities().instabuild) {
                        heldItem.shrink(1);
                    }
                }
                return InteractionResult.sidedSuccess(world.isClientSide);
            }
        }

        TagKey<Item> tag = TagKey.create(Registries.ITEM, new ResourceLocation("sail_togglers"));
        if (!heldItem.is(tag)) {
            if (!world.isClientSide) {
                toggleFirstSail(state, world, pos);
            } else {
                boolean bl = state.getValue(SET);
                world.playSound(player, pos, bl ? SoundEvents.LEASH_KNOT_PLACE : SoundEvents.WOOL_PLACE, SoundSource.BLOCKS, 0.75F, world.getRandom().nextFloat() * 0.1F + 0.9F);

            }
            return InteractionResult.sidedSuccess(world.isClientSide);
        }

        return InteractionResult.PASS;
    }

    public BlockState toMagmaCoatedState(BlockState state) {
        if (isMagmaCoated()) {
            return null;
        }

        Block magmaBlock = SailsBlocks.getMagmaSailBlock(state.getBlock());
        if (!(magmaBlock instanceof SailBlock magmaSailBlock)) {
            return null;
        }

        return magmaSailBlock.defaultBlockState()
                .setValue(SET, state.getValue(SET))
                .setValue(INVISIBLE, state.getValue(INVISIBLE));
    }

    public BlockState toRegularState(BlockState state) {
        if (!isMagmaCoated()) {
            return null;
        }

        Block regularBlock = SailsBlocks.getRegularSailBlock(state.getBlock());
        if (!(regularBlock instanceof SailBlock regularSailBlock)) {
            return null;
        }

        return regularSailBlock.defaultBlockState()
                .setValue(SET, state.getValue(SET))
                .setValue(INVISIBLE, state.getValue(INVISIBLE));
    }

    public boolean isMagmaCoated() {
        return false;
    }

    public void toggleFirstSail(BlockState state, Level world, BlockPos pos) { //todo make this called by rope as well
        com.quintonc.vs_sails.ship.SailRigging.set(world,pos,!state.getValue(SET));
    }

    public void toggleOff(BlockState state, Level world, BlockPos pos) {
        if (world.isClientSide) return;
        SailsShipControl.markDirty(world, pos);

        if ( // a sail should become a "furled" sail if:
                // it has a non-sail block directly or diagonally adjacent to it
                //try horizontalFaceNeighbors.stream().anyMatch(offset -> isNotSailOrAir(world, pos.offset(offset)))
                isNotSailOrAir(world, pos.offset(1, 1, 0))
                        || isNotSailOrAir(world, pos.offset(-1, 1, 0))
                        || isNotSailOrAir(world, pos.offset(0, 1, 1))
                        || isNotSailOrAir(world, pos.offset(0, 1, -1))
                        || isNotSailOrAir(world, pos.offset(1, -1, 0))
                        || isNotSailOrAir(world, pos.offset(-1, -1, 0))
                        || isNotSailOrAir(world, pos.offset(0, -1, 1))
                        || isNotSailOrAir(world, pos.offset(0, -1, -1))
                        || isNotSailOrAir(world, pos.above())
                        || isNotSailOrAir(world, pos.below())
                // it has air directly above it and fewer than 2 sail blocks diagonally above it
                        //|| (world.getBlockState(pos.above()).isAir() && fewerThanXSailsHorizontally(world, pos.above(), 2))
                // it has a sail above it, fewer than 3 sail blocks diagonally above it, and at least 2 sail blocks below it
                        //|| (world.getBlockState(pos.above()).getBlock() instanceof SailBlock && fewerThanXSailsHorizontally(world, pos.above(), 3) && atLeastXSailsHorizontally(world, pos.below(), 2))
        ) {
            //fixme THE PROBLEM AREA
            //if (atLeastXSailsHorizontally(world, pos.above(), 1) && !world.getBlockState(pos.above()).isAir()/*has a solid block above*/ && hasMismatchedOppositeAir(world, pos)) { //also check if sail has above and below perpendicular to the spar
               // state = state.setValue(INVISIBLE, true);
            //} else {
            //if (atLeastXSailsHorizontally(world, pos.above(), 1) && atLeastXSailsHorizontally(world, pos.below(), 1)) {
                //if (noBlockHereOrAboveOrBelow(world, pos.north()) != noBlockHereOrAboveOrBelow(world, pos.south()) || noBlockHereOrAboveOrBelow(world, pos.east()) != noBlockHereOrAboveOrBelow(world, pos.west())) {
                //    state = state.setValue(INVISIBLE, true);
                //} else {
                //    state = state.setValue(INVISIBLE, false);
                //}
            //} else {
                state = state.setValue(INVISIBLE, false);
            //}

            //}
        } else {
            state = state.setValue(INVISIBLE, true);
        }

        state = state.setValue(SET, false);
        world.setBlock(pos, state, 10);
        updateAdjacents(world, pos, this);
    }

    private boolean isNotSailOrAir(Level world, BlockPos pos) {
        BlockState state = world.getBlockState(pos);
        return !(state.getBlock() instanceof SailBlock || state.isAir() || !state.isCollisionShapeFullBlock(world, pos));
    }

    private boolean fewerThanXSailsHorizontally(Level world, BlockPos pos, int x) {
        return countHorizontallyAdjacentSails(world, pos) < x;
    }

    private boolean atLeastXSailsHorizontally(Level world, BlockPos pos, int x) {
        return countHorizontallyAdjacentSails(world, pos) >= x;
    }

    //private List<Vec3i> horizontalFaceNeighbors = List.of(Direction.NORTH.getNormal(), Direction.SOUTH.getNormal(), Direction.EAST.getNormal(), Direction.WEST.getNormal());
    //private List<Vec3i> horizontalEdgeNeighbors = List.of(new Vec3i(1, 0, 1), new Vec3i());

    private int countHorizontallyAdjacentSails(Level world, BlockPos pos) {
        int n = 0;
        if (world.getBlockState(pos).getBlock() instanceof SailBlock) {n++;}
//        for (var offset : horizontalFaceNeighbors) {
//            if (world.getBlockState(pos.offset(offset)).getBlock() instanceof SailBlock) {
//                n++;
//            }
//        }
        if (world.getBlockState(pos.north()).getBlock() instanceof SailBlock) {n++;}
        if (world.getBlockState(pos.south()).getBlock() instanceof SailBlock) {n++;}
        if (world.getBlockState(pos.east()).getBlock() instanceof SailBlock) {n++;}
        if (world.getBlockState(pos.west()).getBlock() instanceof SailBlock) {n++;}
        if (world.getBlockState(pos.east().north()).getBlock() instanceof SailBlock) {n++;}
        if (world.getBlockState(pos.east().south()).getBlock() instanceof SailBlock) {n++;}
        if (world.getBlockState(pos.west().north()).getBlock() instanceof SailBlock) {n++;}
        if (world.getBlockState(pos.west().south()).getBlock() instanceof SailBlock) {n++;}
        return n;
    }

    private boolean noBlockHereOrAboveOrBelow(Level world, BlockPos pos) {
        return isNotSailOrAir(world, pos) && isNotSailOrAir(world, pos.above()) && isNotSailOrAir(world, pos.below());
    }

    private int countHorizontallyAdjacentSolids(Level world, BlockPos pos) {
        int n = 0;
        if (!world.getBlockState(pos).isAir()) {n++;}
        if (!world.getBlockState(pos.north()).isAir()) {n++;}
        if (!world.getBlockState(pos.south()).isAir()) {n++;}
        if (!world.getBlockState(pos.east()).isAir()) {n++;}
        if (!world.getBlockState(pos.west()).isAir()) {n++;}
        if (!world.getBlockState(pos.east().north()).isAir()) {n++;}
        if (!world.getBlockState(pos.east().south()).isAir()) {n++;}
        if (!world.getBlockState(pos.west().north()).isAir()) {n++;}
        if (!world.getBlockState(pos.west().south()).isAir()) {n++;}
        return n;
    }

    //kill me
    private boolean hasMismatchedOppositeAir(Level world, BlockPos pos) {
        return ((world.getBlockState(pos.north()).isAir() != world.getBlockState(pos.south()).isAir()) && (world.getBlockState(pos.north()).getBlock() instanceof SailBlock || world.getBlockState(pos.south()).getBlock() instanceof SailBlock)) ||
                ((world.getBlockState(pos.east()).isAir() != world.getBlockState(pos.west()).isAir()) && (world.getBlockState(pos.east()).getBlock() instanceof SailBlock || world.getBlockState(pos.west()).getBlock() instanceof SailBlock)) ||
                ((world.getBlockState(pos.north().east()).isAir() != world.getBlockState(pos.south().west()).isAir()) && (world.getBlockState(pos.north().east()).getBlock() instanceof SailBlock || world.getBlockState(pos.south().west()).getBlock() instanceof SailBlock)) ||
                ((world.getBlockState(pos.north().west()).isAir() != world.getBlockState(pos.south().east()).isAir()) && (world.getBlockState(pos.north().west()).getBlock() instanceof SailBlock || world.getBlockState(pos.south().east()).getBlock() instanceof SailBlock));
    }

    @SuppressWarnings("deprecation")
    public void neighborChanged(BlockState state, Level world, BlockPos pos, Block sourceBlock, BlockPos sourcePos, boolean notify) {
        if (world.isClientSide) return;
        SailsShipControl.markDirty(world, pos);
        //LOGGER.info("neighborUpdate called!");
        //LOGGER.info(" " + sourceBlock.getClass());

        //if source block is a sail and is not air, check if can toggle state
        if ((sourceBlock instanceof SailBlock || sourceBlock instanceof SailToggleBlock) && !world.getBlockState(sourcePos).isAir()) {
            //LOGGER.info(":)");

            //if this block's set state does not match the source block's, change it to match
            BlockState sourceState = world.getBlockState(sourcePos);
            if (sourceState.hasProperty(SET) && sourceState.getValue(SET) != state.getValue(SET)) {
                if (sourceState.getValue(SET)) {
                    //toggle on
                    state = state.setValue(SET, true);
                    state = state.setValue(INVISIBLE, false);
                    world.setBlock(pos, state, 10);
                    updateAdjacents(world, pos, this);
                } else {
                    toggleOff(state, world, pos);
                }
            }
        }
    }

    public void updateAdjacents(Level world, BlockPos sourcePos, Block sourceBlock) {
        world.blockUpdated(sourcePos, sourceBlock);

        world.neighborChanged(sourcePos.offset(1, 1, 0), sourceBlock, sourcePos);
            //pos.x+1 pos.y+1 pos.z+1
            //pos.x+1 pos.y+1 pos.z-1
        world.neighborChanged(sourcePos.offset(1, -1, 0), sourceBlock, sourcePos);
            //pos.x+1 pos.y-1 pos.z+1
            //pos.x+1 pos.y-1 pos.z-1
        world.neighborChanged(sourcePos.offset(1, 0, 1), sourceBlock, sourcePos);
        world.neighborChanged(sourcePos.offset(1, 0, -1), sourceBlock, sourcePos);

        world.neighborChanged(sourcePos.offset(-1, 1, 0), sourceBlock, sourcePos);
            //pos.x-1 pos.y+1 pos.z+1
            //pos.x-1 pos.y+1 pos.z-1
        world.neighborChanged(sourcePos.offset(-1, -1, 0), sourceBlock, sourcePos);
            //pos.x-1 pos.y-1 pos.z+1
            //pos.x-1 pos.y-1 pos.z-1
        world.neighborChanged(sourcePos.offset(-1, 0, 1), sourceBlock, sourcePos);
        world.neighborChanged(sourcePos.offset(-1, 0, -1), sourceBlock, sourcePos);

        world.neighborChanged(sourcePos.offset(0, 1, 1), sourceBlock, sourcePos);
        world.neighborChanged(sourcePos.offset(0, 1, -1), sourceBlock, sourcePos);

        world.neighborChanged(sourcePos.offset(0, -1, 1), sourceBlock, sourcePos);
        world.neighborChanged(sourcePos.offset(0, -1, -1), sourceBlock, sourcePos);
    }

    public char calculateSailType(Level world, BlockPos pos, SailsShipControl controller) {
        if (!world.getBlockState(pos.north()).isAir() || !world.getBlockState(pos.south()).isAir()) {
            if (world.getBlockState(pos.east()).isAir() && world.getBlockState(pos.west()).isAir()) {
                if (controller.shipDirection == Direction.EAST || controller.shipDirection == Direction.WEST) {
                    return 's'; //fixme use static final strings to make this more readable
                } else {
                    return 'f';
                }
            } else {
                return 'x';
            }
        } else if (!world.getBlockState(pos.east()).isAir() || !world.getBlockState(pos.west()).isAir()) {
            if (world.getBlockState(pos.north()).isAir() && world.getBlockState(pos.south()).isAir()) {
                if (controller.shipDirection == Direction.EAST || controller.shipDirection == Direction.WEST) {
                    return 'f';
                } else {
                    return 's';
                }
            }
        }
        //sail is neither square nor fore&aft. Should only happen if sail has no horizontal adjacent blocks (or has more than one occupied side)
        return 'x';
    }

    private void addSailToShip(Level world, BlockPos pos, SailsShipControl controller) {
        //sails only add to one of the sail types when they have free opposite faces
        char sailType = calculateSailType(world, pos, controller);
        if (sailType == 's') {
            controller.numSquareSails++;
            //LOGGER.info("(a) NUMSQ: " + controller.numSquareSails);
        } else if (sailType == 'f') {
            controller.numFnASails++;
            //LOGGER.info("(a) NUMFA: " + controller.numFnASails);
        }
        controller.numSails++;
        //LOGGER.info("(a) NUMSAILS: " + controller.numSails);
    }

    private void removeSailFromShip(Level world, BlockPos pos, SailsShipControl controller) {
        char sailType = calculateSailType(world, pos, controller);
        if (sailType == 's') {
            controller.numSquareSails--;
            //LOGGER.info("(r) NUMSQ: " + controller.numSquareSails);
        }
        if (sailType == 'f') {
            controller.numFnASails--;
            //LOGGER.info("(r) NUMFA: " + controller.numFnASails);
        }
        controller.numSails--;
        //LOGGER.info("(r) NUMSAILS: " + controller.numSails);
    }

    @SuppressWarnings({"deprecation","UnstableApiUsage"})
    public void onRemove(BlockState state, Level world, BlockPos pos, BlockState newState, boolean moved) {
        if (!world.isClientSide && !state.equals(newState)) {
            SailsShipControl.markDirty(world, pos);
        }
        super.onRemove(state, world, pos, newState, moved);
    }

    public Item getSailItem() {
        return this.asItem();
    }

    public boolean isFlammable(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return true;
    }

    public int getFlammability(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return 5;
    }

    public int getFireSpreadSpeed(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return 20;
    }

    @SuppressWarnings("deprecation")
    public VoxelShape getCollisionShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
        if (state.getValue(INVISIBLE)) {
            return Shapes.empty();
        }
        return SET_SHAPE;
    }

//    @SuppressWarnings("deprecation")
//    public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
//        if (state.getValue(INVISIBLE)) {
//            return Shapes.empty();
//        }
//        return SET_SHAPE;
//    }

//    @Override
//    public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
//        if (state.getValue(INVISIBLE)) {
//            return Block.box(0,0,0,16,16,16);
//        } else {
//            return SET_SHAPE;
//        }
//    }

    public boolean propagatesSkylightDown(BlockState state, BlockGetter world, BlockPos pos) {
        return !state.getValue(SET);
    }

    //fixme this method of face culling only works for faces aligned with the grid
    @SuppressWarnings("deprecation")
    @Override
    public boolean skipRendering(BlockState state, BlockState stateFrom, Direction direction) {
        return stateFrom.is(this) || super.skipRendering(state, stateFrom, direction);
    }

    @Override
    @SuppressWarnings("deprecation")
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(SET);
        builder.add(INVISIBLE);
    }

    @Override
    public @Nullable CompoundTag onCopy(@NotNull ServerLevel serverLevel, @NotNull BlockPos blockPos, @NotNull BlockState blockState, @Nullable BlockEntity blockEntity, @NotNull List<? extends ServerShip> list, @NotNull Map<Long, ? extends org.joml.Vector3dc> map) {
        return null;
    }

    @Override
    public @Nullable CompoundTag onPaste(@NotNull ServerLevel serverLevel, @NotNull BlockPos blockPos, @NotNull BlockState blockState, @NotNull Map<Long, Long> map, @NotNull Map<Long, ? extends Pair<? extends org.joml.Vector3dc, ? extends org.joml.Vector3dc>> map1, @Nullable CompoundTag compoundTag) {
        SailsShipControl.markDirty(serverLevel, blockPos);
        // The global ship-load handler starts a recount after assembly/template loading.
        return null;
    }

}

