/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Holder
 *  net.minecraft.core.HolderGetter
 *  net.minecraft.core.registries.BuiltInRegistries
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.nbt.ListTag
 *  net.minecraft.nbt.NbtUtils
 *  net.minecraft.nbt.StringTag
 *  net.minecraft.nbt.Tag
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.ChunkPos
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.biome.Biome
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.BlockStateProperties
 *  net.minecraft.world.level.block.state.properties.DoubleBlockHalf
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.chunk.ChunkAccess
 *  net.minecraft.world.level.chunk.LevelChunk
 *  net.minecraft.world.level.chunk.LevelChunkSection
 *  net.minecraft.world.level.levelgen.Heightmap$Types
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.common.util.BlockSnapshot
 *  net.minecraftforge.event.TickEvent$LevelTickEvent
 *  net.minecraftforge.event.TickEvent$Phase
 *  net.minecraftforge.event.level.BlockEvent$BreakEvent
 *  net.minecraftforge.event.level.BlockEvent$EntityMultiPlaceEvent
 *  net.minecraftforge.event.level.BlockEvent$EntityPlaceEvent
 *  net.minecraftforge.event.level.ChunkDataEvent$Load
 *  net.minecraftforge.event.level.ChunkDataEvent$Save
 *  net.minecraftforge.event.level.ChunkEvent$Load
 *  net.minecraftforge.event.level.ChunkEvent$Unload
 *  net.minecraftforge.event.server.ServerStoppedEvent
 *  sereneseasons.api.season.ISeasonState
 *  sereneseasons.api.season.SeasonHelper
 *  sereneseasons.init.ModConfig
 */
package ua.empirecraft.leaves;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.BlockSnapshot;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ChunkDataEvent;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import sereneseasons.api.season.ISeasonState;
import sereneseasons.api.season.SeasonHelper;
import sereneseasons.init.ModConfig;
import ua.empirecraft.leaves.PlantCatalog;
import ua.empirecraft.leaves.SeasonCurve;
import ua.empirecraft.leaves.SeasonalLeaves;
import ua.empirecraft.leaves.VegetationConfig;
import ua.empirecraft.leaves.VegetationPolicy;
import ua.empirecraft.leaves.WildernessAccess;

public final class SeasonalVegetation {
    private static final String DATA = "empirecraft_seasonal_vegetation_v1";
    private static SeasonalVegetation instance;
    private final Map<ChunkAccess, CompoundTag> data = Collections.synchronizedMap(new WeakHashMap());
    private final Map<ServerLevel, LinkedHashMap<Long, Work>> worlds = new IdentityHashMap<ServerLevel, LinkedHashMap<Long, Work>>();
    private final WildernessAccess wilderness = new WildernessAccess();

    SeasonalVegetation() {
        instance = this;
        MinecraftForge.EVENT_BUS.addListener(this::read);
        MinecraftForge.EVENT_BUS.addListener(this::save);
        MinecraftForge.EVENT_BUS.addListener(this::load);
        MinecraftForge.EVENT_BUS.addListener(this::unload);
        MinecraftForge.EVENT_BUS.addListener(this::tick);
        MinecraftForge.EVENT_BUS.addListener(this::placed);
        MinecraftForge.EVENT_BUS.addListener(this::broken);
        MinecraftForge.EVENT_BUS.addListener(this::stopped);
    }

    private void stopped(ServerStoppedEvent serverStoppedEvent) {
        this.worlds.clear();
        this.data.clear();
        instance = null;
    }

    private void read(ChunkDataEvent.Load load) {
        this.data.put(load.getChunk(), load.getData().m_128469_(DATA).m_6426_());
    }

    private void save(ChunkDataEvent.Save save) {
        CompoundTag compoundTag = this.data.get(save.getChunk());
        if (compoundTag != null) {
            save.getData().m_128365_(DATA, (Tag)compoundTag.m_6426_());
        }
    }

    private void load(ChunkEvent.Load load) {
        Object levelAccessor = load.getLevel();
        if (levelAccessor instanceof ServerLevel) {
            ServerLevel serverLevel2 = (ServerLevel)levelAccessor;
            levelAccessor = load.getChunk();
            if (levelAccessor instanceof LevelChunk) {
                LevelChunk levelChunk = (LevelChunk)levelAccessor;
                this.worlds.computeIfAbsent(serverLevel2, serverLevel -> new LinkedHashMap()).put(levelChunk.m_7697_().m_45588_(), new Work(levelChunk, this.data.computeIfAbsent((ChunkAccess)levelChunk, chunkAccess -> new CompoundTag())));
            }
        }
    }

    private void unload(ChunkEvent.Unload unload) {
        ServerLevel serverLevel;
        Object object = unload.getLevel();
        if (object instanceof ServerLevel && (object = this.worlds.get(serverLevel = (ServerLevel)object)) != null) {
            ((HashMap)object).remove(unload.getChunk().m_7697_().m_45588_());
        }
    }

    private Work work(ServerLevel serverLevel, BlockPos blockPos) {
        LinkedHashMap<Long, Work> linkedHashMap = this.worlds.get(serverLevel);
        return linkedHashMap == null ? null : linkedHashMap.get(ChunkPos.m_45589_((int)(blockPos.m_123341_() >> 4), (int)(blockPos.m_123343_() >> 4)));
    }

    private static String key(BlockPos blockPos) {
        return Long.toString(blockPos.m_121878_());
    }

    private void placed(BlockEvent.EntityPlaceEvent entityPlaceEvent) {
        ServerLevel serverLevel;
        LevelAccessor levelAccessor;
        block7: {
            block6: {
                levelAccessor = entityPlaceEvent.getLevel();
                if (!(levelAccessor instanceof ServerLevel)) break block6;
                serverLevel = (ServerLevel)levelAccessor;
                if (entityPlaceEvent.getEntity() instanceof Player) break block7;
            }
            return;
        }
        if (entityPlaceEvent instanceof BlockEvent.EntityMultiPlaceEvent) {
            var multiple = (BlockEvent.EntityMultiPlaceEvent)entityPlaceEvent;
            for (BlockSnapshot blockSnapshot : multiple.getReplacedBlockSnapshots()) {
                this.protect(serverLevel, blockSnapshot.getPos());
            }
        } else {
            this.protect(serverLevel, entityPlaceEvent.getPos());
        }
    }

    private void protect(ServerLevel serverLevel, BlockPos blockPos) {
        Work work = this.work(serverLevel, blockPos);
        if (work == null) {
            return;
        }
        SeasonalVegetation.cancel(work, blockPos);
        SeasonalVegetation.cancel(work, blockPos.m_7495_());
        BlockState blockState = serverLevel.m_8055_(blockPos);
        work.tag.m_128469_("NaturalTrees").m_128473_(key(blockPos));work.dirty();
        if (PlantCatalog.profile(blockState) != null || blockState.m_60713_(Blocks.f_50125_)) {
            work.protectedPos.add(blockPos.m_121878_());
            if (SeasonalVegetation.upper(blockState)) {
                work.protectedPos.add(blockPos.m_7495_().m_121878_());
            }
            work.dirty();
        }
    }

    private void broken(BlockEvent.BreakEvent breakEvent) {
        ServerLevel serverLevel;
        Object object = breakEvent.getLevel();
        if (object instanceof ServerLevel && (object = this.work(serverLevel = (ServerLevel)object, breakEvent.getPos())) != null) {
            BlockPos blockPos = breakEvent.getPos();
            ((Work)object).tag.m_128469_("NaturalTrees").m_128473_(key(blockPos));((Work)object).dirty();
            SeasonalVegetation.cancel((Work)object, blockPos);
            SeasonalVegetation.cancel((Work)object, blockPos.m_7495_());
            boolean bl = ((Work)object).protectedPos.remove(blockPos.m_121878_());
            if (SeasonalVegetation.tall(breakEvent.getState())) {
                bl |= ((Work)object).protectedPos.remove((SeasonalVegetation.upper(breakEvent.getState()) ? blockPos.m_7495_() : blockPos.m_7494_()).m_121878_());
            }
            if (bl) {
                ((Work)object).dirty();
            }
        }
    }

    private static void cancel(Work work, BlockPos blockPos) {
        if (work.records.m_128441_(SeasonalVegetation.key(blockPos))) {
            work.records.m_128473_(SeasonalVegetation.key(blockPos));
            work.dirty();
        }
    }

    private static boolean enabled(ServerLevel serverLevel) {
        return SeasonalLeaves.enabled() && (Boolean)VegetationConfig.ENABLED.get() != false && ModConfig.seasons.isDimensionWhitelisted(serverLevel.m_46472_());
    }

    private static boolean waterlogged(BlockState blockState) {
        return !blockState.m_60819_().m_76178_() || blockState.m_61138_((Property)BlockStateProperties.f_61362_) && (Boolean)blockState.m_61143_((Property)BlockStateProperties.f_61362_) != false;
    }

    private static boolean upper(BlockState blockState) {
        return blockState.m_61138_((Property)BlockStateProperties.f_61401_) && blockState.m_61143_((Property)BlockStateProperties.f_61401_) == DoubleBlockHalf.UPPER;
    }

    private static boolean tall(BlockState blockState) {
        return blockState.m_61138_((Property)BlockStateProperties.f_61401_);
    }

    private static double visible(ServerLevel serverLevel, BlockPos blockPos, PlantCatalog.Profile profile) {
        if (!SeasonalVegetation.enabled(serverLevel) || SeasonHelper.usesTropicalSeasons((Holder)serverLevel.m_204166_(blockPos))) {
            return 1.0;
        }
        ISeasonState iSeasonState = SeasonHelper.getSeasonState((Level)serverLevel);
        return VegetationPolicy.visibility(profile.seasons(), iSeasonState.getSeasonCycleTicks(), iSeasonState.getSubSeasonDuration());
    }

    private static boolean inSeason(ServerLevel serverLevel, BlockPos blockPos, BlockState blockState, PlantCatalog.Profile profile) {
        return SeasonCurve.threshold(blockPos.m_121878_() ^ (long)PlantCatalog.id(blockState).hashCode()) < SeasonalVegetation.visible(serverLevel, blockPos, profile);
    }

    private static boolean replaceable(BlockState blockState) {
        return blockState.m_60795_() || blockState.m_60713_(Blocks.f_50125_);
    }

    private static boolean soil(ServerLevel serverLevel, BlockPos blockPos) {
        return VegetationPolicy.SOILS.contains(PlantCatalog.id(serverLevel.m_8055_(blockPos.m_7495_())));
    }

    private static int rareCount(ServerLevel serverLevel, int n, int n2) {
        LevelChunk levelChunk = serverLevel.m_7726_().m_7131_(n, n2);
        if (levelChunk == null) {
            return Integer.MAX_VALUE;
        }
        int n3 = 0;
        for (int i = n * 16; i < n * 16 + 16; ++i) {
            block1: for (int j = n2 * 16; j < n2 * 16 + 16; ++j) {
                int n4 = levelChunk.m_5885_(Heightmap.Types.WORLD_SURFACE, i & 0xF, j & 0xF);
                for (int k = 0; k < 4; ++k) {
                    BlockState blockState = levelChunk.m_8055_(new BlockPos(i, n4 - k, j));
                    if (!VegetationPolicy.RARE.contains(PlantCatalog.id(blockState)) || SeasonalVegetation.upper(blockState)) continue;
                    ++n3;
                    continue block1;
                }
            }
        }
        return n3;
    }

    private boolean rareAllowed(ServerLevel serverLevel, BlockPos blockPos, Work work) {
        return VegetationPolicy.rareChunk(serverLevel.m_7328_(), blockPos.m_123341_() >> 4, blockPos.m_123343_() >> 4, (Integer)VegetationConfig.RARE_CHUNKS.get()) && (work == null || serverLevel.m_46467_() >= work.tag.m_128454_("RareUntil")) && SeasonalVegetation.rareCount(serverLevel, blockPos.m_123341_() >> 4, blockPos.m_123343_() >> 4) == 0;
    }

    private void rareSeen(ServerLevel serverLevel, Work work) {
        long l = serverLevel.m_46467_() + (long)((Integer)VegetationConfig.RARE_DAYS.get()).intValue() * (long)SeasonHelper.getSeasonState((Level)serverLevel).getDayDuration();
        if (l > work.tag.m_128454_("RareUntil")) {
            work.tag.m_128356_("RareUntil", l);
            work.dirty();
        }
    }

    public static boolean allowRenewal(ServerLevel serverLevel, int n, int n2, BlockState blockState) {
        if (instance == null || !SeasonalVegetation.enabled(serverLevel)) {
            return true;
        }
        BlockPos blockPos = new BlockPos(n * 16 + 8, 64, n2 * 16 + 8);
        PlantCatalog.Profile profile = PlantCatalog.profile(blockState);
        if (profile != null && !SeasonalVegetation.inSeason(serverLevel, blockPos, blockState, profile)) {
            return false;
        }
        return !VegetationPolicy.RARE.contains(PlantCatalog.id(blockState)) || instance.rareAllowed(serverLevel, blockPos, instance.work(serverLevel, blockPos));
    }

    public static void renewalComplete(ServerLevel serverLevel, int n, int n2) {
        if (instance == null || !SeasonalVegetation.enabled(serverLevel) || !VegetationPolicy.rareChunk(serverLevel.m_7328_(), n, n2, (Integer)VegetationConfig.RARE_CHUNKS.get())) {
            return;
        }
        BlockPos blockPos = new BlockPos(n * 16 + 8, 64, n2 * 16 + 8);
        Work work = instance.work(serverLevel, blockPos);
        if (work != null && SeasonalVegetation.rareCount(serverLevel, n, n2) > 0) {
            instance.rareSeen(serverLevel, work);
        }
    }

    private boolean restore(ServerLevel serverLevel, Work work, String string) {
        CompoundTag compoundTag = work.records.m_128469_(string);
        BlockPos blockPos = BlockPos.m_122022_((long)compoundTag.m_128454_("pos"));
        ResourceLocation resourceLocation = ResourceLocation.m_135820_((String)compoundTag.m_128469_("state").m_128461_("Name"));
        if (resourceLocation == null || !BuiltInRegistries.f_256975_.m_7804_(resourceLocation)) {
            return false;
        }
        BlockState blockState = NbtUtils.m_247651_((HolderGetter)BuiltInRegistries.f_256975_.m_255303_(), (CompoundTag)compoundTag.m_128469_("state"));
        PlantCatalog.Profile profile = PlantCatalog.profile(blockState);
        if (profile != null && !SeasonalVegetation.inSeason(serverLevel, blockPos, blockState, profile)) {
            return false;
        }
        if (SeasonalVegetation.enabled(serverLevel) && VegetationPolicy.RARE.contains(PlantCatalog.id(blockState)) && !this.rareAllowed(serverLevel, blockPos, work)) {
            return false;
        }
        if (!this.wilderness.allowed(serverLevel, blockPos)) {
            return false;
        }
        boolean bl = compoundTag.m_128425_("upper", 10);
        if (!SeasonalVegetation.replaceable(serverLevel.m_8055_(blockPos)) || bl && !SeasonalVegetation.replaceable(serverLevel.m_8055_(blockPos.m_7494_())) || !SeasonalVegetation.soil(serverLevel, blockPos) || !blockState.m_60710_((LevelReader)serverLevel, blockPos)) {
            work.records.m_128473_(string);
            work.dirty();
            return true;
        }
        if (bl) {
            ResourceLocation resourceLocation2 = ResourceLocation.m_135820_((String)compoundTag.m_128469_("upper").m_128461_("Name"));
            if (resourceLocation2 == null || !BuiltInRegistries.f_256975_.m_7804_(resourceLocation2)) {
                return false;
            }
            BlockState blockState2 = NbtUtils.m_247651_((HolderGetter)BuiltInRegistries.f_256975_.m_255303_(), (CompoundTag)compoundTag.m_128469_("upper"));
            serverLevel.m_7731_(blockPos, blockState, 2);
            serverLevel.m_7731_(blockPos.m_7494_(), blockState2, 2);
        } else {
            serverLevel.m_7731_(blockPos, blockState, 2);
        }
        work.records.m_128473_(string);
        work.dirty();
        if (VegetationPolicy.RARE.contains(PlantCatalog.id(blockState))) {
            this.rareSeen(serverLevel, work);
        }
        return true;
    }

    private boolean hide(ServerLevel serverLevel, Work work, BlockPos blockPos, BlockState blockState) {
        PlantCatalog.Profile profile = PlantCatalog.profile(blockState);
        if (profile == null || SeasonalVegetation.upper(blockState) || SeasonalVegetation.waterlogged(blockState) || !SeasonalVegetation.soil(serverLevel, blockPos) || work.protectedPos.contains(blockPos.m_121878_()) || !serverLevel.m_45527_(blockPos.m_7494_()) || SeasonalVegetation.inSeason(serverLevel, blockPos, blockState, profile)) {
            return false;
        }
        if (!this.wilderness.allowed(serverLevel, blockPos) || work.records.m_128440_() >= 32768) {
            return false;
        }
        boolean bl = SeasonalVegetation.tall(blockState);
        BlockState blockState2 = serverLevel.m_8055_(blockPos.m_7494_());
        if (bl && (!blockState2.m_60713_(blockState.m_60734_()) || !SeasonalVegetation.upper(blockState2) || SeasonalVegetation.waterlogged(blockState2))) {
            return false;
        }
        CompoundTag compoundTag = new CompoundTag();
        compoundTag.m_128356_("pos", blockPos.m_121878_());
        compoundTag.m_128365_("state", (Tag)NbtUtils.m_129202_((BlockState)blockState));
        if (bl) {
            compoundTag.m_128365_("upper", (Tag)NbtUtils.m_129202_((BlockState)blockState2));
        }
        work.records.m_128365_(SeasonalVegetation.key(blockPos), (Tag)compoundTag);
        work.dirty();
        if (bl) {
            serverLevel.m_7731_(blockPos.m_7494_(), Blocks.f_50016_.m_49966_(), 2);
        }
        serverLevel.m_7731_(blockPos, Blocks.f_50016_.m_49966_(), 2);
        return true;
    }

    private int groundCount(ServerLevel serverLevel, Work work) {
        int n = 0;
        LevelChunk levelChunk = work.chunk;
        for (int i = 0; i < 16; ++i) {
            block1: for (int j = 0; j < 16; ++j) {
                int n2 = levelChunk.m_5885_(Heightmap.Types.WORLD_SURFACE, i, j);
                for (int k = 0; k < 3; ++k) {
                    if (PlantCatalog.profile(levelChunk.m_8055_(new BlockPos(levelChunk.m_7697_().m_45604_() + i, n2 - k, levelChunk.m_7697_().m_45605_() + j))) == null) continue;
                    ++n;
                    continue block1;
                }
            }
        }
        return n;
    }

    private boolean grow(ServerLevel serverLevel, Work work) {
        if (!SeasonalVegetation.enabled(serverLevel) || !((Boolean)VegetationConfig.SPAWN.get()).booleanValue() || this.groundCount(serverLevel, work) >= (Integer)VegetationConfig.DENSITY.get()) {
            return false;
        }
        RandomSource randomSource = serverLevel.m_213780_();
        for (int i = 0; i < 8; ++i) {
            int n;
            int n2 = work.chunk.m_7697_().m_45604_() + randomSource.m_188503_(16);
            BlockPos blockPos = new BlockPos(n2, serverLevel.m_6924_(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, n2, n = work.chunk.m_7697_().m_45605_() + randomSource.m_188503_(16)), n);
            if (!serverLevel.m_8055_(blockPos).m_60795_() || !SeasonalVegetation.soil(serverLevel, blockPos) || !serverLevel.m_45527_(blockPos) || !this.wilderness.allowed(serverLevel, blockPos) || work.protectedPos.contains(blockPos.m_121878_()) || work.records.m_128441_(SeasonalVegetation.key(blockPos))) continue;
            ArrayList<BlockState> arrayList = new ArrayList<BlockState>();
            HashSet<String> hashSet = new HashSet<String>(work.seeds);
            hashSet.add("minecraft:grass");
            boolean bl = randomSource.m_188503_(8) == 0;
            for (String string : hashSet) {
                BlockState blockState;
                PlantCatalog.Profile profile;
                ResourceLocation resourceLocation;
                if (!bl && !string.equals("minecraft:grass") && !string.equals("minecraft:fern") || (resourceLocation = ResourceLocation.m_135820_((String)string)) == null || !BuiltInRegistries.f_256975_.m_7804_(resourceLocation) || (profile = PlantCatalog.profile(blockState = ((Block)BuiltInRegistries.f_256975_.m_7745_(resourceLocation)).m_49966_())) == null || profile.renewal() || SeasonalVegetation.tall(blockState) || SeasonalVegetation.waterlogged(blockState) || !SeasonalVegetation.inSeason(serverLevel, blockPos, blockState, profile) || !VegetationPolicy.climate(profile.climate(), ((Biome)serverLevel.m_204166_(blockPos).m_203334_()).m_47554_()) || !blockState.m_60710_((LevelReader)serverLevel, blockPos)) continue;
                arrayList.add(blockState);
            }
            if (arrayList.isEmpty()) continue;
            return serverLevel.m_7731_(blockPos, (BlockState)arrayList.get(randomSource.m_188503_(arrayList.size())), 2);
        }
        return false;
    }

    private void tick(TickEvent.LevelTickEvent e) {
        if(e.phase!=TickEvent.Phase.END || !(e.level instanceof ServerLevel l))return;
        var map=worlds.get(l);if(map==null || map.isEmpty())return;
        var season=SeasonHelper.getSeasonState(l);
        int duration=season.getSubSeasonDuration();
        int current=duration>0?(int)(Math.floorMod((long)season.getSeasonCycleTicks(),12L*duration)/(3L*duration)):-1;
        boolean winter=current==3,summer=current==1;
        // Cleanup never spends its budget on restoration. Existing configs retain these independent limits.
        int scans=winter||summer?VegetationConfig.FAST_SCAN.get():VegetationConfig.SCAN.get();
        int changes=winter||summer?VegetationConfig.FAST_CHANGES.get():VegetationConfig.CHANGES.get();
        int visits=map.size();
        while(visits-->0 && scans>0 && changes>0){
            var it=map.entrySet().iterator();var entry=it.next();Work w=entry.getValue();it.remove();map.put(entry.getKey(),w);
            if(l.m_7726_().m_7131_(w.chunk.m_7697_().f_45578_,w.chunk.m_7697_().f_45579_)!=w.chunk)continue;
            if(!l.m_6857_().m_61937_(w.chunk.m_7697_().m_45615_()))continue;
            if(w.lastSeason!=current){w.lastSeason=current;w.nextScan=0;}
            if(l.m_46467_()<w.nextScan)continue;
            var sections=w.chunk.m_7103_();
            // Limit each chunk's slice so a dense chunk cannot monopolize the queue.
            int slice=Math.min(scans,4096);
            while(w.cursor<sections.length*4096 && slice>0 && changes>0){
                int index=w.cursor>>>12;var section=sections[index];
                if(section.m_188008_() || !section.m_63002_(state->PlantCatalog.profile(state)!=null || summer && state.m_60713_(Blocks.f_50125_))){
                    w.cursor=(index+1)*4096;scans--;slice--;continue;
                }
                int local=w.cursor++&4095;scans--;slice--;
                BlockState state=section.m_62982_(local&15,local>>>8,(local>>>4)&15);
                BlockPos pos=new BlockPos(w.chunk.m_7697_().m_45604_()+(local&15),w.chunk.m_141937_()+index*16+(local>>>8),w.chunk.m_7697_().m_45605_()+((local>>>4)&15));
                if(summer && state.m_60713_(Blocks.f_50125_) && melt(l,w,pos)){changes--;continue;}
                var profile=PlantCatalog.profile(state);if(profile==null || upper(state))continue;
                if(!profile.renewal() && w.seeds.add(PlantCatalog.id(state)))w.dirty();
                if(VegetationPolicy.RARE.contains(PlantCatalog.id(state)))rareSeen(l,w);
                if(hide(l,w,pos,state))changes--;
            }
            if(w.cursor>=sections.length*4096){
                w.cursor=0;
                w.nextScan=l.m_46467_()+(winter||summer?VegetationConfig.FAST_DELAY.get():VegetationConfig.DELAY.get());
            }
        }
        // One appearance per level at a time; persisted per-chunk delay also applies after reloads.
        if(l.m_46467_()%VegetationConfig.GROW_INTERVAL.get()!=0)return;
        for(Work w:map.values()){
            if(l.m_7726_().m_7131_(w.chunk.m_7697_().f_45578_,w.chunk.m_7697_().f_45579_)!=w.chunk)continue;
            long now=l.m_46467_();
            if(!w.tag.m_128441_("GrowthAt")){scheduleGrowth(l,w);continue;}
            if(now<w.tag.m_128454_("GrowthAt"))continue;
            scheduleGrowth(l,w);
            if(w.restore==null || w.restore.isEmpty()){
                var keys=new ArrayList<>(w.records.m_128431_());Collections.shuffle(keys);w.restore=new ArrayDeque<>(keys);
            }
            // Bounded search: out-of-season records cannot block other chunks or removal.
            int remaining=64;
            while(!w.restore.isEmpty() && remaining-->0){
                String key=w.restore.remove();
                if(w.records.m_128425_(key,10) && restore(l,w,key))return;
            }
            if(grow(l,w))return;
        }
    }
    private void scheduleGrowth(ServerLevel l,Work w){
        int delay=VegetationConfig.GROW_DELAY.get();
        w.tag.m_128356_("GrowthAt",l.m_46467_()+delay+l.m_213780_().m_188503_(delay));w.dirty();
    }
    private boolean melt(ServerLevel l,Work w,BlockPos p){
        if(!enabled(l) || w.protectedPos.contains(p.m_121878_()) || !l.m_45527_(p.m_7494_())
            || SeasonHelper.usesTropicalSeasons(l.m_204166_(p))
            // Preserve snow in naturally freezing biomes, on mountains, and in protected claims.
            || l.m_204166_(p).m_203334_().m_198904_(p) || !wilderness.allowed(l,p))return false;
        return l.m_7731_(p,Blocks.f_50016_.m_49966_(),2);
    }
    public static boolean allowNativeAttempt(ServerLevel l,int cx,int cz,boolean tree){
        if(instance==null || !enabled(l))return true;
        BlockPos p=new BlockPos(cx*16+8,64,cz*16+8);Work w=instance.work(l,p);
        if(w==null)return false;
        String key=tree?"NativeTreeAt":"NativePlantAt";long now=l.m_46467_();
        if(!w.tag.m_128441_(key)){
            w.tag.m_128356_(key,now+(tree?VegetationConfig.TREE_DELAY.get():VegetationConfig.NATIVE_DELAY.get()));w.dirty();return false;
        }
        if(now<w.tag.m_128454_(key))return false;
        int delay=tree?VegetationConfig.TREE_DELAY.get():VegetationConfig.NATIVE_DELAY.get();
        w.tag.m_128356_(key,now+delay+l.m_213780_().m_188503_(delay));w.dirty();
        if(nearPlayer(l,p,tree?VegetationConfig.TREE_DISTANCE.get()+12:24))return false;
        if(tree){
            var season=SeasonHelper.getSeasonState(l);
            if(season.getSeason().toString().equals("WINTER"))return false;
        }
        return l.m_213780_().m_188503_(tree?32:8)==0;
    }
    private static boolean nearPlayer(ServerLevel l,BlockPos pos,int radius){
        for(var player:l.m_6907_()){
            double dx=player.m_20185_()-(pos.m_123341_()+.5),dz=player.m_20189_()-(pos.m_123343_()+.5);
            if(dx*dx+dz*dz<(double)radius*radius)return true;
        }
        return false;
    }
    public static BlockState youngTree(BlockState state){
        return state.m_61138_(SaplingBlock.f_55973_)?state.m_61124_(SaplingBlock.f_55973_,0):state;
    }
    public static void rememberTree(ServerLevel l,BlockPos p){
        if(instance==null)return;Work w=instance.work(l,p);if(w==null)return;
        CompoundTag record=new CompoundTag();record.m_128359_("id",PlantCatalog.id(l.m_8055_(p)));
        record.m_128356_("ready",l.m_46467_()+VegetationConfig.TREE_AGE.get());
        w.tag.m_128469_("NaturalTrees").m_128365_(key(p),record);w.dirty();
    }
    public static boolean delayTree(ServerLevel l,BlockPos p){
        if(instance==null || !enabled(l))return false;Work w=instance.work(l,p);if(w==null)return false;
        var trees=w.tag.m_128469_("NaturalTrees");String key=key(p);
        if(!trees.m_128441_(key))return false;
        var record=trees.m_128469_(key);
        if(!record.m_128461_("id").equals(PlantCatalog.id(l.m_8055_(p)))){trees.m_128473_(key);w.dirty();return false;}
        return l.m_46467_()<record.m_128454_("ready") || nearPlayer(l,p,VegetationConfig.TREE_DISTANCE.get());
    }

    private static final class Work {
        final LevelChunk chunk;
        final CompoundTag tag;
        final CompoundTag records;
        final Set<Long> protectedPos = new HashSet<Long>();
        final Set<String> seeds = new HashSet<String>();
        ArrayDeque<String> restore;
        int cursor;
        long nextScan;
        int lastSeason=-2;

        Work(LevelChunk levelChunk, CompoundTag compoundTag) {
            this.chunk = levelChunk;
            this.tag = compoundTag;
            if(!compoundTag.m_128425_("NaturalTrees",10))compoundTag.m_128365_("NaturalTrees",new CompoundTag());
            this.records = compoundTag.m_128469_("Dormant");
            compoundTag.m_128365_("Dormant", (Tag)this.records);
            for (long l : compoundTag.m_128467_("Protected")) {
                this.protectedPos.add(l);
            }
            var object = compoundTag.m_128437_("Seeds", 8).iterator();
            while (object.hasNext()) {
                Tag tag = (Tag)object.next();
                this.seeds.add(tag.m_7916_());
            }
        }

        void dirty() {
            this.tag.m_128388_("Protected", this.protectedPos.stream().mapToLong(Long::longValue).toArray());
            ListTag listTag = new ListTag();
            this.seeds.stream().sorted().forEach(string -> listTag.add(StringTag.m_129297_((String)string)));
            this.tag.m_128365_("Seeds", (Tag)listTag);
            this.chunk.m_8092_(true);
        }
    }
}

