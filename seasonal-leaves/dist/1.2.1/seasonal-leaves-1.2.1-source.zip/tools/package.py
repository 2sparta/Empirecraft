from pathlib import Path
import zipfile,json,hashlib
base=next(Path('attachments').rglob('*.jar'))
with zipfile.ZipFile(base) as z:entries={n:z.read(n) for n in z.namelist()}
for p in Path('work/classes').rglob('*.class'):entries[str(p.relative_to('work/classes'))]=p.read_bytes()
config=json.loads(entries['empirecraft_seasonal_vegetation.mixins.json']);config['mixins']+=['SlowRenewalMixin','NaturalSaplingMixin']
entries['empirecraft_seasonal_vegetation.mixins.json']=json.dumps(config).encode()
for n in ['META-INF/mods.toml','META-INF/MANIFEST.MF']:entries[n]=entries[n].replace(b'1.2.0',b'1.2.1')
out=Path('work/deliverables');out.mkdir(parents=True,exist_ok=True)
p=out/'empirecraft-seasonal-leaves-1.2.1.jar'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
    for n,data in sorted(entries.items()):z.writestr(n,data)
Path('work/newjar').write_text(str(p))
print(p,hashlib.sha256(p.read_bytes()).hexdigest())
