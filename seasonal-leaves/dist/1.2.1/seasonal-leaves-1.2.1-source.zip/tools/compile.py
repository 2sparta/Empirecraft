from pathlib import Path
import subprocess
sources=[Path('work/source/ua/empirecraft/leaves')/n for n in ['VegetationConfig.java','SeasonalVegetation.java']]
sources+=list(Path('work/source/ua/empirecraft/leaves/mixin').glob('*.java'))
r=subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-proc:none','-cp',Path('work/classpath').read_text(),'-d','work/classes',*map(str,sources)],capture_output=True,text=True)
print(r.stdout,r.stderr);raise SystemExit(r.returncode)
