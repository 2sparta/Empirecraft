from pathlib import Path
import subprocess,os
libraries=Path('Empirecraft/server/libraries')
# Prioritize one current ASM family and the actual SRG server over vanilla jars.
asm=list(libraries.glob('org/ow2/asm/*/9.9.1/*.jar'))
cp=':'.join(map(str,[*asm,Path('work/newjar').read_text(),*libraries.glob('net/minecraft/server/*/*-srg.jar'),*libraries.glob('net/minecraftforge/forge/*/*-server.jar'),*libraries.rglob('*.jar'),*Path('Empirecraft/server/mods').glob('*.jar')]))
Path('work/testcp').write_text(cp)
cmd=['java','com.sun.tools.javac.Main','-source','17','-target','17','-proc:none','-cp',cp,'-d','work/testclasses','work/OfflineMixinService.java','work/OfflineProperties.java','work/IntegrationTest.java']
r=subprocess.run(cmd,capture_output=True,text=True);print(r.stdout,r.stderr);assert r.returncode==0
services=Path('work/testclasses/META-INF/services');services.mkdir(parents=True,exist_ok=True)
(services/'org.spongepowered.asm.service.IMixinService').write_text('guardtest.OfflineMixinService\n')
(services/'org.spongepowered.asm.service.IGlobalPropertyService').write_text('guardtest.OfflineProperties\n')
r=subprocess.run(['java','-ea','-cp','work/testclasses:'+cp,'guardtest.IntegrationTest'],capture_output=True,text=True)
Path('work/integration.log').write_text(r.stdout+r.stderr);print((r.stdout+r.stderr)[-6000:]);assert r.returncode==0
