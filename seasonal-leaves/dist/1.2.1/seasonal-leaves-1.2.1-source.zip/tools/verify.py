from pathlib import Path
import zipfile,subprocess,struct
p=Path('work/newjar').read_text()
with zipfile.ZipFile(p) as z,zipfile.ZipFile(next(Path('attachments').rglob('*.jar'))) as old:
 for n in old.namelist():
  if n.startswith('ua/empirecraft/leaves/SeasonalLeaves') or n.startswith('ua/empirecraft/leaves/SeasonCurve') or n.startswith('ua/empirecraft/leaves/PlantCatalog'):
   assert z.read(n)==old.read(n),n+' changed unexpectedly'
 for n in z.namelist():
  if n.endswith('.class'):assert struct.unpack('>H',z.read(n)[6:8])[0]==61,n
 assert z.testzip() is None
 print('JAR_PASS: original 1.2.0 crown logic preserved; all classes Java 17; archive intact')
# Original mathematical tests against the actual shipped 1.2.1 policies, not recompiled stale source.
r=subprocess.run(['java','com.sun.tools.javac.Main','-source','17','-target','17','-proc:none','-cp',p,'-d','work/testclasses','Empirecraft/seasonal-leaves/tests/SeasonCurveTest.java','Empirecraft/seasonal-leaves/tests/VegetationPolicyTest.java'],capture_output=True,text=True)
print(r.stderr);assert r.returncode==0
for cls in ['SeasonCurveTest','VegetationPolicyTest']:
 r=subprocess.run(['java','-ea','-cp','work/testclasses:'+p,cls],capture_output=True,text=True)
 print(r.stdout,r.stderr);assert r.returncode==0
