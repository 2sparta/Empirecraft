#!/usr/bin/env python3
"""Package the built mod and complete source project without game/dependency JARs."""
import argparse,hashlib,json,zipfile
from pathlib import Path
import build

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--adm-list',type=Path);args=parser.parse_args()
    root=build.ROOT;version=build.VERSION;dist=root/'dist'/version
    jar=dist/('empirecraft-seasonal-leaves-'+version+'.jar')
    with zipfile.ZipFile(jar) as archive:
        assert ('version="'+version+'"') in archive.read('META-INF/mods.toml').decode()
        assert not any(n.startswith(('net/minecraft/','net/minecraftforge/','sereneseasons/','me/jellysquid/','ua/empirecraft/leaves/test/')) for n in archive.namelist())
    digest=build.sha(jar)
    assert (jar.with_suffix('.jar.sha256')).read_text()==digest+'  '+jar.name+'\n'
    row={'id':'empirecraft_seasonal_leaves','version':version,'file':jar.name,'path':'seasonal-leaves/dist/'+version+'/'+jar.name,'sides':['client','server'],'source':'local:seasonal-leaves','size':jar.stat().st_size,'sha256':digest,'sha512':hashlib.sha512(jar.read_bytes()).hexdigest(),'replaces':'empirecraft-seasonal-leaves-1.3.0.jar'}
    (root/'release.json').write_text(json.dumps([row],indent=2)+'\n')
    install={side+'/mods/'+jar.name+suffix:(jar.with_suffix('.jar.sha256').read_bytes() if suffix else jar.read_bytes()) for side in ['client','server'] for suffix in ['', '.sha256']}
    if args.adm_list:
        install['server/config/admanticheat/idfile/admanticheat_id_list.json']=args.adm_list.read_bytes()
        # The combined checkout fixes Engagement's stale Sails 17 dependency.
        # Carry that exact native-tested companion when the supplied ADM requires it.
        companion_sha='a6419f5505027bcff4623675001ceed1947d491fd5414f4904bed040ac3ddb1f'
        adm=json.loads(args.adm_list.read_text())
        companion=next((r for r in adm['modIds'] if r['id']=='empirecraft_engagement'),None)
        if companion and companion['sha256']==companion_sha:
            companion_name='empirecraft-engagement-1.1.0.jar'
            companion_jar=build.REPO/'mods'/companion_name
            assert build.sha(companion_jar)==companion_sha
            for side in ['client','server']:
                install[side+'/mods/'+companion_name]=companion_jar.read_bytes()
                install[side+'/mods/'+companion_name+'.sha256']=(companion_sha+'  '+companion_name+'\n').encode()
    import importlib.util as packfix_importlib
    packfix_spec=packfix_importlib.spec_from_file_location('packfix_package_support',build.REPO/'pack-fixes/package_support.py')
    packfix_helper=packfix_importlib.module_from_spec(packfix_spec);packfix_spec.loader.exec_module(packfix_helper)
    packfix_helper.add_updates(install,build.REPO)
    validation=dist/'validation.json'
    if validation.exists():install['validation.json']=validation.read_bytes()
    for name in ['INSTALL-UA.md','README.md','PERFORMANCE.md','LICENSE']:install[name]=(root/name).read_bytes()
    build.jar(dist/('Empirecraft-Seasonal-Leaves-'+version+'-install.zip'),install)
    files=['README.md','INSTALL-UA.md','PERFORMANCE.md','LICENSE','.gitignore','build.gradle','settings.gradle','gradle.properties','gradlew','gradlew.bat','build.py','build-inputs.json','client-inputs.json','compat-inputs.json','smoke-runtime.json','test.py','mixin_test.py','growth_smoke.py','performance_smoke.py','install.py','package.py','release.json','libs/README.md']
    for folder in ['src','gradle','tools','tests','audit']:
        files.extend(str(p.relative_to(root)) for p in (root/folder).rglob('*') if p.is_file())
    source=dist/('empirecraft-seasonal-leaves-'+version+'-source.zip')
    entries={name:(root/name).read_bytes() for name in files}
    if validation.exists():entries['dist/'+version+'/validation.json']=validation.read_bytes()
    build.jar(source,entries,executable={'gradlew'})
    for artifact in [*dist.glob('*.zip')]:artifact.with_suffix('.zip.sha256').write_text(build.sha(artifact)+'  '+artifact.name+'\n')
    manifest={p.name:{'size':p.stat().st_size,'sha256':build.sha(p)} for p in sorted(dist.iterdir()) if p.suffix in ['.jar','.zip']}
    (dist/'artifacts.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('PACKAGE_PASS',json.dumps(manifest))
if __name__=='__main__':main()
