package ua.empirecraft.casting.test;
import java.util.*;import com.google.gson.*;
import net.minecraft.core.*;import net.minecraft.resources.ResourceLocation;import net.minecraft.server.MinecraftServer;import net.minecraft.server.level.ServerLevel;import net.minecraft.world.item.*;import net.minecraft.world.item.crafting.*;import net.minecraft.world.inventory.TransientCraftingContainer;import net.minecraft.world.SimpleContainer;import net.minecraft.world.level.block.Blocks;import net.minecraftforge.common.capabilities.ForgeCapabilities;import net.minecraftforge.items.*;import net.dries007.tfc.common.blockentities.*;import net.dries007.tfc.common.blocks.TFCBlocks;import net.dries007.tfc.common.blocks.DirectionPropertyBlock;import net.dries007.tfc.common.blocks.devices.*;import net.dries007.tfc.common.capabilities.heat.*;import net.dries007.tfc.util.Fuel;import net.dries007.tfc.common.recipes.*;import net.dries007.tfc.common.recipes.inventory.ItemStackInventory;import net.stirdrem.overgeared.recipe.ForgingRecipe;import ua.empirecraft.casting.*;import ua.empirecraft.casting.mixin.InventoryAccess;
public final class MetallurgyProbe {
 static int checks;static void check(boolean ok,String reason){checks++;if(!ok)throw new AssertionError(reason);}
 static ItemStack stack(String id){return new ItemStack(CastingProbe.item(id));}
 static Recipe<?> recipe(MinecraftServer server,String id){return server.getRecipeManager().byKey(new ResourceLocation(id)).orElseThrow(()->new AssertionError("Missing recipe "+id));}
 public static void check(MinecraftServer server,ServerLevel level)throws Exception{
  var config=net.dries007.tfc.config.TFCConfig.SERVER;check(config.blastFurnaceCapacity.get()==16,"Blast furnace per-level capacity is 16");
  var pos=new BlockPos(1900,100,1900);level.getChunkAt(pos);level.setBlockAndUpdate(pos,TFCBlocks.CRUCIBLE.get().defaultBlockState());var crucible=(CrucibleBlockEntity)level.getBlockEntity(pos);
  var top=crucible.getCapability(ForgeCapabilities.ITEM_HANDLER,Direction.UP).orElseThrow(()->new AssertionError("Crucible top input"));var side=crucible.getCapability(ForgeCapabilities.ITEM_HANDLER,Direction.NORTH).orElseThrow(()->new AssertionError("Crucible side input"));
  check(top.insertItem(0,stack("minecraft:raw_iron"),false).isEmpty(),"Top hopper accepts smelting input");check(side.insertItem(1,stack("minecraft:raw_copper"),false).isEmpty(),"Create side funnel accepts smelting input");check(top.extractItem(0,1,false).isEmpty()&&side.extractItem(1,1,false).isEmpty(),"Input ports cannot extract unprocessed ores");
  var forgePos=pos.offset(4,0,0);level.setBlockAndUpdate(forgePos,TFCBlocks.CHARCOAL_FORGE.get().defaultBlockState());var forge=(CharcoalForgeBlockEntity)level.getBlockEntity(forgePos);var inventory=((InventoryAccess)forge).casting$inventory();var coal=new ItemStack(Items.CHARCOAL,64);
  check(inventory.insertItem(0,coal,false).getCount()==48&&inventory.getStackInSlot(0).getCount()==16,"Forge fuel slot accepts exactly 16");check(inventory.getSlotLimit(5)==1,"Forge smelting input remains one item to prevent material loss");
  var consume=CharcoalForgeBlockEntity.class.getDeclaredMethod("consumeFuel");consume.setAccessible(true);check((boolean)consume.invoke(forge),"Forge lights using native fuel code");check(inventory.getStackInSlot(0).getCount()==15,"One burn consumes one charcoal, not the 16-stack");
  int duration=Fuel.get(new ItemStack(Items.CHARCOAL)).getDuration();var remainder=HeatCapability.consumeFuelForTicks(duration*2L+1,inventory,0,0,0,4);check(inventory.getStackInSlot(0).getCount()==12&&remainder.burnTicks()==duration-1,"Offline catch-up consumes three individual charcoal units");
  // Build one native chimney level with iron sheet insulation, then exercise actual capacity calculation.
  var furnacePos=pos.offset(12,0,0);level.setBlockAndUpdate(furnacePos,TFCBlocks.BLAST_FURNACE.get().defaultBlockState());var center=furnacePos.above();level.setBlockAndUpdate(center,Blocks.AIR.defaultBlockState());
  for(var d:Direction.Plane.HORIZONTAL)level.setBlockAndUpdate(center.relative(d),TFCBlocks.FIRE_BRICKS.get().defaultBlockState());
  for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++)if((Math.abs(x)==2&&z==0)||(Math.abs(z)==2&&x==0)||(Math.abs(x)==1&&Math.abs(z)==1)){
   var sheetPos=center.offset(x,0,z);var state=TFCBlocks.SHEET_PILE.get().defaultBlockState();for(var d:Direction.Plane.HORIZONTAL)state=state.setValue(DirectionPropertyBlock.getProperty(d),true);level.setBlockAndUpdate(sheetPos,state);var pile=(SheetPileBlockEntity)level.getBlockEntity(sheetPos);for(var d:Direction.Plane.HORIZONTAL)pile.addSheet(d,stack("tfc:metal/sheet/wrought_iron"));
  }
  check(BlastFurnaceBlock.getChimneyLevels(level,furnacePos)==1,"Native single-block chimney is valid");var calculate=BlastFurnaceBlockEntity.class.getDeclaredMethod("calculateCapacity");calculate.setAccessible(true);check((int)calculate.invoke(level.getBlockEntity(furnacePos))==16,"Actual blast furnace capacity is 16 for one molten block");
  checkGradualBlast(level,(BlastFurnaceBlockEntity)level.getBlockEntity(furnacePos));
  // Simulate a remote drafting client, whose server datapack reload listener is empty.
  var typeData=net.stirdrem.overgeared.datapack.BlueprintTooltypesReloadListener.DATA;
  var savedTypes=new java.util.HashMap<>(typeData);typeData.clear();
  try{net.stirdrem.overgeared.item.ToolTypeRegistry.init();for(String type:new String[]{"javelin_head","scythe_blade","pickaxe_head","axe_head","shovel_head","hoe_head","hammer_head","knife_blade","saw_blade","chisel_head"})check(net.stirdrem.overgeared.item.ToolTypeRegistry.getRegisteredTypes().stream().anyMatch(t->t.getId().equals(type)),"Part blueprint is selectable without server datapack data: "+type);}
  finally{typeData.putAll(savedTypes);net.stirdrem.overgeared.item.ToolTypeRegistry.init();}
  var data=JsonParser.parseReader(new java.io.InputStreamReader(Metallurgy.class.getResourceAsStream("/metallurgy.json"))).getAsJsonObject();
  for(var entry:data.getAsJsonObject("recipes").entrySet()){
   var actual=recipe(server,entry.getKey());var spec=entry.getValue().getAsJsonObject();if(!spec.get("type").getAsString().equals("overgeared:forging"))continue;
   check(actual instanceof ForgingRecipe,"Part/refining recipe uses real Overgeared forging");var forging=(ForgingRecipe)actual;var material=spec.getAsJsonObject("key").getAsJsonObject("I").getAsJsonObject("ingredient").get("item").getAsString();var ingredient=forging.getForgingIngredients().stream().filter(i->!i.ingredient().isEmpty()).findFirst().orElseThrow();var input=stack(material);
   check(!ingredient.test(input),"Cold metal is rejected: "+entry.getKey());check(HeatCapability.get(input)!=null,"Forge material has native TFC heat: "+material);HeatCapability.setTemperature(input,1400);check(ingredient.test(input),"Heated metal is accepted: "+entry.getKey());
   var anvilInput=new SimpleContainer(12);for(int y=0;y<forging.getHeight();y++)for(int x=0;x<forging.getWidth();x++)anvilInput.setItem(y*3+x,input.copy());
   if(forging.requiresBlueprint()){var blueprint=stack("overgeared:blueprint");blueprint.getOrCreateTag().putString("ToolType",spec.getAsJsonArray("blueprint").get(0).getAsString());blueprint.getOrCreateTag().putString("Quality","master");anvilInput.setItem(11,blueprint);}
   var selected=ForgingRecipe.findBestMatch(level,anvilInput);check(selected.isPresent()&&((Recipe<?>)selected.get()).getId().equals(actual.getId()),"The native anvil selects this exact part, not another one: "+entry.getKey());
  }
  var player=net.minecraftforge.common.util.FakePlayerFactory.get(level,new com.mojang.authlib.GameProfile(java.util.UUID.fromString("f727e586-4ba0-497e-912b-180eb66ff663"),"MetallurgyProbe"));int weapons=0,tools=0;var conflicts=new java.util.ArrayList<String>();
  for(var entry:data.getAsJsonObject("recipes").entrySet()){
   var spec=entry.getValue().getAsJsonObject();if(!spec.get("type").getAsString().equals("empirecraft_casting:quality_shaped"))continue;
   var actual=recipe(server,entry.getKey());check(actual instanceof QualityRecipe,"Assembly uses native shaped recipe subclass");var grid=new TransientCraftingContainer(player.inventoryMenu,3,3);var pattern=spec.getAsJsonArray("pattern");var key=spec.getAsJsonObject("key");var sampleRecipe=(ShapedRecipe)actual;
   for(int row=0;row<sampleRecipe.getHeight();row++)for(int col=0;col<sampleRecipe.getWidth();col++){
    var ingredient=sampleRecipe.getIngredients().get(col+row*sampleRecipe.getWidth());if(ingredient.isEmpty())continue;check(ingredient.getItems().length>0,"Assembly ingredient exists");var input=ingredient.getItems()[0].copy();HeatCapability.setTemperature(input,1400);String id=ua.empirecraft.tfc.Integration.id(input.getItem());if(id.contains("_head/")||id.contains("_blade/")||id.endsWith("_javelin_head"))input.getOrCreateTag().putString("ForgingQuality","master");grid.setItem(row*3+col,input);
   }
   var selected=server.getRecipeManager().getRecipeFor(RecipeType.CRAFTING,grid,level);if(selected.isEmpty()||!selected.get().getId().equals(actual.getId()))conflicts.add(entry.getKey()+" selected "+selected.map(r->r.getId().toString()).orElse("none"));check(((ShapedRecipe)actual).matches(grid,level),"Native crafting grid matches assembly: "+entry.getKey());var result=((ShapedRecipe)actual).assemble(grid,server.registryAccess());check(result.hasTag()&&result.getTag().getString("ForgingQuality").equals("master"),"Master quality is preserved into the final equipment: "+entry.getKey());if(entry.getKey().contains("/tfc/"))tools++;else weapons++;
  }
  check(weapons>0&&tools>0,"Both Epic Knights and TFC tool assemblies are covered");
  var blast=BlastFurnaceRecipe.get(level,stack("minecraft:raw_iron"));check(blast!=null&&blast.assembleFluidOutput(CastingProbe.fluid("cast_iron",100)).isFluidEqual(CastingProbe.fluid("pig_iron",100)),"Raw iron enters the real blast-furnace route to pig iron");
  for(String material:new String[]{"gold","silver"}){var head=stack("empirecraft_casting:"+material+"_javelin_head");var melt=HeatingRecipe.getRecipe(head);check(HeatCapability.get(head)!=null&&melt!=null&&melt.assembleFluid(new ItemStackInventory(head)).isFluidEqual(CastingProbe.fluid(material,100)),"New spearheads retain their full metal value for remelting: "+material);}
  var high=stack("tfc:metal/ingot/high_carbon_steel");var heating=HeatingRecipe.getRecipe(high);check(heating!=null&&heating.assembleFluid(new ItemStackInventory(high)).isFluidEqual(CastingProbe.fluid("pig_iron",100)),"Legacy high-carbon steel recovers pig iron for flux refining");
  check(server.getRecipeManager().byKey(new ResourceLocation("empirecraft_tfc:refining/metal/ingot/high_carbon_steel")).isEmpty(),"Early heating-to-steel no longer masks the high-carbon liquid route");
  check(server.getRecipeManager().getRecipes().stream().noneMatch(r->r.getId().toString().equals("overgeared:crude_steel_from_alloying")),"Ordinary Overgeared iron/coal steel bypass is removed");
  for(var r:server.getRecipeManager().getRecipes()){String result=ua.empirecraft.tfc.Integration.id(r.getResultItem(server.registryAccess()).getItem());check(!Metallurgy.retired(result),"Removed metals have no remaining acquisition recipe: "+r.getId());}
  check(server.getRecipeManager().byKey(new ResourceLocation("empirecraft_casting:refining/high_carbon_steel")).isEmpty()&&server.getRecipeManager().byKey(new ResourceLocation("empirecraft_casting:refining/steel")).isEmpty(),"High-carbon steel forging stages are removed");recipe(server,"empirecraft_casting:refining/black_steel");recipe(server,"tfc:alloy/weak_steel");
  var weak=CastingProbe.pair();CastingProbe.mold(weak);CastingProbe.fill(weak,"steel",600);CastingProbe.fill(weak,"nickel",200);CastingProbe.fill(weak,"bronze",200);CastingProbe.heat(weak);check(weak.metal().drain(100,net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.SIMULATE).isFluidEqual(CastingProbe.fluid("weak_steel",100)),"Actual 60/20/20 alloy yields weak steel without black bronze");CastingProbe.run(weak,CastingBlockEntity.CYCLE_TICKS);check(CastingProbe.out(weak).is(CastingProbe.item("tfc:metal/ingot/weak_steel")),"Weak steel is obtainable as a cast intermediate");
  var black=CastingProbe.pair();CastingProbe.mold(black);CastingProbe.fill(black,"weak_steel",100);CastingProbe.fill(black,"pig_iron",100);CastingProbe.heat(black);check(black.metal().drain(100,net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.SIMULATE).isFluidEqual(CastingProbe.fluid("high_carbon_black_steel",100)),"Actual 50/50 alloy yields high-carbon black steel");CastingProbe.run(black,CastingBlockEntity.CYCLE_TICKS);check(CastingProbe.out(black).is(CastingProbe.item("tfc:metal/ingot/high_carbon_black_steel")),"High-carbon black steel can be cast for final refining");
  checkToolCosts(server,level,player);
  check(conflicts.isEmpty(),"Crafting manager selects every exact quality-preserving assembly: "+conflicts);
  System.out.println("CASTING_NATIVE_METALLURGY_PASS checks="+checks+" weapons="+weapons+" tools="+tools+" forge_stack=16 blast_level=16 hopper=passed quality=passed high_carbon=passed");
 }
 static java.lang.reflect.Field blastField(String name)throws Exception{var f=BlastFurnaceBlockEntity.class.getDeclaredField(name);f.setAccessible(true);return f;}
 @SuppressWarnings("unchecked") static java.util.List<ItemStack> blastItems(BlastFurnaceBlockEntity furnace,String name)throws Exception{return (java.util.List<ItemStack>)blastField(name).get(furnace);}
 static void blastTicks(ServerLevel level,BlastFurnaceBlockEntity furnace,int count,float temperature)throws Exception{
  var state=furnace.getBlockState().setValue(BlastFurnaceBlock.LIT,true);level.setBlockAndUpdate(furnace.getBlockPos(),state);
  for(int i=0;i<count;i++){blastField("temperature").setFloat(furnace,temperature);blastField("burnTemperature").setFloat(furnace,temperature);blastField("burnTicks").setInt(furnace,100000);BlastFurnaceBlockEntity.serverTick(level,furnace.getBlockPos(),state,furnace);}
 }
 static void chargeBlast(BlastFurnaceBlockEntity furnace,int count)throws Exception{for(int i=0;i<count;i++){var ore=stack("minecraft:raw_iron");HeatCapability.setTemperature(ore,1700);blastItems(furnace,"inputStacks").add(ore);blastItems(furnace,"catalystStacks").add(stack("tfc:powder/flux"));}}
 static void checkGradualBlast(ServerLevel level,BlastFurnaceBlockEntity furnace)throws Exception{
  chargeBlast(furnace,3);blastTicks(level,furnace,20,1700);check(furnace.getInputCount()==3&&furnace.getCatalystCount()==3,"A hot blast furnace does not consume its batch immediately");
  var tag=furnace.saveWithFullMetadata();check(tag.getInt("empirecraftSmeltProgress")==20,"Blast processing saves earned progress");
  var restored=(BlastFurnaceBlockEntity)net.minecraft.world.level.block.entity.BlockEntity.loadStatic(furnace.getBlockPos(),furnace.getBlockState(),tag);furnace.setRemoved();level.setBlockEntity(restored);furnace=restored;
  blastTicks(level,furnace,19,1700);check(furnace.getInputCount()==3,"Reloaded progress does not finish the charge early");
  blastTicks(level,furnace,1,1700);var tank=(net.minecraftforge.fluids.capability.templates.FluidTank)blastField("outputFluidTank").get(furnace);
  check(furnace.getInputCount()==2&&furnace.getCatalystCount()==2&&tank.getFluidAmount()==100,"Exactly one ore and one flux produce 100 units at 40 ticks");
  blastTicks(level,furnace,40,1700);check(furnace.getInputCount()==1&&furnace.getCatalystCount()==1&&tank.getFluidAmount()==200,"The second charge has its own 40-tick cycle");
  blastTicks(level,furnace,40,1700);check(furnace.getInputCount()==0&&furnace.getCatalystCount()==0&&tank.getFluidAmount()==300,"All charges retain their native total yield");
  check(tank.getFluid().isFluidEqual(CastingProbe.fluid("pig_iron",300)),"Blast-furnace output remains pig iron");
  tank.setFluid(CastingProbe.fluid("pig_iron",tank.getCapacity()));chargeBlast(furnace,2);blastTicks(level,furnace,100,1700);
  check(furnace.getInputCount()==2&&furnace.getCatalystCount()==2&&tank.getFluidAmount()==tank.getCapacity(),"A full output tank pauses ore and flux consumption");
  tank.drain(100,net.minecraftforge.fluids.capability.IFluidHandler.FluidAction.EXECUTE);blastTicks(level,furnace,40,1700);
  check(furnace.getInputCount()==1&&furnace.getCatalystCount()==1&&tank.getFluidAmount()==tank.getCapacity(),"Processing resumes for one charge when output space opens");
  tank.setFluid(net.minecraftforge.fluids.FluidStack.EMPTY);for(var ore:blastItems(furnace,"inputStacks"))HeatCapability.setTemperature(ore,0);blastTicks(level,furnace,40,1000);
  check(furnace.getInputCount()==1&&furnace.getCatalystCount()==1&&tank.isEmpty(),"Cold ore cannot advance blast processing");
  for(var ore:blastItems(furnace,"inputStacks"))HeatCapability.setTemperature(ore,1700);blastTicks(level,furnace,20,1700);
  for(var ore:blastItems(furnace,"inputStacks"))HeatCapability.setTemperature(ore,0);blastTicks(level,furnace,20,1000);
  check(furnace.saveWithFullMetadata().getInt("empirecraftSmeltProgress")==20,"Cooling pauses earned progress");
  for(var ore:blastItems(furnace,"inputStacks"))HeatCapability.setTemperature(ore,1700);blastTicks(level,furnace,20,1700);
  check(furnace.getInputCount()==0&&tank.getFluidAmount()==100,"Reheating resumes the unfinished charge without duplication");
  tank.setFluid(net.minecraftforge.fluids.FluidStack.EMPTY);chargeBlast(furnace,16);blastTicks(level,furnace,40,1700);
  check(furnace.getInputCount()==15&&furnace.getCatalystCount()==15&&tank.getFluidAmount()==100,"The full 16-charge capacity is retained and only one charge finishes per cycle");
  System.out.println("CASTING_NATIVE_BLAST_PROGRESS_PASS cycle_ticks=40 single_charge=passed reload=passed cold_pause=passed blocked_output=passed capacity=16");
 }

 static void checkToolCosts(MinecraftServer server,ServerLevel level,net.minecraft.server.level.ServerPlayer player)throws Exception{
  var matrix=JsonParser.parseReader(new java.io.InputStreamReader(Metallurgy.class.getResourceAsStream("/META-INF/tool-costs.json"))).getAsJsonArray();
  for(var value:matrix){var row=value.getAsJsonObject();String metal=row.get("metal").getAsString(),tool=row.get("tool").getAsString(),item=row.get("item").getAsString();int units=row.get("metal_units").getAsInt();
   var assembly=recipe(server,"empirecraft_casting:assembly/tfc/"+metal+"/"+tool);int supplied=0;
   for(var ingredient:assembly.getIngredients())if(!ingredient.isEmpty()){var input=ingredient.getItems()[0].copy();var melt=HeatingRecipe.getRecipe(input);if(melt!=null)supplied+=melt.assembleFluid(new ItemStackInventory(input)).getAmount();}
   check(supplied==units,"Finished tool consumes its full metal budget: "+item+" supplied="+supplied+" expected="+units);
   var melt=HeatingRecipe.getRecipe(stack(item));check(melt!=null&&melt.assembleFluid(new ItemStackInventory(stack(item))).getAmount()==units,"Finished tool recycling matches its metal budget: "+item);
  }
  for(String metal:new String[]{"steel","wrought_iron"})for(String tool:new String[]{"pickaxe","axe","shovel","hoe"}){
   String id="tfc:metal/"+tool+"/"+metal;check(FoodPolicy.removed(id),"Duplicate tool is retired: "+id);
   check(server.getRecipeManager().getRecipes().stream().noneMatch(r->ua.empirecraft.tfc.Integration.id(r.getResultItem(server.registryAccess()).getItem()).equals(id)),"Duplicate tool has no acquisition recipe: "+id);
  }
  check(FoodPolicy.removed("tfc:metal/hammer/steel")&&!FoodPolicy.removed("tfc:metal/saw/steel")&&!FoodPolicy.removed("tfc:metal/chisel/wrought_iron"),"Only duplicates retire; unique metal tools stay available");
  check(!FoodPolicy.removed("tfc:metal/javelin/steel")&&!FoodPolicy.removed("tfc:metal/javelin/wrought_iron"),"TFC throwing spears are retained");
  for(String metal:new String[]{"bronze","steel","wrought_iron"}){
   var grid=new TransientCraftingContainer(player.inventoryMenu,3,3);grid.setItem(0,stack("tfc:metal/axe_head/"+metal));grid.setItem(3,new ItemStack(Items.STICK));
   var result=server.getRecipeManager().getRecipeFor(RecipeType.CRAFTING,grid,level);check(result.isEmpty(),"A one-ingot head and stick no longer bypass the three-ingot axe cost: "+metal);
  }
  for(String tool:new String[]{"pickaxe","axe","shovel","hoe"}){
   check(server.getRecipeManager().getRecipes().stream().anyMatch(r->ua.empirecraft.tfc.Integration.id(r.getResultItem(server.registryAccess()).getItem()).equals("minecraft:iron_"+tool)),"Canonical vanilla iron tool is craftable: "+tool);
   check(server.getRecipeManager().getRecipes().stream().anyMatch(r->ua.empirecraft.tfc.Integration.id(r.getResultItem(server.registryAccess()).getItem()).equals("overgeared:steel_"+tool)),"Canonical Overgeared steel tool is craftable: "+tool);
  }
  System.out.println("CASTING_NATIVE_TOOL_COSTS_PASS tools="+matrix.size()+" duplicates=removed javelins=retained casting_bypass=removed recycling=matched");
 }

}
